
// Run this script with node after setting GOOGLE_APPLICATION_CREDENTIALS env variable or run in client by deploying.
// This script uses firebase-admin (requires service account) - kept as optional helper.
const admin = require('firebase-admin');
const serviceAccount = require('./service-account.json'); // replace with actual file
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
const db = admin.firestore();

async function seed() {
  const devs = [
    { email: 'sohamsingle775@gmail.com', name: 'Soham', role: 'developer' },
    { email: 'jerry415721@gmail.com', name: 'Hrishikesh', role: 'developer' }
  ];
  for(const d of devs){
    // create a user doc keyed by email-based id (or you can set by uid later)
    const id = 'dev_' + d.email.replace(/[^a-z0-9]/gi,'_');
    await db.doc('users/' + id).set({ id, name: d.name, email: d.email, role: d.role, joinedDate: new Date().toISOString() }, { merge: true });
    console.log('Seeded', d.email);
  }
}
seed().catch(console.error);
