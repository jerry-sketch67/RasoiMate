
  # Rasoi Mate Website Design

  This is a code bundle for Rasoi Mate Website Design. The original project is available at https://www.figma.com/design/D8ITF5mlEmhlPeNz0HwPNv/Rasoi-Mate-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  