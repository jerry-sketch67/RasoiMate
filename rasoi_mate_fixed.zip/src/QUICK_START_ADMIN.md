# ⚡ Quick Start - Admin Panel

## 🎯 Get Started in 3 Steps

### Step 1: Login as Developer
```
Email: sohamsingale775@gmail.com OR jerry415721@gmail.com
Password: [Your chosen password during signup]
```

### Step 2: Access Admin Panel
- Look for the **"🛡️ Admin Panel"** button in the header (top-right)
- Click it to enter the full admin dashboard

### Step 3: Start Managing
- Use the **sidebar menu** to navigate between sections
- All changes are **saved automatically**
- Data **updates in real-time** every 5 seconds

---

## 🔥 Common Tasks

### Add a Recipe
1. Go to **Recipe Manager**
2. Click **"Add New Recipe"**
3. Fill in:
   - Name (required)
   - Cooking Time (required)
   - Other details (optional)
4. Click **"Save Recipe"**

### View All Users
1. Go to **User Management**
2. Scroll through the list
3. Click 👁️ to view user details

### Toggle a Feature
1. Go to **Feature Toggles**
2. Click the switch next to any feature
3. Feature enables/disables instantly

### Check System Health
1. Go to **System Status**
2. View real-time metrics
3. Monitor CPU, Memory, Network
4. Check API health status

---

## 💡 Pro Tips

1. **Use Search** - In Recipe Manager, use the search bar
2. **Filter Smart** - Filter by region or status to find recipes fast
3. **Archive vs Delete** - Archive recipes to hide them (can revive later)
4. **Monitor Logs** - Check System Logs daily for issues
5. **Watch Performance** - System Status shows real-time health

---

## 🆘 Troubleshooting

**Q: Can't see Admin Panel button?**  
A: Make sure you're logged in with an authorized email

**Q: Changes not saving?**  
A: Check browser console for errors, try refreshing

**Q: Data not updating?**  
A: Wait 5 seconds for auto-refresh, or refresh page manually

---

## 📱 Where to Find Everything

| Feature | Location |
|---------|----------|
| Add Recipe | Recipe Manager → Add New Recipe |
| View Users | User Management |
| API Keys | API Key Management |
| Feature Toggles | Feature Toggles |
| System Health | System Status |
| Logs | System Logs |
| Settings | Site Settings |

---

## 🎓 Full Documentation

For complete details, see:
- **ADMIN_PANEL_GUIDE.md** - Full admin panel documentation
- **ADMIN_SYSTEM_COMPLETE.md** - Technical implementation details

---

**Ready? Login and start managing! 🚀**
