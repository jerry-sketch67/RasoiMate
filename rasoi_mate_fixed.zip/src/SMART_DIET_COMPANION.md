# Smart Diet Companion Feature

## Overview
The Smart Diet Companion is a comprehensive personalized Indian meal and nutrition planning system that automatically adjusts diet suggestions based on each user's workouts, lifestyle, and daily routine.

## Location
- **Main Component**: `/components/SmartDietCompanionPage.tsx`
- **Route**: `smart-diet`
- **Navigation**: Accessible via Header navigation menu and featured prominently on the Home page

## Features

### 1. User Profile Card
- Circular profile picture with user information
- Display: Name, Age, Weight, Goal (Weight Loss/Gain/Maintenance), Activity Level
- Editable profile with edit icon
- Integrated with AuthContext for user data

### 2. Routine & Workout Section
- **Today's Activity Tracker**
  - Multiple workout type selections (Yoga, Gym, Running, Cycling, Meditation)
  - Visual workout icons with color-coding matching Rasoi Mate palette
  - Duration slider (10-120 minutes) with calorie burn estimate
  - "Add Workout" button to log activities
  - Toggle for "Auto Sync with Fitness App" (future integration)
  
- **Completed Activities List**
  - Real-time display of logged workouts
  - Shows duration and calories burned for each activity
  - Clean card-based layout with icons

- **Daily Routine Timeline**
  - Visual timeline showing daily schedule (Wake Up, Breakfast, Lunch, Snack, Dinner, Sleep)
  - Color-coded timeline points matching Rasoi Mate brand colors
  - Helps users visualize their meal timing

### 3. Personalized Diet Plan Section
- **Four Meal Cards** (Breakfast, Lunch, Snacks, Dinner)
  - Each card is collapsible/expandable
  - Displays:
    - High-quality meal image from Unsplash
    - Recipe name
    - Scheduled time
    - Calorie count
    - Macros breakdown (Protein, Carbs, Fats)
    - Customization tags (e.g., "High Protein", "Post-Workout")
  
- **Expanded View** includes:
  - Detailed macros breakdown with progress bars
  - "View Recipe" button for full recipe details
  - Heart icon for favoriting
  - Personalization message explaining why this meal was chosen

### 4. AI Suggestion Box
- Chat-style floating card with AI-generated suggestions
- Examples:
  - "You burned 320 calories today! Try Paneer Bhurji for recovery."
  - "Since you skipped workout, here's a lighter dinner option."
- Voice/text input field with microphone icon
- Positioned in right column for easy access

### 5. Analytics Section
- **Rasoi Score**: Daily health score out of 100 with progress bar
- **Calorie Tracking**:
  - Beautiful circular progress chart (donut chart)
  - Shows consumed vs. goal calories
  - Displays net calories (consumed - burned)
  - Grid showing goal and burned calories separately
- "Generate New Plan" button to refresh recommendations

### 6. Quick Stats Card
- Weekly summary showing:
  - Workouts completed
  - Meals on track
  - Average daily score
- Color-coded badges for visual appeal

## Design Features

### Colors & Styling
- Utilizes Rasoi Mate's signature color palette:
  - Saffron (#FF9933) - Primary actions, highlights
  - Green (#4CAF50) - Success states, health indicators
  - Tech Blue (#3F51B5) - Information, analytics
- Rounded corners (rounded-3xl, rounded-2xl)
- Soft shadows and hover effects (hover-lift)
- Smooth transitions and animations using Motion

### Background
- Gradient background: `from-orange-50 via-white to-green-50`
- Maintains wavy pattern from global styles
- Matches overall Rasoi Mate aesthetic

### Responsive Design
- Grid layout adjusts for mobile, tablet, and desktop
- Mobile-first approach
- Collapsible sections for better mobile UX

## Integration

### Authentication
- Integrates with `AuthContext` for user profile data
- Falls back to "Guest User" if not logged in
- Displays user avatar and name from auth context

### Navigation
- Added to Header navigation menu with translations in 8 languages
- Featured prominently on Home page with dedicated section
- Direct navigation from "Explore Smart Diet" button

### State Management
- Local state for workout activities, meal plans, and analytics
- Real-time updates when workouts are added
- Dynamic calorie calculations

## User Interactions

### Micro-interactions
- Hover effects on workout selection buttons
- Scale animations on buttons (whileHover, whileTap)
- Smooth expand/collapse for meal cards
- Progress bar animations

### Toast Notifications
- Success messages when workouts are added
- Confirmation when new diet plan is generated
- Uses Sonner toast library

## Future Enhancements
1. **Fitness App Integration**: Connect with Google Fit, Apple Health, Fitbit
2. **Recipe Linking**: Direct integration with RecipesPage for "View Recipe" button
3. **Meal Logging**: Allow users to mark meals as completed
4. **Historical Data**: Show trends over weeks/months
5. **Nutritionist Chat**: Real-time AI nutritionist for dietary advice
6. **Shopping List**: Generate grocery lists based on meal plans
7. **Meal Prep Calendar**: Weekly meal planning view

## Technical Details

### Dependencies
- Motion (framer-motion) for animations
- Lucide React for icons
- Shadcn/ui components (Card, Button, Badge, Avatar, Slider, Progress, Switch)
- Sonner for toast notifications
- ImageWithFallback for images

### Performance
- Uses AnimatePresence for smooth mount/unmount animations
- Lazy loading for images
- Optimized re-renders with proper state management

## Usage
Navigate to the Smart Diet Companion page by:
1. Clicking "Smart Diet" in the header navigation
2. Clicking "Explore Smart Diet" button on the Home page
3. Direct URL navigation to `/smart-diet` route

## Accessibility
- Proper ARIA labels (to be added)
- Keyboard navigation support
- Focus states matching global design system
- Color contrast ratios meet WCAG standards
