# Rasoi Mate Feedback System

## Overview

The Rasoi Mate feedback system allows users to send feedback directly to the development team via email. The system is integrated into the Contact page and Developer Dashboard.

## Features

### 1. Contact Form (ContactPage.tsx)
- **Multi-category Support**: Users can select from various categories:
  - General Inquiry
  - Bug Report
  - Feature Request
  - Recipe Submission
  - Partnership Opportunity
  - General Feedback

- **Smart Email Routing**:
  - Most categories → sohamsingale775@gmail.com
  - Recipe submissions → jerry415721@gmail.com

- **Dual Sending Methods**:
  - **Primary**: EmailJS integration (direct email sending)
  - **Fallback**: Mailto links (opens email client)

### 2. Developer Dashboard Feedback Tab
- **View All Submissions**: See all feedback in one place
- **Category Statistics**: Quick overview of feedback by category
- **Detailed View**: Read full feedback with timestamps
- **Reply Directly**: Quick reply button that opens email client
- **Delete/Resolve**: Mark feedback as resolved
- **Export**: Download all feedback as JSON for analysis

## Email Setup Options

### Option 1: EmailJS (Recommended)
**Pros:**
- Seamless user experience
- No email client required
- Professional appearance
- Tracking and analytics

**Setup Required:**
1. Create EmailJS account
2. Configure Gmail service
3. Create email template
4. Update credentials in ContactPage.tsx

See `EMAIL_SETUP_GUIDE.md` for detailed instructions.

### Option 2: Mailto Links (Current Fallback)
**Pros:**
- No setup required
- Works immediately
- No third-party dependencies

**Cons:**
- Requires configured email client
- Less user-friendly
- No tracking

## Current Status

✅ **Working Now**: Mailto fallback (opens user's email client)
⏳ **Pending**: EmailJS setup for direct sending

## Email Template Variables

When setting up EmailJS, use these template variables:
- `{{from_name}}` - Sender's name
- `{{from_email}}` - Sender's email
- `{{to_email}}` - Recipient email (dynamic)
- `{{category}}` - Feedback category
- `{{category_label}}` - Formatted category
- `{{subject}}` - Email subject
- `{{message}}` - Message body

## Data Storage

All feedback is automatically stored in `localStorage` with:
- Unique ID (timestamp)
- Sender information (name, email)
- Category and subject
- Message content
- Timestamp
- Recipient email
- Status

This allows developers to:
- Review all feedback even if email fails
- Track feedback history
- Export for analysis
- Maintain records

## Access Control

- **All Users**: Can submit feedback via Contact page
- **Developers Only**: Can view feedback tab in dashboard
  - sohamsingale775@gmail.com
  - jerry415721@gmail.com

## Usage Statistics

The Developer Dashboard shows:
- Total feedback count
- Feedback by category
- Recent submissions
- Response metrics

## Best Practices

1. **Review Regularly**: Check the Feedback tab daily
2. **Respond Promptly**: Use the reply button to respond within 24-48 hours
3. **Export Periodically**: Download feedback monthly for records
4. **Delete Resolved**: Keep dashboard clean by deleting resolved items
5. **Categorize Properly**: Ensure users select correct categories

## Future Enhancements

- [ ] Email notifications for new feedback
- [ ] Priority flagging system
- [ ] Integration with project management tools
- [ ] Automated responses for common queries
- [ ] Feedback analytics dashboard
- [ ] Sentiment analysis

## Troubleshooting

**No emails arriving?**
- Check spam folder
- Verify EmailJS configuration
- Check browser console for errors
- Ensure email addresses are correct

**Feedback not showing in dashboard?**
- Check localStorage (browser dev tools)
- Ensure you're logged in as developer
- Refresh the page

**Reply button not working?**
- Check default email client is configured
- Verify mailto: links are enabled in browser

---

**Last Updated**: October 13, 2025  
**Maintained by**: Soham Singale (sohamsingale775@gmail.com)
