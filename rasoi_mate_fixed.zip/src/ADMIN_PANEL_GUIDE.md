# 🛡️ RasoiMate Admin Panel - Complete Guide

## Overview
The RasoiMate Admin Panel is a comprehensive, real-time system management dashboard designed exclusively for authorized developers. It provides full control over recipes, users, system settings, API configurations, and platform features.

---

## 🔐 Access & Authentication

### Developer Access
Only users with authorized email addresses can access the admin panel:
- **Authorized Emails:**
  - `sohamsingale775@gmail.com`
  - `jerry415721@gmail.com`

### Accessing the Panel
1. **Sign up/Login** with an authorized email
2. Click the **"🛡️ Admin Panel"** button in the header (visible only to developers)
3. You'll be redirected to the full-featured admin dashboard

---

## 📊 Dashboard Sections

### 1. **Dashboard Overview**
Real-time system metrics and analytics:

**Key Metrics:**
- **Total Users** - All registered users on the platform
- **Active Users** - Users active in the last hour
- **Active Recipes** - Published and available recipes
- **Total Views** - Combined recipe view count

**Features:**
- Live data updates every 5 seconds
- Recent system activity feed
- Color-coded status indicators
- Quick navigation to all sections

---

### 2. **Recipe Manager** 🍳
Complete CRUD control over all recipes in the system.

**Features:**
- ✅ **Add New Recipes** - Create recipes with full details
- ✏️ **Edit Recipes** - Modify any recipe attribute
- 🗄️ **Archive Recipes** - Hide recipes without deleting
- ♻️ **Revive Recipes** - Restore archived recipes
- 🗑️ **Delete Recipes** - Permanently remove recipes

**Search & Filter:**
- Search by recipe name
- Filter by status (Active, Archived, Draft)
- Filter by region (North, South, East, West Indian)

**Recipe Details Include:**
- Name, description, cooking time
- Difficulty level (Easy, Medium, Hard)
- Region & dietary type
- Ingredients with quantities
- Step-by-step instructions
- Images
- Metadata (created by, dates, status)

**Adding a New Recipe:**
1. Click "Add New Recipe"
2. Fill in required fields:
   - Recipe Name *
   - Cooking Time *
3. Optional fields:
   - Description
   - Difficulty, Region, Diet Type
   - Ingredients (format: "2 cups rice")
   - Steps (one per line)
   - Image URL
4. Click "Save Recipe"

---

### 3. **User Management** 👥
View and manage all registered users.

**User Information:**
- Full name and email
- Join date and last active timestamp
- Recipes cooked count
- Developer status badge
- User avatar (auto-generated from initials)

**Actions:**
- 👁️ View detailed user profile
- ✏️ Edit user permissions
- View user activity logs

**Real-Time Data:**
- All changes sync automatically
- Live activity tracking
- User statistics update in real-time

---

### 4. **API Key Management** 🔑
Configure and manage AI provider API keys.

**Supported Providers:**
- OpenAI API
- Anthropic (Claude) API
- Google AI API

**Features:**
- View all configured API keys
- Copy API keys to clipboard
- Edit API configurations
- Monitor API status (Active/Inactive)
- Track last usage timestamps

**Security:**
- Keys are masked by default
- Secure storage in localStorage
- Developer-only access

---

### 5. **Feature Toggles** ⚡
Enable or disable platform features dynamically.

**Available Features:**

**Core Features:**
- AI Assistant
- Voice Commands
- Ingredient Alternatives
- Multi-Language Support

**Social Features:**
- Recipe Sharing
- User Contributions

**UI Features:**
- Dark Mode

**Communication:**
- Email Notifications

**How to Use:**
1. Navigate to Feature Toggles
2. Toggle the switch for any feature
3. Changes apply immediately across the platform
4. Features are stored persistently

---

### 6. **Site Settings** ⚙️
Configure global platform settings.

**Brand Settings:**
- Site Name: Rasoi Mate
- Tagline: Your AI-Powered Kitchen Companion

**Color Scheme:**
- Primary Color (Saffron): #FF9933
- Secondary Color (Green): #4CAF50
- Accent Color (Blue): #3F51B5

**Platform Controls:**
- **Maintenance Mode** - Temporarily disable the site
- **Open Registration** - Allow/block new signups
- **Email Notifications** - Enable/disable email system
- **Max Recipes Per User** - Set user recipe limit

---

### 7. **System Logs** 📝
Monitor system activity and errors in real-time.

**Log Types:**
- ℹ️ **Info** - General system information
- ✅ **Success** - Successful operations
- ⚠️ **Warning** - Potential issues
- ❌ **Error** - System errors

**Features:**
- Real-time log streaming
- Color-coded severity levels
- Timestamp for each entry
- Export logs functionality
- Searchable log history

---

### 8. **Analytics** 📈
Advanced analytics and insights (uses Dashboard data).

**Metrics Tracked:**
- User growth trends
- Recipe popularity
- Engagement rates
- Platform usage patterns

---

### 9. **System Status** 🖥️
Real-time system health monitoring.

**Performance Metrics:**
- **CPU Usage** - Current processor load
- **Memory Usage** - RAM consumption
- **Disk Usage** - Storage utilization
- **Network Stats** - Active connections, response times

**API Health:**
- OpenAI API status
- Anthropic API status
- Google AI API status

**Core Services:**
- Database connection
- Authentication service
- Storage service
- Email service

**Features:**
- Live performance graphs
- Uptime monitoring
- Response time tracking
- Error rate analysis
- 24-hour performance trends

---

## 🎨 UI/UX Features

### Design Elements:
- **Professional Dark Theme** - Purple-to-blue gradient sidebar
- **Live Status Indicators** - Pulsing green dots for real-time updates
- **Smooth Animations** - Motion transitions between sections
- **Responsive Design** - Optimized for desktop and tablet
- **Micro-interactions** - Hover effects, button animations

### Navigation:
- **Sidebar Menu** - Quick access to all sections
- **Breadcrumb Trail** - Know your current location
- **Section Highlighting** - Active section clearly marked
- **Keyboard Shortcuts** - (Coming soon)

---

## 🔄 Real-Time Features

### Auto-Refresh (Every 5 seconds):
- User statistics
- Active user count
- System metrics
- Activity feeds
- Performance graphs

### Live Updates:
- User activity logs
- Recipe interactions
- System health status
- API status monitoring

---

## 🔒 Security Features

### Access Control:
- Email-based authorization
- Developer role verification
- Protected routes
- Session management

### Data Security:
- Secure localStorage usage
- Password masking for API keys
- Role-based permissions
- Audit logging

---

## 💡 Best Practices

### Recipe Management:
1. Always fill required fields when adding recipes
2. Use high-quality images (Unsplash URLs recommended)
3. Archive recipes instead of deleting when possible
4. Keep descriptions concise and clear
5. Format ingredients consistently

### User Management:
1. Review user activity regularly
2. Monitor for suspicious accounts
3. Respect user privacy
4. Track engagement metrics

### System Maintenance:
1. Monitor system logs daily
2. Check API health status
3. Review performance metrics
4. Keep feature toggles updated
5. Maintain uptime targets

---

## 🚀 Quick Actions

### Common Tasks:

**Add a Recipe:**
Dashboard → Recipe Manager → Add New Recipe

**View User Activity:**
Dashboard → User Management → Select User

**Toggle a Feature:**
Dashboard → Feature Toggles → Toggle Switch

**Check System Health:**
Dashboard → System Status

**View Logs:**
Dashboard → System Logs

---

## 📱 Mobile Access
Currently optimized for desktop/tablet. Mobile view coming soon.

---

## 🆘 Troubleshooting

### Issue: Can't access Admin Panel
- ✓ Verify you're using an authorized email
- ✓ Make sure you're logged in
- ✓ Check if "Admin Panel" button is visible in header

### Issue: Data not updating
- ✓ Refresh the page
- ✓ Check localStorage quota
- ✓ Clear browser cache

### Issue: Recipe changes not saving
- ✓ Fill all required fields
- ✓ Check console for errors
- ✓ Verify localStorage permissions

---

## 🔮 Future Enhancements

### Planned Features:
- [ ] Two-Factor Authentication (2FA)
- [ ] Advanced analytics dashboard
- [ ] Bulk recipe operations
- [ ] Email templates editor
- [ ] User role management
- [ ] Database backup/restore
- [ ] API usage analytics
- [ ] Custom theme builder
- [ ] Export/Import recipes (CSV, JSON)
- [ ] Mobile app version

---

## 📞 Support

For admin panel support:
- Check this guide first
- Review console logs
- Contact: sohamsingale775@gmail.com

---

## 🎯 Tips & Tricks

1. **Use Filters** - Quickly find recipes by region or status
2. **Bulk Actions** - (Coming soon) Select multiple items
3. **Keyboard Shortcuts** - Navigate faster
4. **Export Data** - Download logs and analytics
5. **Monitor Performance** - Check system status regularly

---

## 📊 Metrics Glossary

- **Active Users** - Users logged in within the last hour
- **Total Views** - Combined count of all recipe views
- **Uptime** - Percentage of time system is operational
- **Response Time** - Average API response latency
- **Streak Days** - Consecutive days user has been active

---

## ✅ System Requirements

**Browser Support:**
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+

**Minimum Screen:**
- 1280x720 (Desktop)
- 768x1024 (Tablet)

**Storage:**
- 10MB free localStorage

---

**Last Updated:** October 31, 2025
**Version:** 1.0.0
**Status:** Production Ready ✅
