// Firestore helpers for listening to live settings, feature flags and recipes.
// These are convenience wrappers — import and use in your pages/admin components.
import { db } from './firebase';
import { doc, serverTimestamp } from 'firebase/firestore';
import {
  doc, collection, onSnapshot, getDoc, setDoc, updateDoc, where, query, orderBy, limit, getDocs
} from 'firebase/firestore';

export function listenSiteSettings(callback) {
  const docRef = doc(db, 'site_settings', 'global');
  return onSnapshot(docRef, (snap) => {
    if (snap.exists()) callback(snap.data());
    else callback(null);
  });
}

export function listenFeatureFlags(callback) {
  const colRef = collection(db, 'feature_toggles');
  return onSnapshot(colRef, (snap) => {
    const flags = {};
    snap.forEach(d => flags[d.id] = d.data().enabled);
    callback(flags);
  });
}

export function listenRecipes(callback, limitCount=100) {
  const colRef = collection(db, 'recipes');
  const q = query(colRef, orderBy('createdAt','desc'), limit(limitCount));
  return onSnapshot(q, (snap) => {
    const items = [];
    snap.forEach(d => items.push({ id: d.id, ...d.data() }));
    callback(items);
  });
}

export async function fetchUserSavedRecipes(uid) {
  const docRef = doc(db, 'users', uid);
  const snap = await getDoc(docRef);
  if (!snap.exists()) return [];
  const data = snap.data();
  return data.savedRecipes || [];
}

export async function updateSiteSettings(newSettings) {
  const docRef = doc(db, 'site_settings', 'global');
  await setDoc(docRef, newSettings, { merge: true });
}

export async function setFeatureFlag(id, enabled, meta={}) {
  const docRef = doc(db, 'feature_toggles', id);
  await setDoc(docRef, { enabled, ...meta }, { merge: true });
}

export async function createOrUpdateUserProfile(uid, profile) {
  const docRef = doc(db, 'users', uid);
  await setDoc(docRef, profile, { merge: true });
}

// simple seeding helper for dev/testing
export async function seedInitialData({ siteSettings, featureFlags, recipes=[] } = {}) {
  if (siteSettings) {
    await setDoc(doc(db,'site_settings','global'), siteSettings, { merge: true });
  }
  if (featureFlags) {
    for (const [id, val] of Object.entries(featureFlags)) {
      await setDoc(doc(db,'feature_toggles', id), { enabled: !!val }, { merge: true });
    }
  }
  if (recipes.length) {
    for (const r of recipes) {
      const id = r.id || `${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
      await setDoc(doc(db,'recipes', id), { ...r, createdAt: serverTimestamp() }, { merge: true });
    }
  }
}
