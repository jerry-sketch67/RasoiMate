import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ScrollArea } from './ui/scroll-area';
import { 
  Users, 
  TrendingUp, 
  Activity,
  Shield,
  ChefHat,
  Clock,
  Mail,
  Calendar,
  Sparkles,
  Eye,
  Heart,
  MessageSquare
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { Footer } from './Footer';
import { useSiteSettings, useFeatureFlags } from '../hooks/useFirebaseHooks';

export function DeveloperDashboardPage() {
  const settings = useSiteSettings();
  const flags = useFeatureFlags();

  const { user, getAllUsers, getTotalUsers, getActiveUsers, getRecentSignups } = useAuth();
  const [allUsers, setAllUsers] = useState(getAllUsers());
  const [refreshKey, setRefreshKey] = useState(0);

  // Refresh data every 5 seconds for real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setAllUsers(getAllUsers());
      setRefreshKey(prev => prev + 1);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const totalUsers = getTotalUsers();
  const activeUsers = getActiveUsers();
  const recentSignups = getRecentSignups();

  // Calculate real-time analytics
  const analytics = {
    totalRecipesCooked: allUsers.reduce((sum, u) => sum + (u.stats?.totalRecipesCooked || 0), 0),
    totalRecipesViewed: allUsers.reduce((sum, u) => sum + (u.stats?.totalRecipesViewed || 0), 0),
    totalRecipesSaved: allUsers.reduce((sum, u) => sum + (u.stats?.totalRecipesSaved || 0), 0),
    averageStreak: allUsers.length > 0 
      ? (allUsers.reduce((sum, u) => sum + (u.stats?.streakDays || 0), 0) / allUsers.length).toFixed(1)
      : 0
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTimeSince = (dateString: string) => {
    const now = new Date();
    const past = new Date(dateString);
    const diffMs = now.getTime() - past.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins} min${diffMins !== 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
  };

  if (!user || !user.isDeveloper) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="p-8 text-center">
          <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">This page is only accessible to authorized developers.</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-purple-50 via-blue-50 to-background dark:from-background dark:via-purple-950/20 dark:to-background">
      <div className="container mx-auto max-w-7xl px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white shadow-lg">
              <Shield className="h-10 w-10" />
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl mb-1 flex items-center gap-3">
                Admin Dashboard
                <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                  Live
                </Badge>
              </h1>
              <p className="text-muted-foreground">
                Welcome, {user.name} • Real-time platform analytics
              </p>
            </div>
          </div>
        </motion.div>

        {/* Real-time Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <Card className="p-6 hover:shadow-xl transition-all border-2 hover:border-purple-500/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-500/10 to-transparent rounded-full -mr-16 -mt-16" />
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <Users className="h-8 w-8 text-purple-500" />
                <motion.div
                  key={refreshKey}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="w-2 h-2 rounded-full bg-green-500 animate-pulse"
                />
              </div>
              <p className="text-3xl font-bold mb-1">{totalUsers}</p>
              <p className="text-sm text-muted-foreground">Total Users</p>
              <p className="text-xs text-green-600 mt-2">+{recentSignups.length} this week</p>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-xl transition-all border-2 hover:border-green-500/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-green-500/10 to-transparent rounded-full -mr-16 -mt-16" />
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <Activity className="h-8 w-8 text-green-500" />
                <motion.div
                  key={refreshKey}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="w-2 h-2 rounded-full bg-green-500 animate-pulse"
                />
              </div>
              <p className="text-3xl font-bold mb-1">{activeUsers}</p>
              <p className="text-sm text-muted-foreground">Active Now</p>
              <p className="text-xs text-green-600 mt-2">Last hour</p>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-xl transition-all border-2 hover:border-blue-500/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-transparent rounded-full -mr-16 -mt-16" />
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <ChefHat className="h-8 w-8 text-blue-500" />
                <motion.div
                  key={refreshKey}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="w-2 h-2 rounded-full bg-green-500 animate-pulse"
                />
              </div>
              <p className="text-3xl font-bold mb-1">{analytics.totalRecipesCooked}</p>
              <p className="text-sm text-muted-foreground">Recipes Cooked</p>
              <p className="text-xs text-blue-600 mt-2">Platform-wide</p>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-xl transition-all border-2 hover:border-yellow-500/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-500/10 to-transparent rounded-full -mr-16 -mt-16" />
            <div className="relative">
              <div className="flex items-center justify-between mb-2">
                <Sparkles className="h-8 w-8 text-yellow-500" />
                <motion.div
                  key={refreshKey}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="w-2 h-2 rounded-full bg-green-500 animate-pulse"
                />
              </div>
              <p className="text-3xl font-bold mb-1">{analytics.averageStreak}</p>
              <p className="text-sm text-muted-foreground">Avg. Streak</p>
              <p className="text-xs text-yellow-600 mt-2">Days active</p>
            </div>
          </Card>
        </motion.div>

        {/* Additional Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8"
        >
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <Eye className="h-6 w-6 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">{analytics.totalRecipesViewed}</p>
                <p className="text-sm text-muted-foreground">Total Views</p>
              </div>
            </div>
            <TrendingUp className="h-4 w-4 text-green-500 inline mr-1" />
            <span className="text-xs text-green-600">High engagement</span>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <Heart className="h-6 w-6 text-red-500" />
              <div>
                <p className="text-2xl font-bold">{analytics.totalRecipesSaved}</p>
                <p className="text-sm text-muted-foreground">Recipes Saved</p>
              </div>
            </div>
            <TrendingUp className="h-4 w-4 text-green-500 inline mr-1" />
            <span className="text-xs text-green-600">Growing library</span>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <MessageSquare className="h-6 w-6 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{allUsers.reduce((sum, u) => sum + (u.recentActivity?.length || 0), 0)}</p>
                <p className="text-sm text-muted-foreground">Total Activities</p>
              </div>
            </div>
            <TrendingUp className="h-4 w-4 text-green-500 inline mr-1" />
            <span className="text-xs text-green-600">Active community</span>
          </Card>
        </motion.div>

        {/* Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Tabs defaultValue="users" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="users">
                <Users className="h-4 w-4 mr-2" />
                Users
              </TabsTrigger>
              <TabsTrigger value="activity">
                <Activity className="h-4 w-4 mr-2" />
                Activity
              </TabsTrigger>
              <TabsTrigger value="analytics">
                <TrendingUp className="h-4 w-4 mr-2" />
                Analytics
              </TabsTrigger>
            </TabsList>

            {/* Users Tab */}
            <TabsContent value="users">
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  All Registered Users ({totalUsers})
                </h2>
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-3">
                    {allUsers.map((u, index) => (
                      <motion.div
                        key={u.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="p-4 rounded-lg border-2 hover:border-purple-500/50 transition-all bg-card hover:shadow-lg"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold text-lg">
                              {u.name.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-semibold">{u.name}</p>
                                {u.isDeveloper && (
                                  <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white text-xs">
                                    DEV
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-muted-foreground">{u.email}</p>
                              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                                <span className="flex items-center gap-1">
                                  <Calendar className="h-3 w-3" />
                                  Joined: {formatDate(u.joinedDate)}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  Last seen: {getTimeSince(u.lastLogin)}
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex gap-2 mb-2">
                              <Badge variant="outline" className="text-xs">
                                {u.stats?.totalRecipesCooked || 0} cooked
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                {u.favoriteRecipes?.length || 0} saved
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {u.stats?.streakDays || 0} day streak
                            </p>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </ScrollArea>
              </Card>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity">
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Real-Time Activity Feed
                </h2>
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-3">
                    {allUsers
                      .flatMap(u => (u.recentActivity || []).map(a => ({ ...a, userName: u.name, userEmail: u.email })))
                      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                      .slice(0, 50)
                      .map((activity, index) => (
                        <motion.div
                          key={activity.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.03 }}
                          className="flex items-start gap-4 p-4 rounded-lg bg-accent/50 border hover:border-purple-500/50 transition-all"
                        >
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-white font-bold flex-shrink-0">
                            {activity.userName.charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{activity.userName}</p>
                              <Badge variant="outline" className="text-xs capitalize">
                                {activity.type.replace('_', ' ')}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-1">{activity.description}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {getTimeSince(activity.timestamp)}
                            </p>
                          </div>
                        </motion.div>
                      ))}
                  </div>
                </ScrollArea>
              </Card>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Recent Signups</h3>
                  <div className="space-y-3">
                    {recentSignups.map(u => (
                      <div key={u.id} className="flex items-center justify-between p-3 rounded-lg bg-accent/50 border">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center text-white font-bold">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-medium">{u.name}</p>
                            <p className="text-xs text-muted-foreground">{u.email}</p>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground">{getTimeSince(u.joinedDate)}</p>
                      </div>
                    ))}
                  </div>
                </Card>

                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Platform Statistics</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 rounded-lg bg-accent/50">
                      <span className="text-sm font-medium">Average Recipes per User</span>
                      <span className="text-xl font-bold">
                        {totalUsers > 0 ? (analytics.totalRecipesCooked / totalUsers).toFixed(1) : 0}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 rounded-lg bg-accent/50">
                      <span className="text-sm font-medium">Total Activity Logs</span>
                      <span className="text-xl font-bold">
                        {allUsers.reduce((sum, u) => sum + (u.recentActivity?.length || 0), 0)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 rounded-lg bg-accent/50">
                      <span className="text-sm font-medium">Developers</span>
                      <span className="text-xl font-bold">
                        {allUsers.filter(u => u.isDeveloper).length}
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 rounded-lg bg-accent/50">
                      <span className="text-sm font-medium">Active Rate</span>
                      <span className="text-xl font-bold">
                        {totalUsers > 0 ? ((activeUsers / totalUsers) * 100).toFixed(0) : 0}%
                      </span>
                    </div>
                  </div>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    <Footer />
    </div>
  );
{
