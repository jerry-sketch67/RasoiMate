import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { 
  Search, Filter, Star, Clock, Users, Volume2, Download, 
  Globe, Heart, ChevronRight, Home, X, Minus, Plus, StopCircle, ArrowLeft 
} from 'lucide-react';
import { useState, useRef } from 'react';
import { drinkCategories, allDrinks, type Drink } from './data/drinksData';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { toast } from 'sonner@2.0.3';
import { useLanguage } from './LanguageContext';
import { generateRecipePDF } from './utils/pdfGenerator';
import { Footer } from './Footer';

interface DrinksPageProps {
  onNavigate?: (page: string) => void;
}

export function DrinksPage({ onNavigate }: DrinksPageProps = {}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(null);
  const [selectedDrink, setSelectedDrink] = useState<Drink | null>(null);
  const [servings, setServings] = useState(2);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [filterDifficulty, setFilterDifficulty] = useState<string>('all');
  const [filterTime, setFilterTime] = useState<string>('all');
  const { language, setLanguage } = useLanguage();
  
  const speechSynthRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Language codes for speech synthesis
  const languageCodes: Record<string, string> = {
    english: 'en-IN',
    hindi: 'hi-IN',
    tamil: 'ta-IN',
    bengali: 'bn-IN',
    marathi: 'mr-IN',
    telugu: 'te-IN',
    gujarati: 'gu-IN',
    kannada: 'kn-IN'
  };

  const handleCategoryClick = (category: string) => {
    setSelectedCategory(category);
    setSelectedSubCategory(null);
  };

  const handleSubCategoryClick = (subCategory: string) => {
    setSelectedSubCategory(subCategory);
  };

  const handleDrinkClick = (drink: Drink) => {
    setSelectedDrink(drink);
    setServings(drink.servings);
  };

  const handleCloseRecipe = () => {
    setSelectedDrink(null);
    stopSpeaking();
  };

  const scaleIngredients = (drink: Drink, newServings: number) => {
    const scale = newServings / drink.servings;
    return drink.ingredients.map(ing => ({
      ...ing,
      amount: Math.round(ing.amount * scale * 100) / 100
    }));
  };

  const speakRecipe = (drink: Drink) => {
    if (isSpeaking) {
      stopSpeaking();
      return;
    }

    const scaledIngredients = scaleIngredients(drink, servings);
    const ingredientsText = scaledIngredients
      .map(ing => `${ing.amount} ${ing.unit} ${ing.name}`)
      .join(', ');
    
    const stepsText = drink.steps
      .map((step, idx) => `Step ${idx + 1}: ${step}`)
      .join('. ');

    const fullText = `Recipe for ${drink.name}. Ingredients: ${ingredientsText}. Instructions: ${stepsText}`;

    const utterance = new SpeechSynthesisUtterance(fullText);
    utterance.lang = languageCodes[language] || 'en-IN';
    utterance.rate = 0.9;
    utterance.pitch = 1;

    // Try to find a voice that matches the language
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(voice => 
      voice.lang.startsWith(languageCodes[language]?.split('-')[0] || 'en')
    );
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => {
      setIsSpeaking(false);
      toast.error('Speech synthesis error');
    };

    speechSynthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    toast.success('🔊 Speaking recipe...');
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const downloadRecipe = async (drink: Drink) => {
    try {
      const scaledIngredients = scaleIngredients(drink, servings);
      await generateRecipePDF({
        name: drink.name,
        description: drink.description,
        ingredients: scaledIngredients.map(ing => `${ing.amount} ${ing.unit} ${ing.name}`),
        steps: drink.steps,
        time: drink.time,
        difficulty: drink.difficulty,
        servings: servings
      });
      toast.success('✅ Recipe downloaded as PDF!');
    } catch (error) {
      toast.error('Failed to download recipe');
    }
  };

  const toggleFavorite = (drinkId: string) => {
    setFavorites(prev => 
      prev.includes(drinkId) 
        ? prev.filter(id => id !== drinkId)
        : [...prev, drinkId]
    );
    toast.success(favorites.includes(drinkId) ? 'Removed from favorites' : '❤️ Added to favorites!');
  };

  // Filter drinks based on search and filters
  const filteredDrinks = allDrinks.filter(drink => {
    const matchesSearch = drink.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          drink.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || drink.category === selectedCategory;
    const matchesSubCategory = !selectedSubCategory || drink.subCategory === selectedSubCategory;
    const matchesDifficulty = filterDifficulty === 'all' || drink.difficulty.toLowerCase() === filterDifficulty.toLowerCase();
    
    let matchesTime = true;
    if (filterTime !== 'all') {
      const time = parseInt(drink.time);
      if (filterTime === 'quick' && time > 10) matchesTime = false;
      if (filterTime === 'medium' && (time <= 10 || time > 30)) matchesTime = false;
      if (filterTime === 'long' && time <= 30) matchesTime = false;
    }
    
    return matchesSearch && matchesCategory && matchesSubCategory && matchesDifficulty && matchesTime;
  });

  const getSubCategories = () => {
    if (!selectedCategory) return [];
    return drinkCategories[selectedCategory as keyof typeof drinkCategories]?.subCategories || [];
  };

  return (
    <div className="relative py-12">
      {/* Modern Gradient Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-50 via-blue-50 to-purple-50" />
        <div className="absolute inset-0 opacity-30" style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(255, 182, 193, 0.3) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(173, 216, 230, 0.3) 0%, transparent 50%)',
        }} />
      </div>

      {/* Floating Animated Elements */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute"
          style={{
            top: '10%',
            left: '5%',
            fontSize: '60px',
            opacity: 0.15,
          }}
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍹
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            top: '60%',
            right: '10%',
            fontSize: '50px',
            opacity: 0.15,
          }}
          animate={{
            y: [0, 15, 0],
            x: [0, -10, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          ☕
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            bottom: '20%',
            left: '15%',
            fontSize: '55px',
            opacity: 0.15,
          }}
          animate={{
            y: [0, -25, 0],
            rotate: [0, -10, 0],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥤
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            top: '30%',
            right: '5%',
            fontSize: '45px',
            opacity: 0.15,
          }}
          animate={{
            y: [0, 20, 0],
            x: [0, 10, 0],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍊
        </motion.div>
      </div>

      <div className="relative container mx-auto max-w-7xl px-4 z-10">
        {/* Back Button */}
        {onNavigate && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Button
              variant="ghost"
              onClick={() => onNavigate('home')}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </motion.div>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          
          <Badge className="mb-4" style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)', color: 'white' }}>
            <span className="mr-1">🧋</span>
            500+ Beverages
          </Badge>
          
          <h1 className="text-4xl md:text-6xl mb-4" style={{
            background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>
            Drinks & Beverages
          </h1>
          
          <p className="text-lg text-gray-700 max-w-2xl mx-auto mb-6">
            From traditional Indian drinks to modern mocktails and smoothies - discover the perfect beverage for every occasion
          </p>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 max-w-4xl mx-auto">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search drinks... (e.g., Mango Lassi, Masala Chai)"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 rounded-full border-2 bg-white/80 backdrop-blur"
              />
            </div>
            
            <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
              <SelectTrigger className="w-full md:w-[180px] h-12 rounded-full bg-white/80 backdrop-blur">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="easy">Easy</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="hard">Hard</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterTime} onValueChange={setFilterTime}>
              <SelectTrigger className="w-full md:w-[180px] h-12 rounded-full bg-white/80 backdrop-blur">
                <Clock className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Time" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Any Time</SelectItem>
                <SelectItem value="quick">&lt; 10 mins</SelectItem>
                <SelectItem value="medium">10-30 mins</SelectItem>
                <SelectItem value="long">&gt; 30 mins</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </motion.div>

        {/* Category Selection */}
        {!selectedCategory && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12"
          >
            {Object.entries(drinkCategories).map(([key, category]) => (
              <motion.div
                key={key}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
              >
                <Card
                  className="p-8 cursor-pointer text-center hover-lift border-2 bg-white/90 backdrop-blur"
                  onClick={() => handleCategoryClick(key)}
                  style={{
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.9), rgba(255,255,255,0.7))',
                    borderColor: 'rgba(255, 153, 51, 0.2)',
                  }}
                >
                  <div className="text-5xl mb-4">{category.icon}</div>
                  <h3 className="text-lg text-gray-900">{category.name}</h3>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        )}

        {/* Sub-Category Selection */}
        {selectedCategory && !selectedSubCategory && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-8"
          >
            <Button
              variant="ghost"
              onClick={() => {
                setSelectedCategory(null);
                setSelectedSubCategory(null);
              }}
              className="mb-6"
            >
              <ChevronRight className="mr-2 h-4 w-4 rotate-180" />
              Back to Categories
            </Button>

            <h2 className="text-2xl md:text-3xl mb-6 text-center" style={{ color: '#FF9933' }}>
              {drinkCategories[selectedCategory as keyof typeof drinkCategories]?.name}
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {getSubCategories().map((subCat) => (
                <motion.div
                  key={subCat}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                >
                  <Card
                    className="p-6 cursor-pointer hover-lift border-2 bg-white/90 backdrop-blur"
                    onClick={() => handleSubCategoryClick(subCat)}
                    style={{ borderColor: 'rgba(76, 175, 80, 0.3)' }}
                  >
                    <h3 className="text-lg text-gray-900 flex items-center justify-between">
                      {subCat}
                      <ChevronRight className="h-5 w-5" style={{ color: '#4CAF50' }} />
                    </h3>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Drinks Grid */}
        {(selectedSubCategory || searchQuery) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {selectedSubCategory && (
              <Button
                variant="ghost"
                onClick={() => setSelectedSubCategory(null)}
                className="mb-6"
              >
                <ChevronRight className="mr-2 h-4 w-4 rotate-180" />
                Back to Sub-Categories
              </Button>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDrinks.map((drink) => (
                <motion.div
                  key={drink.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  whileHover={{ y: -8 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card
                    className="overflow-hidden cursor-pointer border-2 bg-white/95 backdrop-blur"
                    onClick={() => handleDrinkClick(drink)}
                    style={{ borderColor: 'rgba(63, 81, 181, 0.2)' }}
                  >
                    <div className="relative h-48 overflow-hidden">
                      <ImageWithFallback
                        src={`https://images.unsplash.com/photo-${drink.image}?w=400&h=300&fit=crop`}
                        alt={drink.name}
                        className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                      />
                      <div className="absolute top-3 right-3">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="rounded-full bg-white/90 backdrop-blur hover:bg-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(drink.id);
                          }}
                        >
                          <Heart 
                            className={`h-5 w-5 ${favorites.includes(drink.id) ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
                          />
                        </Button>
                      </div>
                      <Badge 
                        className="absolute bottom-3 left-3"
                        style={{ background: 'rgba(255,255,255,0.95)' }}
                      >
                        <Clock className="mr-1 h-3 w-3" />
                        <span className="text-gray-800">{drink.time}</span>
                      </Badge>
                    </div>
                    
                    <div className="p-5">
                      <h3 className="text-xl mb-2 text-gray-900">{drink.name}</h3>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">{drink.description}</p>
                      
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${i < Math.floor(drink.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                            />
                          ))}
                          <span className="text-sm text-gray-600 ml-1">({drink.reviews})</span>
                        </div>
                        
                        <Badge variant="outline" style={{ borderColor: drink.difficulty === 'Easy' ? '#4CAF50' : drink.difficulty === 'Medium' ? '#FF9933' : '#3F51B5' }}>
                          {drink.difficulty}
                        </Badge>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {drink.tags.slice(0, 3).map(tag => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>

            {filteredDrinks.length === 0 && (
              <div className="text-center py-16">
                <p className="text-xl text-gray-600">No drinks found matching your criteria.</p>
                <Button
                  onClick={() => {
                    setSearchQuery('');
                    setFilterDifficulty('all');
                    setFilterTime('all');
                  }}
                  className="mt-4"
                  style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)' }}
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </motion.div>
        )}

        {/* Recipe Detail Dialog */}
        <AnimatePresence>
          {selectedDrink && (
            <Dialog open={!!selectedDrink} onOpenChange={handleCloseRecipe}>
              <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <DialogTitle className="text-3xl mb-2">{selectedDrink.name}</DialogTitle>
                      <DialogDescription className="text-gray-600">{selectedDrink.description}</DialogDescription>
                      
                      <div className="flex items-center gap-4 mt-4">
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-5 w-5 ${i < Math.floor(selectedDrink.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                            />
                          ))}
                          <span className="text-sm text-gray-600 ml-2">
                            {selectedDrink.rating} ({selectedDrink.reviews} reviews)
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={handleCloseRecipe}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                </DialogHeader>

                <div className="space-y-6 mt-6">
                  {/* Recipe Image */}
                  <div className="relative h-64 rounded-2xl overflow-hidden">
                    <ImageWithFallback
                      src={selectedDrink.image}
                      alt={selectedDrink.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Quick Info */}
                  <div className="grid grid-cols-3 gap-4">
                    <Card className="p-4 text-center bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                      <Clock className="h-6 w-6 mx-auto mb-2" style={{ color: '#FF9933' }} />
                      <p className="text-sm text-gray-600">Time</p>
                      <p className="text-gray-900">{selectedDrink.time}</p>
                    </Card>
                    <Card className="p-4 text-center bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                      <Users className="h-6 w-6 mx-auto mb-2" style={{ color: '#4CAF50' }} />
                      <p className="text-sm text-gray-600">Servings</p>
                      <p className="text-gray-900">{servings}</p>
                    </Card>
                    <Card className="p-4 text-center bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                      <Badge style={{ background: '#3F51B5', color: 'white' }}>
                        {selectedDrink.difficulty}
                      </Badge>
                    </Card>
                  </div>

                  {/* Serving Adjustment */}
                  <Card className="p-6 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
                    <h3 className="text-lg mb-4 text-gray-900">Adjust Servings</h3>
                    <div className="flex items-center gap-4">
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => setServings(Math.max(1, servings - 1))}
                        className="rounded-full"
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <div className="flex-1">
                        <Slider
                          value={[servings]}
                          onValueChange={(value) => setServings(value[0])}
                          min={1}
                          max={10}
                          step={1}
                          className="w-full"
                        />
                      </div>
                      <Button
                        size="icon"
                        variant="outline"
                        onClick={() => setServings(Math.min(10, servings + 1))}
                        className="rounded-full"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                      <span className="text-xl min-w-[60px] text-center text-gray-900">{servings} {servings === 1 ? 'serving' : 'servings'}</span>
                    </div>
                  </Card>

                  {/* Action Buttons */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <Button
                      onClick={() => speakRecipe(selectedDrink)}
                      className="rounded-full"
                      style={{ background: isSpeaking ? '#FF9933' : 'linear-gradient(135deg, #FF9933, #4CAF50)' }}
                    >
                      {isSpeaking ? <StopCircle className="mr-2 h-4 w-4" /> : <Volume2 className="mr-2 h-4 w-4" />}
                      {isSpeaking ? 'Stop' : 'Speak'}
                    </Button>
                    
                    <Button
                      onClick={() => downloadRecipe(selectedDrink)}
                      variant="outline"
                      className="rounded-full"
                    >
                      <Download className="mr-2 h-4 w-4" />
                      PDF
                    </Button>
                    
                    <Button
                      onClick={() => toggleFavorite(selectedDrink.id)}
                      variant="outline"
                      className="rounded-full"
                    >
                      <Heart className={`mr-2 h-4 w-4 ${favorites.includes(selectedDrink.id) ? 'fill-red-500 text-red-500' : ''}`} />
                      Save
                    </Button>
                    
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="rounded-full">
                        <Globe className="mr-2 h-4 w-4" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="hindi">हिन्दी</SelectItem>
                        <SelectItem value="tamil">தமிழ்</SelectItem>
                        <SelectItem value="bengali">বাংলা</SelectItem>
                        <SelectItem value="marathi">मराठी</SelectItem>
                        <SelectItem value="telugu">తెలుగు</SelectItem>
                        <SelectItem value="gujarati">ગુજરાતી</SelectItem>
                        <SelectItem value="kannada">ಕನ್ನಡ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Ingredients */}
                  <Card className="p-6 bg-white/95 backdrop-blur">
                    <h3 className="text-xl mb-4" style={{ color: '#FF9933' }}>Ingredients</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {scaleIngredients(selectedDrink, servings).map((ing, idx) => (
                        <div key={idx} className="flex items-center gap-3 p-3 rounded-lg bg-gradient-to-r from-orange-50 to-transparent">
                          <div className="w-2 h-2 rounded-full" style={{ background: '#FF9933' }} />
                          <span className="text-gray-900">
                            {ing.amount} {ing.unit} <strong>{ing.name}</strong>
                          </span>
                        </div>
                      ))}
                    </div>
                  </Card>

                  {/* Steps */}
                  <Card className="p-6 bg-white/95 backdrop-blur">
                    <h3 className="text-xl mb-4" style={{ color: '#4CAF50' }}>Steps to Make It</h3>
                    <div className="space-y-4">
                      {selectedDrink.steps.map((step, idx) => (
                        <div key={idx} className="flex gap-4">
                          <div 
                            className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-white"
                            style={{ background: 'linear-gradient(135deg, #4CAF50, #3F51B5)' }}
                          >
                            {idx + 1}
                          </div>
                          <p className="text-gray-700 pt-1">{step}</p>
                        </div>
                      ))}
                    </div>
                  </Card>

                  {/* Tags */}
                  {selectedDrink.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {selectedDrink.tags.map(tag => (
                        <Badge 
                          key={tag} 
                          variant="secondary"
                          className="px-3 py-1"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </DialogContent>
            </Dialog>
          )}
        </AnimatePresence>
      </div>
    <Footer />
    </div>
  );
{
