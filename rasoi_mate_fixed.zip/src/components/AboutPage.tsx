import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Sparkles, Heart, Leaf, Zap, Shield, Globe, Home, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { KitchenBackground } from './KitchenBackground';
import { Footer } from './Footer';

interface AboutPageProps {
  onNavigate?: (page: string) => void;
}

const values = [
  {
    icon: Zap,
    title: 'Innovation',
    description: 'Leveraging cutting-edge AI to make cooking accessible to everyone',
    color: 'var(--tech-blue)',
  },
  {
    icon: Heart,
    title: 'Culture',
    description: 'Preserving and celebrating the rich diversity of Indian cuisine',
    color: 'var(--saffron)',
  },
  {
    icon: Leaf,
    title: 'Sustainability',
    description: 'Promoting mindful cooking and reducing food waste',
    color: 'var(--green)',
  },
  {
    icon: Shield,
    title: 'Empowerment',
    description: 'Giving voice to local chefs and traditional knowledge',
    color: 'var(--tech-blue)',
  },
];

const timeline = [
  { year: '2023', title: 'The Idea', description: 'Rasoi Mate was born from a simple question: How can we make traditional cooking accessible?' },
  { year: '2024', title: 'Development', description: 'Built AI models trained on authentic Indian recipes and cooking techniques' },
  { year: '2024', title: 'Beta Launch', description: 'Soft launch with 100 recipes and voice assistance in 5 languages' },
  { year: '2025', title: 'Today', description: '500+ recipes, 50K+ users, and growing every day' },
];

export function AboutPage({ onNavigate }: AboutPageProps = {}) {
  return (
    <div className="min-h-screen py-12 relative overflow-hidden">
      <KitchenBackground />
      <div className="container mx-auto max-w-7xl px-4 relative z-10">
        {/* Back Button */}
        {onNavigate && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Button
              variant="ghost"
              onClick={() => onNavigate('home')}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </motion.div>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <Badge className="mb-4" style={{ background: 'var(--tech-blue)', color: 'white' }}>
            <Sparkles className="mr-1 h-3 w-3" />
            Our Story
          </Badge>
          <h1 className="text-3xl md:text-5xl mb-4">About Rasoi Mate</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Where Tradition Meets Technology, One Recipe at a Time
          </p>
        </motion.div>

        {/* Grandmother + AI Illustration Section */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="mb-16"
        >
          <Card className="overflow-hidden relative hover-lift" style={{
            background: 'linear-gradient(135deg, rgba(255, 153, 51, 0.1), rgba(63, 81, 181, 0.1))',
            border: '2px solid rgba(255, 153, 51, 0.3)'
          }}>
            <div className="grid md:grid-cols-2 gap-0">
              {/* Left: Grandmother (Tradition) */}
              <div className="relative p-8 md:p-12 flex flex-col justify-center bg-gradient-to-br from-[var(--saffron)]/20 to-transparent">
                <div className="relative z-10">
                  <Badge className="mb-4" style={{ background: 'var(--saffron)', color: 'white' }}>
                    <Heart className="mr-1 h-3 w-3" />
                    Tradition
                  </Badge>
                  <h2 className="text-3xl md:text-4xl mb-4">
                    Grandmother's Wisdom
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Every recipe carries generations of knowledge. The pinch of love, the patience in slow cooking, 
                    the stories behind each dish—these are irreplaceable.
                  </p>
                  <ul className="space-y-3 text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Heart className="h-5 w-5 mt-0.5" style={{ color: 'var(--saffron)' }} />
                      <span>Authentic family recipes passed down through generations</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Heart className="h-5 w-5 mt-0.5" style={{ color: 'var(--saffron)' }} />
                      <span>Cultural significance and stories behind each dish</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Heart className="h-5 w-5 mt-0.5" style={{ color: 'var(--saffron)' }} />
                      <span>Regional variations and traditional techniques</span>
                    </li>
                  </ul>
                </div>
                
                {/* Decorative grandmother icon */}
                <div className="absolute bottom-4 right-4 opacity-10">
                  <svg width="120" height="120" viewBox="0 0 120 120" fill="none">
                    <circle cx="60" cy="35" r="20" fill="var(--saffron)" />
                    <path d="M30 70 Q60 85 90 70 L85 110 Q60 115 35 110 Z" fill="var(--saffron)" />
                    <text x="60" y="42" fontSize="16" fill="white" textAnchor="middle">👵</text>
                  </svg>
                </div>
              </div>

              {/* Right: AI (Technology) */}
              <div className="relative p-8 md:p-12 flex flex-col justify-center bg-gradient-to-bl from-[var(--tech-blue)]/20 to-transparent">
                <div className="relative z-10">
                  <Badge className="mb-4" style={{ background: 'var(--tech-blue)', color: 'white' }}>
                    <Sparkles className="mr-1 h-3 w-3" />
                    Technology
                  </Badge>
                  <h2 className="text-3xl md:text-4xl mb-4">
                    AI Intelligence
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Modern technology makes this wisdom accessible to everyone. Voice commands, 
                    smart substitutions, and personalized guidance—cooking made effortless.
                  </p>
                  <ul className="space-y-3 text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Zap className="h-5 w-5 mt-0.5" style={{ color: 'var(--tech-blue)' }} />
                      <span>AI-powered voice assistance in multiple languages</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Zap className="h-5 w-5 mt-0.5" style={{ color: 'var(--tech-blue)' }} />
                      <span>Smart ingredient substitutions and scaling</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Zap className="h-5 w-5 mt-0.5" style={{ color: 'var(--tech-blue)' }} />
                      <span>Personalized recommendations based on preferences</span>
                    </li>
                  </ul>
                </div>

                {/* AI Orb with pulsing effect */}
                <motion.div
                  className="absolute bottom-8 right-8 w-24 h-24 rounded-full"
                  style={{
                    background: 'radial-gradient(circle, var(--tech-blue), var(--tech-blue-light))',
                    boxShadow: '0 0 40px var(--tech-blue)',
                  }}
                  animate={{
                    scale: [1, 1.15, 1],
                    opacity: [0.7, 1, 0.7],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                >
                  <div className="w-full h-full flex items-center justify-center text-3xl">
                    🤖
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Center connecting element */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
              <motion.div
                className="w-16 h-16 rounded-full flex items-center justify-center text-2xl"
                style={{
                  background: 'linear-gradient(135deg, var(--saffron), var(--tech-blue))',
                  boxShadow: '0 0 30px rgba(255, 153, 51, 0.5), 0 0 30px rgba(63, 81, 181, 0.5)',
                }}
                animate={{
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 20,
                  repeat: Infinity,
                  ease: 'linear',
                }}
              >
                ❤️
              </motion.div>
            </div>
          </Card>

          {/* Caption */}
          <p className="text-center mt-4 text-muted-foreground italic">
            "When grandmother's love meets AI's intelligence, magic happens in the kitchen"
          </p>
        </motion.div>

        {/* Vision Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-16"
        >
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl mb-6">Our Vision</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Rasoi Mate was born from a simple observation: cooking traditional Indian food can be intimidating. Complex recipes, regional variations, and the fear of making mistakes often prevent people from exploring their culinary heritage.
                </p>
                <p>
                  We envisioned a solution that combines the warmth of a grandmother's guidance with the precision of modern technology. Our AI assistant doesn't just give you recipes—it understands your needs, speaks your language, and adapts to your cooking style.
                </p>
                <p>
                  Today, we're proud to serve thousands of home chefs, from college students making their first dal to experienced cooks exploring new regional cuisines.
                </p>
              </div>
            </div>

            <div className="relative">
              <Card className="p-8 relative overflow-hidden">
                <div
                  className="absolute inset-0 opacity-5"
                  style={{
                    backgroundImage: 'radial-gradient(circle, var(--saffron) 2px, transparent 2px)',
                    backgroundSize: '30px 30px',
                  }}
                />
                <div className="relative z-10 space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--tech-blue)20' }}>
                      <Globe className="h-6 w-6" style={{ color: 'var(--tech-blue)' }} />
                    </div>
                    <div>
                      <h3 className="mb-2">Smart</h3>
                      <p className="text-sm text-muted-foreground">
                        AI-powered recipe assistance that learns from you
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--green)20' }}>
                      <Shield className="h-6 w-6" style={{ color: 'var(--green)' }} />
                    </div>
                    <div>
                      <h3 className="mb-2">Safe</h3>
                      <p className="text-sm text-muted-foreground">
                        Trusted recipes from verified sources and chefs
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center shrink-0" style={{ background: 'var(--saffron)20' }}>
                      <Heart className="h-6 w-6" style={{ color: 'var(--saffron)' }} />
                    </div>
                    <div>
                      <h3 className="mb-2">Soulful</h3>
                      <p className="text-sm text-muted-foreground">
                        Preserving the heart and soul of Indian cooking
                      </p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </motion.div>

        {/* Core Values */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-16"
        >
          <h2 className="text-3xl text-center mb-12">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <Card className="p-6 h-full hover:shadow-xl transition-all text-center">
                  <div
                    className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                    style={{ background: `${value.color}20` }}
                  >
                    <value.icon className="h-8 w-8" style={{ color: value.color }} />
                  </div>
                  <h3 className="mb-3">{value.title}</h3>
                  <p className="text-sm text-muted-foreground">{value.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Tech Stack */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="p-8 md:p-12 relative overflow-hidden">
            <div
              className="absolute inset-0 opacity-5"
              style={{
                background: 'linear-gradient(45deg, var(--tech-blue) 25%, transparent 25%, transparent 75%, var(--tech-blue) 75%)',
                backgroundSize: '50px 50px',
              }}
            />
            <div className="relative z-10 text-center max-w-3xl mx-auto">
              <Badge className="mb-4" style={{ background: 'var(--tech-blue)', color: 'white' }}>
                <Sparkles className="mr-1 h-3 w-3" />
                Technology
              </Badge>
              <h2 className="text-2xl md:text-3xl mb-4">Powered by Advanced AI</h2>
              <p className="text-muted-foreground mb-6">
                Our platform uses natural language processing, machine learning, and text-to-speech technology to deliver a seamless cooking experience.
              </p>
              <div className="flex flex-wrap gap-2 justify-center mb-6">
                {['Python', 'Streamlit', 'gTTS', 'Speech Recognition', 'Pandas', 'Gemini API', 'HuggingFace'].map((tech, i) => (
                  <Badge key={i} variant="outline">{tech}</Badge>
                ))}
              </div>
              <p className="text-sm text-muted-foreground italic">
                Voice/Text → NLP Engine → Recipe Database → Audio/Text Output
              </p>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Footer */}
      <Footer onNavigate={onNavigate} />
    </div>
  );
}
