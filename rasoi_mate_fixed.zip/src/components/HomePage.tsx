import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Mic, Play, Sparkles, Users, Globe, Brain, ChevronRight, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Badge } from './ui/badge';
import { useLanguage } from './LanguageContext';
import { getTranslation } from './utils/translations';
import { Footer } from './Footer';
import { useSiteSettings } from '../hooks/useFirebaseHooks';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

/**
 * HomePage Background Design System
 * 
 * A clean, minimalistic homepage with a bright and friendly aesthetic designed to make
 * orange line art food icons pop against a warm, inviting gradient backdrop.
 * 
 * Background Layers (z-index 0):
 * 1. Base Gradient: Linear gradient from warm light cream (#FFF8E7) to subtle pale orange (#FFE0B2)
 * 2. Geometric Pattern: Subtle dots and diagonal lines at 0.15-0.3 opacity
 * 3. Soft Accent Waves: Top and bottom elliptical gradients for depth
 * 4. Floating Geometric Shapes: Animated circles, triangles, and organic shapes
 * 5. Ultra-Faint Food Motifs: Very light food pattern at 0.03 opacity
 * 6. Decorative Line Art Icons: Hand-drawn style food icons (wheat, vegetables, utensils) at 0.08 opacity
 * 
 * Color Palette:
 * - Primary Orange: #FF9933 (for icons and accents)
 * - Warm Cream: #FFF8E7 (gradient start)
 * - Pale Orange: #FFE0B2 (gradient end)
 * - Ultra Light: #FFF3E0 (for subtle motifs)
 * 
 * Design Goals:
 * ✓ Makes orange icons pop with maximum contrast
 * ✓ Maintains clarity for UI elements and text overlays
 * ✓ Creates depth without distraction
 * ✓ Bright, friendly, and inviting atmosphere
 * ✓ Ensures excellent readability for all content
 */
export function HomePage({ onNavigate }: HomePageProps) {
  const siteSettings = useSiteSettings();
  useEffect(()=>{ if(siteSettings){ if(siteSettings.primaryColor) document.documentElement.style.setProperty('--primary-color', siteSettings.primaryColor); if(siteSettings.accentColor) document.documentElement.style.setProperty('--accent-color', siteSettings.accentColor); } }, [siteSettings]);

  const { language } = useLanguage();
  const t = (key: string) => getTranslation(language, key);
  
  const features = [
    {
      icon: Mic,
      title: 'Voice & Text AI',
      description: 'Talk to Rasoi Mate like a friend. Ask in any language.',
      color: '#FF9933',
      page: 'ai-assistant'
    },
    {
      icon: Users,
      title: 'Smart Proportions',
      description: 'Cooking for 2 or 20? Auto-adjust ingredients instantly.',
      color: '#4CAF50',
      page: 'ai-assistant'
    },
    {
      icon: Globe,
      title: 'Multilingual',
      description: 'English, Hindi, Regional & Global recipes available.',
      color: '#3F51B5',
      page: 'vocal-to-local'
    },
    {
      icon: Brain,
      title: 'AI Alternatives',
      description: 'Missing an ingredient? Get smart substitutes instantly.',
      color: '#FF9933',
      page: 'ai-assistant'
    },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Modern Gradient Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50 via-yellow-50 to-green-50" />
        <div className="absolute inset-0 opacity-40" style={{
          backgroundImage: 'radial-gradient(circle at 30% 40%, rgba(255, 153, 51, 0.25) 0%, transparent 50%), radial-gradient(circle at 70% 70%, rgba(76, 175, 80, 0.25) 0%, transparent 50%)',
        }} />
      </div>

      {/* Floating Animated Kitchen Elements */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <motion.div
          className="absolute"
          style={{
            top: '8%',
            left: '8%',
            fontSize: '55px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -25, 0],
            rotate: [0, 8, 0],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="#FF9933" strokeWidth="1.5">
            <path d="M12 2C12 2 10.5 4 10.5 7C10.5 10 12 12 12 12" />
            <path d="M12 2C12 2 13.5 4 13.5 7C13.5 10 12 12 12 12" />
            <path d="M9 7C9 7 7 8 7 10.5C7 13 9 14.5 9 14.5" />
            <path d="M15 7C15 7 17 8 17 10.5C17 13 15 14.5 15 14.5" />
            <line x1="12" y1="12" x2="12" y2="22" />
          </svg>
        </motion.div>
        
        {/* Vegetable/Carrot Icon - Top Right */}
        <motion.div
          className="absolute"
          style={{
            top: '25%',
            right: '8%',
            opacity: 0.25,
          }}
          animate={{
            y: [0, -12, 0],
            x: [0, 5, 0],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="#FF9933" strokeWidth="1.5">
            <path d="M10 2L8 8L2 22L8 18L14 22L11 10L10 2Z" />
            <path d="M10 2C10 2 11 3 12 3C13 3 14 2 14 2" />
            <path d="M8 8L6 10" />
            <path d="M11 10L9 12" />
          </svg>
        </motion.div>
        
        {/* Spoon/Utensil Icon - Bottom Right */}
        <motion.div
          className="absolute"
          style={{
            bottom: '15%',
            right: '12%',
            opacity: 0.25,
          }}
          animate={{
            rotate: [0, -10, 0],
            y: [0, 10, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <svg width="55" height="55" viewBox="0 0 24 24" fill="none" stroke="#FF9933" strokeWidth="1.5">
            <path d="M12 2L12 8C12 9.5 13 10 14 10C15 10 16 9.5 16 8L16 2" />
            <line x1="14" y1="10" x2="14" y2="22" strokeLinecap="round" />
            <ellipse cx="14" cy="21" rx="1.5" ry="1" />
          </svg>
        </motion.div>
        
        {/* Pot/Cooking Icon - Bottom Left */}
        <motion.div
          className="absolute"
          style={{
            bottom: '25%',
            left: '8%',
            opacity: 0.25,
          }}
          animate={{
            y: [0, -15, 0],
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <svg width="65" height="65" viewBox="0 0 24 24" fill="none" stroke="#FF9933" strokeWidth="1.5">
            <path d="M6 10L6 18C6 19.5 7 20 8 20L16 20C17 20 18 19.5 18 18L18 10" />
            <rect x="4" y="8" width="16" height="3" rx="1" />
            <line x1="6" y1="5" x2="6" y2="8" strokeLinecap="round" />
            <line x1="12" y1="4" x2="12" y2="8" strokeLinecap="round" />
            <line x1="18" y1="5" x2="18" y2="8" strokeLinecap="round" />
          </svg>
        </motion.div>
        
        {/* Chili/Spice Icon - Middle Left */}
        <motion.div
          className="absolute"
          style={{
            top: '55%',
            left: '3%',
            opacity: 0.25,
          }}
          animate={{
            rotate: [0, 15, 0],
            x: [0, 8, 0],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <svg width="45" height="45" viewBox="0 0 24 24" fill="none" stroke="#FF9933" strokeWidth="1.5">
            <path d="M10 2C10 2 8 4 8 6C8 8 9 9 9 9L6 20C6 21 7 22 8 22C9 22 10 21 10 20L13 9C13 9 14 8 14 6C14 4 12 2 12 2" />
            <path d="M10 2C10 2 11 1 12 1C13 1 14 2 14 2" strokeLinecap="round" />
          </svg>
        </motion.div>
        
        {/* Bowl/Serving Icon - Middle Right */}
        <motion.div
          className="absolute"
          style={{
            top: '60%',
            right: '5%',
            opacity: 0.25,
          }}
          animate={{
            y: [0, 12, 0],
            scale: [1, 0.95, 1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍳
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            top: '55%',
            right: '12%',
            fontSize: '48px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 18, 0],
            x: [0, -8, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥘
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            bottom: '15%',
            left: '18%',
            fontSize: '52px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -22, 0],
            rotate: [0, -8, 0],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍛
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            top: '25%',
            right: '8%',
            fontSize: '50px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 20, 0],
            x: [0, 12, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥗
        </motion.div>
        <motion.div
          className="absolute"
          style={{
            bottom: '35%',
            right: '5%',
            fontSize: '45px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -15, 0],
            rotate: [0, 10, 0],
          }}
          transition={{
            duration: 7.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍜
        </motion.div>
        
        {/* Additional Dish Icons */}
        <motion.div
          className="absolute"
          style={{
            top: '12%',
            left: '22%',
            fontSize: '46px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -18, 0],
            rotate: [0, -5, 0],
          }}
          transition={{
            duration: 8.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍲
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            top: '40%',
            left: '15%',
            fontSize: '50px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 15, 0],
            x: [0, -5, 0],
          }}
          transition={{
            duration: 9.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥙
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            top: '18%',
            right: '25%',
            fontSize: '48px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 20, 0],
            rotate: [0, 8, 0],
          }}
          transition={{
            duration: 10.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍝
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            bottom: '8%',
            right: '28%',
            fontSize: '52px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -20, 0],
            scale: [1, 1.08, 1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍱
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            bottom: '45%',
            left: '25%',
            fontSize: '44px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 12, 0],
            x: [0, 8, 0],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥟
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            top: '70%',
            left: '12%',
            fontSize: '46px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -16, 0],
            rotate: [0, -12, 0],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍕
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            top: '45%',
            right: '20%',
            fontSize: '50px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 18, 0],
            x: [0, -10, 0],
          }}
          transition={{
            duration: 11,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍢
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            bottom: '50%',
            right: '8%',
            fontSize: '48px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -14, 0],
            scale: [1, 1.06, 1],
          }}
          transition={{
            duration: 8.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥡
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            top: '32%',
            left: '5%',
            fontSize: '45px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 16, 0],
            rotate: [0, 6, 0],
          }}
          transition={{
            duration: 7.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍚
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            bottom: '22%',
            left: '35%',
            fontSize: '47px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -19, 0],
            x: [0, 6, 0],
          }}
          transition={{
            duration: 9.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥘
        </motion.div>
        
        <motion.div
          className="absolute"
          style={{
            top: '8%',
            right: '35%',
            fontSize: '49px',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 22, 0],
            rotate: [0, -8, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍛
        </motion.div>
      </div>
      
      {/* Content Container */}
      <div className="relative z-10">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-transparent pb-20">
        <div className="container mx-auto max-w-7xl px-4 py-20 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-6 max-w-4xl mx-auto"
          >
            <Badge className="mb-4" style={{ 
              background: 'linear-gradient(135deg, #FF9933, #4CAF50)', 
              color: 'white',
              border: '2px solid #FF9933',
              padding: '8px 20px',
              fontSize: '16px'
            }}>
              ✨ AI-Powered Kitchen Assistant ✨
            </Badge>
            
            <h1 className="text-4xl md:text-6xl lg:text-7xl" style={{
              background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              fontWeight: 'bold',
            }}>
              {t('heroTitle')}
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-700 max-w-2xl mx-auto">
              {t('heroSubtitle')}
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  onClick={() => onNavigate('ai-assistant')}
                  className="text-lg px-8 py-6 rounded-full shadow-2xl hover:shadow-3xl transition-all"
                  style={{ 
                    background: 'linear-gradient(135deg, #FF9933, #4CAF50)',
                    color: 'white'
                  }}
                >
                  <Sparkles className="mr-2 h-5 w-5" />
                  {t('tryAIAssistant')}
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => onNavigate('recipes')}
                  className="text-lg px-8 py-6 rounded-full border-2 hover:scale-105 transition-all hover-lift hover-glow"
                  style={{ 
                    borderColor: '#3F51B5',
                    color: '#3F51B5',
                  }}
                >
                  {t('exploreRecipes')}
                  <ChevronRight className="ml-2 h-5 w-5" />
                </Button>
              </motion.div>
            </div>
          </motion.div>
        </div>

      </section>

      {/* Interactive Demo Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <Badge className="mb-4" style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)', color: 'white' }}>
              AI-Powered Assistant
            </Badge>
            <h2 className="text-3xl md:text-4xl mb-4" style={{ color: '#FF9933' }}>
              {t('seeInAction')}
            </h2>
            <p className="text-lg text-gray-700 max-w-2xl mx-auto">
              {t('experienceHow')}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto mb-12">
            {[
              {
                icon: Mic,
                title: t('voiceCommands'),
                description: t('voiceCommandsDesc'),
                color: '#FF9933'
              },
              {
                icon: Sparkles,
                title: t('smartSuggestions'),
                description: t('smartSuggestionsDesc'),
                color: '#4CAF50'
              },
              {
                icon: Users,
                title: t('autoScaling'),
                description: t('autoScalingDesc'),
                color: '#3F51B5'
              }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card className="p-6 h-full hover-lift text-center bg-white border-gray-200">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center" style={{ background: 'white', boxShadow: `0 4px 12px ${item.color}30` }}>
                    <item.icon className="w-8 h-8" style={{ color: item.color }} />
                  </div>
                  <h3 className="mb-2" style={{ color: item.color }}>{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <Button
              size="lg"
              onClick={() => onNavigate('ai-assistant')}
              className="rounded-full shadow-xl hover-lift"
              style={{ 
                background: 'linear-gradient(135deg, #FF9933, #3F51B5)',
                color: 'white'
              }}
            >
              <Play className="mr-2 h-5 w-5" />
              {t('tryAINow')}
            </Button>
            <p className="text-sm text-gray-600 mt-4">
              {t('noSignupRequired')}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl mb-4" style={{ color: '#FF9933' }}>
              Why Choose Rasoi Mate?
            </h2>
            <p className="text-lg text-gray-700">
              Powered by AI, inspired by tradition
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -8 }}
              >
                <Card 
                  className="p-6 h-full hover:shadow-xl transition-all cursor-pointer hover-lift hover-glow bg-white border-gray-200"
                  onClick={() => feature.page && onNavigate(feature.page)}
                  style={{
                    boxShadow: `0 2px 8px rgba(0, 0, 0, 0.1)`,
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center mb-4"
                    style={{ background: 'white', boxShadow: `0 4px 12px ${feature.color}30` }}
                  >
                    <feature.icon className="h-6 w-6" style={{ color: feature.color }} />
                  </div>
                  <h3 className="mb-2 text-gray-900">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { number: '1000+', label: 'Recipes' },
              { number: '8', label: 'Languages' },
              { number: '36', label: 'Indian States' },
            ].map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <h3 className="text-3xl md:text-5xl mb-2" style={{
                  background: 'linear-gradient(135deg, #FF9933, #4CAF50)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  fontWeight: 'bold',
                }}>
                  {stat.number}
                </h3>
                <p className="text-gray-700">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>



      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="container mx-auto max-w-7xl px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="rounded-3xl p-8 md:p-16 text-center text-white relative overflow-hidden hover-lift"
            style={{ 
              background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
            }}
          >
            <div className="relative z-10">
              <h2 className="text-3xl md:text-4xl mb-4">Ready to Transform Your Cooking?</h2>
              <p className="text-lg md:text-xl mb-8 opacity-90">
                Join thousands of home chefs using AI to create delicious meals
              </p>
              <Button
                size="lg"
                onClick={() => onNavigate('login')}
                className="text-lg px-8 py-6 rounded-full bg-white hover:bg-gray-100 hover-lift hover-glow"
                style={{ 
                  color: '#FF9933',
                  fontWeight: 'bold'
                }}
              >
                Get Started Free
              </Button>
            </div>
            
            {/* Decorative elements */}
            <motion.div
              className="absolute -right-20 -top-20 w-64 h-64 rounded-full opacity-20"
              style={{ background: 'white' }}
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            />
          </motion.div>
        </div>
      </section>
      </div>

      {/* Footer */}
      <Footer onNavigate={onNavigate} />
    </div>
  );
}
