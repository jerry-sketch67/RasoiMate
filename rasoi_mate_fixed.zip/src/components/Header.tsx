import { ChefHat, Menu, Moon, Sun, X } from 'lucide-react';
import { Button } from './ui/button';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from './LanguageContext';
import { getTranslation } from './utils/translations';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  isLoggedIn: boolean;
  onLogout: () => void;
  isDeveloper?: boolean;
  user?: any;
}

export function Header({ currentPage, onNavigate, darkMode, onToggleDarkMode, isLoggedIn, onLogout, isDeveloper, user }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { language, setLanguage } = useLanguage();
  const t = (key: string) => getTranslation(language, key);
  
  const getNavItems = () => {
    const translations: Record<string, Record<string, string>> = {
      english: { home: 'Home', aiAssistant: 'AI Assistant', recipes: 'Recipes', drinks: 'Drinks', vocalToLocal: 'Vocal to Local', about: 'About', contact: 'Contact', settings: 'Settings' },
      hindi: { home: 'होम', aiAssistant: 'एआई सहायक', recipes: 'व्यंजन', drinks: 'पेय पदार्थ', vocalToLocal: 'स्थानीय व्यंजन', about: 'हमारे बारे में', contact: 'संपर्क करें', settings: 'सेटिंग्स' },
      tamil: { home: 'முகப்பு', aiAssistant: 'AI உதவியாளர்', recipes: 'சமையல் குறிப்புகள்', drinks: 'பானங்கள்', vocalToLocal: 'உள்ளூர் சமையல்', about: 'எங்களை பற்றி', contact: 'தொடர்பு', settings: 'அமைப்புகள்' },
      bengali: { home: 'হোম', aiAssistant: 'এআই সহায়ক', recipes: 'রেসিপি', drinks: 'পানীয়', vocalToLocal: 'স্থানীয় রান্না', about: 'আমাদের সম্পর্কে', contact: 'যোগাযোগ', settings: 'সেটিংস' },
      marathi: { home: 'मुख्यपृष्ठ', aiAssistant: 'एआय सहाय्यक', recipes: 'पाककृती', drinks: 'पेय', vocalToLocal: 'स्थानिक पाककृती', about: 'आमच्याबद्दल', contact: 'संपर्क', settings: 'सेटिंग्ज' },
      telugu: { home: 'హోమ్', aiAssistant: 'AI అసిస్టెంట్', recipes: 'వంటకాలు', drinks: 'పానీయాలు', vocalToLocal: 'స్థానిక వంటలు', about: 'మా గురించి', contact: 'సంప్రదించండి', settings: 'సెట్టింగ్స్' },
      gujarati: { home: 'હોમ', aiAssistant: 'AI સહાયક', recipes: 'વાનગીઓ', drinks: 'પીણાં', vocalToLocal: 'સ્થાનિક વાનગીઓ', about: 'અમારા વિશે', contact: 'સંપર્ક', settings: 'સેટિંગ્સ' },
      kannada: { home: 'ಮುಖಪುಟ', aiAssistant: 'AI ಸಹಾಯಕ', recipes: 'ಪಾಕವಿಧಾನಗಳು', drinks: 'ಪಾನೀಯಗಳು', vocalToLocal: 'ಸ್ಥಳೀಯ ಪಾಕ', about: 'ನಮ್ಮ ಬಗ್ಗೆ', contact: 'ಸಂಪರ್ಕಿಸಿ', settings: 'ಸೆಟ್ಟಿಂಗ್ಗಳು' }
    };
    const trans = translations[language] || translations.english;
    return [
      { name: trans.home, id: 'home' },
      { name: trans.aiAssistant, id: 'ai-assistant' },
      { name: trans.recipes, id: 'recipes' },
      { name: trans.drinks, id: 'drinks' },
      { name: trans.vocalToLocal, id: 'vocal-to-local' },
      { name: trans.about, id: 'about' },
      { name: trans.contact, id: 'contact' },
      { name: trans.settings, id: 'settings' },
    ];
  };
  
  const navItems = getNavItems();

  const handleNavigate = (page: string) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 mx-auto max-w-7xl">
        {/* Logo */}
        <button 
          onClick={() => handleNavigate('home')}
          className="flex items-center gap-2 hover:opacity-80 transition-opacity"
        >
          <div className="relative">
            <ChefHat className="h-8 w-8" style={{ color: isDeveloper ? 'purple' : 'var(--saffron)' }} />
            <motion.div
              className="absolute -right-1 -top-1 h-3 w-3 rounded-full"
              style={{ background: isDeveloper ? 'purple' : 'var(--tech-blue)' }}
              animate={{
                scale: [1, 1.2, 1],
                opacity: [1, 0.8, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          </div>
          <div className="flex flex-col">
            <span className="font-semibold text-xl">Rasoi Mate</span>
            {isDeveloper && (
              <span className="text-xs text-purple-500">Developer Mode</span>
            )}
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Button
              key={item.id}
              variant={currentPage === item.id ? 'default' : 'ghost'}
              onClick={() => handleNavigate(item.id)}
              className="relative"
              style={currentPage === item.id ? { 
                background: 'linear-gradient(135deg, var(--tech-blue), var(--tech-blue-light))'
              } : {}}
            >
              {item.name}
            </Button>
          ))}
        </nav>

        {/* Right side actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleDarkMode}
            className="rounded-full"
          >
            {darkMode ? (
              <Sun className="h-5 w-5" />
            ) : (
              <Moon className="h-5 w-5" />
            )}
          </Button>

          {isLoggedIn ? (
            <>
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-md bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-semibold text-sm">
                    {user?.name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                  <span className="text-sm font-medium">{user?.name || 'User'}</span>
                </div>
              </div>
              {isDeveloper && (
                <Button
                  variant="outline"
                  onClick={() => handleNavigate('admin-panel')}
                  className="hidden md:flex bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-purple-500/30"
                >
                  🛡️ Admin Panel
                </Button>
              )}
              <Button
                variant="outline"
                onClick={() => handleNavigate('dashboard')}
                className="hidden md:flex"
              >
                {t('dashboard')}
              </Button>
              <Button
                variant="ghost"
                onClick={onLogout}
                className="hidden md:flex"
              >
                {t('logout')}
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={() => handleNavigate('login')}
                className="hidden md:flex"
              >
                {t('login')}
              </Button>
              <Button
                onClick={() => handleNavigate('signup')}
                className="hidden md:flex"
                style={{ background: 'linear-gradient(135deg, var(--saffron), var(--saffron-light))' }}
              >
                {t('signup')}
              </Button>
            </>
          )}

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t bg-background"
          >
            <nav className="container flex flex-col gap-2 p-4 mx-auto max-w-7xl">
              {navItems.map((item) => (
                <Button
                  key={item.id}
                  variant={currentPage === item.id ? 'default' : 'ghost'}
                  onClick={() => handleNavigate(item.id)}
                  className="justify-start"
                  style={currentPage === item.id ? { 
                    background: 'linear-gradient(135deg, var(--tech-blue), var(--tech-blue-light))'
                  } : {}}
                >
                  {item.name}
                </Button>
              ))}
              {isLoggedIn ? (
                <>
                  <Button
                    variant="outline"
                    onClick={() => handleNavigate('dashboard')}
                    className="justify-start"
                  >
                    {t('dashboard')}
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={onLogout}
                    className="justify-start"
                  >
                    {t('logout')}
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    onClick={() => handleNavigate('login')}
                    className="justify-start"
                  >
                    {t('login')}
                  </Button>
                  <Button
                    onClick={() => handleNavigate('signup')}
                    className="justify-start"
                    style={{ background: 'linear-gradient(135deg, var(--saffron), var(--saffron-light))' }}
                  >
                    {t('signup')}
                  </Button>
                </>
              )}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
