import { motion } from 'motion/react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Clock, Users, Flame, ChefHat, Download, Volume2, Globe, 
  Lightbulb, VolumeX, MapPin, Star, Heart, BookOpen, ShoppingBag
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { generateRecipePDF, downloadHTMLRecipe } from './utils/pdfGenerator';
import { getFigmaSafeImage } from './utils/imagePlaceholder';

export interface DetailedRecipe {
  name: string;
  type: string;
  description: string;
  rural?: boolean;
  state: string;
  district: string;
  time?: string;
  servings?: string;
  difficulty?: string;
  ingredients: string[];
  steps: string[];
  alternatives?: {
    ingredient: string;
    substitutes: string[];
  }[];
  tips?: string[];
  culturalNote?: string;
  ingredientSourcing?: string;
  image?: string;
}

interface RecipeDetailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  recipe: DetailedRecipe | null;
}

const languages = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'हिंदी (Hindi)' },
  { code: 'ta', name: 'தமிழ் (Tamil)' },
  { code: 'te', name: 'తెలుగు (Telugu)' },
  { code: 'bn', name: 'বাংলা (Bengali)' },
  { code: 'mr', name: 'मराठी (Marathi)' },
  { code: 'gu', name: 'ગુજરાતી (Gujarati)' },
  { code: 'kn', name: 'ಕನ್ನಡ (Kannada)' },
  { code: 'ml', name: 'മലയാളം (Malayalam)' },
  { code: 'pa', name: 'ਪੰਜਾਬੀ (Punjabi)' },
];

export function RecipeDetailDialog({ open, onOpenChange, recipe }: RecipeDetailDialogProps) {
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [view3D, setView3D] = useState(false);

  useEffect(() => {
    // Stop speech when dialog closes
    if (!open && isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [open, isSpeaking]);

  if (!recipe) return null;

  const handleSpeak = (text: string) => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        toast.info('Voice playback stopped');
      } else {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = selectedLanguage === 'en' ? 'en-IN' : `${selectedLanguage}-IN`;
        utterance.rate = 0.9;
        utterance.pitch = 1;
        
        utterance.onend = () => {
          setIsSpeaking(false);
        };
        
        utterance.onerror = () => {
          setIsSpeaking(false);
          toast.error('Voice playback failed. Try selecting a different language.');
        };
        
        window.speechSynthesis.speak(utterance);
        setIsSpeaking(true);
        toast.success('Voice playback started', {
          description: `Playing in ${languages.find(l => l.code === selectedLanguage)?.name || 'English'}`
        });
      }
    } else {
      toast.error('Speech synthesis not supported in your browser');
    }
  };

  const handleSpeakAll = () => {
    const fullText = `
      Recipe: ${recipe.name}.
      ${recipe.description}.
      Time: ${recipe.time || 'As needed'}.
      Servings: ${recipe.servings || 'Multiple'}.
      Difficulty: ${recipe.difficulty || 'Medium'}.
      
      Ingredients:
      ${recipe.ingredients.map((ing, i) => `${i + 1}. ${ing}`).join('. ')}.
      
      Steps:
      ${recipe.steps.map((step, i) => `Step ${i + 1}. ${step}`).join('. ')}.
      
      ${recipe.tips ? `Tips: ${recipe.tips.join('. ')}` : ''}
    `;
    handleSpeak(fullText);
  };

  const handleDownload = (format: 'text' | 'html' = 'html') => {
    if (format === 'html') {
      downloadHTMLRecipe(recipe);
      toast.success('Recipe downloaded as HTML!', {
        description: 'Open the file and use File → Print → Save as PDF to create a beautifully formatted PDF',
      });
    } else {
      generateRecipePDF(recipe);
      toast.success('Recipe downloaded!', {
        description: 'Open with a text editor and print to PDF for best results',
      });
    }
  };

  const getDifficultyColor = (difficulty?: string) => {
    switch (difficulty?.toLowerCase()) {
      case 'easy': return '#4CAF50';
      case 'medium': return '#FF9933';
      case 'hard': return '#DC143C';
      default: return '#FF9933';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[95vh] p-0 overflow-hidden">
        <DialogHeader className="sr-only">
          <DialogTitle>{recipe.name}</DialogTitle>
          <DialogDescription>{recipe.description}</DialogDescription>
        </DialogHeader>
        <ScrollArea className="h-[95vh]" style={{ background: 'linear-gradient(135deg, #FFF8E1 0%, #FFFBF0 100%)' }}>
          <div className="p-6 space-y-6">
            {/* Header Section */}
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge style={{ 
                      background: recipe.rural ? '#4CAF50' : '#3F51B5',
                      color: 'white'
                    }}>
                      {recipe.rural ? '🌾 Rural' : '🏙️ Urban'}
                    </Badge>
                    <Badge variant="outline" style={{ borderColor: '#FF9933', color: '#FF9933' }}>
                      {recipe.type}
                    </Badge>
                  </div>
                  <h2 className="text-3xl mb-2" style={{ color: '#FF6B35' }}>
                    {recipe.name}
                  </h2>
                  <p className="text-base" style={{ color: '#666' }}>
                    {recipe.description}
                  </p>
                  <div className="flex items-center gap-2 mt-2" style={{ color: '#FF9933' }}>
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{recipe.district}, {recipe.state}</span>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex flex-col gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSpeakAll}
                    style={{ borderColor: '#FF9933', color: '#FF9933' }}
                    className="hover:bg-orange-50"
                  >
                    {isSpeaking ? (
                      <>
                        <VolumeX className="w-4 h-4 mr-2" />
                        Stop
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-4 h-4 mr-2" />
                        Speak All
                      </>
                    )}
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleDownload('html')}
                    style={{ background: 'linear-gradient(135deg, #4CAF50, #66BB6A)', color: 'white', border: 'none' }}
                    className="hover:opacity-90"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                  </Button>
                </div>
              </div>

              {/* Language Selector */}
              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4" style={{ color: '#FF9933' }} />
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select language" />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <span className="text-xs" style={{ color: '#666' }}>
                  For voice playback
                </span>
              </div>

              {/* Features Summary */}
              <div className="flex flex-wrap gap-2 p-3 rounded-lg" style={{ background: 'rgba(76, 175, 80, 0.1)' }}>
                <Badge variant="outline" className="text-xs" style={{ borderColor: '#FF9933', color: '#FF9933' }}>
                  <Volume2 className="w-3 h-3 mr-1" /> Voice Narration
                </Badge>
                <Badge variant="outline" className="text-xs" style={{ borderColor: '#4CAF50', color: '#4CAF50' }}>
                  <Download className="w-3 h-3 mr-1" /> PDF Download
                </Badge>
                <Badge variant="outline" className="text-xs" style={{ borderColor: '#3F51B5', color: '#3F51B5' }}>
                  <Globe className="w-3 h-3 mr-1" /> Multi-language
                </Badge>
                <Badge variant="outline" className="text-xs" style={{ borderColor: '#FFD700', color: '#FFD700' }}>
                  <Lightbulb className="w-3 h-3 mr-1" /> Substitutes Included
                </Badge>
              </div>
            </div>
              {/* Recipe Info Cards */}
              <div className="grid grid-cols-3 gap-3">
                <Card className="p-3 text-center">
                  <Clock className="w-5 h-5 mx-auto mb-2" style={{ color: '#FF9933' }} />
                  <div className="text-xs" style={{ color: '#666' }}>Time</div>
                  <div className="mt-1">{recipe.time || '30-45 mins'}</div>
                </Card>
                <Card className="p-3 text-center">
                  <Users className="w-5 h-5 mx-auto mb-2" style={{ color: '#FF9933' }} />
                  <div className="text-xs" style={{ color: '#666' }}>Servings</div>
                  <div className="mt-1">{recipe.servings || '4-6 people'}</div>
                </Card>
                <Card className="p-3 text-center">
                  <Flame className="w-5 h-5 mx-auto mb-2" style={{ color: getDifficultyColor(recipe.difficulty) }} />
                  <div className="text-xs" style={{ color: '#666' }}>Difficulty</div>
                  <div className="mt-1">{recipe.difficulty || 'Medium'}</div>
                </Card>
              </div>
              {/* Recipe Image */}
              {recipe.image && (
                <div className="rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src={getFigmaSafeImage(recipe.image)}
                    alt={recipe.name}
                    className="w-full h-64 object-cover"
                  />
                </div>
              )}

              {/* Cultural Note */}
              {recipe.culturalNote && (
                <Card className="p-4" style={{ background: 'linear-gradient(135deg, #FFF8E1 0%, #FFFBF0 100%)' }}>
                  <h3 className="mb-2 flex items-center gap-2" style={{ color: '#FF6B35' }}>
                    <BookOpen className="w-5 h-5" />
                    Cultural Significance
                  </h3>
                  <p style={{ color: '#666' }}>{recipe.culturalNote}</p>
                </Card>
              )}

              {/* Ingredient Sourcing */}
              {recipe.ingredientSourcing && (
                <Card className="p-4" style={{ background: '#E8F5E9' }}>
                  <h3 className="mb-2 flex items-center gap-2" style={{ color: '#4CAF50' }}>
                    <ShoppingBag className="w-5 h-5" />
                    Where to Source Ingredients
                  </h3>
                  <p style={{ color: '#666' }}>{recipe.ingredientSourcing}</p>
                </Card>
              )}

              {/* Ingredients Section */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl flex items-center gap-2" style={{ color: '#FF6B35' }}>
                    <ChefHat className="w-5 h-5" />
                    Ingredients
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSpeak(recipe.ingredients.join('. '))}
                  >
                    <Volume2 className="w-4 h-4" />
                  </Button>
                </div>
                <Card className="p-4">
                  <ul className="space-y-2">
                    {recipe.ingredients.map((ingredient, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="flex items-start gap-3"
                      >
                        <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-sm" 
                          style={{ background: '#FF9933', color: 'white' }}>
                          {index + 1}
                        </span>
                        <span>{ingredient}</span>
                      </motion.li>
                    ))}
                  </ul>
                </Card>
              </div>

              {/* Alternatives Section */}
              {recipe.alternatives && recipe.alternatives.length > 0 && (
                <div>
                  <h3 className="text-xl mb-4 flex items-center gap-2" style={{ color: '#4CAF50' }}>
                    <Lightbulb className="w-5 h-5" />
                    Ingredient Alternatives
                  </h3>
                  <Card className="p-4">
                    <div className="space-y-3">
                      {recipe.alternatives.map((alt, index) => (
                        <div key={index} className="pb-3 border-b last:border-b-0" style={{ borderColor: '#FFE4B5' }}>
                          <div className="mb-1" style={{ color: '#FF9933' }}>
                            {alt.ingredient}
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {alt.substitutes.map((sub, i) => (
                              <Badge key={i} variant="outline" style={{ borderColor: '#4CAF50', color: '#4CAF50' }}>
                                {sub}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </Card>
                </div>
              )}

              {/* Preparation Steps */}
              {recipe.steps && recipe.steps.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl flex items-center gap-2" style={{ color: '#FF6B35' }}>
                    <Star className="w-5 h-5" />
                    Preparation Steps
                  </h3>
                  <div className="flex items-center gap-2">
                    <Button
                      variant={view3D ? "default" : "outline"}
                      size="sm"
                      onClick={() => setView3D(!view3D)}
                      style={view3D ? { background: '#3F51B5', color: 'white' } : { borderColor: '#3F51B5', color: '#3F51B5' }}
                    >
                      {view3D ? '2D View' : '3D View'}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSpeak(recipe.steps.join('. '))}
                    >
                      <Volume2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                {!view3D ? (
                  <div className="space-y-4">
                    {recipe.steps.map((step, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.08 }}
                      >
                        <Card 
                          className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                          style={{
                            borderLeft: currentStep === index ? '4px solid #FF9933' : '4px solid transparent'
                          }}
                          onClick={() => setCurrentStep(index)}
                        >
                          <div className="flex gap-3">
                            <div className="flex-shrink-0">
                              <div 
                                className="w-8 h-8 rounded-full flex items-center justify-center"
                                style={{ background: '#FF9933', color: 'white' }}
                              >
                                {index + 1}
                              </div>
                            </div>
                            <div className="flex-1">
                              <p>{step}</p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSpeak(step);
                              }}
                            >
                              <Volume2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                ) : (
                  <Card className="p-8 bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-700">
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 style={{ color: '#3F51B5' }}>Interactive 3D Step Visualization</h4>
                          <p className="text-sm text-muted-foreground mt-1">
                            Step {currentStep + 1} of {recipe.steps.length}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                            disabled={currentStep === 0}
                          >
                            Previous
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setCurrentStep(Math.min(recipe.steps.length - 1, currentStep + 1))}
                            disabled={currentStep === recipe.steps.length - 1}
                          >
                            Next
                          </Button>
                        </div>
                      </div>

                      {/* 3D Visualization Canvas */}
                      <div className="relative w-full h-96 bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-gray-800 rounded-xl overflow-hidden border-2" style={{ borderColor: '#3F51B5' }}>
                        {/* 3D Scene */}
                        <div className="absolute inset-0 flex items-center justify-center">
                          <motion.div
                            key={currentStep}
                            initial={{ opacity: 0, scale: 0.8, rotateY: -90 }}
                            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                            transition={{ duration: 0.6, ease: 'easeOut' }}
                            className="text-center p-8"
                          >
                            {/* Visual representation based on step keywords */}
                            <div className="mb-6 relative perspective-1000">
                              <motion.div
                                animate={{ 
                                  rotateY: [0, 360],
                                  scale: [1, 1.1, 1]
                                }}
                                transition={{ 
                                  duration: 4,
                                  repeat: Infinity,
                                  ease: 'easeInOut'
                                }}
                                className="text-8xl mb-4"
                              >
                                {recipe.steps && recipe.steps[currentStep] ? (
                                  recipe.steps[currentStep].toLowerCase().includes('cut') || recipe.steps[currentStep].toLowerCase().includes('chop') ? '🔪' :
                                  recipe.steps[currentStep].toLowerCase().includes('boil') || recipe.steps[currentStep].toLowerCase().includes('cook') ? '🍲' :
                                  recipe.steps[currentStep].toLowerCase().includes('fry') ? '🍳' :
                                  recipe.steps[currentStep].toLowerCase().includes('mix') || recipe.steps[currentStep].toLowerCase().includes('blend') ? '🥄' :
                                  recipe.steps[currentStep].toLowerCase().includes('grind') ? '⚙️' :
                                  recipe.steps[currentStep].toLowerCase().includes('serve') || recipe.steps[currentStep].toLowerCase().includes('garnish') ? '🍽️' :
                                  '👨‍🍳'
                                ) : '👨‍🍳'}
                              </motion.div>
                              
                              {/* Floating particles */}
                              <div className="absolute inset-0 pointer-events-none">
                                {[...Array(6)].map((_, i) => (
                                  <motion.div
                                    key={i}
                                    className="absolute w-2 h-2 rounded-full"
                                    style={{
                                      background: i % 3 === 0 ? '#FF9933' : i % 3 === 1 ? '#4CAF50' : '#3F51B5',
                                      left: `${20 + i * 15}%`,
                                      top: `${30 + (i % 2) * 40}%`,
                                    }}
                                    animate={{
                                      y: [0, -20, 0],
                                      opacity: [0.3, 1, 0.3],
                                    }}
                                    transition={{
                                      duration: 2 + i * 0.3,
                                      repeat: Infinity,
                                      ease: 'easeInOut',
                                    }}
                                  />
                                ))}
                              </div>
                            </div>

                            <motion.div
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.3 }}
                              className="max-w-2xl mx-auto"
                            >
                              <Badge className="mb-4" style={{ background: '#3F51B5', color: 'white' }}>
                                Step {currentStep + 1}
                              </Badge>
                              <p className="text-lg">{recipe.steps[currentStep]}</p>
                            </motion.div>
                          </motion.div>
                        </div>

                        {/* Grid overlay for 3D effect */}
                        <div 
                          className="absolute inset-0 pointer-events-none opacity-10"
                          style={{
                            backgroundImage: 'linear-gradient(#3F51B5 1px, transparent 1px), linear-gradient(90deg, #3F51B5 1px, transparent 1px)',
                            backgroundSize: '30px 30px',
                          }}
                        />
                      </div>

                      {/* Step Progress */}
                      <div className="flex gap-2 justify-center flex-wrap">
                        {recipe.steps.map((_, index) => (
                          <button
                            key={index}
                            onClick={() => setCurrentStep(index)}
                            className="w-8 h-8 rounded-full flex items-center justify-center text-xs transition-all"
                            style={{
                              background: currentStep === index ? 'linear-gradient(135deg, #FF9933, #4CAF50)' : '#E5E7EB',
                              color: currentStep === index ? 'white' : '#6B7280',
                              transform: currentStep === index ? 'scale(1.2)' : 'scale(1)',
                            }}
                          >
                            {index + 1}
                          </button>
                        ))}
                      </div>

                      <div className="text-center text-sm text-muted-foreground">
                        💡 Use Previous/Next buttons or click step numbers to navigate
                      </div>
                    </div>
                  </Card>
                )}
              </div>
              )}

              {/* Chef's Tips */}
              {recipe.tips && recipe.tips.length > 0 && (
                <div>
                  <h3 className="text-xl mb-4 flex items-center gap-2" style={{ color: '#FFD700' }}>
                    <Heart className="w-5 h-5" />
                    Chef's Tips
                  </h3>
                  <Card className="p-4" style={{ background: '#FFFBF0' }}>
                    <ul className="space-y-2">
                      {recipe.tips.map((tip, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <span style={{ color: '#FFD700' }}>💡</span>
                          <span>{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </Card>
                </div>
              )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
