import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Cpu, 
  HardDrive, 
  Database, 
  Wifi, 
  Zap,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Activity,
  TrendingUp,
  Clock
} from 'lucide-react';
import { useState, useEffect } from 'react';

export function SystemStatusMonitor() {
  const [systemStatus, setSystemStatus] = useState({
    status: 'operational',
    uptime: '99.9%',
    responseTime: '45ms',
    activeConnections: 127,
    cpuUsage: 32,
    memoryUsage: 58,
    diskUsage: 42,
    apiHealth: {
      openai: 'operational',
      anthropic: 'operational',
      google: 'operational',
    },
    services: {
      database: 'operational',
      authentication: 'operational',
      storage: 'operational',
      email: 'operational',
    }
  });

  useEffect(() => {
    // Simulate real-time monitoring
    const interval = setInterval(() => {
      setSystemStatus(prev => ({
        ...prev,
        cpuUsage: Math.min(100, Math.max(10, prev.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.min(100, Math.max(20, prev.memoryUsage + (Math.random() - 0.5) * 5)),
        activeConnections: Math.max(50, Math.floor(prev.activeConnections + (Math.random() - 0.5) * 20)),
        responseTime: `${Math.floor(30 + Math.random() * 30)}ms`,
      }));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'operational': return 'text-green-500';
      case 'degraded': return 'text-yellow-500';
      case 'down': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'degraded': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'down': return <XCircle className="h-5 w-5 text-red-500" />;
      default: return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">System Status & Performance</h2>
        <p className="text-muted-foreground">Real-time monitoring of system health</p>
      </div>

      {/* Overall Status */}
      <Card className="p-6 border-2 border-green-500/50 bg-gradient-to-r from-green-500/5 to-transparent">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center">
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
            <div>
              <h3 className="text-2xl font-bold">All Systems Operational</h3>
              <p className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleTimeString()}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-green-500">{systemStatus.uptime}</p>
            <p className="text-sm text-muted-foreground">Uptime</p>
          </div>
        </div>
      </Card>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Cpu className="h-6 w-6 text-blue-500" />
            <div>
              <p className="text-sm text-muted-foreground">CPU Usage</p>
              <p className="text-2xl font-bold">{systemStatus.cpuUsage.toFixed(1)}%</p>
            </div>
          </div>
          <Progress value={systemStatus.cpuUsage} className="h-2" />
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Database className="h-6 w-6 text-purple-500" />
            <div>
              <p className="text-sm text-muted-foreground">Memory Usage</p>
              <p className="text-2xl font-bold">{systemStatus.memoryUsage.toFixed(1)}%</p>
            </div>
          </div>
          <Progress value={systemStatus.memoryUsage} className="h-2" />
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <HardDrive className="h-6 w-6 text-green-500" />
            <div>
              <p className="text-sm text-muted-foreground">Disk Usage</p>
              <p className="text-2xl font-bold">{systemStatus.diskUsage}%</p>
            </div>
          </div>
          <Progress value={systemStatus.diskUsage} className="h-2" />
        </Card>
      </div>

      {/* Network & Performance */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Wifi className="h-5 w-5" />
            Network Statistics
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Active Connections</span>
              <span className="font-semibold">{systemStatus.activeConnections}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Average Response Time</span>
              <Badge className="bg-green-500">{systemStatus.responseTime}</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Requests/min</span>
              <span className="font-semibold">1,234</span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <Zap className="h-5 w-5" />
            API Health Status
          </h3>
          <div className="space-y-3">
            {Object.entries(systemStatus.apiHealth).map(([key, status]) => (
              <div key={key} className="flex justify-between items-center">
                <span className="text-sm capitalize">{key} API</span>
                <div className="flex items-center gap-2">
                  {getStatusIcon(status)}
                  <span className={`text-sm font-medium capitalize ${getStatusColor(status)}`}>
                    {status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Services Status */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Core Services Status
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(systemStatus.services).map(([key, status]) => (
            <div key={key} className="p-4 rounded-lg border-2 border-green-500/20 bg-green-500/5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium capitalize">{key}</span>
                {getStatusIcon(status)}
              </div>
              <span className={`text-xs capitalize ${getStatusColor(status)}`}>
                {status}
              </span>
            </div>
          ))}
        </div>
      </Card>

      {/* Performance Trends */}
      <Card className="p-6">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Performance Trends (24h)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Peak Traffic</p>
            <p className="text-2xl font-bold">2,847</p>
            <p className="text-xs text-green-500">+12% from yesterday</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Avg Response Time</p>
            <p className="text-2xl font-bold">38ms</p>
            <p className="text-xs text-green-500">-5ms improvement</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Error Rate</p>
            <p className="text-2xl font-bold">0.02%</p>
            <p className="text-xs text-green-500">Within target</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
