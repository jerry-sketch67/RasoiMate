import { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { ScrollArea } from './ui/scroll-area';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, MicOff, Play, Pause, Trash2, Upload, Save, 
  Volume2, Check, AlertCircle, Sparkles, Heart
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface SpeakYourStoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  state?: string;
  district?: string;
}

export function SpeakYourStoryDialog({ open, onOpenChange, state, district }: SpeakYourStoryDialogProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [audioURL, setAudioURL] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [storyTitle, setStoryTitle] = useState('');
  const [storyDescription, setStoryDescription] = useState('');
  const [userName, setUserName] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (audioURL) {
        URL.revokeObjectURL(audioURL);
      }
    };
  }, [audioURL]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setAudioURL(url);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setIsPaused(false);
      
      // Start timer
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      toast.success('Recording started!');
    } catch (error) {
      console.error('Error accessing microphone:', error);
      toast.error('Could not access microphone. Please check permissions.');
    }
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      if (isPaused) {
        mediaRecorderRef.current.resume();
        setIsPaused(false);
        if (timerRef.current === null) {
          timerRef.current = window.setInterval(() => {
            setRecordingTime(prev => prev + 1);
          }, 1000);
        }
      } else {
        mediaRecorderRef.current.pause();
        setIsPaused(true);
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      }
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setIsPaused(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      toast.success('Recording stopped!');
    }
  };

  const playAudio = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const deleteRecording = () => {
    if (audioURL) {
      URL.revokeObjectURL(audioURL);
    }
    setAudioURL(null);
    setRecordingTime(0);
    setIsPlaying(false);
    setUploadedFile(null);
    toast.info('Recording deleted');
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type.startsWith('audio/')) {
        setUploadedFile(file);
        const url = URL.createObjectURL(file);
        setAudioURL(url);
        toast.success('Audio file uploaded!');
      } else {
        toast.error('Please upload an audio file');
      }
    }
  };

  const handleSubmit = () => {
    if (!audioURL || !storyTitle || !userName) {
      toast.error('Please fill in all required fields and record/upload audio');
      return;
    }

    // Store story in localStorage
    const stories = JSON.parse(localStorage.getItem('userStories') || '[]');
    const newStory = {
      id: Date.now(),
      title: storyTitle,
      description: storyDescription,
      userName,
      state: state || 'Unknown',
      district: district || 'Unknown',
      audioURL: audioURL,
      uploadedFileName: uploadedFile?.name || 'recording.webm',
      duration: formatTime(recordingTime),
      timestamp: new Date().toISOString(),
    };
    
    stories.push(newStory);
    localStorage.setItem('userStories', JSON.stringify(stories));

    toast.success('Your story has been saved! Thank you for sharing! 🎉');
    
    // Reset form
    setStoryTitle('');
    setStoryDescription('');
    setUserName('');
    deleteRecording();
    onOpenChange(false);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ background: '#FF9933' }}>
              <Mic className="w-6 h-6 text-white" />
            </div>
            <div>
              <DialogTitle className="text-2xl" style={{ color: '#FF6B35' }}>
                Share Your Food Story
              </DialogTitle>
              <DialogDescription>
                Record or upload your local food experience
                {state && district && (
                  <span className="ml-2" style={{ color: '#FF9933' }}>
                    • {district}, {state}
                  </span>
                )}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[calc(90vh-120px)] px-1">
          <div className="space-y-6 py-4">
            {/* User Information */}
            <Card className="p-4">
              <h3 className="mb-4 flex items-center gap-2" style={{ color: '#FF6B35' }}>
                <Heart className="w-5 h-5" />
                Your Information
              </h3>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="userName">Your Name *</Label>
                  <Input
                    id="userName"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="storyTitle">Story Title *</Label>
                  <Input
                    id="storyTitle"
                    value={storyTitle}
                    onChange={(e) => setStoryTitle(e.target.value)}
                    placeholder="e.g., My Grandmother's Secret Recipe"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="storyDescription">Story Description (Optional)</Label>
                  <Textarea
                    id="storyDescription"
                    value={storyDescription}
                    onChange={(e) => setStoryDescription(e.target.value)}
                    placeholder="Tell us about your food memory, tradition, or experience..."
                    className="mt-1 h-24"
                  />
                </div>
              </div>
            </Card>

            {/* Recording Controls */}
            <Card className="p-6" style={{ background: 'linear-gradient(135deg, #FFF8E1 0%, #FFFBF0 100%)' }}>
              <h3 className="mb-4 flex items-center gap-2" style={{ color: '#FF6B35' }}>
                <Sparkles className="w-5 h-5" />
                Record Your Audio Story
              </h3>

              <div className="space-y-4">
                {/* Recording Status */}
                <AnimatePresence>
                  {isRecording && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="flex items-center justify-center gap-3 p-4 rounded-lg"
                      style={{ background: isPaused ? '#FFE4B5' : '#FFE8E8' }}
                    >
                      <motion.div
                        animate={{ scale: isPaused ? 1 : [1, 1.2, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                        className="w-4 h-4 rounded-full"
                        style={{ background: isPaused ? '#FF9933' : '#DC143C' }}
                      />
                      <span className="text-lg">
                        {isPaused ? 'Recording Paused' : 'Recording...'}
                      </span>
                      <Badge variant="outline" style={{ borderColor: '#FF9933', color: '#FF9933' }}>
                        {formatTime(recordingTime)}
                      </Badge>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Control Buttons */}
                <div className="flex flex-wrap justify-center gap-3">
                  {!isRecording && !audioURL && (
                    <Button
                      onClick={startRecording}
                      size="lg"
                      style={{ background: '#DC143C', color: 'white' }}
                      className="hover:opacity-90"
                    >
                      <Mic className="w-5 h-5 mr-2" />
                      Start Recording
                    </Button>
                  )}

                  {isRecording && (
                    <>
                      <Button
                        onClick={pauseRecording}
                        variant="outline"
                        size="lg"
                        style={{ borderColor: '#FF9933', color: '#FF9933' }}
                      >
                        {isPaused ? (
                          <>
                            <Play className="w-5 h-5 mr-2" />
                            Resume
                          </>
                        ) : (
                          <>
                            <Pause className="w-5 h-5 mr-2" />
                            Pause
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={stopRecording}
                        variant="outline"
                        size="lg"
                        style={{ borderColor: '#4CAF50', color: '#4CAF50' }}
                      >
                        <MicOff className="w-5 h-5 mr-2" />
                        Stop Recording
                      </Button>
                    </>
                  )}

                  {audioURL && !isRecording && (
                    <>
                      <Button
                        onClick={playAudio}
                        variant="outline"
                        size="lg"
                        style={{ borderColor: '#3F51B5', color: '#3F51B5' }}
                      >
                        {isPlaying ? (
                          <>
                            <Pause className="w-5 h-5 mr-2" />
                            Pause
                          </>
                        ) : (
                          <>
                            <Play className="w-5 h-5 mr-2" />
                            Play
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={deleteRecording}
                        variant="outline"
                        size="lg"
                        style={{ borderColor: '#DC143C', color: '#DC143C' }}
                      >
                        <Trash2 className="w-5 h-5 mr-2" />
                        Delete
                      </Button>
                    </>
                  )}
                </div>

                {/* File Upload Option */}
                {!audioURL && !isRecording && (
                  <div className="pt-4 border-t" style={{ borderColor: '#FFE4B5' }}>
                    <Label htmlFor="audioUpload" className="block mb-2 text-center">
                      Or upload an audio file
                    </Label>
                    <div className="flex justify-center">
                      <label
                        htmlFor="audioUpload"
                        className="cursor-pointer inline-flex items-center gap-2 px-6 py-3 rounded-lg border-2 border-dashed hover:border-solid transition-all"
                        style={{ borderColor: '#FF9933', color: '#FF9933' }}
                      >
                        <Upload className="w-5 h-5" />
                        <span>Upload Audio File</span>
                      </label>
                      <input
                        id="audioUpload"
                        type="file"
                        accept="audio/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>
                  </div>
                )}

                {/* Audio Player */}
                {audioURL && (
                  <audio
                    ref={audioRef}
                    src={audioURL}
                    onEnded={() => setIsPlaying(false)}
                    onPlay={() => setIsPlaying(true)}
                    onPause={() => setIsPlaying(false)}
                    className="hidden"
                  />
                )}
              </div>
            </Card>

            {/* Tips Card */}
            <Card className="p-4" style={{ background: '#E8F5E9' }}>
              <h4 className="mb-2 flex items-center gap-2" style={{ color: '#4CAF50' }}>
                <AlertCircle className="w-4 h-4" />
                Tips for a Great Story
              </h4>
              <ul className="space-y-1 text-sm" style={{ color: '#666' }}>
                <li>• Speak clearly and at a comfortable pace</li>
                <li>• Share personal memories or family traditions</li>
                <li>• Mention unique ingredients or cooking techniques</li>
                <li>• Describe the cultural significance of the dish</li>
                <li>• Keep it authentic and from the heart</li>
              </ul>
            </Card>

            {/* Submit Button */}
            <div className="flex justify-end gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                style={{ background: '#4CAF50', color: 'white' }}
                className="hover:opacity-90"
                disabled={!audioURL || !storyTitle || !userName}
              >
                <Check className="w-4 h-4 mr-2" />
                Submit Story
              </Button>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
