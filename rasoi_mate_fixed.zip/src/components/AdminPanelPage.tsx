import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { ScrollArea } from './ui/scroll-area';
import { setFeatureFlag } from '../utils/firebaseHelpers';
import { useSiteSettings, useFeatureFlags, useLiveRecipes } from '../hooks/useFirebaseHooks';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';
import { 
  Shield, 
  Users, 
  Activity, 
  Settings, 
  Database,
  Key,
  FileText,
  BarChart3,
  ChefHat,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  RefreshCw,
  Eye,
  EyeOff,
  Save,
  X,
  Check,
  TrendingUp,
  Clock,
  Mail,
  Globe,
  Palette,
  Code,
  Zap,
  Lock,
  Unlock,
  Download,
  Upload,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Copy,
  Sparkles,
  Info
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { useAuth } from './AuthContext';
import { mockRecipes } from './RecipesPage';

interface Recipe {
  id: number;
  name: string;
  time: string;
  difficulty: string;
  region: string;
  diet: string;
  rating: number;
  reviews: number;
  cooked: number;
  baseServings: number;
  description?: string;
  image?: string;
  ingredients: Array<{
    name: string;
    amount: number;
    unit: string;
  }>;
  steps: string[];
  status: 'active' | 'archived' | 'draft';
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  newlyAdded?: boolean;
}

interface FeatureToggle {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  category: string;
}

interface APIKey {
  id: string;
  name: string;
  key: string;
  provider: string;
  status: 'active' | 'inactive';
  createdAt: string;
  lastUsed?: string;
}

export function AdminPanelPage() {
  // Firebase live hooks
  const siteSettings = useSiteSettings();
  const featureFlags = useFeatureFlags();
  const liveRecipes = useLiveRecipes(200);

  // update local features from featureFlags when they change
  useEffect(()=>{
    if(featureFlags) {
      const fArr = Object.keys(featureFlags).map(k=>({ id:k, name:k, description:'', enabled: featureFlags[k], category:'core' }));
      setFeatures(fArr);
    }
  }, [featureFlags]);

  // Toggle a feature flag in Firestore
  const handleToggleFeature = async (id:string, current:boolean) => {
    try {
      await setFeatureFlag(id, !current);
      toast.success(`Feature ${id} set to ${!current}`);
    } catch(e){ console.error(e); toast.error('Failed to update flag'); }
  };

  const { user, getAllUsers, getTotalUsers, getActiveUsers } = useAuth();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterRegion, setFilterRegion] = useState('all');
  const [editingRecipe, setEditingRecipe] = useState<Recipe | null>(null);
  const [isAddingRecipe, setIsAddingRecipe] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // Feature Toggles
  const [features, setFeatures] = useState<FeatureToggle[]>(featureFlags && Object.keys(featureFlags).length ? Object.keys(featureFlags).map(k=>({ id:k, name:k, description:'', enabled: featureFlags[k], category:'core' })) : [
    { id: 'ai-assistant', name: 'AI Assistant', description: 'Enable AI-powered cooking assistance', enabled: true, category: 'core' },
    { id: 'voice-commands', name: 'Voice Commands', description: 'Allow voice input for recipes', enabled: true, category: 'core' },
    { id: 'recipe-sharing', name: 'Recipe Sharing', description: 'Let users share recipes', enabled: true, category: 'social' },
    { id: 'user-contributions', name: 'User Contributions', description: 'Allow users to submit recipes', enabled: true, category: 'community' },
    { id: 'ingredient-alternatives', name: 'Ingredient Alternatives', description: 'Suggest ingredient substitutes', enabled: true, category: 'core' },
    { id: 'multi-language', name: 'Multi-Language Support', description: 'Enable 8 language translations', enabled: true, category: 'core' },
    { id: 'dark-mode', name: 'Dark Mode', description: 'Theme switching capability', enabled: true, category: 'ui' },
    { id: 'notifications', name: 'Email Notifications', description: 'Send email updates to users', enabled: true, category: 'communication' },
  ]);

  // API Keys
  const [apiKeys, setApiKeys] = useState<APIKey[]>([
    { id: '1', name: 'OpenAI API', key: 'sk-proj-...', provider: 'OpenAI', status: 'active', createdAt: new Date().toISOString() },
    { id: '2', name: 'Anthropic API', key: 'sk-ant-...', provider: 'Anthropic', status: 'active', createdAt: new Date().toISOString() },
    { id: '3', name: 'Google AI API', key: 'AIza...', provider: 'Google', status: 'active', createdAt: new Date().toISOString() },
  ]);

  // Site Settings
  const [siteSettings, setSiteSettings] = useState({
    siteName: 'Rasoi Mate',
    tagline: 'Your AI-Powered Kitchen Companion',
    primaryColor: '#FF9933',
    secondaryColor: '#4CAF50',
    accentColor: '#3F51B5',
    maintenanceMode: false,
    registrationOpen: true,
    maxRecipesPerUser: 100,
    emailNotifications: true,
  });

  // New Recipe Form
  const [newRecipe, setNewRecipe] = useState({
    name: '',
    description: '',
    time: '',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    baseServings: 4,
    ingredients: '',
    steps: '',
    image: ''
  });

  // System Logs
  const [systemLogs, setSystemLogs] = useState([
    { id: '1', type: 'info', message: 'System started successfully', timestamp: new Date().toISOString() },
    { id: '2', type: 'success', message: 'Database connection established', timestamp: new Date().toISOString() },
    { id: '3', type: 'warning', message: 'High memory usage detected', timestamp: new Date().toISOString() },
  ]);

  useEffect(() => {
    loadRecipes();
    const interval = setInterval(() => {
      setRefreshKey(prev => prev + 1);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadRecipes = () => {
    const storedRecipes = localStorage.getItem('adminRecipes');
    if (storedRecipes) {
      setRecipes(JSON.parse(storedRecipes));
    } else {
      const initialRecipes = mockRecipes.map((r, i) => ({
        ...r,
        status: 'active' as const,
        createdBy: 'Admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        description: `Delicious ${r.name} recipe`,
        ingredients: [
          { name: 'Main ingredient', amount: 2, unit: 'cups' },
          { name: 'Spices', amount: 1, unit: 'tsp' },
        ],
        steps: ['Prepare ingredients', 'Cook as directed', 'Serve hot']
      }));
      setRecipes(initialRecipes);
      localStorage.setItem('adminRecipes', JSON.stringify(initialRecipes));
    }
  };

  const saveRecipes = (updatedRecipes: Recipe[]) => {
    setRecipes(updatedRecipes);
    localStorage.setItem('adminRecipes', JSON.stringify(updatedRecipes));
  };

  const handleAddRecipe = () => {
    if (!newRecipe.name || !newRecipe.time) {
      toast.error('Please fill in required fields');
      return;
    }

    const recipe: Recipe = {
      id: Date.now(),
      name: newRecipe.name,
      time: newRecipe.time,
      difficulty: newRecipe.difficulty,
      region: newRecipe.region,
      diet: newRecipe.diet,
      rating: 0,
      reviews: 0,
      cooked: 0,
      baseServings: newRecipe.baseServings,
      description: newRecipe.description,
      image: newRecipe.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c',
      ingredients: newRecipe.ingredients.split('\n').map(i => {
        const parts = i.trim().split(' ');
        return {
          name: parts.slice(2).join(' ') || i,
          amount: parseFloat(parts[0]) || 1,
          unit: parts[1] || 'unit'
        };
      }),
      steps: newRecipe.steps.split('\n').filter(s => s.trim()),
      status: 'active',
      createdBy: user?.name || 'Admin',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    saveRecipes([...recipes, recipe]);
    setIsAddingRecipe(false);
    setNewRecipe({
      name: '', description: '', time: '', difficulty: 'Medium',
      region: 'North Indian', diet: 'Vegetarian', baseServings: 4,
      ingredients: '', steps: '', image: ''
    });
    toast.success('Recipe added successfully! 🎉');
  };

  const handleUpdateRecipe = () => {
    if (!editingRecipe) return;
    
    const updatedRecipes = recipes.map(r => 
      r.id === editingRecipe.id 
        ? { ...editingRecipe, updatedAt: new Date().toISOString() }
        : r
    );
    saveRecipes(updatedRecipes);
    setEditingRecipe(null);
    toast.success('Recipe updated successfully! ✓');
  };

  const handleDeleteRecipe = (id: number) => {
    const updatedRecipes = recipes.filter(r => r.id !== id);
    saveRecipes(updatedRecipes);
    toast.success('Recipe deleted successfully');
  };

  const handleArchiveRecipe = (id: number) => {
    const updatedRecipes = recipes.map(r =>
      r.id === id ? { ...r, status: 'archived' as const, updatedAt: new Date().toISOString() } : r
    );
    saveRecipes(updatedRecipes);
    toast.success('Recipe archived');
  };

  const handleReviveRecipe = (id: number) => {
    const updatedRecipes = recipes.map(r =>
      r.id === id ? { ...r, status: 'active' as const, updatedAt: new Date().toISOString() } : r
    );
    saveRecipes(updatedRecipes);
    toast.success('Recipe revived! 🎉');
  };

  const toggleFeature = (featureId: string) => {
    const updatedFeatures = features.map(f =>
      f.id === featureId ? { ...f, enabled: !f.enabled } : f
    );
    setFeatures(updatedFeatures);
    localStorage.setItem('featureToggles', JSON.stringify(updatedFeatures));
    toast.success(`Feature ${updatedFeatures.find(f => f.id === featureId)?.enabled ? 'enabled' : 'disabled'}`);
  };

  const handleSaveApiKey = (key: APIKey) => {
    const updatedKeys = apiKeys.map(k => k.id === key.id ? key : k);
    setApiKeys(updatedKeys);
    localStorage.setItem('apiKeys', JSON.stringify(updatedKeys));
    toast.success('API key updated');
  };

  const handleCopyApiKey = (key: string) => {
    navigator.clipboard.writeText(key);
    toast.success('API key copied to clipboard');
  };

  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || recipe.status === filterStatus;
    const matchesRegion = filterRegion === 'all' || recipe.region === filterRegion;
    return matchesSearch && matchesStatus && matchesRegion;
  });

  const allUsers = getAllUsers();
  const stats = {
    totalUsers: getTotalUsers(),
    activeUsers: getActiveUsers(),
    totalRecipes: recipes.length,
    activeRecipes: recipes.filter(r => r.status === 'active').length,
    archivedRecipes: recipes.filter(r => r.status === 'archived').length,
    totalViews: recipes.reduce((sum, r) => sum + (r.cooked || 0), 0),
  };

  if (!user || !user.isDeveloper) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-accent/20">
        <Card className="p-8 text-center max-w-md">
          <Lock className="h-16 w-16 mx-auto mb-4 text-red-500" />
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground mb-4">This admin panel is restricted to authorized developers only.</p>
          <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
            Developer Access Required
          </Badge>
        </Card>
      </div>
    );
  }

  const renderSidebar = () => (
    <div className="w-64 bg-gradient-to-b from-purple-900 to-blue-900 text-white p-6 min-h-screen">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="h-8 w-8" />
          <h1 className="text-xl font-bold">Admin Panel</h1>
        </div>
        <p className="text-xs text-purple-200">{user.name}</p>
        <Badge className="mt-2 bg-white/20 text-white text-xs">Developer</Badge>
      </div>

      <nav className="space-y-2">
        {[
          { id: 'dashboard', icon: BarChart3, label: 'Dashboard' },
          { id: 'recipes', icon: ChefHat, label: 'Recipe Manager' },
          { id: 'newly-added', icon: Sparkles, label: 'Newly Added Recipes' },
          { id: 'users', icon: Users, label: 'User Management' },
          { id: 'features', icon: Zap, label: 'Feature Toggles' },
          { id: 'settings', icon: Settings, label: 'Site Settings' },
          { id: 'logs', icon: FileText, label: 'System Logs' },
          { id: 'analytics', icon: TrendingUp, label: 'Analytics' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => setActiveSection(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
              activeSection === item.id
                ? 'bg-white text-purple-900 font-semibold shadow-lg'
                : 'hover:bg-white/10 text-purple-100'
            }`}
          >
            <item.icon className="h-5 w-5" />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );

  const renderDashboard = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Dashboard Overview</h2>
        <p className="text-muted-foreground">Real-time system metrics and analytics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 border-2 hover:border-purple-500/50 transition-all">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-500/10 flex items-center justify-center">
              <Users className="h-6 w-6 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.totalUsers}</p>
              <p className="text-sm text-muted-foreground">Total Users</p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-2 hover:border-green-500/50 transition-all">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500/20 to-green-500/10 flex items-center justify-center">
              <Activity className="h-6 w-6 text-green-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.activeUsers}</p>
              <p className="text-sm text-muted-foreground">Active Now</p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-2 hover:border-blue-500/50 transition-all">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500/20 to-blue-500/10 flex items-center justify-center">
              <ChefHat className="h-6 w-6 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.activeRecipes}</p>
              <p className="text-sm text-muted-foreground">Active Recipes</p>
            </div>
          </div>
        </Card>

        <Card className="p-6 border-2 hover:border-yellow-500/50 transition-all">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500/20 to-yellow-500/10 flex items-center justify-center">
              <Eye className="h-6 w-6 text-yellow-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{stats.totalViews}</p>
              <p className="text-sm text-muted-foreground">Total Views</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card className="p-6">
        <h3 className="text-xl font-semibold mb-4">Recent System Activity</h3>
        <div className="space-y-3">
          {systemLogs.slice(0, 5).map(log => (
            <div key={log.id} className="flex items-start gap-3 p-3 rounded-lg bg-accent/50">
              <div className={`w-2 h-2 rounded-full mt-2 ${
                log.type === 'success' ? 'bg-green-500' :
                log.type === 'warning' ? 'bg-yellow-500' :
                log.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
              }`} />
              <div className="flex-1">
                <p className="text-sm font-medium">{log.message}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(log.timestamp).toLocaleString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );

  const renderRecipeManager = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold mb-2">Recipe Management</h2>
          <p className="text-muted-foreground">Full CRUD control over all recipes</p>
        </div>
        <Button
          onClick={() => setIsAddingRecipe(true)}
          className="bg-gradient-to-r from-purple-500 to-blue-500"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add New Recipe
        </Button>
      </div>

      {/* Filters */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search recipes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterRegion} onValueChange={setFilterRegion}>
            <SelectTrigger>
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="North Indian">North Indian</SelectItem>
              <SelectItem value="South Indian">South Indian</SelectItem>
              <SelectItem value="East Indian">East Indian</SelectItem>
              <SelectItem value="West Indian">West Indian</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Recipe List */}
      <Card className="p-6">
        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-4">
            {filteredRecipes.map(recipe => (
              <Card key={recipe.id} className="p-4 border-2 hover:border-purple-500/50 transition-all">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold">{recipe.name}</h3>
                      <Badge className={
                        recipe.status === 'active' ? 'bg-green-500' :
                        recipe.status === 'archived' ? 'bg-gray-500' : 'bg-yellow-500'
                      }>
                        {recipe.status}
                      </Badge>
                      <Badge variant="outline">{recipe.region}</Badge>
                      <Badge variant="outline">{recipe.diet}</Badge>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm text-muted-foreground">
                      <div>
                        <Clock className="h-4 w-4 inline mr-1" />
                        {recipe.time}
                      </div>
                      <div>Difficulty: {recipe.difficulty}</div>
                      <div>Cooked: {recipe.cooked} times</div>
                      <div>Rating: {recipe.rating}/5</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingRecipe(recipe)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    {recipe.status === 'archived' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleReviveRecipe(recipe.id)}
                        className="text-green-500"
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleArchiveRecipe(recipe.id)}
                      >
                        <Archive className="h-4 w-4" />
                      </Button>
                    )}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="outline" className="text-red-500">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Recipe</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete "{recipe.name}"? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => handleDeleteRecipe(recipe.id)}>
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </Card>

      {/* Add Recipe Dialog */}
      <AnimatePresence>
        {isAddingRecipe && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setIsAddingRecipe(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-background rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-bold">Add New Recipe</h3>
                <Button size="sm" variant="ghost" onClick={() => setIsAddingRecipe(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <Label>Recipe Name *</Label>
                  <Input
                    value={newRecipe.name}
                    onChange={(e) => setNewRecipe({ ...newRecipe, name: e.target.value })}
                    placeholder="e.g., Paneer Butter Masala"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Cooking Time *</Label>
                    <Input
                      value={newRecipe.time}
                      onChange={(e) => setNewRecipe({ ...newRecipe, time: e.target.value })}
                      placeholder="e.g., 30 mins"
                    />
                  </div>
                  <div>
                    <Label>Difficulty</Label>
                    <Select
                      value={newRecipe.difficulty}
                      onValueChange={(value) => setNewRecipe({ ...newRecipe, difficulty: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Easy">Easy</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Region</Label>
                    <Select
                      value={newRecipe.region}
                      onValueChange={(value) => setNewRecipe({ ...newRecipe, region: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="North Indian">North Indian</SelectItem>
                        <SelectItem value="South Indian">South Indian</SelectItem>
                        <SelectItem value="East Indian">East Indian</SelectItem>
                        <SelectItem value="West Indian">West Indian</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Diet Type</Label>
                    <Select
                      value={newRecipe.diet}
                      onValueChange={(value) => setNewRecipe({ ...newRecipe, diet: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Vegetarian">Vegetarian</SelectItem>
                        <SelectItem value="Vegan">Vegan</SelectItem>
                        <SelectItem value="Non-Vegetarian">Non-Vegetarian</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={newRecipe.description}
                    onChange={(e) => setNewRecipe({ ...newRecipe, description: e.target.value })}
                    placeholder="Brief description of the recipe..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label>Ingredients (one per line: "2 cups rice")</Label>
                  <Textarea
                    value={newRecipe.ingredients}
                    onChange={(e) => setNewRecipe({ ...newRecipe, ingredients: e.target.value })}
                    placeholder="2 cups basmati rice&#10;1 tsp turmeric&#10;500g paneer"
                    rows={5}
                  />
                </div>

                <div>
                  <Label>Steps (one per line)</Label>
                  <Textarea
                    value={newRecipe.steps}
                    onChange={(e) => setNewRecipe({ ...newRecipe, steps: e.target.value })}
                    placeholder="Heat oil in a pan&#10;Add spices&#10;Cook until done"
                    rows={5}
                  />
                </div>

                <div className="flex gap-3">
                  <Button onClick={handleAddRecipe} className="flex-1">
                    <Save className="h-4 w-4 mr-2" />
                    Save Recipe
                  </Button>
                  <Button variant="outline" onClick={() => setIsAddingRecipe(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

  const renderUserManagement = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">User Management</h2>
        <p className="text-muted-foreground">Manage all registered users</p>
      </div>

      <Card className="p-6">
        <ScrollArea className="h-[700px] pr-4">
          <div className="space-y-4">
            {allUsers.map(u => (
              <Card key={u.id} className="p-4 border-2 hover:border-blue-500/50 transition-all">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold text-xl">
                      {u.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-lg">{u.name}</h3>
                        {u.isDeveloper && (
                          <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                            Developer
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{u.email}</p>
                      <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                        <span>Joined: {new Date(u.joinedDate).toLocaleDateString()}</span>
                        <span>Last Active: {new Date(u.lastLogin).toLocaleDateString()}</span>
                        <span>Recipes Cooked: {u.stats?.totalRecipesCooked || 0}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );

  const renderApiKeys = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">API Key Management</h2>
        <p className="text-muted-foreground">Configure AI provider API keys</p>
      </div>

      <div className="space-y-4">
        {apiKeys.map(key => (
          <Card key={key.id} className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-lg">{key.name}</h3>
                <p className="text-sm text-muted-foreground">{key.provider}</p>
              </div>
              <Badge className={key.status === 'active' ? 'bg-green-500' : 'bg-gray-500'}>
                {key.status}
              </Badge>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label>API Key</Label>
                <div className="flex gap-2">
                  <Input value={key.key} type="password" readOnly className="flex-1" />
                  <Button size="sm" variant="outline" onClick={() => handleCopyApiKey(key.key)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="text-xs text-muted-foreground">
                Created: {new Date(key.createdAt).toLocaleDateString()}
                {key.lastUsed && ` • Last Used: ${new Date(key.lastUsed).toLocaleDateString()}`}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderFeatureToggles = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Feature Toggles</h2>
        <p className="text-muted-foreground">Enable or disable platform features</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {features.map(feature => (
          <Card key={feature.id} className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold">{feature.name}</h3>
                  <Badge variant="outline" className="text-xs">{feature.category}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
              <Switch onCheckedChange={(val) => handleToggleFeature(f.id, f.enabled)}
                checked={feature.enabled}
                onCheckedChange={() => toggleFeature(feature.id)}
              />
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold mb-2">Site Settings</h2>
        <p className="text-muted-foreground">Configure global site settings</p>
      </div>

      <Card className="p-6 space-y-6">
        <div className="grid grid-cols-2 gap-6">
          <div>
            <Label>Site Name</Label>
            <Input value={siteSettings.siteName} readOnly />
          </div>
          <div>
            <Label>Tagline</Label>
            <Input value={siteSettings.tagline} readOnly />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-6">
          <div>
            <Label>Primary Color (Saffron)</Label>
            <Input type="color" value={siteSettings.primaryColor} readOnly />
          </div>
          <div>
            <Label>Secondary Color (Green)</Label>
            <Input type="color" value={siteSettings.secondaryColor} readOnly />
          </div>
          <div>
            <Label>Accent Color (Blue)</Label>
            <Input type="color" value={siteSettings.accentColor} readOnly />
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Maintenance Mode</p>
              <p className="text-sm text-muted-foreground">Temporarily disable the site for maintenance</p>
            </div>
            <Switch onCheckedChange={(val) => handleToggleFeature(f.id, f.enabled)} checked={siteSettings.maintenanceMode} />
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Open Registration</p>
              <p className="text-sm text-muted-foreground">Allow new users to sign up</p>
            </div>
            <Switch onCheckedChange={(val) => handleToggleFeature(f.id, f.enabled)} checked={siteSettings.registrationOpen} />
          </div>

          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div>
              <p className="font-medium">Email Notifications</p>
              <p className="text-sm text-muted-foreground">Send email updates to users</p>
            </div>
            <Switch onCheckedChange={(val) => handleToggleFeature(f.id, f.enabled)} checked={siteSettings.emailNotifications} />
          </div>
        </div>
      </Card>
    </div>
  );

  const renderLogs = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold mb-2">System Logs</h2>
          <p className="text-muted-foreground">Monitor system activity and errors</p>
        </div>
        <Button variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Logs
        </Button>
      </div>

      <Card className="p-6">
        <ScrollArea className="h-[600px] pr-4">
          <div className="space-y-3">
            {systemLogs.map(log => (
              <div key={log.id} className="flex items-start gap-4 p-4 rounded-lg bg-accent/50 border">
                <div className={`mt-1 ${
                  log.type === 'success' ? 'text-green-500' :
                  log.type === 'warning' ? 'text-yellow-500' :
                  log.type === 'error' ? 'text-red-500' : 'text-blue-500'
                }`}>
                  {log.type === 'success' ? <CheckCircle className="h-5 w-5" /> :
                   log.type === 'warning' ? <AlertTriangle className="h-5 w-5" /> :
                   log.type === 'error' ? <XCircle className="h-5 w-5" /> : <Activity className="h-5 w-5" />}
                </div>
                <div className="flex-1">
                  <p className="font-medium">{log.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(log.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </Card>
    </div>
  );

  const renderNewlyAddedRecipes = () => {
    const newlyAddedRecipes = recipes.filter(r => r.newlyAdded && r.status === 'active');
    
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Sparkles className="h-8 w-8 text-yellow-500" />
              Newly Added Recipes
            </h2>
            <p className="text-muted-foreground">Manage and feature recent recipe additions</p>
          </div>
          <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-lg px-4 py-2">
            {newlyAddedRecipes.length} New
          </Badge>
        </div>

        {newlyAddedRecipes.length === 0 ? (
          <Card className="p-12 text-center">
            <Sparkles className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">No Newly Added Recipes</h3>
            <p className="text-muted-foreground">Mark recipes as "newly added" to feature them here</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {newlyAddedRecipes.map(recipe => (
              <Card key={recipe.id} className="overflow-hidden hover:shadow-lg transition-all border-2 border-yellow-500/30">
                <div className="relative">
                  {recipe.image && (
                    <img 
                      src={recipe.image} 
                      alt={recipe.name}
                      className="w-full h-48 object-cover"
                    />
                  )}
                  <Badge className="absolute top-2 right-2 bg-yellow-500 text-white">
                    <Sparkles className="h-3 w-3 mr-1" />
                    New
                  </Badge>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-2">{recipe.name}</h3>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {recipe.time}
                    </span>
                    <Badge variant="outline">{recipe.difficulty}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                    {recipe.description || `Delicious ${recipe.name} recipe`}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      Added: {new Date(recipe.createdAt).toLocaleDateString()}
                    </span>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        const updatedRecipes = recipes.map(r =>
                          r.id === recipe.id ? { ...r, newlyAdded: false } : r
                        );
                        saveRecipes(updatedRecipes);
                        toast.success('Removed from newly added');
                      }}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Remove
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        <Card className="p-6 bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
          <h3 className="font-semibold mb-2 flex items-center gap-2">
            <Info className="h-5 w-5 text-yellow-600" />
            Manage Newly Added Status
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            Go to Recipe Manager to mark recipes as "newly added". These recipes will be featured on the Recipes page.
          </p>
          <Button onClick={() => setActiveSection('recipes')} className="bg-yellow-500 hover:bg-yellow-600">
            <ChefHat className="h-4 w-4 mr-2" />
            Go to Recipe Manager
          </Button>
        </Card>
      </div>
    );
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-background to-accent/10">
      {renderSidebar()}
      
      <div className="flex-1 p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
          >
            {activeSection === 'dashboard' && renderDashboard()}
            {activeSection === 'recipes' && renderRecipeManager()}
            {activeSection === 'newly-added' && renderNewlyAddedRecipes()}
            {activeSection === 'users' && renderUserManagement()}
            {activeSection === 'features' && renderFeatureToggles()}
            {activeSection === 'settings' && renderSettings()}
            {activeSection === 'logs' && renderLogs()}
            {activeSection === 'analytics' && renderDashboard()}
          </motion.div>
        </AnimatePresence>
      </div>
    <Footer />
    </div>
  );
{

// Missing import
import { Archive } from 'lucide-react';
import { Footer } from './Footer';
