import { motion } from 'motion/react';

/**
 * Reusable Kitchen Background Component
 * Warm gradient with floating kitchen emojis
 * Used across all pages except DrinksPage
 */
export function KitchenBackground() {
  return (
    <>
      {/* Modern Gradient Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50 via-yellow-50 to-green-50" />
        <div className="absolute inset-0 opacity-40" style={{
          backgroundImage: 'radial-gradient(circle at 30% 40%, rgba(255, 153, 51, 0.25) 0%, transparent 50%), radial-gradient(circle at 70% 70%, rgba(76, 175, 80, 0.25) 0%, transparent 50%)',
        }} />
      </div>

      {/* Floating Animated Kitchen Elements */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        {/* Kitchen Pan Icon - Top Left */}
        <motion.div
          className="absolute text-5xl"
          style={{
            top: '10%',
            left: '5%',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍳
        </motion.div>

        {/* Cooking Pot Icon - Top Right */}
        <motion.div
          className="absolute text-5xl"
          style={{
            top: '15%',
            right: '8%',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -15, 0],
            x: [0, 8, 0],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥘
        </motion.div>

        {/* Curry Bowl Icon - Middle Left */}
        <motion.div
          className="absolute text-5xl"
          style={{
            top: '45%',
            left: '10%',
            opacity: 0.2,
          }}
          animate={{
            y: [0, 18, 0],
            rotate: [0, -8, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍛
        </motion.div>

        {/* Salad Bowl Icon - Bottom Right */}
        <motion.div
          className="absolute text-5xl"
          style={{
            bottom: '20%',
            right: '12%',
            opacity: 0.2,
          }}
          animate={{
            rotate: [0, -10, 0],
            y: [0, 12, 0],
          }}
          transition={{
            duration: 7.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🥗
        </motion.div>

        {/* Noodle Bowl Icon - Bottom Left */}
        <motion.div
          className="absolute text-5xl"
          style={{
            bottom: '15%',
            left: '15%',
            opacity: 0.2,
          }}
          animate={{
            y: [0, -22, 0],
            x: [0, -10, 0],
          }}
          transition={{
            duration: 8.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          🍜
        </motion.div>
      </div>
    </>
  );
}
