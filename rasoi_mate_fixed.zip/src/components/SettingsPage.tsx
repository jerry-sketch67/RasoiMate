import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { Globe, Volume2, Bell, Moon, Sun, ChevronLeft, Shield, Info } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { toast } from 'sonner@2.0.3';
import { useState } from 'react';
import { Footer } from './Footer';
import { useSiteSettings } from '../hooks/useFirebaseHooks';
import { updateSiteSettings } from '../utils/firebaseHelpers';

interface SettingsPageProps {
  onNavigate: (page: string) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export function SettingsPage({ onNavigate, darkMode, onToggleDarkMode }: SettingsPageProps) {
  const currentSiteSettings = useSiteSettings();
  const saveSettings = async (newSettings:any) => { try { await updateSiteSettings(newSettings); toast.success('Site settings saved'); } catch(e){ console.error(e); toast.error('Failed to save settings'); } }

  const { language, setLanguage } = useLanguage();
  const [notifications, setNotifications] = useState(true);
  const [voiceEnabled, setVoiceEnabled] = useState(true);

  const handleLanguageChange = (newLang: string) => {
    setLanguage(newLang as any);
    toast.success('Language updated successfully');
  };

  const handleNotificationToggle = (value: boolean) => {
    setNotifications(value);
    toast.success(value ? 'Notifications enabled' : 'Notifications disabled');
  };

  const handleVoiceToggle = (value: boolean) => {
    setVoiceEnabled(value);
    toast.success(value ? 'Voice features enabled' : 'Voice features disabled');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => onNavigate('home')}
          className="mb-6"
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl mb-2">Settings</h1>
          <p className="text-muted-foreground">
            Customize your Rasoi Mate experience
          </p>
        </motion.div>

        {/* Settings Sections */}
        <div className="space-y-6">
          {/* Language Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                  <Globe className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl">Language</h2>
                  <p className="text-sm text-muted-foreground">Choose your preferred language</p>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="language-select" className="text-base">
                    Display Language
                  </Label>
                  <Select value={language} onValueChange={handleLanguageChange}>
                    <SelectTrigger id="language-select" className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">🇬🇧 English</SelectItem>
                      <SelectItem value="hindi">🇮🇳 हिंदी (Hindi)</SelectItem>
                      <SelectItem value="tamil">🇮🇳 தமிழ் (Tamil)</SelectItem>
                      <SelectItem value="bengali">🇮🇳 বাংলা (Bengali)</SelectItem>
                      <SelectItem value="marathi">🇮🇳 मराठी (Marathi)</SelectItem>
                      <SelectItem value="telugu">🇮🇳 తెలుగు (Telugu)</SelectItem>
                      <SelectItem value="gujarati">🇮🇳 ગુજરાતી (Gujarati)</SelectItem>
                      <SelectItem value="kannada">🇮🇳 ಕನ್ನಡ (Kannada)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-xs text-muted-foreground">
                  All recipes, instructions, and content will be shown in your selected language
                </p>
              </div>
            </Card>
          </motion.div>

          {/* Appearance Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                  {darkMode ? (
                    <Moon className="h-5 w-5 text-white" />
                  ) : (
                    <Sun className="h-5 w-5 text-white" />
                  )}
                </div>
                <div>
                  <h2 className="text-xl">Appearance</h2>
                  <p className="text-sm text-muted-foreground">Customize the look and feel</p>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="dark-mode" className="text-base">
                    Dark Mode
                  </Label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Switch between light and dark theme
                  </p>
                </div>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={onToggleDarkMode}
                />
              </div>
            </Card>
          </motion.div>

          {/* Voice & Audio Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center">
                  <Volume2 className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl">Voice & Audio</h2>
                  <p className="text-sm text-muted-foreground">Control voice features</p>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="voice-features" className="text-base">
                    Voice Input & Output
                  </Label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Enable microphone and speech features
                  </p>
                </div>
                <Switch
                  id="voice-features"
                  checked={voiceEnabled}
                  onCheckedChange={handleVoiceToggle}
                />
              </div>
            </Card>
          </motion.div>

          {/* Notifications Settings */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
                  <Bell className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl">Notifications</h2>
                  <p className="text-sm text-muted-foreground">Manage notification preferences</p>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications" className="text-base">
                    Push Notifications
                  </Label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Receive cooking tips and recipe suggestions
                  </p>
                </div>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={handleNotificationToggle}
                />
              </div>
            </Card>
          </motion.div>

          {/* About & Privacy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="h-10 w-10 rounded-full bg-gradient-to-br from-gray-500 to-gray-600 flex items-center justify-center">
                  <Info className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h2 className="text-xl">About & Privacy</h2>
                  <p className="text-sm text-muted-foreground">Legal information and policies</p>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-between"
                  onClick={() => onNavigate('privacy-policy')}
                >
                  <span>Privacy Policy</span>
                  <Shield className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-between"
                  onClick={() => onNavigate('terms-of-service')}
                >
                  <span>Terms of Service</span>
                  <Shield className="h-4 w-4" />
                </Button>
                <div className="pt-2 text-center text-sm text-muted-foreground">
                  <p>Rasoi Mate v1.0.0</p>
                  <p className="text-xs mt-1">© 2025 Rasoi Mate. All rights reserved.</p>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>
    <Footer />
    </div>
  );
{
