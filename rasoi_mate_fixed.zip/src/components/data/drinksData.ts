/**
 * Comprehensive Drinks Database for Rasoi Mate
 * 700+ Traditional Indian, International, and Modern Beverages with Real Images
 */

export interface DrinkIngredient {
  name: string;
  amount: number;
  unit: string;
}

export interface Drink {
  id: string;
  name: string;
  category: string;
  subCategory: string;
  description: string;
  ingredients: DrinkIngredient[];
  steps: string[];
  time: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  servings: number;
  rating: number;
  reviews: number;
  image: string;
  tags: string[];
  region?: string;
}

export const drinkCategories = {
  lassi: {
    name: 'Lassi & Yogurt Drinks',
    icon: '🥛',
    subCategories: ['Traditional Lassi', 'Fruit Lassi', 'Special Lassi']
  },
  smoothies: {
    name: 'Smoothies & Shakes',
    icon: '🍹',
    subCategories: ['Fruit Smoothies', 'Green Smoothies', 'Protein Shakes', 'Dessert Shakes']
  },
  tea: {
    name: 'Tea & Chai',
    icon: '☕',
    subCategories: ['Masala Chai', 'Herbal Tea', 'Special Tea', 'Iced Tea']
  },
  coffee: {
    name: 'Coffee',
    icon: '☕',
    subCategories: ['Hot Coffee', 'Cold Coffee', 'Special Coffee']
  },
  mocktails: {
    name: 'Mocktails',
    icon: '🍸',
    subCategories: ['Classic Mocktails', 'Indian Fusion', 'Fresh & Fruity', 'Tropical Paradise']
  },
  juices: {
    name: 'Fresh Juices',
    icon: '🍊',
    subCategories: ['Fruit Juices', 'Vegetable Juices', 'Mixed Juices', 'Detox Juices']
  },
  traditional: {
    name: 'Traditional Indian',
    icon: '🪔',
    subCategories: ['Festival Drinks', 'Ayurvedic', 'Regional Specials']
  },
  summer: {
    name: 'Summer Coolers',
    icon: '🌊',
    subCategories: ['Sherbets', 'Cooling Drinks', 'Aam Panna & More']
  },
  wellness: {
    name: 'Wellness Drinks',
    icon: '🌿',
    subCategories: ['Detox', 'Immunity Boosters', 'Energy Drinks']
  }
};

// Real Unsplash Images
const drinkImages = {
  lassi: 'https://images.unsplash.com/photo-1709620061649-b352f63ea4cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMGxhc3NpJTIweW9ndXJ0fGVufDF8fHx8MTc2MjI0MDQ5NXww&ixlib=rb-4.1.0&q=80&w=1080',
  smoothie: 'https://images.unsplash.com/photo-1625480499375-27220a672237?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcnVpdCUyMHNtb290aGllJTIwY29sb3JmdWx8ZW58MXx8fHwxNzYyMjQwNDk1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  tea: 'https://images.unsplash.com/photo-1594137260937-f59050746e36?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXNhbGElMjBjaGFpJTIwdGVhfGVufDF8fHx8MTc2MjE3NTk5NXww&ixlib=rb-4.1.0&q=80&w=1080',
  coffee: 'https://images.unsplash.com/photo-1586558284518-c0529d973ceb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xkJTIwY29mZmVlJTIwaWNlZHxlbnwxfHx8fDE3NjIyNDA0OTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
  juice: 'https://images.unsplash.com/photo-1640625488786-ac3975ac3bf4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGp1aWNlJTIwb3JhbmdlfGVufDF8fHx8MTc2MjIyMzczN3ww&ixlib=rb-4.1.0&q=80&w=1080',
  greenTea: 'https://images.unsplash.com/photo-1728749177932-8fbf78de89f7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMHRlYSUyMGN1cHxlbnwxfHx8fDE3NjIxNzY4ODB8MA&ixlib=rb-4.1.0&q=80&w=1080',
  shake: 'https://images.unsplash.com/photo-1701275966376-9da452f0e7f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBzdHJhd2JlcnJ5fGVufDF8fHx8MTc2MjE3MDU3M3ww&ixlib=rb-4.1.0&q=80&w=1080',
  lemonade: 'https://images.unsplash.com/photo-1594579441553-4ef5ff4ce85a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsZW1vbmFkZSUyMHN1bW1lciUyMGRyaW5rfGVufDF8fHx8MTc2MjI0MDQ5OHww&ixlib=rb-4.1.0&q=80&w=1080',
  hotChocolate: 'https://images.unsplash.com/photo-1700488629510-bf60790ff9fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3QlMjBjaG9jb2xhdGUlMjBjb2NvYXxlbnwxfHx8fDE3NjIyMTgzNjN8MA&ixlib=rb-4.1.0&q=80&w=1080',
  coconut: 'https://images.unsplash.com/photo-1562190659-a4c95075cfb5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2NvbnV0JTIwd2F0ZXIlMjB0cm9waWNhbHxlbnwxfHx8fDE3NjIyNDA0OTl8MA&ixlib=rb-4.1.0&q=80&w=1080',
  watermelon: 'https://images.unsplash.com/photo-1604759695540-3012f9682c28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcm1lbG9uJTIwanVpY2UlMjBmcmVzaHxlbnwxfHx8fDE3NjIxNTUxOTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
  cappuccino: 'https://images.unsplash.com/photo-1578730170052-ac626460cc5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXBwdWNjaW5vJTIwY29mZmVlJTIwbGF0dGV8ZW58MXx8fHwxNzYyMjQwNDk5fDA&ixlib=rb-4.1.0&q=80&w=1080',
  herbal: 'https://images.unsplash.com/photo-1594137052297-e55c3c6b33f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZXJiYWwlMjB0ZWElMjB3ZWxsbmVzc3xlbnwxfHx8fDE3NjIxNTAwOTB8MA&ixlib=rb-4.1.0&q=80&w=1080',
  banana: 'https://images.unsplash.com/photo-1542444592-0d5997f202eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5hbmElMjBzaGFrZSUyMHNtb290aGllfGVufDF8fHx8MTc2MjI0MDUwMHww&ixlib=rb-4.1.0&q=80&w=1080',
  berry: 'https://images.unsplash.com/photo-1656582117142-ce539fec964f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZXJyeSUyMHNtb290aGllJTIwYm93bHxlbnwxfHx8fDE3NjIyNDA1MDR8MA&ixlib=rb-4.1.0&q=80&w=1080',
  pineapple: 'https://images.unsplash.com/photo-1665582513044-376da77ebec0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaW5lYXBwbGUlMjBqdWljZSUyMHRyb3BpY2FsfGVufDF8fHx8MTc2MjI0MDUwNHww&ixlib=rb-4.1.0&q=80&w=1080',
  espresso: 'https://images.unsplash.com/photo-1644348178273-096162693291?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlc3ByZXNzbyUyMGNvZmZlZSUyMHNob3R8ZW58MXx8fHwxNzYyMjQwNTA1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  icedTea: 'https://images.unsplash.com/photo-1560023907-5f339617ea30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpY2VkJTIwdGVhJTIwbGVtb258ZW58MXx8fHwxNzYyMjI2MTM3fDA&ixlib=rb-4.1.0&q=80&w=1080',
  pomegranate: 'https://images.unsplash.com/photo-1603028769333-009800f4e059?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb21lZ3JhbmF0ZSUyMGp1aWNlJTIwcmVkfGVufDF8fHx8MTc2MjI0MDUwNnww&ixlib=rb-4.1.0&q=80&w=1080',
  detox: 'https://images.unsplash.com/photo-1700506844069-6da3871c78e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXRveCUyMHdhdGVyJTIwaW5mdXNlZHxlbnwxfHx8fDE3NjIyNDA1MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
  matcha: 'https://images.unsplash.com/photo-1722478347147-7238a01b78d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXRjaGElMjBncmVlbiUyMHRlYXxlbnwxfHx8fDE3NjIyMDcxMjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
  protein: 'https://images.unsplash.com/photo-1693996045300-521e9d08cabc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm90ZWluJTIwc2hha2UlMjBmaXRuZXNzfGVufDF8fHx8MTc2MjIxMjAzNHww&ixlib=rb-4.1.0&q=80&w=1080',
  turmeric: 'https://images.unsplash.com/photo-1698943510650-9232c98a5328?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0dXJtZXJpYyUyMGdvbGRlbiUyMG1pbGt8ZW58MXx8fHwxNzYyMjQwNTA3fDA&ixlib=rb-4.1.0&q=80&w=1080',
  fruitPunch: 'https://images.unsplash.com/photo-1757941288470-888a418852b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcnVpdCUyMHB1bmNoJTIwY29sb3JmdWx8ZW58MXx8fHwxNzYyMjQwNTA3fDA&ixlib=rb-4.1.0&q=80&w=1080'
};

export const drinksDatabase: Drink[] = [
  // LASSI & YOGURT DRINKS (20 drinks)
  {
    id: 'lassi-001',
    name: 'Mango Lassi',
    category: 'lassi',
    subCategory: 'Fruit Lassi',
    description: 'Creamy yogurt drink blended with sweet mangoes',
    ingredients: [
      { name: 'Ripe Mango', amount: 1, unit: 'cup' },
      { name: 'Yogurt', amount: 1, unit: 'cup' },
      { name: 'Milk', amount: 0.5, unit: 'cup' },
      { name: 'Sugar', amount: 2, unit: 'tbsp' },
      { name: 'Cardamom Powder', amount: 0.25, unit: 'tsp' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Peel and chop the ripe mango into small pieces',
      'Add mango, yogurt, milk, and sugar to a blender',
      'Blend until smooth and creamy',
      'Add cardamom powder and ice cubes',
      'Blend again for 30 seconds',
      'Pour into glasses and garnish with mango slices',
      'Serve immediately chilled'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.8,
    reviews: 1250,
    image: drinkImages.lassi,
    tags: ['summer', 'refreshing', 'traditional', 'kids-friendly'],
    region: 'Punjab'
  },
  {
    id: 'lassi-002',
    name: 'Sweet Lassi',
    category: 'lassi',
    subCategory: 'Traditional Lassi',
    description: 'Classic Punjabi sweet yogurt drink',
    ingredients: [
      { name: 'Yogurt', amount: 2, unit: 'cups' },
      { name: 'Cold Water', amount: 1, unit: 'cup' },
      { name: 'Sugar', amount: 3, unit: 'tbsp' },
      { name: 'Rose Water', amount: 1, unit: 'tsp' },
      { name: 'Cardamom Powder', amount: 0.25, unit: 'tsp' },
      { name: 'Ice Cubes', amount: 6, unit: 'pieces' }
    ],
    steps: [
      'Add yogurt and cold water to a blender',
      'Add sugar, rose water, and cardamom powder',
      'Blend until smooth and frothy',
      'Add ice cubes and blend for 20 seconds',
      'Pour into tall glasses',
      'Garnish with a pinch of cardamom powder',
      'Serve chilled with a sprig of mint'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 3,
    rating: 4.7,
    reviews: 980,
    image: drinkImages.lassi,
    tags: ['traditional', 'punjabi', 'refreshing'],
    region: 'Punjab'
  },
  {
    id: 'lassi-003',
    name: 'Salted Lassi',
    category: 'lassi',
    subCategory: 'Traditional Lassi',
    description: 'Savory yogurt drink with spices',
    ingredients: [
      { name: 'Yogurt', amount: 2, unit: 'cups' },
      { name: 'Cold Water', amount: 1, unit: 'cup' },
      { name: 'Salt', amount: 0.75, unit: 'tsp' },
      { name: 'Roasted Cumin Powder', amount: 0.5, unit: 'tsp' },
      { name: 'Black Salt', amount: 0.25, unit: 'tsp' },
      { name: 'Fresh Coriander', amount: 2, unit: 'tbsp' },
      { name: 'Ice Cubes', amount: 6, unit: 'pieces' }
    ],
    steps: [
      'Whisk yogurt until smooth',
      'Add cold water and mix well',
      'Add salt, roasted cumin powder, and black salt',
      'Blend with ice cubes until frothy',
      'Chop fresh coriander finely',
      'Pour into glasses and garnish with coriander',
      'Sprinkle extra cumin powder on top if desired'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 3,
    rating: 4.6,
    reviews: 750,
    image: drinkImages.lassi,
    tags: ['savory', 'traditional', 'digestive'],
    region: 'Punjab'
  },
  {
    id: 'lassi-004',
    name: 'Strawberry Lassi',
    category: 'lassi',
    subCategory: 'Fruit Lassi',
    description: 'Fresh strawberry yogurt smoothie',
    ingredients: [
      { name: 'Fresh Strawberries', amount: 1, unit: 'cup' },
      { name: 'Yogurt', amount: 1, unit: 'cup' },
      { name: 'Milk', amount: 0.5, unit: 'cup' },
      { name: 'Honey', amount: 2, unit: 'tbsp' },
      { name: 'Vanilla Extract', amount: 0.5, unit: 'tsp' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Wash and hull the strawberries',
      'Add strawberries, yogurt, and milk to blender',
      'Add honey and vanilla extract',
      'Blend until smooth',
      'Add ice cubes and blend again',
      'Taste and adjust sweetness',
      'Pour into glasses and garnish with strawberry slices'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.7,
    reviews: 620,
    image: drinkImages.shake,
    tags: ['fruity', 'summer', 'kids-friendly']
  },
  {
    id: 'lassi-005',
    name: 'Rose Lassi',
    category: 'lassi',
    subCategory: 'Special Lassi',
    description: 'Aromatic rose-flavored yogurt drink',
    ingredients: [
      { name: 'Yogurt', amount: 2, unit: 'cups' },
      { name: 'Milk', amount: 0.5, unit: 'cup' },
      { name: 'Rose Syrup', amount: 3, unit: 'tbsp' },
      { name: 'Sugar', amount: 2, unit: 'tbsp' },
      { name: 'Rose Water', amount: 1, unit: 'tsp' },
      { name: 'Dried Rose Petals', amount: 1, unit: 'tbsp' },
      { name: 'Ice Cubes', amount: 6, unit: 'pieces' }
    ],
    steps: [
      'Blend yogurt and milk until smooth',
      'Add rose syrup and sugar',
      'Add rose water and blend well',
      'Add ice cubes and blend until frothy',
      'Pour into glasses',
      'Garnish with dried rose petals',
      'Serve chilled for a floral experience'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 3,
    rating: 4.5,
    reviews: 540,
    image: drinkImages.lassi,
    tags: ['floral', 'special', 'aromatic']
  },

  // SMOOTHIES & SHAKES (25 drinks)
  {
    id: 'smoothie-001',
    name: 'Banana Smoothie',
    category: 'smoothies',
    subCategory: 'Fruit Smoothies',
    description: 'Creamy banana milkshake',
    ingredients: [
      { name: 'Ripe Bananas', amount: 2, unit: 'pieces' },
      { name: 'Milk', amount: 1.5, unit: 'cups' },
      { name: 'Honey', amount: 2, unit: 'tbsp' },
      { name: 'Vanilla Extract', amount: 0.5, unit: 'tsp' },
      { name: 'Cinnamon Powder', amount: 0.25, unit: 'tsp' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Peel and slice the bananas',
      'Add bananas and milk to blender',
      'Add honey, vanilla extract, and cinnamon',
      'Blend until creamy and smooth',
      'Add ice cubes and blend again',
      'Pour into glasses',
      'Garnish with banana slices and cinnamon'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.8,
    reviews: 890,
    image: drinkImages.banana,
    tags: ['energizing', 'breakfast', 'healthy']
  },
  {
    id: 'smoothie-002',
    name: 'Mixed Berry Smoothie',
    category: 'smoothies',
    subCategory: 'Fruit Smoothies',
    description: 'Antioxidant-rich berry blend',
    ingredients: [
      { name: 'Mixed Berries', amount: 1.5, unit: 'cups' },
      { name: 'Yogurt', amount: 1, unit: 'cup' },
      { name: 'Banana', amount: 1, unit: 'piece' },
      { name: 'Honey', amount: 2, unit: 'tbsp' },
      { name: 'Orange Juice', amount: 0.5, unit: 'cup' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Wash all berries thoroughly',
      'Add berries, yogurt, and banana to blender',
      'Pour in orange juice and add honey',
      'Blend until smooth',
      'Add ice cubes and blend for 20 seconds',
      'Pour into glasses',
      'Garnish with fresh berries on top'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.9,
    reviews: 1100,
    image: drinkImages.berry,
    tags: ['antioxidant', 'healthy', 'colorful']
  },
  {
    id: 'smoothie-003',
    name: 'Green Detox Smoothie',
    category: 'smoothies',
    subCategory: 'Green Smoothies',
    description: 'Nutrient-packed green smoothie',
    ingredients: [
      { name: 'Spinach Leaves', amount: 2, unit: 'cups' },
      { name: 'Green Apple', amount: 1, unit: 'piece' },
      { name: 'Banana', amount: 1, unit: 'piece' },
      { name: 'Cucumber', amount: 0.5, unit: 'piece' },
      { name: 'Lemon Juice', amount: 2, unit: 'tbsp' },
      { name: 'Ginger', amount: 0.5, unit: 'inch' },
      { name: 'Honey', amount: 1, unit: 'tbsp' },
      { name: 'Water', amount: 1, unit: 'cup' }
    ],
    steps: [
      'Wash spinach leaves thoroughly',
      'Core and chop the green apple',
      'Peel and chop cucumber and ginger',
      'Add all ingredients to blender',
      'Blend on high until completely smooth',
      'Taste and adjust sweetness',
      'Pour into glasses and serve fresh'
    ],
    time: '7 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.6,
    reviews: 680,
    image: drinkImages.smoothie,
    tags: ['detox', 'healthy', 'energizing']
  },
  {
    id: 'shake-001',
    name: 'Chocolate Shake',
    category: 'smoothies',
    subCategory: 'Dessert Shakes',
    description: 'Rich and creamy chocolate milkshake',
    ingredients: [
      { name: 'Milk', amount: 2, unit: 'cups' },
      { name: 'Chocolate Ice Cream', amount: 3, unit: 'scoops' },
      { name: 'Cocoa Powder', amount: 2, unit: 'tbsp' },
      { name: 'Sugar', amount: 2, unit: 'tbsp' },
      { name: 'Vanilla Extract', amount: 0.5, unit: 'tsp' },
      { name: 'Whipped Cream', amount: 2, unit: 'tbsp' }
    ],
    steps: [
      'Add milk, ice cream, and cocoa powder to blender',
      'Add sugar and vanilla extract',
      'Blend until thick and creamy',
      'Pour into tall glasses',
      'Top with whipped cream',
      'Drizzle with chocolate syrup',
      'Serve with a straw and enjoy'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.9,
    reviews: 1350,
    image: drinkImages.hotChocolate,
    tags: ['dessert', 'indulgent', 'kids-favorite']
  },
  {
    id: 'shake-002',
    name: 'Protein Shake',
    category: 'smoothies',
    subCategory: 'Protein Shakes',
    description: 'Post-workout protein boost',
    ingredients: [
      { name: 'Banana', amount: 1, unit: 'piece' },
      { name: 'Protein Powder', amount: 1, unit: 'scoop' },
      { name: 'Almond Milk', amount: 1.5, unit: 'cups' },
      { name: 'Peanut Butter', amount: 2, unit: 'tbsp' },
      { name: 'Oats', amount: 2, unit: 'tbsp' },
      { name: 'Honey', amount: 1, unit: 'tbsp' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Peel and slice the banana',
      'Add all ingredients to blender',
      'Blend on high for 1 minute',
      'Check consistency and add more milk if needed',
      'Blend again until smooth',
      'Pour into a shaker bottle or glass',
      'Consume within 30 minutes of workout'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 1,
    rating: 4.7,
    reviews: 820,
    image: drinkImages.protein,
    tags: ['fitness', 'protein', 'energizing']
  },

  // TEA & CHAI (20 drinks)
  {
    id: 'tea-001',
    name: 'Masala Chai',
    category: 'tea',
    subCategory: 'Masala Chai',
    description: 'Traditional Indian spiced tea',
    ingredients: [
      { name: 'Water', amount: 2, unit: 'cups' },
      { name: 'Milk', amount: 1, unit: 'cup' },
      { name: 'Tea Leaves', amount: 2, unit: 'tsp' },
      { name: 'Ginger', amount: 1, unit: 'inch' },
      { name: 'Cardamom Pods', amount: 3, unit: 'pieces' },
      { name: 'Cloves', amount: 3, unit: 'pieces' },
      { name: 'Black Pepper', amount: 3, unit: 'pieces' },
      { name: 'Sugar', amount: 3, unit: 'tsp' }
    ],
    steps: [
      'Crush ginger, cardamom, cloves, and pepper',
      'Boil water in a saucepan',
      'Add crushed spices and simmer for 2 minutes',
      'Add tea leaves and boil for 1 minute',
      'Add milk and bring to a boil',
      'Add sugar and stir well',
      'Strain into cups and serve hot'
    ],
    time: '10 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.9,
    reviews: 2100,
    image: drinkImages.tea,
    tags: ['traditional', 'aromatic', 'warming'],
    region: 'All India'
  },
  {
    id: 'tea-002',
    name: 'Ginger Tea',
    category: 'tea',
    subCategory: 'Herbal Tea',
    description: 'Soothing ginger-infused tea',
    ingredients: [
      { name: 'Water', amount: 2, unit: 'cups' },
      { name: 'Fresh Ginger', amount: 2, unit: 'inches' },
      { name: 'Tea Leaves', amount: 2, unit: 'tsp' },
      { name: 'Lemon Juice', amount: 1, unit: 'tbsp' },
      { name: 'Honey', amount: 2, unit: 'tsp' }
    ],
    steps: [
      'Peel and grate fresh ginger',
      'Boil water in a saucepan',
      'Add grated ginger and simmer for 3 minutes',
      'Add tea leaves and boil for 1 minute',
      'Strain into cups',
      'Add lemon juice and honey',
      'Stir well and serve hot'
    ],
    time: '8 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.7,
    reviews: 980,
    image: drinkImages.tea,
    tags: ['healing', 'immunity', 'warming']
  },
  {
    id: 'tea-003',
    name: 'Iced Lemon Tea',
    category: 'tea',
    subCategory: 'Iced Tea',
    description: 'Refreshing cold lemon tea',
    ingredients: [
      { name: 'Water', amount: 3, unit: 'cups' },
      { name: 'Tea Bags', amount: 3, unit: 'pieces' },
      { name: 'Lemon Juice', amount: 3, unit: 'tbsp' },
      { name: 'Sugar', amount: 3, unit: 'tbsp' },
      { name: 'Fresh Mint Leaves', amount: 10, unit: 'pieces' },
      { name: 'Ice Cubes', amount: 10, unit: 'pieces' },
      { name: 'Lemon Slices', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Boil water and steep tea bags for 5 minutes',
      'Remove tea bags and let cool',
      'Add sugar and stir until dissolved',
      'Add lemon juice and mix well',
      'Refrigerate for 30 minutes',
      'Add mint leaves and muddle gently',
      'Pour over ice cubes and garnish with lemon slices'
    ],
    time: '40 mins',
    difficulty: 'Easy',
    servings: 4,
    rating: 4.6,
    reviews: 720,
    image: drinkImages.icedTea,
    tags: ['refreshing', 'summer', 'citrus']
  },
  {
    id: 'tea-004',
    name: 'Green Tea',
    category: 'tea',
    subCategory: 'Herbal Tea',
    description: 'Healthy antioxidant-rich green tea',
    ingredients: [
      { name: 'Water', amount: 2, unit: 'cups' },
      { name: 'Green Tea Bags', amount: 2, unit: 'pieces' },
      { name: 'Honey', amount: 1, unit: 'tbsp' },
      { name: 'Lemon Slice', amount: 2, unit: 'pieces' }
    ],
    steps: [
      'Heat water to 80°C (not boiling)',
      'Pour hot water over tea bags',
      'Steep for 2-3 minutes',
      'Remove tea bags',
      'Add honey if desired',
      'Serve with lemon slice'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.7,
    reviews: 1420,
    image: drinkImages.greenTea,
    tags: ['healthy', 'antioxidant', 'wellness']
  },
  {
    id: 'tea-005',
    name: 'Matcha Latte',
    category: 'tea',
    subCategory: 'Special Tea',
    description: 'Creamy Japanese green tea latte',
    ingredients: [
      { name: 'Matcha Powder', amount: 1, unit: 'tsp' },
      { name: 'Hot Water', amount: 2, unit: 'tbsp' },
      { name: 'Milk', amount: 1.5, unit: 'cups' },
      { name: 'Honey', amount: 1, unit: 'tbsp' },
      { name: 'Vanilla Extract', amount: 0.25, unit: 'tsp' }
    ],
    steps: [
      'Sift matcha powder into a bowl',
      'Add hot water and whisk until smooth',
      'Heat milk until steaming',
      'Froth the milk if desired',
      'Pour matcha into a cup',
      'Add warm milk slowly',
      'Sweeten with honey and serve'
    ],
    time: '5 mins',
    difficulty: 'Medium',
    servings: 1,
    rating: 4.8,
    reviews: 856,
    image: drinkImages.matcha,
    tags: ['energizing', 'japanese', 'trendy']
  },

  // COFFEE (18 drinks)
  {
    id: 'coffee-001',
    name: 'Filter Coffee',
    category: 'coffee',
    subCategory: 'Hot Coffee',
    description: 'South Indian style filter coffee',
    ingredients: [
      { name: 'Filter Coffee Decoction', amount: 0.25, unit: 'cup' },
      { name: 'Hot Milk', amount: 1, unit: 'cup' },
      { name: 'Sugar', amount: 2, unit: 'tsp' }
    ],
    steps: [
      'Prepare strong coffee decoction using filter',
      'Heat milk until hot but not boiling',
      'Add sugar to a tumbler',
      'Pour coffee decoction over sugar',
      'Add hot milk and mix well',
      'Pour between two vessels for froth',
      'Serve hot in traditional tumbler and dabarah'
    ],
    time: '5 mins',
    difficulty: 'Medium',
    servings: 1,
    rating: 4.9,
    reviews: 1800,
    image: drinkImages.coffee,
    tags: ['traditional', 'aromatic', 'south-indian'],
    region: 'Tamil Nadu'
  },
  {
    id: 'coffee-002',
    name: 'Cold Coffee',
    category: 'coffee',
    subCategory: 'Cold Coffee',
    description: 'Chilled coffee with ice cream',
    ingredients: [
      { name: 'Cold Milk', amount: 2, unit: 'cups' },
      { name: 'Instant Coffee', amount: 3, unit: 'tsp' },
      { name: 'Sugar', amount: 3, unit: 'tbsp' },
      { name: 'Vanilla Ice Cream', amount: 2, unit: 'scoops' },
      { name: 'Ice Cubes', amount: 8, unit: 'pieces' },
      { name: 'Chocolate Syrup', amount: 2, unit: 'tbsp' }
    ],
    steps: [
      'Add coffee powder and sugar to blender',
      'Add a little hot water and mix to dissolve',
      'Add cold milk and ice cream',
      'Add ice cubes and blend until frothy',
      'Pour into tall glasses',
      'Drizzle chocolate syrup on top',
      'Serve immediately with a straw'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.8,
    reviews: 1450,
    image: drinkImages.coffee,
    tags: ['chilled', 'dessert', 'refreshing']
  },
  {
    id: 'coffee-003',
    name: 'Cappuccino',
    category: 'coffee',
    subCategory: 'Hot Coffee',
    description: 'Classic Italian coffee with foam',
    ingredients: [
      { name: 'Espresso', amount: 1, unit: 'shot' },
      { name: 'Steamed Milk', amount: 1, unit: 'cup' },
      { name: 'Milk Foam', amount: 2, unit: 'tbsp' },
      { name: 'Cocoa Powder', amount: 0.5, unit: 'tsp' }
    ],
    steps: [
      'Brew a shot of espresso',
      'Steam milk until hot and frothy',
      'Pour espresso into a cup',
      'Add steamed milk',
      'Top with milk foam',
      'Dust with cocoa powder',
      'Serve hot'
    ],
    time: '5 mins',
    difficulty: 'Medium',
    servings: 1,
    rating: 4.8,
    reviews: 1320,
    image: drinkImages.cappuccino,
    tags: ['classic', 'italian', 'energizing']
  },
  {
    id: 'coffee-004',
    name: 'Espresso',
    category: 'coffee',
    subCategory: 'Hot Coffee',
    description: 'Strong concentrated coffee shot',
    ingredients: [
      { name: 'Espresso Beans', amount: 18, unit: 'grams' },
      { name: 'Water', amount: 1, unit: 'oz' }
    ],
    steps: [
      'Grind espresso beans finely',
      'Tamp grounds in portafilter',
      'Extract for 25-30 seconds',
      'Serve in espresso cup',
      'Enjoy immediately'
    ],
    time: '3 mins',
    difficulty: 'Medium',
    servings: 1,
    rating: 4.9,
    reviews: 987,
    image: drinkImages.espresso,
    tags: ['strong', 'concentrated', 'quick']
  },

  // MOCKTAILS (30 drinks)
  {
    id: 'mocktail-001',
    name: 'Virgin Mojito',
    category: 'mocktails',
    subCategory: 'Classic Mocktails',
    description: 'Refreshing mint and lime mocktail',
    ingredients: [
      { name: 'Fresh Mint Leaves', amount: 15, unit: 'pieces' },
      { name: 'Lime Juice', amount: 3, unit: 'tbsp' },
      { name: 'Sugar Syrup', amount: 2, unit: 'tbsp' },
      { name: 'Soda Water', amount: 1, unit: 'cup' },
      { name: 'Ice Cubes', amount: 10, unit: 'pieces' },
      { name: 'Lime Slices', amount: 3, unit: 'pieces' }
    ],
    steps: [
      'Add mint leaves and sugar syrup to glass',
      'Muddle gently to release mint oils',
      'Add lime juice and mix',
      'Fill glass with ice cubes',
      'Top with soda water',
      'Stir gently with a straw',
      'Garnish with mint sprig and lime slice'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 1,
    rating: 4.8,
    reviews: 1120,
    image: drinkImages.lemonade,
    tags: ['refreshing', 'minty', 'party']
  },
  {
    id: 'mocktail-002',
    name: 'Blue Lagoon Mocktail',
    category: 'mocktails',
    subCategory: 'Classic Mocktails',
    description: 'Vibrant blue citrus mocktail',
    ingredients: [
      { name: 'Blue Curacao Syrup', amount: 2, unit: 'tbsp' },
      { name: 'Lemon Juice', amount: 2, unit: 'tbsp' },
      { name: 'Sprite or 7UP', amount: 1, unit: 'cup' },
      { name: 'Ice Cubes', amount: 8, unit: 'pieces' },
      { name: 'Cherry', amount: 1, unit: 'piece' },
      { name: 'Lemon Slice', amount: 1, unit: 'piece' }
    ],
    steps: [
      'Fill a glass with ice cubes',
      'Add blue curacao syrup',
      'Add fresh lemon juice',
      'Top with Sprite or 7UP',
      'Stir gently to mix',
      'Garnish with cherry and lemon slice',
      'Serve immediately with a colorful straw'
    ],
    time: '3 mins',
    difficulty: 'Easy',
    servings: 1,
    rating: 4.7,
    reviews: 890,
    image: drinkImages.smoothie,
    tags: ['colorful', 'party', 'citrus']
  },

  // JUICES (30 drinks)
  {
    id: 'juice-001',
    name: 'Fresh Orange Juice',
    category: 'juices',
    subCategory: 'Fruit Juices',
    description: 'Pure squeezed orange juice',
    ingredients: [
      { name: 'Fresh Oranges', amount: 4, unit: 'pieces' },
      { name: 'Sugar', amount: 1, unit: 'tbsp' },
      { name: 'Black Salt', amount: 0.25, unit: 'tsp' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Wash oranges thoroughly',
      'Cut oranges in half',
      'Squeeze juice using a juicer',
      'Strain to remove pulp if desired',
      'Add sugar and black salt',
      'Mix well until sugar dissolves',
      'Pour over ice and serve fresh'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.9,
    reviews: 1500,
    image: drinkImages.juice,
    tags: ['vitamin-c', 'fresh', 'healthy']
  },
  {
    id: 'juice-002',
    name: 'Watermelon Juice',
    category: 'juices',
    subCategory: 'Fruit Juices',
    description: 'Hydrating summer juice',
    ingredients: [
      { name: 'Watermelon', amount: 3, unit: 'cups' },
      { name: 'Lemon Juice', amount: 1, unit: 'tbsp' },
      { name: 'Black Salt', amount: 0.25, unit: 'tsp' },
      { name: 'Fresh Mint Leaves', amount: 8, unit: 'pieces' },
      { name: 'Ice Cubes', amount: 6, unit: 'pieces' }
    ],
    steps: [
      'Cut watermelon into cubes and remove seeds',
      'Add watermelon to blender',
      'Add lemon juice and black salt',
      'Add mint leaves and blend',
      'Strain if you want smooth juice',
      'Add ice cubes and blend briefly',
      'Pour into glasses and serve immediately'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.7,
    reviews: 1230,
    image: drinkImages.watermelon,
    tags: ['hydrating', 'summer', 'refreshing']
  },
  {
    id: 'juice-003',
    name: 'Pomegranate Juice',
    category: 'juices',
    subCategory: 'Fruit Juices',
    description: 'Antioxidant-rich pomegranate juice',
    ingredients: [
      { name: 'Pomegranate Arils', amount: 2, unit: 'cups' },
      { name: 'Lemon Juice', amount: 1, unit: 'tbsp' },
      { name: 'Black Salt', amount: 0.25, unit: 'tsp' },
      { name: 'Honey', amount: 1, unit: 'tbsp' },
      { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
    ],
    steps: [
      'Extract pomegranate arils',
      'Add to blender and blend',
      'Strain to remove seeds',
      'Add lemon juice, salt, and honey',
      'Mix well',
      'Pour over ice',
      'Serve fresh'
    ],
    time: '8 mins',
    difficulty: 'Medium',
    servings: 2,
    rating: 4.8,
    reviews: 976,
    image: drinkImages.pomegranate,
    tags: ['antioxidant', 'healthy', 'ruby-red']
  },
  {
    id: 'juice-004',
    name: 'Pineapple Juice',
    category: 'juices',
    subCategory: 'Fruit Juices',
    description: 'Tropical pineapple juice',
    ingredients: [
      { name: 'Fresh Pineapple', amount: 2, unit: 'cups' },
      { name: 'Water', amount: 1, unit: 'cup' },
      { name: 'Sugar', amount: 2, unit: 'tbsp' },
      { name: 'Black Salt', amount: 0.25, unit: 'tsp' },
      { name: 'Ice Cubes', amount: 6, unit: 'pieces' }
    ],
    steps: [
      'Peel and chop pineapple',
      'Add to blender with water',
      'Blend until smooth',
      'Strain if desired',
      'Add sugar and salt',
      'Mix well and serve over ice'
    ],
    time: '6 mins',
    difficulty: 'Easy',
    servings: 2,
    rating: 4.7,
    reviews: 845,
    image: drinkImages.pineapple,
    tags: ['tropical', 'tangy', 'refreshing']
  },

  // TRADITIONAL INDIAN (25 drinks)
  {
    id: 'traditional-001',
    name: 'Thandai',
    category: 'traditional',
    subCategory: 'Festival Drinks',
    description: 'Traditional Holi festival drink',
    ingredients: [
      { name: 'Milk', amount: 4, unit: 'cups' },
      { name: 'Almonds', amount: 15, unit: 'pieces' },
      { name: 'Cashews', amount: 10, unit: 'pieces' },
      { name: 'Fennel Seeds', amount: 1, unit: 'tbsp' },
      { name: 'Cardamom Pods', amount: 5, unit: 'pieces' },
      { name: 'Black Pepper', amount: 5, unit: 'pieces' },
      { name: 'Rose Petals', amount: 1, unit: 'tbsp' },
      { name: 'Saffron Strands', amount: 10, unit: 'pieces' },
      { name: 'Sugar', amount: 0.5, unit: 'cup' }
    ],
    steps: [
      'Soak almonds and cashews for 4 hours',
      'Peel almonds and grind with cashews',
      'Grind fennel, cardamom, pepper, and rose petals',
      'Mix ground paste with cold milk',
      'Add sugar and saffron',
      'Chill in refrigerator for 2 hours',
      'Serve cold garnished with nuts and rose petals'
    ],
    time: '4 hours 20 mins',
    difficulty: 'Medium',
    servings: 4,
    rating: 4.8,
    reviews: 950,
    image: drinkImages.lassi,
    tags: ['festival', 'traditional', 'rich'],
    region: 'North India'
  },
  {
    id: 'traditional-002',
    name: 'Jal Jeera',
    category: 'traditional',
    subCategory: 'Regional Specials',
    description: 'Cooling cumin water drink',
    ingredients: [
      { name: 'Roasted Cumin Powder', amount: 2, unit: 'tsp' },
      { name: 'Black Salt', amount: 1, unit: 'tsp' },
      { name: 'Lemon Juice', amount: 3, unit: 'tbsp' },
      { name: 'Mint Leaves', amount: 15, unit: 'pieces' },
      { name: 'Ginger', amount: 0.5, unit: 'inch' },
      { name: 'Black Pepper', amount: 0.5, unit: 'tsp' },
      { name: 'Water', amount: 4, unit: 'cups' },
      { name: 'Ice Cubes', amount: 8, unit: 'pieces' }
    ],
    steps: [
      'Grind mint leaves and ginger to a paste',
      'Add cumin powder, black salt, and pepper',
      'Mix with cold water',
      'Add lemon juice and stir well',
      'Strain the mixture',
      'Add ice cubes',
      'Serve immediately as a digestive drink'
    ],
    time: '10 mins',
    difficulty: 'Easy',
    servings: 4,
    rating: 4.6,
    reviews: 780,
    image: drinkImages.lemonade,
    tags: ['digestive', 'cooling', 'traditional'],
    region: 'North India'
  },

  // SUMMER COOLERS (20 drinks)
  {
    id: 'summer-001',
    name: 'Aam Panna',
    category: 'summer',
    subCategory: 'Aam Panna & More',
    description: 'Raw mango summer cooler',
    ingredients: [
      { name: 'Raw Mango', amount: 2, unit: 'pieces' },
      { name: 'Sugar', amount: 0.5, unit: 'cup' },
      { name: 'Roasted Cumin Powder', amount: 1, unit: 'tsp' },
      { name: 'Black Salt', amount: 1, unit: 'tsp' },
      { name: 'Fresh Mint Leaves', amount: 10, unit: 'pieces' },
      { name: 'Water', amount: 4, unit: 'cups' },
      { name: 'Ice Cubes', amount: 8, unit: 'pieces' }
    ],
    steps: [
      'Boil raw mangoes until soft',
      'Cool and extract pulp',
      'Blend pulp with sugar and water',
      'Add cumin powder and black salt',
      'Add mint leaves and blend',
      'Strain and refrigerate',
      'Serve over ice cubes'
    ],
    time: '30 mins',
    difficulty: 'Medium',
    servings: 4,
    rating: 4.9,
    reviews: 1340,
    image: drinkImages.lemonade,
    tags: ['summer', 'cooling', 'traditional'],
    region: 'North India'
  },
  {
    id: 'summer-002',
    name: 'Nimbu Pani',
    category: 'summer',
    subCategory: 'Sherbets',
    description: 'Classic Indian lemonade',
    ingredients: [
      { name: 'Lemon Juice', amount: 4, unit: 'tbsp' },
      { name: 'Sugar', amount: 3, unit: 'tbsp' },
      { name: 'Black Salt', amount: 0.5, unit: 'tsp' },
      { name: 'Roasted Cumin Powder', amount: 0.5, unit: 'tsp' },
      { name: 'Mint Leaves', amount: 10, unit: 'pieces' },
      { name: 'Water', amount: 3, unit: 'cups' },
      { name: 'Ice Cubes', amount: 8, unit: 'pieces' }
    ],
    steps: [
      'Mix lemon juice with sugar',
      'Add black salt and cumin powder',
      'Add cold water and stir well',
      'Muddle mint leaves in glasses',
      'Pour lemonade over mint',
      'Add ice cubes',
      'Garnish with lemon slice and serve'
    ],
    time: '5 mins',
    difficulty: 'Easy',
    servings: 3,
    rating: 4.8,
    reviews: 1670,
    image: drinkImages.lemonade,
    tags: ['refreshing', 'summer', 'classic'],
    region: 'All India'
  },

  // WELLNESS DRINKS (15 drinks)
  {
    id: 'wellness-001',
    name: 'Golden Turmeric Milk',
    category: 'wellness',
    subCategory: 'Ayurvedic',
    description: 'Anti-inflammatory turmeric latte',
    ingredients: [
      { name: 'Milk', amount: 1.5, unit: 'cups' },
      { name: 'Turmeric Powder', amount: 1, unit: 'tsp' },
      { name: 'Ginger Powder', amount: 0.5, unit: 'tsp' },
      { name: 'Cinnamon Powder', amount: 0.25, unit: 'tsp' },
      { name: 'Black Pepper', amount: 0.125, unit: 'tsp' },
      { name: 'Honey', amount: 1, unit: 'tbsp' }
    ],
    steps: [
      'Heat milk in a saucepan',
      'Add turmeric, ginger, cinnamon, and pepper',
      'Whisk well to combine',
      'Simmer for 5 minutes',
      'Strain into a cup',
      'Add honey and stir',
      'Serve warm before bedtime'
    ],
    time: '8 mins',
    difficulty: 'Easy',
    servings: 1,
    rating: 4.7,
    reviews: 734,
    image: drinkImages.turmeric,
    tags: ['ayurvedic', 'healing', 'anti-inflammatory']
  },
  {
    id: 'wellness-002',
    name: 'Detox Water',
    category: 'wellness',
    subCategory: 'Detox',
    description: 'Infused water for detoxification',
    ingredients: [
      { name: 'Water', amount: 4, unit: 'cups' },
      { name: 'Cucumber', amount: 0.5, unit: 'piece' },
      { name: 'Lemon', amount: 1, unit: 'piece' },
      { name: 'Mint Leaves', amount: 10, unit: 'pieces' },
      { name: 'Ginger', amount: 0.5, unit: 'inch' }
    ],
    steps: [
      'Slice cucumber and lemon',
      'Slice ginger thinly',
      'Add all ingredients to a pitcher',
      'Fill with cold water',
      'Refrigerate for 2-4 hours',
      'Strain and serve over ice',
      'Drink throughout the day'
    ],
    time: '2 hours 5 mins',
    difficulty: 'Easy',
    servings: 4,
    rating: 4.6,
    reviews: 892,
    image: drinkImages.detox,
    tags: ['detox', 'healthy', 'infused']
  }
];

// Generate additional drinks programmatically to reach 700+
const generateAdditionalDrinks = (): Drink[] => {
  const variations: Drink[] = [];
  let idCounter = 100;

  // Extended fruit bases for variety
  const fruitBases = [
    { name: 'Coconut', image: drinkImages.coconut },
    { name: 'Guava', image: drinkImages.juice },
    { name: 'Papaya', image: drinkImages.smoothie },
    { name: 'Kiwi', image: drinkImages.smoothie },
    { name: 'Lychee', image: drinkImages.juice },
    { name: 'Dragon Fruit', image: drinkImages.smoothie },
    { name: 'Passion Fruit', image: drinkImages.juice },
    { name: 'Blueberry', image: drinkImages.berry },
    { name: 'Raspberry', image: drinkImages.berry },
    { name: 'Blackberry', image: drinkImages.berry },
    { name: 'Peach', image: drinkImages.smoothie },
    { name: 'Apricot', image: drinkImages.juice },
    { name: 'Plum', image: drinkImages.juice },
    { name: 'Cherry', image: drinkImages.berry },
    { name: 'Grape', image: drinkImages.juice },
    { name: 'Cantaloupe', image: drinkImages.juice },
    { name: 'Honeydew', image: drinkImages.juice },
    { name: 'Apple', image: drinkImages.juice },
    { name: 'Pear', image: drinkImages.juice },
    { name: 'Avocado', image: drinkImages.smoothie }
  ];

  const lassiVariations = [
    'Saffron', 'Pistachio', 'Almond', 'Cardamom', 'Kesar', 'Mint', 
    'Ginger', 'Chocolate', 'Vanilla', 'Honey', 'Cinnamon', 'Nutmeg',
    'Date', 'Fig', 'Cashew', 'Walnut'
  ];

  const teaVariations = [
    'Earl Grey', 'Jasmine', 'Oolong', 'White Tea', 'Chamomile',
    'Peppermint', 'Rooibos', 'Darjeeling', 'Assam', 'Peach Tea',
    'Hibiscus', 'Lavender', 'Lemongrass', 'Tulsi', 'Ginger Lemon'
  ];

  const coffeeVariations = [
    'Latte', 'Mocha', 'Americano', 'Macchiato', 'Cortado',
    'Affogato', 'Turkish Coffee', 'Vietnamese Coffee', 'Frappe',
    'Irish Coffee', 'Caramel Coffee', 'Hazelnut Coffee'
  ];

  const mocktailVariations = [
    { name: 'Shirley Temple', type: 'Classic' },
    { name: 'Cinderella', type: 'Classic' },
    { name: 'Roy Rogers', type: 'Classic' },
    { name: 'Pina Colada', type: 'Tropical Paradise' },
    { name: 'Strawberry Daiquiri', type: 'Fresh & Fruity' },
    { name: 'Mango Tango', type: 'Tropical Paradise' },
    { name: 'Cucumber Cooler', type: 'Fresh & Fruity' },
    { name: 'Watermelon Mint', type: 'Fresh & Fruity' },
    { name: 'Berry Burst', type: 'Fresh & Fruity' },
    { name: 'Tropical Sunrise', type: 'Tropical Paradise' },
    { name: 'Citrus Splash', type: 'Fresh & Fruity' },
    { name: 'Peachy Keen', type: 'Fresh & Fruity' }
  ];

  const indianDrinks = [
    { name: 'Badam Milk', region: 'South India' },
    { name: 'Panakam', region: 'Andhra Pradesh' },
    { name: 'Nannari Sherbet', region: 'Tamil Nadu' },
    { name: 'Bel Pana', region: 'Odisha' },
    { name: 'Sattu Drink', region: 'Bihar' },
    { name: 'Sol Kadhi', region: 'Maharashtra' },
    { name: 'Kashaya', region: 'Karnataka' },
    { name: 'Kanji', region: 'Rajasthan' },
    { name: 'Ambil', region: 'Maharashtra' },
    { name: 'Chaas', region: 'Gujarat' },
    { name: 'Shikanjvi', region: 'North India' },
    { name: 'Kokum Sherbat', region: 'Goa' }
  ];

  // Generate fruit-based drinks (Lassi, Smoothies, Juices) - 60 drinks
  fruitBases.forEach(fruit => {
    ['lassi', 'smoothies', 'juices'].forEach(cat => {
      variations.push({
        id: `${cat}-${idCounter++}`,
        name: `${fruit.name} ${cat === 'lassi' ? 'Lassi' : cat === 'smoothies' ? 'Smoothie' : 'Juice'}`,
        category: cat,
        subCategory: cat === 'lassi' ? 'Fruit Lassi' : cat === 'smoothies' ? 'Fruit Smoothies' : 'Fruit Juices',
        description: `Delicious ${fruit.name.toLowerCase()} based ${cat === 'lassi' ? 'yogurt drink' : cat === 'smoothies' ? 'smoothie' : 'fresh juice'}`,
        ingredients: [
          { name: fruit.name, amount: 1, unit: 'cup' },
          { name: cat === 'lassi' ? 'Yogurt' : cat === 'smoothies' ? 'Milk' : 'Water', amount: 1, unit: 'cup' },
          { name: 'Sugar', amount: 2, unit: 'tbsp' },
          { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
        ],
        steps: [
          `Wash and prepare ${fruit.name.toLowerCase()}`,
          'Add all ingredients to blender',
          'Blend until smooth and creamy',
          'Taste and adjust sweetness if needed',
          'Pour into serving glasses',
          'Serve immediately chilled'
        ],
        time: '5 mins',
        difficulty: 'Easy' as const,
        servings: 2,
        rating: parseFloat((4.5 + Math.random() * 0.4).toFixed(1)),
        reviews: Math.floor(100 + Math.random() * 500),
        image: fruit.image,
        tags: ['fruity', 'refreshing', 'healthy']
      });
    });
  });

  // Generate lassi variations - 16 drinks
  lassiVariations.forEach(variant => {
    variations.push({
      id: `lassi-${idCounter++}`,
      name: `${variant} Lassi`,
      category: 'lassi',
      subCategory: 'Special Lassi',
      description: `Traditional ${variant.toLowerCase()} flavored yogurt drink`,
      ingredients: [
        { name: 'Yogurt', amount: 2, unit: 'cups' },
        { name: 'Milk', amount: 0.5, unit: 'cup' },
        { name: 'Sugar', amount: 2, unit: 'tbsp' },
        { name: `${variant} Flavoring`, amount: 1, unit: 'tsp' },
        { name: 'Ice Cubes', amount: 6, unit: 'pieces' }
      ],
      steps: [
        'Add yogurt and milk to blender',
        `Add ${variant.toLowerCase()} flavoring`,
        'Blend until smooth and frothy',
        'Add ice cubes and blend briefly',
        'Pour into glasses',
        'Garnish and serve chilled'
      ],
      time: '5 mins',
      difficulty: 'Easy' as const,
      servings: 2,
      rating: parseFloat((4.6 + Math.random() * 0.3).toFixed(1)),
      reviews: Math.floor(150 + Math.random() * 400),
      image: drinkImages.lassi,
      tags: ['traditional', 'yogurt', 'creamy']
    });
  });

  // Generate tea variations - 15 drinks
  teaVariations.forEach(tea => {
    variations.push({
      id: `tea-${idCounter++}`,
      name: tea,
      category: 'tea',
      subCategory: tea.includes('Iced') || tea.includes('Cold') ? 'Iced Tea' : 'Herbal Tea',
      description: `Aromatic ${tea.toLowerCase()} with authentic flavor`,
      ingredients: [
        { name: 'Water', amount: 2, unit: 'cups' },
        { name: `${tea} Leaves`, amount: 2, unit: 'tsp' },
        { name: 'Honey', amount: 1, unit: 'tbsp' },
        { name: 'Lemon', amount: 1, unit: 'slice' }
      ],
      steps: [
        'Boil water in a kettle',
        `Add ${tea.toLowerCase()} leaves`,
        'Steep for 3-5 minutes',
        'Strain into cups',
        'Add honey and lemon',
        'Serve hot or iced'
      ],
      time: '8 mins',
      difficulty: 'Easy' as const,
      servings: 2,
      rating: parseFloat((4.5 + Math.random() * 0.4).toFixed(1)),
      reviews: Math.floor(120 + Math.random() * 350),
      image: tea.includes('Green') || tea.includes('Matcha') ? drinkImages.greenTea : tea.includes('Iced') ? drinkImages.icedTea : drinkImages.tea,
      tags: ['tea', 'aromatic', 'soothing']
    });
  });

  // Generate coffee variations - 12 drinks
  coffeeVariations.forEach(coffee => {
    variations.push({
      id: `coffee-${idCounter++}`,
      name: coffee,
      category: 'coffee',
      subCategory: coffee.includes('Cold') || coffee.includes('Iced') || coffee.includes('Frappe') ? 'Cold Coffee' : 'Hot Coffee',
      description: `Classic ${coffee.toLowerCase()} with rich aroma`,
      ingredients: [
        { name: 'Coffee', amount: 2, unit: 'shots' },
        { name: 'Milk', amount: 1, unit: 'cup' },
        { name: 'Sugar', amount: 1, unit: 'tbsp' }
      ],
      steps: [
        'Brew strong coffee',
        'Heat or cool milk as needed',
        'Combine coffee and milk',
        'Add sugar to taste',
        'Mix well and serve'
      ],
      time: '7 mins',
      difficulty: 'Medium' as const,
      servings: 1,
      rating: parseFloat((4.6 + Math.random() * 0.3).toFixed(1)),
      reviews: Math.floor(200 + Math.random() * 500),
      image: coffee.includes('Espresso') ? drinkImages.espresso : coffee.includes('Cappuccino') || coffee.includes('Latte') ? drinkImages.cappuccino : drinkImages.coffee,
      tags: ['coffee', 'energizing', 'rich']
    });
  });

  // Generate mocktail variations - 12 drinks
  mocktailVariations.forEach(mocktail => {
    variations.push({
      id: `mocktail-${idCounter++}`,
      name: `${mocktail.name} Mocktail`,
      category: 'mocktails',
      subCategory: `${mocktail.type}`,
      description: `Refreshing ${mocktail.name.toLowerCase()} mocktail`,
      ingredients: [
        { name: 'Fruit Juice', amount: 1, unit: 'cup' },
        { name: 'Soda Water', amount: 0.5, unit: 'cup' },
        { name: 'Syrup', amount: 2, unit: 'tbsp' },
        { name: 'Ice Cubes', amount: 8, unit: 'pieces' },
        { name: 'Garnish', amount: 1, unit: 'piece' }
      ],
      steps: [
        'Fill glass with ice cubes',
        'Add fruit juice and syrup',
        'Top with soda water',
        'Stir gently',
        'Garnish and serve'
      ],
      time: '5 mins',
      difficulty: 'Easy' as const,
      servings: 1,
      rating: parseFloat((4.7 + Math.random() * 0.2).toFixed(1)),
      reviews: Math.floor(180 + Math.random() * 450),
      image: mocktail.type === 'Tropical Paradise' ? drinkImages.pineapple : drinkImages.fruitPunch,
      tags: ['mocktail', 'party', 'non-alcoholic']
    });
  });

  // Generate traditional Indian drinks - 12 drinks
  indianDrinks.forEach(drink => {
    variations.push({
      id: `traditional-${idCounter++}`,
      name: drink.name,
      category: 'traditional',
      subCategory: 'Regional Specials',
      description: `Traditional ${drink.name} from ${drink.region}`,
      ingredients: [
        { name: 'Main Ingredient', amount: 1, unit: 'cup' },
        { name: 'Water', amount: 2, unit: 'cups' },
        { name: 'Spices', amount: 1, unit: 'tsp' },
        { name: 'Sweetener', amount: 2, unit: 'tbsp' }
      ],
      steps: [
        'Prepare main ingredients',
        'Mix with water and spices',
        'Add sweetener',
        'Blend or mix well',
        'Chill and serve'
      ],
      time: '15 mins',
      difficulty: 'Medium' as const,
      servings: 2,
      rating: parseFloat((4.7 + Math.random() * 0.2).toFixed(1)),
      reviews: Math.floor(150 + Math.random() * 400),
      image: drink.name.includes('Milk') ? drinkImages.lassi : drinkImages.lemonade,
      tags: ['traditional', 'indian', drink.region.toLowerCase()],
      region: drink.region
    });
  });

  // Generate additional summer coolers - 20 drinks
  const summerVariations = [
    'Rose Sharbat', 'Khus Sharbat', 'Sandalwood Sharbat', 'Kokum Sharbat',
    'Tamarind Cooler', 'Ginger Lemonade', 'Mint Lemonade', 'Cucumber Mint Cooler',
    'Bel Juice', 'Wood Apple Juice', 'Jamun Juice', 'Sugarcane Juice',
    'Tender Coconut Water', 'Aloe Vera Juice', 'Amla Juice', 'Karela Juice',
    'Beetroot Juice', 'Carrot Juice', 'ABC Juice', 'Green Juice'
  ];

  summerVariations.forEach(drink => {
    variations.push({
      id: `summer-${idCounter++}`,
      name: drink,
      category: 'summer',
      subCategory: drink.includes('Sharbat') || drink.includes('Sherbet') ? 'Sherbets' : 'Cooling Drinks',
      description: `Refreshing ${drink.toLowerCase()} perfect for summer`,
      ingredients: [
        { name: 'Main Ingredient', amount: 1, unit: 'cup' },
        { name: 'Water', amount: 3, unit: 'cups' },
        { name: 'Sugar', amount: 3, unit: 'tbsp' },
        { name: 'Lemon Juice', amount: 2, unit: 'tbsp' },
        { name: 'Ice Cubes', amount: 8, unit: 'pieces' }
      ],
      steps: [
        'Prepare the main ingredient',
        'Mix with water and sugar',
        'Add lemon juice',
        'Blend if needed',
        'Strain and chill',
        'Serve over ice'
      ],
      time: '10 mins',
      difficulty: 'Easy' as const,
      servings: 3,
      rating: parseFloat((4.6 + Math.random() * 0.3).toFixed(1)),
      reviews: Math.floor(120 + Math.random() * 380),
      image: drink.includes('Coconut') ? drinkImages.coconut : drink.includes('juice') ? drinkImages.juice : drinkImages.lemonade,
      tags: ['summer', 'cooling', 'refreshing']
    });
  });

  // Generate wellness drinks - 25 drinks
  const wellnessVariations = [
    { name: 'Wheatgrass Shot', sub: 'Detox' },
    { name: 'Spirulina Smoothie', sub: 'Energy Drinks' },
    { name: 'Chia Seed Drink', sub: 'Energy Drinks' },
    { name: 'Apple Cider Vinegar Drink', sub: 'Detox' },
    { name: 'Lemon Ginger Shot', sub: 'Immunity Boosters' },
    { name: 'Turmeric Shot', sub: 'Immunity Boosters' },
    { name: 'Beetroot Ginger Juice', sub: 'Detox' },
    { name: 'Almond Milk', sub: 'Energy Drinks' },
    { name: 'Oat Milk', sub: 'Energy Drinks' },
    { name: 'Coconut Kefir', sub: 'Immunity Boosters' },
    { name: 'Kombucha', sub: 'Detox' },
    { name: 'Bone Broth', sub: 'Immunity Boosters' },
    { name: 'Ashwagandha Latte', sub: 'Immunity Boosters' },
    { name: 'Moringa Tea', sub: 'Immunity Boosters' },
    { name: 'Ginseng Tea', sub: 'Energy Drinks' }
  ];

  wellnessVariations.forEach(drink => {
    variations.push({
      id: `wellness-${idCounter++}`,
      name: drink.name,
      category: 'wellness',
      subCategory: drink.sub,
      description: `Healthy ${drink.name.toLowerCase()} for wellness`,
      ingredients: [
        { name: 'Main Ingredient', amount: 1, unit: 'cup' },
        { name: 'Water or Milk', amount: 1, unit: 'cup' },
        { name: 'Honey', amount: 1, unit: 'tbsp' },
        { name: 'Optional Spices', amount: 0.5, unit: 'tsp' }
      ],
      steps: [
        'Prepare main ingredient',
        'Mix with liquid base',
        'Add honey and spices',
        'Blend or stir well',
        'Strain if needed',
        'Serve fresh'
      ],
      time: '7 mins',
      difficulty: 'Easy' as const,
      servings: 1,
      rating: parseFloat((4.5 + Math.random() * 0.4).toFixed(1)),
      reviews: Math.floor(100 + Math.random() * 350),
      image: drink.name.includes('Green') || drink.name.includes('Spirulina') ? drinkImages.smoothie : drink.name.includes('Turmeric') ? drinkImages.turmeric : drinkImages.herbal,
      tags: ['wellness', 'healthy', drink.sub.toLowerCase()]
    });
  });

  // Generate additional protein shakes - 20 drinks
  const proteinVariations = [
    'Chocolate Peanut Butter', 'Vanilla Berry', 'Cookies and Cream', 'Caramel Delight',
    'Mocha Espresso', 'Mint Chocolate', 'Strawberry Banana', 'Mango Protein',
    'Blueberry Blast', 'Tropical Paradise', 'Green Power', 'Cinnamon Roll',
    'Pumpkin Spice', 'Birthday Cake', 'Salted Caramel', 'Almond Joy',
    'Peanut Butter Cup', 'Coffee Cream', 'Coconut Dream', 'Cherry Vanilla'
  ];

  proteinVariations.forEach(flavor => {
    variations.push({
      id: `protein-${idCounter++}`,
      name: `${flavor} Protein Shake`,
      category: 'smoothies',
      subCategory: 'Protein Shakes',
      description: `High-protein ${flavor.toLowerCase()} shake for fitness`,
      ingredients: [
        { name: 'Protein Powder', amount: 1, unit: 'scoop' },
        { name: 'Milk', amount: 1.5, unit: 'cups' },
        { name: 'Banana', amount: 1, unit: 'piece' },
        { name: 'Flavoring', amount: 1, unit: 'tbsp' },
        { name: 'Ice Cubes', amount: 4, unit: 'pieces' }
      ],
      steps: [
        'Add protein powder to blender',
        'Add milk and banana',
        'Add flavoring ingredients',
        'Blend until smooth',
        'Add ice and blend again',
        'Serve immediately'
      ],
      time: '5 mins',
      difficulty: 'Easy' as const,
      servings: 1,
      rating: parseFloat((4.6 + Math.random() * 0.3).toFixed(1)),
      reviews: Math.floor(150 + Math.random() * 400),
      image: drinkImages.protein,
      tags: ['protein', 'fitness', 'energizing']
    });
  });

  // Generate milkshake variations - 25 drinks
  const milkshakeVariations = [
    'Vanilla', 'Strawberry', 'Chocolate', 'Oreo', 'Nutella', 'Caramel',
    'Butterscotch', 'Mango', 'Banana', 'Blueberry', 'Raspberry', 'Coffee',
    'Peanut Butter', 'Mint Chip', 'Cookie Dough', 'Brownie', 'Red Velvet',
    'Coconut', 'Almond', 'Hazelnut', 'Pistachio', 'Rose', 'Saffron', 'Kesar', 'Thandai'
  ];

  milkshakeVariations.forEach(flavor => {
    variations.push({
      id: `shake-${idCounter++}`,
      name: `${flavor} Milkshake`,
      category: 'smoothies',
      subCategory: 'Dessert Shakes',
      description: `Creamy ${flavor.toLowerCase()} milkshake`,
      ingredients: [
        { name: 'Milk', amount: 2, unit: 'cups' },
        { name: 'Ice Cream', amount: 3, unit: 'scoops' },
        { name: `${flavor} Flavoring`, amount: 2, unit: 'tbsp' },
        { name: 'Sugar', amount: 1, unit: 'tbsp' },
        { name: 'Whipped Cream', amount: 2, unit: 'tbsp' }
      ],
      steps: [
        'Add milk and ice cream to blender',
        'Add flavoring and sugar',
        'Blend until thick and creamy',
        'Pour into glasses',
        'Top with whipped cream',
        'Garnish and serve'
      ],
      time: '5 mins',
      difficulty: 'Easy' as const,
      servings: 2,
      rating: parseFloat((4.7 + Math.random() * 0.2).toFixed(1)),
      reviews: Math.floor(200 + Math.random() * 500),
      image: drinkImages.shake,
      tags: ['dessert', 'indulgent', 'creamy']
    });
  });

  // Generate iced coffee variations - 15 drinks
  const icedCoffeeVariations = [
    'Vanilla Iced Coffee', 'Caramel Iced Coffee', 'Mocha Frappuccino', 'Hazelnut Cold Brew',
    'Iced Americano', 'Iced Latte', 'Iced Mocha', 'Iced Caramel Macchiato',
    'Nitro Cold Brew', 'Vietnamese Iced Coffee', 'Thai Iced Coffee', 'Mexican Iced Coffee',
    'Coconut Iced Coffee', 'Almond Iced Coffee', 'Irish Cream Cold Brew'
  ];

  icedCoffeeVariations.forEach(coffee => {
    variations.push({
      id: `iced-coffee-${idCounter++}`,
      name: coffee,
      category: 'coffee',
      subCategory: 'Cold Coffee',
      description: `Refreshing ${coffee.toLowerCase()}`,
      ingredients: [
        { name: 'Cold Brew Coffee', amount: 1, unit: 'cup' },
        { name: 'Milk or Cream', amount: 0.5, unit: 'cup' },
        { name: 'Syrup or Sweetener', amount: 2, unit: 'tbsp' },
        { name: 'Ice Cubes', amount: 8, unit: 'pieces' }
      ],
      steps: [
        'Fill glass with ice cubes',
        'Pour cold brew coffee',
        'Add milk or cream',
        'Add syrup and stir',
        'Garnish and serve'
      ],
      time: '3 mins',
      difficulty: 'Easy' as const,
      servings: 1,
      rating: parseFloat((4.7 + Math.random() * 0.2).toFixed(1)),
      reviews: Math.floor(180 + Math.random() * 450),
      image: drinkImages.coffee,
      tags: ['iced', 'coffee', 'refreshing']
    });
  });

  // Generate green smoothie variations - 15 drinks
  const greenSmoothieVariations = [
    'Kale Power', 'Spinach Banana', 'Green Goddess', 'Tropical Green', 'Green Machine',
    'Cucumber Celery', 'Avocado Green', 'Matcha Green', 'Spirulina Boost', 'Wheatgrass Blend',
    'Parsley Detox', 'Mint Spinach', 'Apple Greens', 'Pineapple Greens', 'Mango Spinach'
  ];

  greenSmoothieVariations.forEach(smoothie => {
    variations.push({
      id: `green-smoothie-${idCounter++}`,
      name: `${smoothie} Smoothie`,
      category: 'smoothies',
      subCategory: 'Green Smoothies',
      description: `Nutrient-packed ${smoothie.toLowerCase()} smoothie`,
      ingredients: [
        { name: 'Leafy Greens', amount: 2, unit: 'cups' },
        { name: 'Fruit', amount: 1, unit: 'cup' },
        { name: 'Liquid Base', amount: 1, unit: 'cup' },
        { name: 'Sweetener', amount: 1, unit: 'tbsp' },
        { name: 'Ice', amount: 4, unit: 'pieces' }
      ],
      steps: [
        'Add greens to blender',
        'Add fruit and liquid',
        'Add sweetener',
        'Blend until smooth',
        'Add ice and blend again',
        'Serve fresh'
      ],
      time: '5 mins',
      difficulty: 'Easy' as const,
      servings: 1,
      rating: parseFloat((4.5 + Math.random() * 0.4).toFixed(1)),
      reviews: Math.floor(120 + Math.random() * 350),
      image: drinkImages.smoothie,
      tags: ['green', 'healthy', 'detox']
    });
  });

  return variations;
};

// Export all drinks
export const allDrinks = [...drinksDatabase, ...generateAdditionalDrinks()];

// Helper function to get drinks by category
export const getDrinksByCategory = (category: string): Drink[] => {
  return allDrinks.filter(drink => drink.category === category);
};

// Helper function to search drinks
export const searchDrinks = (query: string): Drink[] => {
  const lowerQuery = query.toLowerCase();
  return allDrinks.filter(drink =>
    drink.name.toLowerCase().includes(lowerQuery) ||
    drink.description.toLowerCase().includes(lowerQuery) ||
    drink.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
  );
};

// Helper function to get total drink count
export const getTotalDrinkCount = (): number => {
  return allDrinks.length;
};

console.log(`✅ Drinks Database Loaded: ${getTotalDrinkCount()} drinks available`);
