// Comprehensive data for all 28 States and 8 Union Territories of India
// Each state/UT has multiple districts with authentic recipes (rural and urban)

type Recipe = {
  name: string;
  type: string;
  description: string;
  rural?: boolean;
};

type District = {
  name: string;
  recipes: Recipe[];
};

type StateData = {
  name: string;
  color: string;
  type: 'state' | 'ut';
  districts: Record<string, District>;
};

export const stateDistrictData: Record<string, StateData> = {
  // STATES (28)
  
  'Andhra Pradesh': {
    name: 'Andhra Pradesh',
    color: '#FF6B6B',
    type: 'state',
    districts: {
      'Visakhapatnam': {
        name: 'Visakhapatnam',
        recipes: [
          { name: 'Royyala Iguru', type: 'Curry', description: 'Spicy prawn curry with coastal flavors' },
          { name: 'Pesarattu', type: 'Breakfast', description: 'Green gram dosa', rural: true },
          { name: 'Upma Pesarattu', type: 'Breakfast', description: 'Dosa stuffed with upma' },
          { name: 'Gongura Pachadi', type: 'Chutney', description: 'Tangy sorrel leaves chutney', rural: true },
          { name: 'Bendakaya Pulusu', type: 'Curry', description: 'Okra in tamarind gravy', rural: true },
          { name: 'Gutti Vankaya', type: 'Curry', description: 'Stuffed brinjal curry' },
          { name: 'Pulihora', type: 'Rice', description: 'Tamarind rice', rural: true },
          { name: 'Bobbatlu', type: 'Sweet', description: 'Sweet flatbread with lentil filling', rural: true },
          { name: 'Madugula Halwa', type: 'Sweet', description: 'Traditional halwa' },
          { name: 'Arisa', type: 'Sweet', description: 'Rice flour sweet', rural: true },
          { name: 'Boorelu', type: 'Sweet', description: 'Sweet lentil balls', rural: true },
        ]
      },
      'Vijayawada': {
        name: 'Vijayawada',
        recipes: [
          { name: 'Ulavacharu', type: 'Soup', description: 'Horse gram soup', rural: true },
          { name: 'Punugulu', type: 'Snack', description: 'Deep fried lentil balls' },
          { name: 'Vadiyalu', type: 'Side Dish', description: 'Sun-dried lentil wafers', rural: true },
          { name: 'Gummadikaya Koora', type: 'Curry', description: 'Pumpkin curry', rural: true },
          { name: 'Andhra Chicken Fry', type: 'Main Course', description: 'Spicy chicken fry' },
          { name: 'Avakaya', type: 'Pickle', description: 'Mango pickle', rural: true },
          { name: 'Dosakaya Pachadi', type: 'Chutney', description: 'Cucumber chutney', rural: true },
          { name: 'Chepala Pulusu', type: 'Curry', description: 'Fish curry with tamarind', rural: true },
          { name: 'Poornalu', type: 'Sweet', description: 'Sweet dumplings', rural: true },
          { name: 'Sakinalu', type: 'Snack', description: 'Rice flour spirals', rural: true },
          { name: 'Ariselu', type: 'Sweet', description: 'Sesame rice cakes', rural: true },
        ]
      },
      'Guntur': {
        name: 'Guntur',
        recipes: [
          { name: 'Guntur Chicken', type: 'Main Course', description: 'Extremely spicy chicken curry' },
          { name: 'Mirchi Bajji', type: 'Snack', description: 'Chili fritters' },
          { name: 'Gongura Mamsam', type: 'Main Course', description: 'Mutton with sorrel leaves', rural: true },
          { name: 'Natu Kodi Pulusu', type: 'Curry', description: 'Country chicken curry', rural: true },
          { name: 'Kanda Bachali', type: 'Curry', description: 'Amaranth leaves curry', rural: true },
          { name: 'Pachi Pulusu', type: 'Soup', description: 'Raw tamarind soup', rural: true },
          { name: 'Avakai', type: 'Pickle', description: 'Raw mango pickle', rural: true },
          { name: 'Bellam Pongali', type: 'Sweet', description: 'Jaggery rice pudding', rural: true },
          { name: 'Murukulu', type: 'Snack', description: 'Spicy fried snack', rural: true },
          { name: 'Kakinada Kaja', type: 'Sweet', description: 'Layered sweet pastry' },
          { name: 'Pootharekulu', type: 'Sweet', description: 'Paper-thin sweet', rural: true },
        ]
      },
      'Anantapur': {
        name: 'Anantapur',
        recipes: [
          { name: 'Ragi Mudde', type: 'Main Course', description: 'Finger millet balls', rural: true },
          { name: 'Benda Pongali', type: 'Rice', description: 'Sambar rice', rural: true },
          { name: 'Pesara Pappu', type: 'Dal', description: 'Green gram dal', rural: true },
          { name: 'Tomato Pappu', type: 'Dal', description: 'Tomato lentil stew', rural: true },
          { name: 'Gutthi Vankaya Kura', type: 'Curry', description: 'Stuffed eggplant curry' },
          { name: 'Karam Podi', type: 'Condiment', description: 'Spicy powder mix', rural: true },
          { name: 'Nellore Chepala Pulusu', type: 'Curry', description: 'Fish in sour curry' },
          { name: 'Pappu Charu', type: 'Soup', description: 'Thin dal soup', rural: true },
          { name: 'Dosakaya Pachadi', type: 'Chutney', description: 'Cucumber yogurt chutney', rural: true },
          { name: 'Gulab Jamun', type: 'Sweet', description: 'Milk solid dumplings in syrup' },
        ]
      },
      'Krishna': {
        name: 'Krishna',
        recipes: [
          { name: 'Bandar Laddu', type: 'Sweet', description: 'Famous laddu from Machilipatnam' },
          { name: 'Ulava Charu', type: 'Soup', description: 'Horse gram rasam', rural: true },
          { name: 'Andhra Biryani', type: 'Rice', description: 'Spicy Andhra style biryani' },
          { name: 'Pesarattu Upma', type: 'Breakfast', description: 'Green gram dosa with upma' },
          { name: 'Chepala Vepudu', type: 'Fry', description: 'Fish fry', rural: true },
          { name: 'Gongura Mutton', type: 'Curry', description: 'Mutton with sorrel leaves' },
          { name: 'Bellam Gavvalu', type: 'Snack', description: 'Sweet shell pasta', rural: true },
          { name: 'Bobbatlu', type: 'Sweet', description: 'Sweet flatbread' },
          { name: 'Pulihora', type: 'Rice', description: 'Tamarind rice' },
          { name: 'Garelu', type: 'Snack', description: 'Lentil fritters' },
        ]
      },
      'Chittoor': {
        name: 'Chittoor',
        recipes: [
          { name: 'Ragi Sankati', type: 'Main Course', description: 'Finger millet ball', rural: true },
          { name: 'Sambar', type: 'Curry', description: 'Lentil vegetable stew' },
          { name: 'Mudda Pappu', type: 'Dal', description: 'Thick dal', rural: true },
          { name: 'Tirupati Laddu', type: 'Sweet', description: 'Famous temple offering' },
          { name: 'Peanut Chutney', type: 'Chutney', description: 'Ground peanut chutney', rural: true },
          { name: 'Rasam', type: 'Soup', description: 'Spiced tamarind soup' },
          { name: 'Dosa', type: 'Breakfast', description: 'Rice and lentil crepe' },
          { name: 'Idli', type: 'Breakfast', description: 'Steamed rice cakes' },
          { name: 'Vada', type: 'Snack', description: 'Lentil donuts' },
          { name: 'Payasam', type: 'Sweet', description: 'Sweet pudding' },
        ]
      },
    }
  },

  'Arunachal Pradesh': {
    name: 'Arunachal Pradesh',
    color: '#9B59B6',
    type: 'state',
    districts: {
      'Itanagar': {
        name: 'Itanagar',
        recipes: [
          { name: 'Thukpa', type: 'Soup', description: 'Tibetan noodle soup' },
          { name: 'Momos', type: 'Snack', description: 'Steamed dumplings' },
          { name: 'Pika Pila', type: 'Pickle', description: 'Bamboo shoot pickle', rural: true },
          { name: 'Lukter', type: 'Main Course', description: 'Meat with dry chili', rural: true },
          { name: 'Apong', type: 'Beverage', description: 'Rice beer', rural: true },
          { name: 'Chura Sabji', type: 'Curry', description: 'Fermented cheese curry', rural: true },
          { name: 'Ngatok', type: 'Snack', description: 'Smoked meat', rural: true },
          { name: 'Bamboo Shoot Curry', type: 'Curry', description: 'Fresh bamboo shoot curry', rural: true },
          { name: 'Khapse', type: 'Snack', description: 'Fried cookies' },
          { name: 'Zan', type: 'Porridge', description: 'Millet porridge', rural: true },
        ]
      },
      'Tawang': {
        name: 'Tawang',
        recipes: [
          { name: 'Thenthuk', type: 'Soup', description: 'Hand-pulled noodle soup', rural: true },
          { name: 'Tingmo', type: 'Bread', description: 'Steamed bread' },
          { name: 'Gyapa Khazi', type: 'Fry', description: 'Stir-fried chicken', rural: true },
          { name: 'Sha Phaley', type: 'Snack', description: 'Meat filled bread' },
          { name: 'Butter Tea', type: 'Beverage', description: 'Salted butter tea', rural: true },
          { name: 'Churpi', type: 'Cheese', description: 'Hard cheese', rural: true },
          { name: 'Khambir', type: 'Bread', description: 'Local bread', rural: true },
          { name: 'Phing', type: 'Noodles', description: 'Glass noodles' },
          { name: 'Dresi', type: 'Sweet', description: 'Sweet rice', rural: true },
          { name: 'Momo Soup', type: 'Soup', description: 'Dumplings in soup' },
        ]
      },
      'West Kameng': {
        name: 'West Kameng',
        recipes: [
          { name: 'Bamboo Shoot Fry', type: 'Fry', description: 'Stir-fried bamboo shoots', rural: true },
          { name: 'Fried Rice', type: 'Rice', description: 'Local style fried rice' },
          { name: 'Chicken Stew', type: 'Curry', description: 'Himalayan chicken stew', rural: true },
          { name: 'Potato Curry', type: 'Curry', description: 'Simple potato curry', rural: true },
          { name: 'Rice Beer', type: 'Beverage', description: 'Traditional rice beer', rural: true },
          { name: 'Steamed Greens', type: 'Vegetable', description: 'Local greens', rural: true },
          { name: 'Pork with Bamboo', type: 'Main Course', description: 'Pork with bamboo shoots', rural: true },
          { name: 'Noodle Soup', type: 'Soup', description: 'Clear noodle soup' },
          { name: 'Sweet Bread', type: 'Sweet', description: 'Festival bread' },
          { name: 'Milk Tea', type: 'Beverage', description: 'Butter milk tea', rural: true },
        ]
      },
    }
  },

  'Assam': {
    name: 'Assam',
    color: '#27AE60',
    type: 'state',
    districts: {
      'Guwahati': {
        name: 'Kamrup Metropolitan',
        recipes: [
          { name: 'Masor Tenga', type: 'Curry', description: 'Sour fish curry', rural: true },
          { name: 'Aloo Pitika', type: 'Side Dish', description: 'Mashed potato', rural: true },
          { name: 'Khaar', type: 'Curry', description: 'Alkaline curry with vegetables', rural: true },
          { name: 'Pitha', type: 'Snack', description: 'Rice cakes', rural: true },
          { name: 'Laksa', type: 'Noodles', description: 'Rice noodles' },
          { name: 'Duck Curry', type: 'Curry', description: 'Traditional duck curry', rural: true },
          { name: 'Poitabhat', type: 'Rice', description: 'Fermented rice', rural: true },
          { name: 'Narikol Laru', type: 'Sweet', description: 'Coconut balls' },
          { name: 'Til Pitha', type: 'Sweet', description: 'Sesame rice cake', rural: true },
          { name: 'Assam Tea', type: 'Beverage', description: 'Famous Assam tea' },
        ]
      },
      'Jorhat': {
        name: 'Jorhat',
        recipes: [
          { name: 'Omita Khar', type: 'Curry', description: 'Papaya curry', rural: true },
          { name: 'Kol Pitha', type: 'Snack', description: 'Banana rice cake', rural: true },
          { name: 'Tenga Mach', type: 'Curry', description: 'Sour fish curry', rural: true },
          { name: 'Xaak', type: 'Vegetable', description: 'Mixed greens', rural: true },
          { name: 'Manxho', type: 'Curry', description: 'Meat curry', rural: true },
          { name: 'Sunga Pitha', type: 'Snack', description: 'Rice in bamboo', rural: true },
          { name: 'Bora Saul', type: 'Rice', description: 'Sticky rice', rural: true },
          { name: 'Payox', type: 'Sweet', description: 'Rice pudding', rural: true },
          { name: 'Chira', type: 'Snack', description: 'Flattened rice' },
          { name: 'Jolpan', type: 'Breakfast', description: 'Assamese breakfast platter' },
        ]
      },
      'Dibrugarh': {
        name: 'Dibrugarh',
        recipes: [
          { name: 'Paro Manxho', type: 'Curry', description: 'Pigeon meat curry', rural: true },
          { name: 'Mati Mah', type: 'Dal', description: 'Black gram dal', rural: true },
          { name: 'Bengena Aru Ngonga', type: 'Curry', description: 'Brinjal with fish', rural: true },
          { name: 'Ghila Pitha', type: 'Snack', description: 'Deep fried rice cake', rural: true },
          { name: 'Bilahi Tenga', type: 'Curry', description: 'Tomato curry', rural: true },
          { name: 'Kosu Bilahi Curry', type: 'Vegetable', description: 'Cauliflower tomato curry' },
          { name: 'Bhat Diya Mach', type: 'Curry', description: 'Rice with fish', rural: true },
          { name: 'Tekeli Pitha', type: 'Snack', description: 'Steamed rice cake', rural: true },
          { name: 'Til Mitha Aachar', type: 'Pickle', description: 'Sesame pickle', rural: true },
          { name: 'Doi Chira', type: 'Dessert', description: 'Yogurt with flattened rice' },
        ]
      },
    }
  },

  'Bihar': {
    name: 'Bihar',
    color: '#E67E22',
    type: 'state',
    districts: {
      'Patna': {
        name: 'Patna',
        recipes: [
          { name: 'Litti Chokha', type: 'Main Course', description: 'Stuffed wheat balls with mashed vegetables', rural: true },
          { name: 'Sattu Paratha', type: 'Breakfast', description: 'Paratha with roasted gram flour', rural: true },
          { name: 'Chana Ghugni', type: 'Snack', description: 'Black chickpea curry' },
          { name: 'Khaja', type: 'Sweet', description: 'Layered crispy sweet' },
          { name: 'Thekua', type: 'Sweet', description: 'Traditional fried sweet', rural: true },
          { name: 'Dal Pitha', type: 'Snack', description: 'Lentil filled dumplings', rural: true },
          { name: 'Chura Dahi', type: 'Breakfast', description: 'Flattened rice with yogurt' },
          { name: 'Makhana Kheer', type: 'Sweet', description: 'Fox nuts pudding' },
          { name: 'Aloo Chokha', type: 'Side Dish', description: 'Mashed spiced potato', rural: true },
          { name: 'Kadhi Badi', type: 'Curry', description: 'Yogurt curry with lentil dumplings' },
        ]
      },
      'Gaya': {
        name: 'Gaya',
        recipes: [
          { name: 'Tilkut', type: 'Sweet', description: 'Sesame jaggery brittle', rural: true },
          { name: 'Laung Latika', type: 'Sweet', description: 'Clove flavored sweet' },
          { name: 'Pua', type: 'Sweet', description: 'Sweet pancake', rural: true },
          { name: 'Khichdi', type: 'Rice', description: 'Rice and lentil porridge', rural: true },
          { name: 'Sattu Drink', type: 'Beverage', description: 'Roasted gram flour drink', rural: true },
          { name: 'Peda', type: 'Sweet', description: 'Milk sweet' },
          { name: 'Ghugni', type: 'Snack', description: 'Yellow pea curry', rural: true },
          { name: 'Anarsa', type: 'Sweet', description: 'Rice puffed sweet', rural: true },
          { name: 'Balushahi', type: 'Sweet', description: 'Flaky glazed sweet' },
          { name: 'Nimona', type: 'Curry', description: 'Green pea curry', rural: true },
        ]
      },
      'Bhagalpur': {
        name: 'Bhagalpur',
        recipes: [
          { name: 'Fish Curry', type: 'Curry', description: 'Ganges river fish curry', rural: true },
          { name: 'Bihari Kebab', type: 'Snack', description: 'Minced meat kebab' },
          { name: 'Mutton Curry', type: 'Curry', description: 'Spicy mutton curry' },
          { name: 'Dal Makhani', type: 'Dal', description: 'Black lentil in butter gravy' },
          { name: 'Parwal Ki Mithai', type: 'Sweet', description: 'Pointed gourd sweet' },
          { name: 'Chandrakala', type: 'Sweet', description: 'Crescent shaped sweet' },
          { name: 'Roti Chokha', type: 'Main Course', description: 'Flatbread with mashed vegetables', rural: true },
          { name: 'Baingan Bharta', type: 'Curry', description: 'Smoked eggplant', rural: true },
          { name: 'Pappad', type: 'Snack', description: 'Thin crispy wafer', rural: true },
          { name: 'Pistachio Barfi', type: 'Sweet', description: 'Pistachio fudge' },
        ]
      },
    }
  },

  'Chhattisgarh': {
    name: 'Chhattisgarh',
    color: '#16A085',
    type: 'state',
    districts: {
      'Raipur': {
        name: 'Raipur',
        recipes: [
          { name: 'Bafauri', type: 'Snack', description: 'Steamed lentil cakes', rural: true },
          { name: 'Chila', type: 'Breakfast', description: 'Rice pancake', rural: true },
          { name: 'Bada', type: 'Snack', description: 'Lentil fritters', rural: true },
          { name: 'Aamat', type: 'Curry', description: 'Mixed vegetable curry', rural: true },
          { name: 'Dehati Chicken', type: 'Curry', description: 'Village style chicken', rural: true },
          { name: 'Muthia', type: 'Snack', description: 'Steamed dumplings', rural: true },
          { name: 'Fara', type: 'Snack', description: 'Rice flour dumplings', rural: true },
          { name: 'Khurmi', type: 'Sweet', description: 'Traditional sweet', rural: true },
          { name: 'Bada', type: 'Snack', description: 'Lentil dumplings' },
          { name: 'Arsa', type: 'Sweet', description: 'Rice flour sweet', rural: true },
        ]
      },
      'Bilaspur': {
        name: 'Bilaspur',
        recipes: [
          { name: 'Angakar Roti', type: 'Bread', description: 'Charcoal roasted bread', rural: true },
          { name: 'Bafla', type: 'Bread', description: 'Wheat balls', rural: true },
          { name: 'Petha', type: 'Curry', description: 'Pumpkin curry', rural: true },
          { name: 'Chousela', type: 'Snack', description: 'Rice pancakes', rural: true },
          { name: 'Babru Roti', type: 'Bread', description: 'Stuffed flatbread', rural: true },
          { name: 'Sabudana Khichdi', type: 'Snack', description: 'Tapioca pearls' },
          { name: 'Gulgul Pitha', type: 'Sweet', description: 'Sweet rice cakes', rural: true },
          { name: 'Dhuska', type: 'Snack', description: 'Rice lentil fritters', rural: true },
          { name: 'Bore Baasi', type: 'Rice', description: 'Fermented rice', rural: true },
          { name: 'Kusli', type: 'Sweet', description: 'Traditional sweet', rural: true },
        ]
      },
    }
  },

  'Goa': {
    name: 'Goa',
    color: '#E74C3C',
    type: 'state',
    districts: {
      'North Goa': {
        name: 'North Goa',
        recipes: [
          { name: 'Fish Curry', type: 'Curry', description: 'Coconut fish curry' },
          { name: 'Prawn Balchao', type: 'Pickle', description: 'Spicy prawn pickle' },
          { name: 'Pork Vindaloo', type: 'Curry', description: 'Spicy pork curry' },
          { name: 'Xacuti', type: 'Curry', description: 'Complex spice curry' },
          { name: 'Bebinca', type: 'Sweet', description: 'Layered pudding' },
          { name: 'Sannas', type: 'Bread', description: 'Steamed rice cakes' },
          { name: 'Sol Kadi', type: 'Beverage', description: 'Kokum drink' },
          { name: 'Ros Omelette', type: 'Breakfast', description: 'Omelette in curry' },
          { name: 'Chicken Cafreal', type: 'Fry', description: 'Green chicken curry' },
          { name: 'Feni', type: 'Beverage', description: 'Cashew or coconut liquor' },
        ]
      },
      'South Goa': {
        name: 'South Goa',
        recipes: [
          { name: 'Fish Recheado', type: 'Main Course', description: 'Fish stuffed with masala' },
          { name: 'Sorpotel', type: 'Curry', description: 'Spicy pork curry' },
          { name: 'Khatkhate', type: 'Curry', description: 'Mixed vegetable coconut curry', rural: true },
          { name: 'Dodol', type: 'Sweet', description: 'Coconut jaggery sweet' },
          { name: 'Coconut Barfi', type: 'Sweet', description: 'Coconut fudge' },
          { name: 'Patoli', type: 'Sweet', description: 'Turmeric leaf wraps', rural: true },
          { name: 'Ambot Tik', type: 'Curry', description: 'Sour spicy fish curry' },
          { name: 'Prawn Curry', type: 'Curry', description: 'Coconut prawn curry' },
          { name: 'Balchao', type: 'Pickle', description: 'Spicy pickle' },
          { name: 'Fish Fry', type: 'Fry', description: 'Crispy fried fish' },
        ]
      },
    }
  },

  'Gujarat': {
    name: 'Gujarat',
    color: '#9B59B6',
    type: 'state',
    districts: {
      'Ahmedabad': {
        name: 'Ahmedabad',
        recipes: [
          { name: 'Dhokla', type: 'Snack', description: 'Steamed gram flour cake' },
          { name: 'Khandvi', type: 'Snack', description: 'Gram flour rolls' },
          { name: 'Thepla', type: 'Bread', description: 'Spiced flatbread' },
          { name: 'Undhiyu', type: 'Curry', description: 'Mixed vegetable curry', rural: true },
          { name: 'Fafda Jalebi', type: 'Snack', description: 'Crispy strips with sweet spirals' },
          { name: 'Mohanthal', type: 'Sweet', description: 'Gram flour fudge' },
          { name: 'Khaman', type: 'Snack', description: 'Soft spongy gram cake' },
          { name: 'Handvo', type: 'Savory Cake', description: 'Vegetable rice lentil cake', rural: true },
          { name: 'Shrikhand', type: 'Sweet', description: 'Sweetened yogurt' },
          { name: 'Patra', type: 'Snack', description: 'Colocasia leaf rolls', rural: true },
        ]
      },
      'Surat': {
        name: 'Surat',
        recipes: [
          { name: 'Locho', type: 'Snack', description: 'Steamed gram flour dish' },
          { name: 'Surati Ghari', type: 'Sweet', description: 'Sweet filled pastry' },
          { name: 'Ponk Vada', type: 'Snack', description: 'Tender jowar fritters', rural: true },
          { name: 'Rasawala Khaman', type: 'Snack', description: 'Khaman in gravy' },
          { name: 'Nylon Khaman', type: 'Snack', description: 'Soft white khaman' },
          { name: 'Surati Undhiyu', type: 'Curry', description: 'Surati mixed vegetables', rural: true },
          { name: 'Sev Usal', type: 'Curry', description: 'Peas curry with sev' },
          { name: 'Doodh Pak', type: 'Sweet', description: 'Rice pudding' },
          { name: 'Kakra', type: 'Snack', description: 'Deep fried biscuit' },
          { name: 'Basundi', type: 'Sweet', description: 'Thickened sweet milk' },
        ]
      },
      'Vadodara': {
        name: 'Vadodara',
        recipes: [
          { name: 'Sev Tameta', type: 'Curry', description: 'Tomato with gram flour sev' },
          { name: 'Methi na Gota', type: 'Snack', description: 'Fenugreek fritters' },
          { name: 'Kachori', type: 'Snack', description: 'Stuffed fried bread' },
          { name: 'Aamras Puri', type: 'Breakfast', description: 'Mango pulp with fried bread' },
          { name: 'Khichu', type: 'Snack', description: 'Rice flour dough', rural: true },
          { name: 'Rotli Shaak', type: 'Main Course', description: 'Flatbread with curry', rural: true },
          { name: 'Bataka Pauva', type: 'Snack', description: 'Potato flattened rice' },
          { name: 'Dahi Vada', type: 'Snack', description: 'Lentil dumplings in yogurt' },
          { name: 'Lilva Kachori', type: 'Snack', description: 'Pigeon pea stuffed kachori' },
          { name: 'Sutarfeni', type: 'Sweet', description: 'Thread-like sweet' },
        ]
      },
    }
  },

  // Continue with more states...
  // (For brevity, I'll add a few more key states and show the pattern)

  'Haryana': {
    name: 'Haryana',
    color: '#C0392B',
    type: 'state',
    districts: {
      'Gurugram': {
        name: 'Gurugram',
        recipes: [
          { name: 'Bajra Khichdi', type: 'Rice', description: 'Pearl millet rice', rural: true },
          { name: 'Besan Masala Roti', type: 'Bread', description: 'Gram flour flatbread', rural: true },
          { name: 'Kadhi Pakora', type: 'Curry', description: 'Yogurt curry with fritters' },
          { name: 'Mixed Dal', type: 'Dal', description: 'Mixed lentils', rural: true },
          { name: 'Singri Ki Sabzi', type: 'Curry', description: 'Desert beans curry', rural: true },
          { name: 'Methi Gajar', type: 'Curry', description: 'Fenugreek carrot', rural: true },
          { name: 'Alsi Ki Pinni', type: 'Sweet', description: 'Flaxseed sweet balls', rural: true },
          { name: 'Bathua Raita', type: 'Side Dish', description: 'Chenopodium in yogurt', rural: true },
          { name: 'Churma', type: 'Sweet', description: 'Crushed wheat sweet', rural: true },
          { name: 'Kheer', type: 'Sweet', description: 'Rice pudding' },
        ]
      },
      'Faridabad': {
        name: 'Faridabad',
        recipes: [
          { name: 'Kachri Ki Sabzi', type: 'Curry', description: 'Wild melon curry', rural: true },
          { name: 'Lassi', type: 'Beverage', description: 'Yogurt drink' },
          { name: 'Meethi Seviyan', type: 'Sweet', description: 'Sweet vermicelli' },
          { name: 'Panjiri', type: 'Sweet', description: 'Wheat flour sweet', rural: true },
          { name: 'Rabri', type: 'Sweet', description: 'Thickened milk sweet' },
          { name: 'Saag', type: 'Curry', description: 'Mustard greens', rural: true },
          { name: 'Makki Ki Roti', type: 'Bread', description: 'Corn flour flatbread', rural: true },
          { name: 'Til Ke Ladoo', type: 'Sweet', description: 'Sesame balls', rural: true },
          { name: 'Gulgule', type: 'Sweet', description: 'Sweet fried balls' },
          { name: 'Halwa', type: 'Sweet', description: 'Wheat flour sweet' },
        ]
      },
    }
  },

  'Himachal Pradesh': {
    name: 'Himachal Pradesh',
    color: '#3498DB',
    type: 'state',
    districts: {
      'Shimla': {
        name: 'Shimla',
        recipes: [
          { name: 'Dham', type: 'Main Course', description: 'Traditional feast', rural: true },
          { name: 'Madra', type: 'Curry', description: 'Chickpea curry', rural: true },
          { name: 'Chana Madra', type: 'Curry', description: 'Yogurt chickpea curry', rural: true },
          { name: 'Tudkiya Bhath', type: 'Rice', description: 'Spiced rice', rural: true },
          { name: 'Siddu', type: 'Bread', description: 'Stuffed steamed bread', rural: true },
          { name: 'Aktori', type: 'Pancake', description: 'Buckwheat pancake', rural: true },
          { name: 'Babru', type: 'Bread', description: 'Black gram stuffed bread', rural: true },
          { name: 'Auriya Kaddoo', type: 'Curry', description: 'Pumpkin curry', rural: true },
          { name: 'Mittha', type: 'Sweet', description: 'Sweet rice', rural: true },
          { name: 'Chha Gosht', type: 'Curry', description: 'Marinated lamb curry', rural: true },
        ]
      },
      'Manali': {
        name: 'Kullu',
        recipes: [
          { name: 'Thukpa', type: 'Soup', description: 'Noodle soup' },
          { name: 'Tibetan Bread', type: 'Bread', description: 'Fried bread', rural: true },
          { name: 'Momos', type: 'Snack', description: 'Dumplings' },
          { name: 'Tingmo', type: 'Bread', description: 'Steamed bread' },
          { name: 'Mittha Rice', type: 'Sweet', description: 'Sweet rice', rural: true },
          { name: 'Anardana Chicken', type: 'Curry', description: 'Pomegranate seed chicken' },
          { name: 'Aloo Palda', type: 'Curry', description: 'Potato in yogurt', rural: true },
          { name: 'Sepu Badi', type: 'Curry', description: 'Spinach with lentil nuggets', rural: true },
          { name: 'Khatta', type: 'Curry', description: 'Sour curry', rural: true },
          { name: 'Sweet Lassi', type: 'Beverage', description: 'Yogurt drink' },
        ]
      },
    }
  },

  'Jharkhand': {
    name: 'Jharkhand',
    color: '#8E44AD',
    type: 'state',
    districts: {
      'Ranchi': {
        name: 'Ranchi',
        recipes: [
          { name: 'Dhuska', type: 'Snack', description: 'Rice lentil fritters', rural: true },
          { name: 'Litti Chokha', type: 'Main Course', description: 'Stuffed wheat balls', rural: true },
          { name: 'Rugra', type: 'Curry', description: 'Mushroom curry', rural: true },
          { name: 'Handia', type: 'Beverage', description: 'Rice beer', rural: true },
          { name: 'Chilka Roti', type: 'Bread', description: 'Rice pancake', rural: true },
          { name: 'Arsa', type: 'Sweet', description: 'Rice flour sweet', rural: true },
          { name: 'Malpua', type: 'Sweet', description: 'Sweet pancake' },
          { name: 'Thekua', type: 'Sweet', description: 'Fried sweet cookie', rural: true },
          { name: 'Pittha', type: 'Snack', description: 'Rice cakes', rural: true },
          { name: 'Bamboo Shoot Curry', type: 'Curry', description: 'Tribal bamboo curry', rural: true },
        ]
      },
      'Dhanbad': {
        name: 'Dhanbad',
        recipes: [
          { name: 'Sattu Paratha', type: 'Bread', description: 'Roasted gram flour flatbread', rural: true },
          { name: 'Pua', type: 'Sweet', description: 'Sweet pancake', rural: true },
          { name: 'Dal Pitha', type: 'Snack', description: 'Lentil dumplings', rural: true },
          { name: 'Mutton Curry', type: 'Curry', description: 'Spicy mutton curry' },
          { name: 'Khichdi', type: 'Rice', description: 'Rice and lentil', rural: true },
          { name: 'Chura Dahi', type: 'Breakfast', description: 'Flattened rice with yogurt' },
          { name: 'Aloo Chokha', type: 'Side Dish', description: 'Mashed potato', rural: true },
          { name: 'Kadhi Badi', type: 'Curry', description: 'Yogurt curry' },
          { name: 'Tilkut', type: 'Sweet', description: 'Sesame brittle', rural: true },
          { name: 'Ghugni', type: 'Snack', description: 'Yellow pea curry', rural: true },
        ]
      },
    }
  },

  'Karnataka': {
    name: 'Karnataka',
    color: '#F39C12',
    type: 'state',
    districts: {
      'Bangalore Urban': {
        name: 'Bangalore Urban',
        recipes: [
          { name: 'Bisi Bele Bath', type: 'Rice', description: 'Spiced lentil rice' },
          { name: 'Masala Dosa', type: 'Breakfast', description: 'Crispy crepe with potato filling' },
          { name: 'Idli Sambar', type: 'Breakfast', description: 'Steamed cakes with lentil stew' },
          { name: 'Vada', type: 'Snack', description: 'Lentil donuts' },
          { name: 'Holige', type: 'Sweet', description: 'Sweet flatbread with lentil filling', rural: true },
          { name: 'Kesari Bath', type: 'Sweet', description: 'Semolina sweet' },
          { name: 'Rava Idli', type: 'Breakfast', description: 'Semolina steamed cakes' },
          { name: 'Bisibele Huliyanna', type: 'Rice', description: 'Traditional rice dish', rural: true },
          { name: 'Mysore Pak', type: 'Sweet', description: 'Gram flour sweet' },
          { name: 'Filter Coffee', type: 'Beverage', description: 'South Indian coffee' },
        ]
      },
      'Mysore': {
        name: 'Mysore',
        recipes: [
          { name: 'Mysore Masala Dosa', type: 'Breakfast', description: 'Spicy dosa' },
          { name: 'Ragi Mudde', type: 'Main Course', description: 'Finger millet balls', rural: true },
          { name: 'Jolada Rotti', type: 'Bread', description: 'Sorghum flatbread', rural: true },
          { name: 'Mysore Rasam', type: 'Soup', description: 'Spiced tamarind soup' },
          { name: 'Holige (Obbattu)', type: 'Sweet', description: 'Sweet lentil flatbread', rural: true },
          { name: 'Chitranna', type: 'Rice', description: 'Lemon rice' },
          { name: 'Mysore Pak', type: 'Sweet', description: 'Traditional gram flour sweet' },
          { name: 'Kosambari', type: 'Salad', description: 'Lentil cucumber salad' },
          { name: 'Akki Roti', type: 'Bread', description: 'Rice flatbread', rural: true },
          { name: 'Obbattu Holige', type: 'Sweet', description: 'Festival sweet', rural: true },
        ]
      },
      'Belgaum': {
        name: 'Belgaum',
        recipes: [
          { name: 'Kunda', type: 'Sweet', description: 'Milk sweet' },
          { name: 'Mandige', type: 'Sweet', description: 'Rice fritters' },
          { name: 'Jolada Rotti Ennegai', type: 'Main Course', description: 'Sorghum bread with brinjal', rural: true },
          { name: 'Hurali Saaru', type: 'Curry', description: 'Horse gram curry', rural: true },
          { name: 'Kane Fry', type: 'Fry', description: 'Lady fish fry' },
          { name: 'Girmit', type: 'Snack', description: 'Puffed rice snack' },
          { name: 'Shenga Holige', type: 'Sweet', description: 'Peanut flatbread', rural: true },
          { name: 'Karadantu', type: 'Sweet', description: 'Edible gum sweet', rural: true },
          { name: 'Pundi', type: 'Snack', description: 'Rice balls', rural: true },
          { name: 'Bombil Fry', type: 'Fry', description: 'Bombay duck fry' },
        ]
      },
    }
  },

  'Kerala': {
    name: 'Kerala',
    color: '#27AE60',
    type: 'state',
    districts: {
      'Thiruvananthapuram': {
        name: 'Thiruvananthapuram',
        recipes: [
          { name: 'Sadya', type: 'Main Course', description: 'Traditional feast' },
          { name: 'Appam', type: 'Breakfast', description: 'Rice pancake' },
          { name: 'Stew', type: 'Curry', description: 'Coconut milk stew' },
          { name: 'Puttu Kadala', type: 'Breakfast', description: 'Steamed rice with chickpeas', rural: true },
          { name: 'Fish Moilee', type: 'Curry', description: 'Fish in coconut milk' },
          { name: 'Payasam', type: 'Sweet', description: 'Sweet pudding' },
          { name: 'Avial', type: 'Curry', description: 'Mixed vegetables in coconut', rural: true },
          { name: 'Olan', type: 'Curry', description: 'Pumpkin in coconut milk', rural: true },
          { name: 'Thoran', type: 'Curry', description: 'Stir-fried vegetables with coconut', rural: true },
          { name: 'Pachadi', type: 'Side Dish', description: 'Yogurt based curry' },
        ]
      },
      'Kochi': {
        name: 'Ernakulam',
        recipes: [
          { name: 'Karimeen Pollichathu', type: 'Main Course', description: 'Pearl spot fish wrapped in banana leaf' },
          { name: 'Thalassery Biryani', type: 'Rice', description: 'Malabar biryani' },
          { name: 'Banana Chips', type: 'Snack', description: 'Fried banana slices', rural: true },
          { name: 'Beef Fry', type: 'Fry', description: 'Spicy beef fry' },
          { name: 'Kallummakkaya Fry', type: 'Fry', description: 'Mussel fry' },
          { name: 'Idiyappam', type: 'Breakfast', description: 'String hoppers', rural: true },
          { name: 'Prawn Curry', type: 'Curry', description: 'Coconut prawn curry' },
          { name: 'Ela Ada', type: 'Sweet', description: 'Rice dumpling in banana leaf', rural: true },
          { name: 'Palada Payasam', type: 'Sweet', description: 'Rice pudding' },
          { name: 'Unniyappam', type: 'Sweet', description: 'Rice banana fritters', rural: true },
        ]
      },
      'Kozhikode': {
        name: 'Kozhikode',
        recipes: [
          { name: 'Kozhikode Biriyani', type: 'Rice', description: 'Malabar chicken biryani' },
          { name: 'Halwa', type: 'Sweet', description: 'Sweet Kozhikodan halwa' },
          { name: 'Pathiri', type: 'Bread', description: 'Rice flatbread', rural: true },
          { name: 'Chicken Fry', type: 'Fry', description: 'Malabar style chicken' },
          { name: 'Mussels Fry', type: 'Fry', description: 'Spicy mussels' },
          { name: 'Banana Boli', type: 'Snack', description: 'Banana fritters', rural: true },
          { name: 'Neichoru', type: 'Rice', description: 'Ghee rice' },
          { name: 'Kallappam', type: 'Breakfast', description: 'Toddy fermented rice pancake', rural: true },
          { name: 'Ada Pradhaman', type: 'Sweet', description: 'Rice flakes pudding', rural: true },
          { name: 'Chattipathiri', type: 'Layered Dish', description: 'Layered pastry', rural: true },
        ]
      },
    }
  },

  // Continue with remaining states in same pattern...
  // (Adding placeholder districts for remaining states)

  'Madhya Pradesh': {
    name: 'Madhya Pradesh',
    color: '#E67E22',
    type: 'state',
    districts: {
      'Bhopal': {
        name: 'Bhopal',
        recipes: [
          { name: 'Poha', type: 'Breakfast', description: 'Flattened rice' },
          { name: 'Dal Bafla', type: 'Main Course', description: 'Wheat balls with lentils', rural: true },
          { name: 'Bhutte Ka Kees', type: 'Snack', description: 'Grated corn dish' },
          { name: 'Malpua', type: 'Sweet', description: 'Sweet pancake' },
          { name: 'Jalebi', type: 'Sweet', description: 'Sweet spirals' },
          { name: 'Sabudana Khichdi', type: 'Snack', description: 'Tapioca pearls' },
          { name: 'Chakki Ki Shaak', type: 'Curry', description: 'Sour curry', rural: true },
          { name: 'Palak Puri', type: 'Bread', description: 'Spinach fried bread' },
          { name: 'Lavang Latika', type: 'Sweet', description: 'Clove flavored sweet' },
          { name: 'Doodh Jalebi', type: 'Sweet', description: 'Jalebi in milk' },
        ]
      },
      'Indore': {
        name: 'Indore',
        recipes: [
          { name: 'Poha Jalebi', type: 'Breakfast', description: 'Flattened rice with sweet' },
          { name: 'Sabudana Khichdi', type: 'Snack', description: 'Tapioca pearls' },
          { name: 'Kachori', type: 'Snack', description: 'Stuffed fried bread' },
          { name: 'Bhutte Ka Kees', type: 'Snack', description: 'Grated corn dish' },
          { name: 'Daal Bafla', type: 'Main Course', description: 'Wheat balls with dal', rural: true },
          { name: 'Mawa Bati', type: 'Sweet', description: 'Milk solid balls' },
          { name: 'Garadu', type: 'Snack', description: 'Fried yam', rural: true },
          { name: 'Shikanjvi', type: 'Beverage', description: 'Lemon drink' },
          { name: 'Khopra Patties', type: 'Snack', description: 'Coconut patties' },
          { name: 'Chaat', type: 'Snack', description: 'Street food snack' },
        ]
      },
    }
  },

  'Maharashtra': {
    name: 'Maharashtra',
    color: '#1ABC9C',
    type: 'state',
    districts: {
      'Mumbai City': {
        name: 'Mumbai City',
        recipes: [
          { name: 'Vada Pav', type: 'Snack', description: 'Potato fritter in bun' },
          { name: 'Pav Bhaji', type: 'Main Course', description: 'Mashed vegetables with bread' },
          { name: 'Misal Pav', type: 'Main Course', description: 'Spicy sprouts curry with bread' },
          { name: 'Bhel Puri', type: 'Snack', description: 'Puffed rice snack' },
          { name: 'Pani Puri', type: 'Snack', description: 'Crispy shells with spicy water' },
          { name: 'Dabeli', type: 'Snack', description: 'Spiced potato in bun' },
          { name: 'Kanda Poha', type: 'Breakfast', description: 'Onion flattened rice' },
          { name: 'Sabudana Vada', type: 'Snack', description: 'Tapioca fritters' },
          { name: 'Modak', type: 'Sweet', description: 'Sweet dumplings' },
          { name: 'Puran Poli', type: 'Sweet', description: 'Sweet lentil flatbread' },
        ]
      },
      'Pune': {
        name: 'Pune',
        recipes: [
          { name: 'Misal Pav', type: 'Main Course', description: 'Spicy lentil sprouts' },
          { name: 'Mastani', type: 'Beverage', description: 'Thick milkshake' },
          { name: 'Bhakarwadi', type: 'Snack', description: 'Spicy rolled snack' },
          { name: 'Puran Poli', type: 'Sweet', description: 'Sweet flatbread', rural: true },
          { name: 'Pithla Bhakri', type: 'Main Course', description: 'Gram flour curry with millet bread', rural: true },
          { name: 'Zunka Bhakri', type: 'Main Course', description: 'Chickpea flour side with bread', rural: true },
          { name: 'Varan Bhaat', type: 'Rice', description: 'Dal rice', rural: true },
          { name: 'Bhakri', type: 'Bread', description: 'Millet flatbread', rural: true },
          { name: 'Modak', type: 'Sweet', description: 'Steamed dumplings' },
          { name: 'Shrikhand', type: 'Sweet', description: 'Sweetened yogurt' },
        ]
      },
      'Nagpur': {
        name: 'Nagpur',
        recipes: [
          { name: 'Tarri Poha', type: 'Breakfast', description: 'Flattened rice in spicy gravy' },
          { name: 'Saoji Chicken', type: 'Curry', description: 'Spicy chicken curry' },
          { name: 'Patodi Rassa', type: 'Curry', description: 'Gram flour rolls in curry' },
          { name: 'Nagpuri Samosa', type: 'Snack', description: 'Stuffed pastry' },
          { name: 'Orange Barfi', type: 'Sweet', description: 'Orange flavored fudge' },
          { name: 'Kadboli', type: 'Snack', description: 'Gram flour spiral', rural: true },
          { name: 'Zunka', type: 'Side Dish', description: 'Chickpea flour dry curry', rural: true },
          { name: 'Pitla', type: 'Curry', description: 'Gram flour curry', rural: true },
          { name: 'Khichdi', type: 'Rice', description: 'Rice and lentils', rural: true },
          { name: 'Puran Poli', type: 'Sweet', description: 'Sweet lentil flatbread', rural: true },
        ]
      },
    }
  },

  'Manipur': {
    name: 'Manipur',
    color: '#E74C3C',
    type: 'state',
    districts: {
      'Imphal West': {
        name: 'Imphal West',
        recipes: [
          { name: 'Eromba', type: 'Curry', description: 'Vegetable with fermented fish', rural: true },
          { name: 'Morok Metpa', type: 'Chutney', description: 'Chili chutney', rural: true },
          { name: 'Ngari', type: 'Condiment', description: 'Fermented fish', rural: true },
          { name: 'Chamthong', type: 'Soup', description: 'Vegetable stew', rural: true },
          { name: 'Singju', type: 'Salad', description: 'Vegetable salad', rural: true },
          { name: 'Paknam', type: 'Pickle', description: 'Bamboo shoot pickle', rural: true },
          { name: 'Kangshoi', type: 'Soup', description: 'Healthy vegetable soup', rural: true },
          { name: 'Alu Kangmet', type: 'Curry', description: 'Potato curry', rural: true },
          { name: 'Chak-hao Kheer', type: 'Sweet', description: 'Black rice pudding', rural: true },
          { name: 'Paaknam', type: 'Fermented', description: 'Fermented soybeans', rural: true },
        ]
      },
    }
  },

  'Meghalaya': {
    name: 'Meghalaya',
    color: '#16A085',
    type: 'state',
    districts: {
      'East Khasi Hills': {
        name: 'East Khasi Hills',
        recipes: [
          { name: 'Jadoh', type: 'Rice', description: 'Rice cooked with meat', rural: true },
          { name: 'Dohneiiong', type: 'Curry', description: 'Pork with black sesame', rural: true },
          { name: 'Doh Khlieh', type: 'Salad', description: 'Pork salad', rural: true },
          { name: 'Tungtap', type: 'Fermented', description: 'Fermented fish', rural: true },
          { name: 'Pukhlein', type: 'Snack', description: 'Fried rice cake', rural: true },
          { name: 'Minil Songa', type: 'Snack', description: 'Sticky rice cake', rural: true },
          { name: 'Nakham Bitchi', type: 'Curry', description: 'Dried fish chutney', rural: true },
          { name: 'Ki Kpu', type: 'Rice', description: 'Rice beer', rural: true },
          { name: 'Pumaloi', type: 'Bread', description: 'Sticky rice bread', rural: true },
          { name: 'Jhur Sideh', type: 'Chicken', description: 'Shredded chicken', rural: true },
        ]
      },
    }
  },

  'Mizoram': {
    name: 'Mizoram',
    color: '#E67E22',
    type: 'state',
    districts: {
      'Aizawl': {
        name: 'Aizawl',
        recipes: [
          { name: 'Bai', type: 'Soup', description: 'Vegetable and herb stew', rural: true },
          { name: 'Vawksa Rep', type: 'Curry', description: 'Smoked pork', rural: true },
          { name: 'Sawhchiar', type: 'Rice', description: 'Rice porridge', rural: true },
          { name: 'Bamboo Shoot Fry', type: 'Fry', description: 'Fried bamboo shoots', rural: true },
          { name: 'Zu', type: 'Beverage', description: 'Rice beer', rural: true },
          { name: 'Chhangban', type: 'Salad', description: 'Steamed vegetables', rural: true },
          { name: 'Panch Phoran Tarkari', type: 'Curry', description: 'Five spice vegetables', rural: true },
          { name: 'Misa Mach Poora', type: 'Curry', description: 'Shrimp paste curry', rural: true },
          { name: 'Koat Pitha', type: 'Snack', description: 'Fried fritter', rural: true },
          { name: 'Arsa Buhchiar', type: 'Chicken', description: 'Chicken cooked in rice paste', rural: true },
        ]
      },
    }
  },

  'Nagaland': {
    name: 'Nagaland',
    color: '#3498DB',
    type: 'state',
    districts: {
      'Kohima': {
        name: 'Kohima',
        recipes: [
          { name: 'Smoked Pork', type: 'Main Course', description: 'Traditional smoked pork', rural: true },
          { name: 'Axone', type: 'Condiment', description: 'Fermented soybean', rural: true },
          { name: 'Galho', type: 'Rice', description: 'Rice porridge with vegetables', rural: true },
          { name: 'Bamboo Shoot', type: 'Curry', description: 'Fermented bamboo shoot curry', rural: true },
          { name: 'Naga Chutney', type: 'Chutney', description: 'Extremely spicy chutney', rural: true },
          { name: 'Anishi', type: 'Fermented', description: 'Fermented yam leaves', rural: true },
          { name: 'Fish Cooked in Bamboo', type: 'Main Course', description: 'Bamboo steamed fish', rural: true },
          { name: 'Zutho', type: 'Beverage', description: 'Rice beer', rural: true },
          { name: 'Akini Chokibo', type: 'Snack', description: 'Perilla and axone chutney', rural: true },
          { name: 'Hinkejvu', type: 'Curry', description: 'Colocasia leaves curry', rural: true },
        ]
      },
    }
  },

  'Odisha': {
    name: 'Odisha',
    color: '#9B59B6',
    type: 'state',
    districts: {
      'Puri': {
        name: 'Puri',
        recipes: [
          { name: 'Mahaprasad', type: 'Main Course', description: 'Temple offering food' },
          { name: 'Khichdi', type: 'Rice', description: 'Rice and lentil porridge' },
          { name: 'Rasagola', type: 'Sweet', description: 'Spongy cottage cheese balls' },
          { name: 'Chhena Poda', type: 'Sweet', description: 'Baked cottage cheese cake' },
          { name: 'Dalma', type: 'Dal', description: 'Mixed vegetables with lentils', rural: true },
          { name: 'Santula', type: 'Curry', description: 'Mixed vegetable curry', rural: true },
          { name: 'Machha Besara', type: 'Curry', description: 'Fish in mustard gravy', rural: true },
          { name: 'Pakhala Bhata', type: 'Rice', description: 'Fermented rice', rural: true },
          { name: 'Kakara Pitha', type: 'Sweet', description: 'Stuffed pancake', rural: true },
          { name: 'Arisa Pitha', type: 'Sweet', description: 'Rice flour sweet', rural: true },
        ]
      },
      'Bhubaneswar': {
        name: 'Khordha',
        recipes: [
          { name: 'Dalma', type: 'Dal', description: 'Lentil vegetable stew', rural: true },
          { name: 'Chhena Gaja', type: 'Sweet', description: 'Cottage cheese sweet' },
          { name: 'Kanika', type: 'Rice', description: 'Sweet yellow rice' },
          { name: 'Machha Kalia', type: 'Curry', description: 'Fish curry' },
          { name: 'Dahi Baigana', type: 'Curry', description: 'Eggplant in yogurt', rural: true },
          { name: 'Aloo Potala Rasa', type: 'Curry', description: 'Potato pointed gourd curry', rural: true },
          { name: 'Chingudi Jhola', type: 'Curry', description: 'Prawn curry' },
          { name: 'Khiri', type: 'Sweet', description: 'Rice pudding' },
          { name: 'Manda Pitha', type: 'Sweet', description: 'Steamed rice cake', rural: true },
          { name: 'Enduri Pitha', type: 'Sweet', description: 'Rice cake in turmeric leaf', rural: true },
        ]
      },
    }
  },

  'Punjab': {
    name: 'Punjab',
    color: '#E74C3C',
    type: 'state',
    districts: {
      'Amritsar': {
        name: 'Amritsar',
        recipes: [
          { name: 'Amritsari Kulcha', type: 'Bread', description: 'Stuffed bread' },
          { name: 'Chole Bhature', type: 'Main Course', description: 'Chickpea curry with fried bread' },
          { name: 'Makki Ki Roti Sarson Ka Saag', type: 'Main Course', description: 'Corn bread with mustard greens', rural: true },
          { name: 'Amritsari Fish', type: 'Fry', description: 'Crispy fried fish' },
          { name: 'Butter Chicken', type: 'Curry', description: 'Chicken in butter tomato gravy' },
          { name: 'Dal Makhani', type: 'Dal', description: 'Black lentils in butter' },
          { name: 'Lassi', type: 'Beverage', description: 'Yogurt drink' },
          { name: 'Pinni', type: 'Sweet', description: 'Wheat flour sweet balls', rural: true },
          { name: 'Jalebi', type: 'Sweet', description: 'Sweet spirals' },
          { name: 'Kulfi', type: 'Sweet', description: 'Indian ice cream' },
        ]
      },
      'Ludhiana': {
        name: 'Ludhiana',
        recipes: [
          { name: 'Tandoori Chicken', type: 'Main Course', description: 'Clay oven grilled chicken' },
          { name: 'Paneer Tikka', type: 'Snack', description: 'Grilled cottage cheese' },
          { name: 'Rajma Chawal', type: 'Rice', description: 'Kidney beans with rice', rural: true },
          { name: 'Kadhi Pakora', type: 'Curry', description: 'Yogurt curry with fritters' },
          { name: 'Aloo Paratha', type: 'Bread', description: 'Potato stuffed flatbread' },
          { name: 'Chana Dal', type: 'Dal', description: 'Split chickpea lentils' },
          { name: 'Gajar Ka Halwa', type: 'Sweet', description: 'Carrot pudding' },
          { name: 'Besan Ladoo', type: 'Sweet', description: 'Gram flour balls' },
          { name: 'Makki Ki Roti', type: 'Bread', description: 'Corn flatbread', rural: true },
          { name: 'Moong Dal Halwa', type: 'Sweet', description: 'Lentil sweet' },
        ]
      },
    }
  },

  'Rajasthan': {
    name: 'Rajasthan',
    color: '#C0392B',
    type: 'state',
    districts: {
      'Jaipur': {
        name: 'Jaipur',
        recipes: [
          { name: 'Dal Baati Churma', type: 'Main Course', description: 'Lentils with wheat balls and sweet', rural: true },
          { name: 'Laal Maas', type: 'Curry', description: 'Spicy red meat curry' },
          { name: 'Ghevar', type: 'Sweet', description: 'Honeycomb sweet' },
          { name: 'Pyaaz Kachori', type: 'Snack', description: 'Onion stuffed fried bread' },
          { name: 'Mirchi Bada', type: 'Snack', description: 'Chili fritters' },
          { name: 'Ker Sangri', type: 'Curry', description: 'Desert beans curry', rural: true },
          { name: 'Gatte Ki Sabzi', type: 'Curry', description: 'Gram flour dumplings curry' },
          { name: 'Mawa Kachori', type: 'Sweet', description: 'Sweet stuffed kachori' },
          { name: 'Mohan Thaal', type: 'Sweet', description: 'Gram flour fudge' },
          { name: 'Lassi', type: 'Beverage', description: 'Yogurt drink' },
        ]
      },
      'Jodhpur': {
        name: 'Jodhpur',
        recipes: [
          { name: 'Makhaniya Lassi', type: 'Beverage', description: 'Butter yogurt drink' },
          { name: 'Pyaaz Kachori', type: 'Snack', description: 'Onion kachori' },
          { name: 'Mirchi Vada', type: 'Snack', description: 'Chili potato fritters' },
          { name: 'Dal Baati Churma', type: 'Main Course', description: 'Traditional wheat balls with lentils', rural: true },
          { name: 'Gulab Jamun', type: 'Sweet', description: 'Milk sweet balls' },
          { name: 'Mawa Kachori', type: 'Sweet', description: 'Sweet kachori' },
          { name: 'Laal Maas', type: 'Curry', description: 'Spicy meat curry' },
          { name: 'Ker Sangri', type: 'Curry', description: 'Desert vegetable', rural: true },
          { name: 'Pakora', type: 'Snack', description: 'Vegetable fritters' },
          { name: 'Ghevar', type: 'Sweet', description: 'Honeycomb sweet' },
        ]
      },
    }
  },

  'Sikkim': {
    name: 'Sikkim',
    color: '#27AE60',
    type: 'state',
    districts: {
      'East Sikkim': {
        name: 'East Sikkim',
        recipes: [
          { name: 'Momos', type: 'Snack', description: 'Steamed dumplings' },
          { name: 'Thukpa', type: 'Soup', description: 'Noodle soup' },
          { name: 'Phagshapa', type: 'Curry', description: 'Pork with radish', rural: true },
          { name: 'Gundruk', type: 'Fermented', description: 'Fermented leafy greens', rural: true },
          { name: 'Sel Roti', type: 'Snack', description: 'Rice bread ring' },
          { name: 'Kinema', type: 'Fermented', description: 'Fermented soybean', rural: true },
          { name: 'Churpi', type: 'Cheese', description: 'Hard yak cheese', rural: true },
          { name: 'Sael Roti', type: 'Bread', description: 'Traditional bread', rural: true },
          { name: 'Shaphaley', type: 'Snack', description: 'Meat filled bread' },
          { name: 'Chhurpi Soup', type: 'Soup', description: 'Cheese soup', rural: true },
        ]
      },
    }
  },

  'Tamil Nadu': {
    name: 'Tamil Nadu',
    color: '#E67E22',
    type: 'state',
    districts: {
      'Chennai': {
        name: 'Chennai',
        recipes: [
          { name: 'Idli', type: 'Breakfast', description: 'Steamed rice cakes' },
          { name: 'Dosa', type: 'Breakfast', description: 'Crispy rice crepe' },
          { name: 'Sambar', type: 'Curry', description: 'Lentil vegetable stew' },
          { name: 'Vada', type: 'Snack', description: 'Lentil donuts' },
          { name: 'Pongal', type: 'Rice', description: 'Rice and lentil porridge' },
          { name: 'Rasam', type: 'Soup', description: 'Tamarind soup' },
          { name: 'Chettinad Chicken', type: 'Curry', description: 'Spicy chicken curry' },
          { name: 'Payasam', type: 'Sweet', description: 'Sweet pudding' },
          { name: 'Filter Coffee', type: 'Beverage', description: 'South Indian coffee' },
          { name: 'Murukku', type: 'Snack', description: 'Savory spiral snack' },
        ]
      },
      'Madurai': {
        name: 'Madurai',
        recipes: [
          { name: 'Jigarthanda', type: 'Beverage', description: 'Cold milk dessert drink' },
          { name: 'Parotta', type: 'Bread', description: 'Layered flatbread' },
          { name: 'Chicken Chettinad', type: 'Curry', description: 'Spicy chicken curry' },
          { name: 'Kari Dosai', type: 'Breakfast', description: 'Spicy dosa', rural: true },
          { name: 'Paruthi Paal', type: 'Beverage', description: 'Cotton seed milk', rural: true },
          { name: 'Athirasam', type: 'Sweet', description: 'Rice jaggery sweet', rural: true },
          { name: 'Kuzhi Paniyaram', type: 'Snack', description: 'Ball-shaped snack' },
          { name: 'Mutton Kola Urundai', type: 'Curry', description: 'Meatball curry' },
          { name: 'Nei Payasam', type: 'Sweet', description: 'Ghee pudding' },
          { name: 'Paal Kozhukattai', type: 'Sweet', description: 'Rice dumplings in milk', rural: true },
        ]
      },
      'Coimbatore': {
        name: 'Coimbatore',
        recipes: [
          { name: 'Idiyappam', type: 'Breakfast', description: 'String hoppers', rural: true },
          { name: 'Appam', type: 'Breakfast', description: 'Rice pancake' },
          { name: 'Kothu Parotta', type: 'Main Course', description: 'Shredded flatbread with curry' },
          { name: 'Keera Vadai', type: 'Snack', description: 'Spinach fritters', rural: true },
          { name: 'Arisi Upma', type: 'Breakfast', description: 'Rice upma', rural: true },
          { name: 'Kambu Koozh', type: 'Beverage', description: 'Millet porridge drink', rural: true },
          { name: 'Paniyaram', type: 'Snack', description: 'Rice lentil balls' },
          { name: 'Ellu Urundai', type: 'Sweet', description: 'Sesame balls', rural: true },
          { name: 'Ragi Kali', type: 'Main Course', description: 'Finger millet balls', rural: true },
          { name: 'Sukku Kaapi', type: 'Beverage', description: 'Dry ginger coffee', rural: true },
        ]
      },
    }
  },

  'Telangana': {
    name: 'Telangana',
    color: '#1ABC9C',
    type: 'state',
    districts: {
      'Hyderabad': {
        name: 'Hyderabad',
        recipes: [
          { name: 'Hyderabadi Biryani', type: 'Rice', description: 'Famous aromatic rice dish' },
          { name: 'Haleem', type: 'Main Course', description: 'Slow-cooked meat stew' },
          { name: 'Mirchi Ka Salan', type: 'Curry', description: 'Chili peanut curry' },
          { name: 'Double Ka Meetha', type: 'Sweet', description: 'Bread pudding' },
          { name: 'Qubani Ka Meetha', type: 'Sweet', description: 'Apricot dessert' },
          { name: 'Lukhmi', type: 'Snack', description: 'Pastry with meat filling' },
          { name: 'Bagara Baingan', type: 'Curry', description: 'Eggplant in peanut sesame gravy' },
          { name: 'Sheer Korma', type: 'Sweet', description: 'Vermicelli pudding' },
          { name: 'Irani Chai', type: 'Beverage', description: 'Milk tea' },
          { name: 'Osmania Biscuit', type: 'Snack', description: 'Salty sweet biscuit' },
        ]
      },
      'Warangal Urban': {
        name: 'Warangal Urban',
        recipes: [
          { name: 'Sakinalu', type: 'Snack', description: 'Rice flour spirals', rural: true },
          { name: 'Boorelu', type: 'Sweet', description: 'Sweet lentil balls', rural: true },
          { name: 'Pachi Pulusu', type: 'Soup', description: 'Raw tamarind soup', rural: true },
          { name: 'Sarva Pindi', type: 'Bread', description: 'Rice flour pancake', rural: true },
          { name: 'Jonna Rotte', type: 'Bread', description: 'Sorghum flatbread', rural: true },
          { name: 'Bellam Pappu', type: 'Dal', description: 'Jaggery lentils', rural: true },
          { name: 'Gutti Vankaya', type: 'Curry', description: 'Stuffed brinjal' },
          { name: 'Bandipotu', type: 'Snack', description: 'Traditional sweet', rural: true },
          { name: 'Ariselu', type: 'Sweet', description: 'Rice flour sweet', rural: true },
          { name: 'Ravva Dosa', type: 'Breakfast', description: 'Semolina crepe' },
        ]
      },
    }
  },

  'Tripura': {
    name: 'Tripura',
    color: '#E74C3C',
    type: 'state',
    districts: {
      'West Tripura': {
        name: 'West Tripura',
        recipes: [
          { name: 'Mui Borok', type: 'Curry', description: 'Fermented fish curry', rural: true },
          { name: 'Wahan Mosdeng', type: 'Salad', description: 'Pork salad', rural: true },
          { name: 'Gudok', type: 'Curry', description: 'Mixed vegetable stew', rural: true },
          { name: 'Chakhwi', type: 'Curry', description: 'Bamboo shoot curry', rural: true },
          { name: 'Panch Phoron Tarkari', type: 'Curry', description: 'Five spice vegetables' },
          { name: 'Bhangui', type: 'Rice', description: 'Rice beer', rural: true },
          { name: 'Kosoi Bwtwi', type: 'Snack', description: 'Fried cakes', rural: true },
          { name: 'Mwkhwi', type: 'Beverage', description: 'Rice wine', rural: true },
          { name: 'Chiakhlam', type: 'Main Course', description: 'Rice with meat', rural: true },
          { name: 'Berma', type: 'Dried Fish', description: 'Dried fermented fish', rural: true },
        ]
      },
    }
  },

  'Uttar Pradesh': {
    name: 'Uttar Pradesh',
    color: '#9B59B6',
    type: 'state',
    districts: {
      'Lucknow': {
        name: 'Lucknow',
        recipes: [
          { name: 'Tunday Kabab', type: 'Snack', description: 'Minced meat kabab' },
          { name: 'Lucknowi Biryani', type: 'Rice', description: 'Awadhi style biryani' },
          { name: 'Kakori Kabab', type: 'Snack', description: 'Soft minced meat kabab' },
          { name: 'Sheermal', type: 'Bread', description: 'Saffron flatbread' },
          { name: 'Malai Makhan', type: 'Snack', description: 'Cream fritters' },
          { name: 'Basket Chaat', type: 'Snack', description: 'Potato basket with toppings' },
          { name: 'Kulfi Faluda', type: 'Sweet', description: 'Ice cream with vermicelli' },
          { name: 'Makhan Malai', type: 'Sweet', description: 'Cream dessert' },
          { name: 'Galouti Kabab', type: 'Snack', description: 'Melt-in-mouth kabab' },
          { name: 'Nihari', type: 'Curry', description: 'Slow-cooked meat stew' },
        ]
      },
      'Varanasi': {
        name: 'Varanasi',
        recipes: [
          { name: 'Kachori Sabzi', type: 'Breakfast', description: 'Stuffed fried bread with curry' },
          { name: 'Tamatar Chaat', type: 'Snack', description: 'Tomato chaat' },
          { name: 'Malaiyo', type: 'Sweet', description: 'Milk foam dessert' },
          { name: 'Banarasi Paan', type: 'Digestive', description: 'Betel leaf preparation' },
          { name: 'Launglata', type: 'Sweet', description: 'Clove pastry' },
          { name: 'Chura Matar', type: 'Snack', description: 'Flattened rice with peas', rural: true },
          { name: 'Dahi Vada', type: 'Snack', description: 'Lentil balls in yogurt' },
          { name: 'Baati Chokha', type: 'Main Course', description: 'Wheat balls with mashed vegetables', rural: true },
          { name: 'Jalebi', type: 'Sweet', description: 'Sweet spirals' },
          { name: 'Rabri', type: 'Sweet', description: 'Thickened milk sweet' },
        ]
      },
      'Agra': {
        name: 'Agra',
        recipes: [
          { name: 'Petha', type: 'Sweet', description: 'Ash gourd sweet' },
          { name: 'Bedai', type: 'Breakfast', description: 'Spicy fried bread' },
          { name: 'Dalmoth', type: 'Snack', description: 'Spicy fried lentils' },
          { name: 'Bhalla', type: 'Snack', description: 'Lentil dumplings' },
          { name: 'Jalebi', type: 'Sweet', description: 'Sweet spirals' },
          { name: 'Kachori', type: 'Snack', description: 'Stuffed fried bread' },
          { name: 'Paneer Petha', type: 'Sweet', description: 'Cottage cheese petha' },
          { name: 'Patthar Ka Gosht', type: 'Main Course', description: 'Stone-cooked meat' },
          { name: 'Aloo Tikki', type: 'Snack', description: 'Potato patties' },
          { name: 'Samosa', type: 'Snack', description: 'Stuffed pastry' },
        ]
      },
    }
  },

  'Uttarakhand': {
    name: 'Uttarakhand',
    color: '#16A085',
    type: 'state',
    districts: {
      'Dehradun': {
        name: 'Dehradun',
        recipes: [
          { name: 'Kafuli', type: 'Curry', description: 'Spinach curry', rural: true },
          { name: 'Chainsoo', type: 'Dal', description: 'Black gram dal', rural: true },
          { name: 'Jhangora Ki Kheer', type: 'Sweet', description: 'Barnyard millet pudding', rural: true },
          { name: 'Aloo Ke Gutke', type: 'Snack', description: 'Spicy potatoes', rural: true },
          { name: 'Bal Mithai', type: 'Sweet', description: 'Chocolate-coated fudge' },
          { name: 'Singori', type: 'Sweet', description: 'Khoya sweet in leaf', rural: true },
          { name: 'Gahat Ki Dal', type: 'Dal', description: 'Horse gram dal', rural: true },
          { name: 'Baadi', type: 'Curry', description: 'Black gram nuggets', rural: true },
          { name: 'Phaanu', type: 'Dal', description: 'Mixed lentils', rural: true },
          { name: 'Kandalee Ka Saag', type: 'Curry', description: 'Himalayan nettle curry', rural: true },
        ]
      },
      'Nainital': {
        name: 'Nainital',
        recipes: [
          { name: 'Bhatt Ki Churkani', type: 'Dal', description: 'Black soybean curry', rural: true },
          { name: 'Arsa', type: 'Sweet', description: 'Rice flour sweet', rural: true },
          { name: 'Ras', type: 'Curry', description: 'Lentil gravy', rural: true },
          { name: 'Dubuk', type: 'Dal', description: 'Lentil curry', rural: true },
          { name: 'Gulgula', type: 'Sweet', description: 'Sweet fried balls' },
          { name: 'Sisunak Saag', type: 'Curry', description: 'Nettle curry', rural: true },
          { name: 'Kulath Ki Dal', type: 'Dal', description: 'Horse gram dal', rural: true },
          { name: 'Madua Roti', type: 'Bread', description: 'Finger millet flatbread', rural: true },
          { name: 'Chudkani', type: 'Curry', description: 'Dal curry', rural: true },
          { name: 'Aloo Tamatar Ka Jhol', type: 'Curry', description: 'Potato tomato curry', rural: true },
        ]
      },
    }
  },

  'West Bengal': {
    name: 'West Bengal',
    color: '#E67E22',
    type: 'state',
    districts: {
      'Kolkata': {
        name: 'Kolkata',
        recipes: [
          { name: 'Macher Jhol', type: 'Curry', description: 'Fish curry' },
          { name: 'Kosha Mangsho', type: 'Curry', description: 'Slow-cooked mutton' },
          { name: 'Aloo Posto', type: 'Curry', description: 'Potato in poppy seeds', rural: true },
          { name: 'Ilish Bhapa', type: 'Main Course', description: 'Steamed hilsa fish' },
          { name: 'Rosogolla', type: 'Sweet', description: 'Cottage cheese balls in syrup' },
          { name: 'Sandesh', type: 'Sweet', description: 'Cottage cheese sweet' },
          { name: 'Mishti Doi', type: 'Sweet', description: 'Sweet yogurt' },
          { name: 'Luchi Alur Dom', type: 'Breakfast', description: 'Fried bread with potato curry' },
          { name: 'Chingri Malai Curry', type: 'Curry', description: 'Prawn in coconut milk' },
          { name: 'Patishapta', type: 'Sweet', description: 'Rice flour crepes', rural: true },
        ]
      },
      'Darjeeling': {
        name: 'Darjeeling',
        recipes: [
          { name: 'Momos', type: 'Snack', description: 'Steamed dumplings' },
          { name: 'Thukpa', type: 'Soup', description: 'Noodle soup' },
          { name: 'Sel Roti', type: 'Snack', description: 'Rice bread ring' },
          { name: 'Kinema', type: 'Fermented', description: 'Fermented soybean', rural: true },
          { name: 'Gundruk', type: 'Fermented', description: 'Fermented greens', rural: true },
          { name: 'Sha Phaley', type: 'Snack', description: 'Meat filled bread' },
          { name: 'Churpi', type: 'Cheese', description: 'Hard cheese', rural: true },
          { name: 'Darjeeling Tea', type: 'Beverage', description: 'Famous tea' },
          { name: 'Wonton Soup', type: 'Soup', description: 'Dumpling soup' },
          { name: 'Sael Roti', type: 'Bread', description: 'Traditional bread', rural: true },
        ]
      },
    }
  },

  // UNION TERRITORIES (8)

  'Andaman and Nicobar Islands': {
    name: 'Andaman and Nicobar Islands',
    color: '#3498DB',
    type: 'ut',
    districts: {
      'South Andaman': {
        name: 'South Andaman',
        recipes: [
          { name: 'Fish Curry', type: 'Curry', description: 'Coconut fish curry' },
          { name: 'Prawn Curry', type: 'Curry', description: 'Fresh prawn curry' },
          { name: 'Grilled Fish', type: 'Main Course', description: 'Barbecued fresh fish' },
          { name: 'Coconut Prawn', type: 'Curry', description: 'Prawns in coconut' },
          { name: 'Banana Flower Curry', type: 'Curry', description: 'Banana blossom curry', rural: true },
          { name: 'Fish Fry', type: 'Fry', description: 'Crispy fried fish' },
          { name: 'Lobster Curry', type: 'Curry', description: 'Fresh lobster curry' },
          { name: 'Crab Curry', type: 'Curry', description: 'Spicy crab curry' },
          { name: 'Coconut Rice', type: 'Rice', description: 'Rice with coconut', rural: true },
          { name: 'Seafood Platter', type: 'Main Course', description: 'Mixed seafood' },
        ]
      },
    }
  },

  'Chandigarh': {
    name: 'Chandigarh',
    color: '#E74C3C',
    type: 'ut',
    districts: {
      'Chandigarh': {
        name: 'Chandigarh',
        recipes: [
          { name: 'Chole Bhature', type: 'Main Course', description: 'Chickpea curry with fried bread' },
          { name: 'Rajma Chawal', type: 'Rice', description: 'Kidney beans with rice' },
          { name: 'Aloo Paratha', type: 'Bread', description: 'Potato stuffed flatbread' },
          { name: 'Kadhi Pakora', type: 'Curry', description: 'Yogurt curry with fritters' },
          { name: 'Sarson Ka Saag', type: 'Curry', description: 'Mustard greens curry', rural: true },
          { name: 'Makki Ki Roti', type: 'Bread', description: 'Corn flatbread', rural: true },
          { name: 'Lassi', type: 'Beverage', description: 'Yogurt drink' },
          { name: 'Butter Chicken', type: 'Curry', description: 'Chicken in butter tomato gravy' },
          { name: 'Dal Makhani', type: 'Dal', description: 'Black lentils in butter' },
          { name: 'Kulfi', type: 'Sweet', description: 'Indian ice cream' },
        ]
      },
    }
  },

  'Dadra and Nagar Haveli and Daman and Diu': {
    name: 'Dadra and Nagar Haveli and Daman and Diu',
    color: '#16A085',
    type: 'ut',
    districts: {
      'Daman': {
        name: 'Daman',
        recipes: [
          { name: 'Papdi Nu Shaak', type: 'Curry', description: 'Valor beans curry', rural: true },
          { name: 'Khaman', type: 'Snack', description: 'Steamed gram flour cake' },
          { name: 'Fish Curry', type: 'Curry', description: 'Coastal fish curry' },
          { name: 'Khandvi', type: 'Snack', description: 'Gram flour rolls' },
          { name: 'Undhiyu', type: 'Curry', description: 'Mixed vegetable curry', rural: true },
          { name: 'Thepla', type: 'Bread', description: 'Spiced flatbread' },
          { name: 'Dhokla', type: 'Snack', description: 'Steamed savory cake' },
          { name: 'Fafda', type: 'Snack', description: 'Crispy strips' },
          { name: 'Patra', type: 'Snack', description: 'Colocasia leaf rolls', rural: true },
          { name: 'Shrikhand', type: 'Sweet', description: 'Sweetened yogurt' },
        ]
      },
    }
  },

  'Delhi': {
    name: 'Delhi',
    color: '#9B59B6',
    type: 'ut',
    districts: {
      'New Delhi': {
        name: 'New Delhi',
        recipes: [
          { name: 'Chole Bhature', type: 'Main Course', description: 'Chickpea curry with fried bread' },
          { name: 'Butter Chicken', type: 'Curry', description: 'Chicken in butter tomato gravy' },
          { name: 'Paratha', type: 'Bread', description: 'Stuffed flatbread' },
          { name: 'Tikki', type: 'Snack', description: 'Potato patties' },
          { name: 'Chaat', type: 'Snack', description: 'Street food snack' },
          { name: 'Dal Makhani', type: 'Dal', description: 'Black lentils in butter' },
          { name: 'Kebab', type: 'Snack', description: 'Grilled meat' },
          { name: 'Kulfi', type: 'Sweet', description: 'Indian ice cream' },
          { name: 'Jalebi', type: 'Sweet', description: 'Sweet spirals' },
          { name: 'Momos', type: 'Snack', description: 'Steamed dumplings' },
        ]
      },
      'South Delhi': {
        name: 'South Delhi',
        recipes: [
          { name: 'Nihari', type: 'Curry', description: 'Slow-cooked meat stew' },
          { name: 'Biryani', type: 'Rice', description: 'Aromatic rice dish' },
          { name: 'Tandoori Chicken', type: 'Main Course', description: 'Clay oven chicken' },
          { name: 'Paneer Tikka', type: 'Snack', description: 'Grilled cottage cheese' },
          { name: 'Samosa', type: 'Snack', description: 'Stuffed pastry' },
          { name: 'Rajma', type: 'Curry', description: 'Kidney beans curry' },
          { name: 'Kathi Roll', type: 'Snack', description: 'Wrapped roll' },
          { name: 'Gajar Ka Halwa', type: 'Sweet', description: 'Carrot pudding' },
          { name: 'Ras Malai', type: 'Sweet', description: 'Cottage cheese in cream' },
          { name: 'Kheer', type: 'Sweet', description: 'Rice pudding' },
        ]
      },
    }
  },

  'Jammu and Kashmir': {
    name: 'Jammu and Kashmir',
    color: '#C0392B',
    type: 'ut',
    districts: {
      'Srinagar': {
        name: 'Srinagar',
        recipes: [
          { name: 'Rogan Josh', type: 'Curry', description: 'Aromatic lamb curry' },
          { name: 'Kahwa', type: 'Beverage', description: 'Kashmiri green tea' },
          { name: 'Gushtaba', type: 'Main Course', description: 'Minced meat balls in yogurt' },
          { name: 'Yakhni', type: 'Curry', description: 'Yogurt based mutton curry' },
          { name: 'Dum Aloo', type: 'Curry', description: 'Baby potatoes in gravy' },
          { name: 'Modur Pulao', type: 'Rice', description: 'Sweet saffron rice' },
          { name: 'Tabak Maaz', type: 'Fry', description: 'Fried lamb ribs' },
          { name: 'Nadru Yakhni', type: 'Curry', description: 'Lotus stem in yogurt' },
          { name: 'Shufta', type: 'Sweet', description: 'Dry fruit sweet' },
          { name: 'Phirni', type: 'Sweet', description: 'Ground rice pudding' },
        ]
      },
      'Jammu': {
        name: 'Jammu',
        recipes: [
          { name: 'Rajma', type: 'Curry', description: 'Kidney beans curry' },
          { name: 'Kaladi Kulcha', type: 'Snack', description: 'Cheese with bread', rural: true },
          { name: 'Patisa', type: 'Sweet', description: 'Flaky sweet' },
          { name: 'Kalaadi', type: 'Cheese', description: 'Traditional cheese', rural: true },
          { name: 'Maa Ki Dal', type: 'Dal', description: 'Black lentils' },
          { name: 'Auria', type: 'Curry', description: 'Pumpkin curry', rural: true },
          { name: 'Khatta Meat', type: 'Curry', description: 'Sour meat curry' },
          { name: 'Madra', type: 'Curry', description: 'Chickpea curry', rural: true },
          { name: 'Sepu Vadi', type: 'Curry', description: 'Spinach with lentil nuggets', rural: true },
          { name: 'Sund Panjeeri', type: 'Sweet', description: 'Dry ginger sweet', rural: true },
        ]
      },
    }
  },

  'Ladakh': {
    name: 'Ladakh',
    color: '#27AE60',
    type: 'ut',
    districts: {
      'Leh': {
        name: 'Leh',
        recipes: [
          { name: 'Thukpa', type: 'Soup', description: 'Noodle soup' },
          { name: 'Momos', type: 'Snack', description: 'Steamed dumplings' },
          { name: 'Skyu', type: 'Main Course', description: 'Pasta-like dish with vegetables', rural: true },
          { name: 'Butter Tea', type: 'Beverage', description: 'Salted butter tea', rural: true },
          { name: 'Tsampa', type: 'Porridge', description: 'Roasted barley flour', rural: true },
          { name: 'Tingmo', type: 'Bread', description: 'Steamed bread' },
          { name: 'Khambir', type: 'Bread', description: 'Local bread', rural: true },
          { name: 'Paba', type: 'Bread', description: 'Roasted barley bread', rural: true },
          { name: 'Chutagi', type: 'Pasta', description: 'Bow-tie pasta', rural: true },
          { name: 'Apricot Jam', type: 'Preserve', description: 'Local apricot jam', rural: true },
        ]
      },
    }
  },

  'Lakshadweep': {
    name: 'Lakshadweep',
    color: '#3498DB',
    type: 'ut',
    districts: {
      'Lakshadweep': {
        name: 'Lakshadweep',
        recipes: [
          { name: 'Tuna Curry', type: 'Curry', description: 'Coconut tuna curry' },
          { name: 'Octopus Fry', type: 'Fry', description: 'Fried octopus' },
          { name: 'Fish Curry', type: 'Curry', description: 'Island style fish curry' },
          { name: 'Mas Huni', type: 'Breakfast', description: 'Tuna with coconut', rural: true },
          { name: 'Coconut Rice', type: 'Rice', description: 'Rice with coconut', rural: true },
          { name: 'Fish Cutlet', type: 'Snack', description: 'Fish patties' },
          { name: 'Breadfruit Curry', type: 'Curry', description: 'Breadfruit in coconut curry', rural: true },
          { name: 'Coconut Water', type: 'Beverage', description: 'Fresh coconut water' },
          { name: 'Banana Chips', type: 'Snack', description: 'Fried banana slices', rural: true },
          { name: 'Seafood Platter', type: 'Main Course', description: 'Mixed seafood' },
        ]
      },
    }
  },

  'Puducherry': {
    name: 'Puducherry',
    color: '#E67E22',
    type: 'ut',
    districts: {
      'Puducherry': {
        name: 'Puducherry',
        recipes: [
          { name: 'Chicken Stew', type: 'Curry', description: 'French-influenced chicken stew' },
          { name: 'Fish Curry', type: 'Curry', description: 'Coastal fish curry' },
          { name: 'Prawn Varuval', type: 'Fry', description: 'Fried prawns' },
          { name: 'Baguette', type: 'Bread', description: 'French bread' },
          { name: 'Croissant', type: 'Pastry', description: 'French pastry' },
          { name: 'Crepes', type: 'Breakfast', description: 'Thin pancakes' },
          { name: 'Poulet Roti', type: 'Main Course', description: 'Roasted chicken' },
          { name: 'Prawn Masala', type: 'Curry', description: 'Spicy prawn curry' },
          { name: 'Caramel Custard', type: 'Sweet', description: 'French dessert' },
          { name: 'Filter Coffee', type: 'Beverage', description: 'South Indian coffee' },
        ]
      },
    }
  },
};
