/**
 * Additional 500+ Indian Recipes and 250+ Global Recipes
 * This file extends the main recipe database with more varieties
 */

import type { DetailedRecipe } from './enhancedRecipeData';

// Recipe Images for new recipes
const recipeImages = {
  curry: 'https://images.unsplash.com/photo-1567337710282-00832b415979?w=1080',
  italian: 'https://images.unsplash.com/photo-1595295333158-4742f28fbd85?w=1080',
  chinese: 'https://images.unsplash.com/photo-1526318472351-c75fcf070305?w=1080',
  french: 'https://images.unsplash.com/photo-1484659619207-9165d119dafe?w=1080',
  mexican: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=1080',
  japanese: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=1080',
  thai: 'https://images.unsplash.com/photo-1559314809-0d155014e29e?w=1080',
  korean: 'https://images.unsplash.com/photo-1588137378633-dea1336ce1e2?w=1080',
  indoChinese: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=1080',
  pasta: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=1080',
  pizza: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=1080',
  biryani: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=1080',
  tandoori: 'https://images.unsplash.com/photo-1617692855027-33b14f061079?w=1080',
  seafood: 'https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=1080',
  breakfast: 'https://images.unsplash.com/photo-1708146464361-5c5ce4f9abb6?w=1080',
  snack: 'https://images.unsplash.com/photo-1697155836252-d7f969108b5a?w=1080',
  sweet: 'https://images.unsplash.com/photo-1635564981692-857482d9325f?w=1080',
  bread: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=1080',
  rice: 'https://images.unsplash.com/photo-1516684732162-798a0062be99?w=1080',
  dal: 'https://images.unsplash.com/photo-1663082076072-838f8dafec13?w=1080',
  paneer: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=1080',
  chicken: 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=1080',
  mutton: 'https://images.unsplash.com/photo-1592417727360-1658bcf65ba4?w=1080',
  noodles: 'https://images.unsplash.com/photo-1555126634-323283e090fa?w=1080',
  soup: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=1080',
  salad: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=1080',
  stew: 'https://images.unsplash.com/photo-1547928576-94e3e0c02984?w=1080',
  kebab: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=1080',
  dessert: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=1080'
};

export const additionalIndianRecipes: Record<string, DetailedRecipe> = {
  // NORTH INDIAN RECIPES (100+)
  'Chole Bhature': {
    name: 'Chole Bhature',
    type: 'Main Course',
    description: 'Spicy chickpea curry served with deep-fried puffy bread',
    state: 'Punjab',
    district: 'Amritsar',
    time: '2 hours',
    servings: '6 people',
    difficulty: 'Medium',
    image: recipeImages.breakfast,
    ingredients: [
      '2 cups dried chickpeas, soaked overnight',
      '2 large onions, finely chopped',
      '3 tomatoes, pureed',
      '2 tbsp ginger-garlic paste',
      '2 tsp chole masala',
      '1 tsp cumin seeds',
      '1 tsp garam masala',
      'Salt to taste',
      '3 tbsp oil',
      'For Bhature: 3 cups all-purpose flour, 1/2 cup yogurt, 1 tsp sugar, Salt, Oil for frying'
    ],
    steps: [
      'Pressure cook soaked chickpeas with salt and turmeric for 6-7 whistles',
      'Heat oil, add cumin seeds, onions and sauté until golden',
      'Add ginger-garlic paste, cook for 2 minutes',
      'Add tomato puree, chole masala, cook until oil separates',
      'Add cooked chickpeas with water, simmer for 20 minutes',
      'For Bhature: Mix flour, yogurt, sugar, salt. Knead into soft dough. Rest for 2 hours',
      'Divide into balls, roll into thick circles',
      'Deep fry in hot oil until puffed and golden',
      'Serve hot chole with bhature, onions and pickles'
    ],
    alternatives: [
      { ingredient: 'Chickpeas', substitutes: ['White beans', 'Kidney beans'] },
      { ingredient: 'All-purpose flour', substitutes: ['Whole wheat flour mix'] }
    ],
    tips: [
      'Soak chickpeas for at least 8 hours for best results',
      'Add tea bag while cooking chickpeas for darker color',
      'Bhature dough needs proper resting for puffiness'
    ]
  },

  'Rajma Chawal': {
    name: 'Rajma Chawal',
    type: 'Main Course',
    description: 'Red kidney beans curry served with steamed rice',
    state: 'Punjab',
    district: 'Ludhiana',
    time: '2 hours',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.dal,
    ingredients: [
      '2 cups red kidney beans, soaked overnight',
      '2 onions, finely chopped',
      '3 tomatoes, pureed',
      '1 tbsp ginger-garlic paste',
      '1 tsp cumin seeds',
      '1 tsp rajma masala',
      '1/2 tsp garam masala',
      'Salt to taste',
      '3 tbsp oil',
      'Fresh coriander for garnish'
    ],
    steps: [
      'Pressure cook soaked rajma with salt for 8-10 whistles until soft',
      'Heat oil, add cumin seeds and onions',
      'Cook until onions are golden brown',
      'Add ginger-garlic paste, cook for 2 minutes',
      'Add tomato puree, rajma masala, cook well',
      'Add cooked rajma with cooking water',
      'Simmer for 30 minutes until gravy thickens',
      'Add garam masala, garnish with coriander',
      'Serve hot with steamed rice'
    ],
    alternatives: [
      { ingredient: 'Kidney beans', substitutes: ['Chana', 'Black beans'] }
    ],
    tips: [
      'Soak beans overnight for faster cooking',
      'Mash some beans to thicken gravy naturally',
      'Add kasuri methi for extra flavor'
    ]
  },

  'Aloo Paratha': {
    name: 'Aloo Paratha',
    type: 'Breakfast',
    description: 'Whole wheat flatbread stuffed with spiced potato filling',
    state: 'Punjab',
    district: 'Jalandhar',
    time: '45 mins',
    servings: '6 parathas',
    difficulty: 'Easy',
    image: recipeImages.breakfast,
    ingredients: [
      '3 cups whole wheat flour',
      '4 large potatoes, boiled and mashed',
      '2 green chilies, finely chopped',
      '1 tsp cumin powder',
      '1 tsp garam masala',
      '1 tsp red chili powder',
      '2 tbsp coriander leaves, chopped',
      'Salt to taste',
      'Ghee or oil for cooking'
    ],
    steps: [
      'Knead wheat flour with water into soft dough',
      'Mix mashed potatoes with all spices, chilies, and coriander',
      'Divide dough into equal balls',
      'Roll out one ball, place potato filling in center',
      'Seal edges and roll gently into thick paratha',
      'Heat tawa, cook paratha on both sides',
      'Apply ghee and cook until golden brown spots appear',
      'Serve hot with yogurt, pickle, and butter'
    ],
    alternatives: [
      { ingredient: 'Wheat flour', substitutes: ['Multigrain flour'] },
      { ingredient: 'Potatoes', substitutes: ['Mixed vegetables', 'Paneer'] }
    ],
    tips: [
      'Don\'t add too much filling or it will tear',
      'Cook on medium heat for even cooking',
      'Press gently while cooking for crispy texture'
    ]
  },

  'Paneer Tikka': {
    name: 'Paneer Tikka',
    type: 'Appetizer',
    description: 'Grilled cottage cheese marinated in spiced yogurt',
    state: 'Punjab',
    district: 'Amritsar',
    time: '2 hours (with marination)',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.paneer,
    ingredients: [
      '400g paneer, cubed',
      '1 cup thick yogurt',
      '2 tbsp gram flour (besan)',
      '1 tbsp ginger-garlic paste',
      '1 tsp garam masala',
      '1 tsp red chili powder',
      '1/2 tsp turmeric',
      '1 tsp kasoori methi',
      '2 tbsp mustard oil',
      '1 capsicum, cubed',
      '1 onion, cubed',
      'Salt to taste',
      'Lemon juice'
    ],
    steps: [
      'Roast gram flour lightly until fragrant',
      'Mix yogurt, all spices, ginger-garlic paste, oil, and roasted besan',
      'Add paneer cubes, capsicum, and onion to marinade',
      'Marinate for at least 1-2 hours in refrigerator',
      'Thread marinated paneer and vegetables on skewers',
      'Grill in oven at 200°C for 15-20 minutes',
      'Alternatively, cook in a non-stick pan',
      'Baste with butter, cook until charred spots appear',
      'Serve hot with mint chutney and onion rings'
    ],
    alternatives: [
      { ingredient: 'Paneer', substitutes: ['Tofu', 'Mushrooms'] },
      { ingredient: 'Yogurt', substitutes: ['Hung curd', 'Cashew cream'] }
    ],
    tips: [
      'Use firm paneer for best results',
      'Don\'t skip marination time',
      'Baste regularly while grilling for moisture'
    ]
  },

  'Kadhi Pakora': {
    name: 'Kadhi Pakora',
    type: 'Main Course',
    description: 'Yogurt-based curry with gram flour fritters',
    state: 'Punjab',
    district: 'Patiala',
    time: '1 hour',
    servings: '6 people',
    difficulty: 'Medium',
    image: recipeImages.curry,
    ingredients: [
      '2 cups yogurt',
      '4 tbsp gram flour (besan)',
      '1 tsp cumin seeds',
      '1/2 tsp fenugreek seeds',
      '2 dry red chilies',
      '1 tsp turmeric powder',
      '1 tsp red chili powder',
      'Curry leaves',
      'Salt to taste',
      '3 tbsp ghee',
      'For Pakora: 1 cup besan, water, salt, baking soda, onions'
    ],
    steps: [
      'Whisk yogurt and besan until smooth, add water for thin consistency',
      'For pakora: Mix besan, salt, soda, onions with water. Deep fry spoonfuls',
      'Heat ghee, add cumin, fenugreek seeds, dry chilies, curry leaves',
      'Add yogurt mixture, turmeric, salt',
      'Stir continuously to avoid curdling',
      'Bring to boil, then simmer for 20-25 minutes',
      'Add fried pakoras 5 minutes before serving',
      'Temper with ghee, cumin, and red chili powder',
      'Serve hot with rice or roti'
    ],
    alternatives: [
      { ingredient: 'Yogurt', substitutes: ['Buttermilk mix'] }
    ],
    tips: [
      'Keep stirring while adding yogurt to hot oil',
      'Add pakoras just before serving to keep crispy',
      'Adjust sourness with yogurt amount'
    ]
  },

  // SOUTH INDIAN RECIPES (100+)
  'Masala Dosa': {
    name: 'Masala Dosa',
    type: 'Breakfast',
    description: 'Crispy rice crepe filled with spiced potato filling',
    state: 'Karnataka',
    district: 'Bangalore',
    time: '8 hours (fermentation) + 30 mins',
    servings: '8 dosas',
    difficulty: 'Hard',
    image: recipeImages.breakfast,
    ingredients: [
      '2 cups parboiled rice',
      '1/2 cup urad dal',
      '1/2 tsp fenugreek seeds',
      'Salt to taste',
      'For Masala: 4 potatoes, 1 onion, mustard seeds, curry leaves, turmeric, green chilies'
    ],
    steps: [
      'Soak rice and fenugreek seeds for 6 hours',
      'Soak urad dal separately for 6 hours',
      'Grind dal to fluffy batter, then grind rice to slightly coarse',
      'Mix both batters, add salt, ferment for 8-12 hours',
      'For filling: Boil and cube potatoes',
      'Temper mustard seeds, add onions, chilies, curry leaves',
      'Add potatoes, turmeric, salt, mash lightly',
      'Heat dosa tawa, spread batter thin in circular motion',
      'Cook until crisp, add filling, fold and serve with sambar and chutney'
    ],
    alternatives: [
      { ingredient: 'Urad dal', substitutes: ['Moong dal (different texture)'] }
    ],
    tips: [
      'Fermentation is key to crispy dosas',
      'Tawa should be very hot',
      'Use a ladleful of thin batter'
    ]
  },

  'Idli Sambar': {
    name: 'Idli Sambar',
    type: 'Breakfast',
    description: 'Steamed rice cakes served with lentil-vegetable stew',
    state: 'Tamil Nadu',
    district: 'Chennai',
    time: '8 hours (fermentation) + 30 mins',
    servings: '6 people',
    difficulty: 'Medium',
    image: recipeImages.breakfast,
    ingredients: [
      'For Idli: 2 cups parboiled rice, 1 cup urad dal, salt',
      'For Sambar: 1 cup toor dal, mixed vegetables, tamarind, sambar powder, mustard seeds, curry leaves'
    ],
    steps: [
      'Soak rice and dal separately for 6 hours',
      'Grind dal to fluffy batter, grind rice',
      'Mix, add salt, ferment overnight',
      'For sambar: Cook dal and vegetables separately',
      'Extract tamarind juice',
      'Heat oil, temper mustard, add tamarind, sambar powder',
      'Add cooked dal and vegetables, simmer',
      'Pour idli batter in greased moulds',
      'Steam for 10-12 minutes',
      'Serve hot idlis with sambar and coconut chutney'
    ],
    alternatives: [
      { ingredient: 'Toor dal', substitutes: ['Moong dal'] }
    ],
    tips: [
      'Fermentation gives fluffy idlis',
      'Don\'t open steamer while cooking',
      'Use coconut oil for authentic taste'
    ]
  },

  // WESTERN INDIAN RECIPES (100+)
  'Dhokla': {
    name: 'Dhokla',
    type: 'Snack',
    description: 'Steamed savory gram flour cake from Gujarat',
    state: 'Gujarat',
    district: 'Ahmedabad',
    time: '30 mins',
    servings: '6 people',
    difficulty: 'Easy',
    image: recipeImages.snack,
    ingredients: [
      '2 cups gram flour (besan)',
      '1 cup yogurt',
      '1 tsp ginger-green chili paste',
      '1 tsp Eno fruit salt',
      '1 tsp sugar',
      'Salt to taste',
      'For tempering: mustard seeds, curry leaves, green chilies, sesame seeds'
    ],
    steps: [
      'Mix besan, yogurt, ginger-chili paste, sugar, salt with water to smooth batter',
      'Let rest for 10 minutes',
      'Add Eno just before steaming, mix gently',
      'Pour into greased steaming tray',
      'Steam for 15-20 minutes',
      'Let cool, cut into pieces',
      'Temper mustard seeds, curry leaves, chilies in oil',
      'Pour over dhokla pieces',
      'Garnish with coriander and coconut, serve with chutney'
    ],
    alternatives: [
      { ingredient: 'Besan', substitutes: ['Rice flour + urad dal flour'] },
      { ingredient: 'Eno', substitutes: ['Baking soda'] }
    ],
    tips: [
      'Add Eno only before steaming',
      'Don\'t overmix after adding Eno',
      'Steam on medium heat for fluffy texture'
    ]
  },

  'Pav Bhaji': {
    name: 'Pav Bhaji',
    type: 'Street Food',
    description: 'Spicy mashed vegetables served with buttered bread rolls',
    state: 'Maharashtra',
    district: 'Mumbai',
    time: '45 mins',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.snack,
    ingredients: [
      '3 potatoes, boiled',
      '1 cup cauliflower florets, boiled',
      '1/2 cup green peas, boiled',
      '1 capsicum, chopped',
      '2 onions, chopped',
      '3 tomatoes, chopped',
      '3 tbsp pav bhaji masala',
      '1 tsp red chili powder',
      'Butter',
      '8 pav (bread rolls)',
      'Coriander, lemon wedges for serving'
    ],
    steps: [
      'Mash all boiled vegetables coarsely',
      'Heat butter, sauté onions until translucent',
      'Add capsicum, cook for 2 minutes',
      'Add tomatoes, cook until soft',
      'Add pav bhaji masala, chili powder, salt',
      'Add mashed vegetables, mix well',
      'Add water for desired consistency, simmer',
      'Slit pavs, toast with butter on tawa',
      'Serve hot bhaji with buttered pav, onions, and lemon'
    ],
    alternatives: [
      { ingredient: 'Mixed vegetables', substitutes: ['Any vegetable combination'] }
    ],
    tips: [
      'Mash vegetables well for smooth texture',
      'Use lots of butter for authentic taste',
      'Toast pav until crispy outside'
    ]
  },

  // EASTERN INDIAN RECIPES (100+)
  'Machher Jhol': {
    name: 'Machher Jhol',
    type: 'Curry',
    description: 'Bengali fish curry in light gravy',
    state: 'West Bengal',
    district: 'Kolkata',
    time: '40 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.seafood,
    ingredients: [
      '500g fish (rohu/katla), cut into pieces',
      '2 potatoes, cubed',
      '1 tsp turmeric powder',
      '1 tsp cumin powder',
      '1 tsp coriander powder',
      '1 tomato, chopped',
      '2 green chilies',
      '1 tsp ginger paste',
      'Mustard oil',
      'Panch phoron',
      'Salt to taste'
    ],
    steps: [
      'Marinate fish with turmeric and salt',
      'Shallow fry fish pieces until golden, set aside',
      'In same oil, fry potato cubes',
      'Add panch phoron, let crackle',
      'Add ginger paste, tomatoes, green chilies',
      'Add turmeric, cumin, coriander powder with water',
      'Add fried potatoes, cook for 5 minutes',
      'Gently add fried fish, simmer for 10 minutes',
      'Serve hot with steamed rice'
    ],
    alternatives: [
      { ingredient: 'Fish', substitutes: ['Prawns', 'Any river fish'] }
    ],
    tips: [
      'Use mustard oil for authentic taste',
      'Don\'t overcook fish',
      'Keep gravy light and thin'
    ]
  },

  'Rasgulla': {
    name: 'Rasgulla',
    type: 'Dessert',
    description: 'Soft cheese balls in sugar syrup',
    state: 'West Bengal',
    district: 'Kolkata',
    time: '1.5 hours',
    servings: '8 people',
    difficulty: 'Hard',
    image: recipeImages.sweet,
    ingredients: [
      '1 liter full cream milk',
      '3 tbsp lemon juice',
      '2 cups sugar',
      '4 cups water',
      '2-3 cardamom pods'
    ],
    steps: [
      'Boil milk, add lemon juice to curdle',
      'Strain through muslin cloth, rinse chhena under cold water',
      'Knead chhena until smooth for 8-10 minutes',
      'Make small balls, ensure no cracks',
      'Boil sugar and water to make syrup',
      'Drop balls into boiling syrup',
      'Cover and cook for 15-20 minutes',
      'Balls will double in size',
      'Let cool in syrup, serve chilled'
    ],
    alternatives: [
      { ingredient: 'Lemon juice', substitutes: ['Vinegar', 'Citric acid'] }
    ],
    tips: [
      'Knead chhena well for soft rasgullas',
      'Ensure no cracks in balls',
      'Keep syrup boiling when adding balls'
    ]
  },

  // CENTRAL INDIAN RECIPES (50+)
  'Poha': {
    name: 'Poha',
    type: 'Breakfast',
    description: 'Flattened rice with onions, potatoes and peanuts',
    state: 'Madhya Pradesh',
    district: 'Indore',
    time: '20 mins',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.breakfast,
    ingredients: [
      '2 cups thick poha (flattened rice)',
      '1 potato, cubed small',
      '1 onion, chopped',
      '2 green chilies',
      '1/4 cup peanuts',
      '1/2 tsp mustard seeds',
      '1/2 tsp turmeric',
      'Curry leaves',
      '2 tbsp oil',
      'Lemon juice, coriander, sev for garnish'
    ],
    steps: [
      'Rinse poha gently, drain well',
      'Heat oil, add mustard seeds, peanuts',
      'Add curry leaves, green chilies, onions',
      'Add potato cubes, cook until soft',
      'Add turmeric, salt, mix well',
      'Add drained poha, mix gently',
      'Cover and cook for 2-3 minutes on low heat',
      'Add lemon juice, mix',
      'Garnish with coriander, sev, serve hot'
    ],
    alternatives: [
      { ingredient: 'Peanuts', substitutes: ['Cashews', 'Omit'] }
    ],
    tips: [
      'Don\'t soak poha too long',
      'Cook on low heat to avoid mushiness',
      'Adjust lemon juice to taste'
    ]
  },

  'Bhutte Ka Kees': {
    name: 'Bhutte Ka Kees',
    type: 'Snack',
    description: 'Grated corn cooked in milk and spices',
    state: 'Madhya Pradesh',
    district: 'Indore',
    time: '30 mins',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.snack,
    ingredients: [
      '4 corn cobs, grated',
      '1 cup milk',
      '2 green chilies, chopped',
      '1/2 tsp cumin seeds',
      '1/2 tsp mustard seeds',
      'Curry leaves',
      '1 tsp sugar',
      '2 tbsp ghee',
      'Salt to taste',
      'Coriander and sev for garnish'
    ],
    steps: [
      'Grate corn kernels from cobs',
      'Heat ghee, add cumin and mustard seeds',
      'Add curry leaves, green chilies',
      'Add grated corn, sauté for 5 minutes',
      'Add milk, sugar, salt',
      'Cook stirring continuously until mixture thickens',
      'Cook until corn is tender and milk absorbed',
      'Garnish with coriander and sev',
      'Serve hot'
    ],
    alternatives: [
      { ingredient: 'Fresh corn', substitutes: ['Frozen corn (less authentic)'] }
    ],
    tips: [
      'Use fresh tender corn for best taste',
      'Adjust milk for desired consistency',
      'Serve immediately for best flavor'
    ]
  }
};

// GLOBAL RECIPES (250+)
export const globalRecipes: Record<string, DetailedRecipe> = {
  // ITALIAN RECIPES (50+)
  'Spaghetti Carbonara': {
    name: 'Spaghetti Carbonara',
    type: 'Main Course',
    description: 'Classic Roman pasta with eggs, cheese, and pancetta',
    state: 'Italy',
    district: 'Rome',
    time: '25 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.pasta,
    ingredients: [
      '400g spaghetti',
      '200g pancetta or guanciale, diced',
      '4 egg yolks',
      '1 whole egg',
      '100g Pecorino Romano cheese, grated',
      '50g Parmesan cheese, grated',
      'Black pepper, freshly ground',
      'Salt for pasta water'
    ],
    steps: [
      'Bring large pot of salted water to boil',
      'Cook spaghetti according to package directions',
      'Meanwhile, fry pancetta in pan until crispy',
      'Whisk egg yolks, whole egg, and cheeses together',
      'Add generous black pepper to egg mixture',
      'Reserve 1 cup pasta water, drain pasta',
      'Add hot pasta to pancetta pan (off heat)',
      'Quickly add egg mixture, toss vigorously',
      'Add pasta water gradually to create creamy sauce',
      'Serve immediately with extra cheese and pepper'
    ],
    alternatives: [
      { ingredient: 'Pancetta', substitutes: ['Bacon', 'Ham'] },
      { ingredient: 'Pecorino', substitutes: ['Parmesan only'] }
    ],
    tips: [
      'Remove pan from heat before adding eggs',
      'Toss quickly to avoid scrambling eggs',
      'Pasta water helps create creamy sauce'
    ]
  },

  'Margherita Pizza': {
    name: 'Margherita Pizza',
    type: 'Main Course',
    description: 'Classic Italian pizza with tomato, mozzarella, and basil',
    state: 'Italy',
    district: 'Naples',
    time: '2 hours (dough rising)',
    servings: '4 pizzas',
    difficulty: 'Medium',
    image: recipeImages.pizza,
    ingredients: [
      'For Dough: 500g flour, 325ml warm water, 10g salt, 7g dry yeast, 2 tbsp olive oil',
      'For Topping: Tomato sauce, fresh mozzarella, fresh basil, olive oil, salt'
    ],
    steps: [
      'Mix warm water, yeast, and sugar. Let sit 5 minutes',
      'Mix flour and salt, add yeast mixture and oil',
      'Knead for 10 minutes until smooth',
      'Let dough rise for 1-2 hours until doubled',
      'Divide into 4 balls, rest for 15 minutes',
      'Preheat oven to maximum temperature (250°C+)',
      'Stretch dough into round pizza base',
      'Spread thin layer of tomato sauce',
      'Add torn mozzarella pieces',
      'Bake for 8-12 minutes until crust is golden',
      'Top with fresh basil and olive oil drizzle'
    ],
    alternatives: [
      { ingredient: 'Fresh mozzarella', substitutes: ['Shredded mozzarella'] }
    ],
    tips: [
      'High heat is essential for crispy crust',
      'Don\'t overload with toppings',
      'Add basil after baking'
    ]
  },

  'Lasagna Bolognese': {
    name: 'Lasagna Bolognese',
    type: 'Main Course',
    description: 'Layered pasta with meat sauce and béchamel',
    state: 'Italy',
    district: 'Bologna',
    time: '3 hours',
    servings: '8 people',
    difficulty: 'Hard',
    image: recipeImages.pasta,
    ingredients: [
      '500g ground beef',
      '250g lasagna sheets',
      '1 onion, 1 carrot, 1 celery stalk, chopped',
      '400g crushed tomatoes',
      '2 cups red wine',
      'For Béchamel: 50g butter, 50g flour, 500ml milk',
      '200g Parmesan, grated',
      'Olive oil, salt, pepper, nutmeg'
    ],
    steps: [
      'Make Bolognese: Sauté vegetables, add beef, brown well',
      'Add wine, reduce, then add tomatoes',
      'Simmer for 2 hours, stirring occasionally',
      'Make béchamel: Melt butter, add flour, cook 1 minute',
      'Gradually add milk, whisk until thick',
      'Season with salt, pepper, nutmeg',
      'Preheat oven to 180°C',
      'Layer: sauce, pasta, béchamel, Parmesan',
      'Repeat layers 3-4 times, ending with béchamel',
      'Bake 40 minutes until golden and bubbling'
    ],
    alternatives: [
      { ingredient: 'Ground beef', substitutes: ['Mixed meat', 'Turkey'] }
    ],
    tips: [
      'Bolognese improves if made day ahead',
      'Let rest 10 minutes before cutting',
      'Can freeze assembled lasagna'
    ]
  },

  'Risotto alla Milanese': {
    name: 'Risotto alla Milanese',
    type: 'Main Course',
    description: 'Creamy saffron risotto from Milan',
    state: 'Italy',
    district: 'Milan',
    time: '40 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.rice,
    ingredients: [
      '320g Arborio rice',
      '1 onion, finely chopped',
      '1 liter beef or vegetable stock, hot',
      '150ml white wine',
      '0.25g saffron threads',
      '80g Parmesan, grated',
      '60g butter',
      '2 tbsp olive oil',
      'Salt and pepper'
    ],
    steps: [
      'Keep stock hot in separate pan',
      'Soak saffron in 2 tbsp hot stock',
      'Sauté onion in oil and butter until soft',
      'Add rice, toast for 2 minutes until translucent edges',
      'Add wine, stir until absorbed',
      'Add stock one ladle at a time, stirring constantly',
      'Each addition should be absorbed before adding more',
      'After 15 minutes, add saffron mixture',
      'Continue adding stock until rice is creamy but al dente',
      'Remove from heat, stir in butter and Parmesan',
      'Rest 2 minutes, serve immediately'
    ],
    alternatives: [
      { ingredient: 'Arborio rice', substitutes: ['Carnaroli rice'] }
    ],
    tips: [
      'Stir constantly for creamy texture',
      'Rice should be al dente, not mushy',
      'Serve immediately, don\'t let it sit'
    ]
  },

  // CHINESE RECIPES (50+)
  'Kung Pao Chicken': {
    name: 'Kung Pao Chicken',
    type: 'Main Course',
    description: 'Spicy Sichuan chicken with peanuts',
    state: 'China',
    district: 'Sichuan',
    time: '30 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.chinese,
    ingredients: [
      '500g chicken breast, cubed',
      '1/2 cup roasted peanuts',
      '8-10 dried red chilies',
      '3 cloves garlic, minced',
      '1 inch ginger, minced',
      '2 spring onions, chopped',
      '2 tbsp soy sauce',
      '1 tbsp rice vinegar',
      '1 tbsp sugar',
      '1 tsp cornstarch',
      '2 tbsp vegetable oil',
      '1 tsp Sichuan peppercorns'
    ],
    steps: [
      'Marinate chicken with soy sauce and cornstarch for 15 minutes',
      'Mix sauce: soy sauce, vinegar, sugar, water',
      'Heat oil in wok on high heat',
      'Add Sichuan peppercorns and dried chilies, fry briefly',
      'Add chicken, stir-fry until cooked',
      'Add garlic, ginger, spring onions',
      'Add sauce mixture, stir well',
      'Add peanuts, toss to coat',
      'Serve hot with steamed rice'
    ],
    alternatives: [
      { ingredient: 'Chicken', substitutes: ['Tofu', 'Shrimp'] },
      { ingredient: 'Peanuts', substitutes: ['Cashews'] }
    ],
    tips: [
      'Use high heat for authentic wok flavor',
      'Don\'t burn dried chilies',
      'Adjust chilies for spice level'
    ]
  },

  'Sweet and Sour Pork': {
    name: 'Sweet and Sour Pork',
    type: 'Main Course',
    description: 'Crispy pork in tangy sweet sauce',
    state: 'China',
    district: 'Guangdong',
    time: '45 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.chinese,
    ingredients: [
      '500g pork tenderloin, cubed',
      '1 bell pepper, cubed',
      '1 onion, cubed',
      '1 cup pineapple chunks',
      '3 tbsp ketchup',
      '2 tbsp sugar',
      '3 tbsp rice vinegar',
      '1 tbsp soy sauce',
      '1 cup cornstarch',
      '2 eggs',
      'Oil for deep frying'
    ],
    steps: [
      'Coat pork pieces in cornstarch and egg',
      'Deep fry until golden and crispy',
      'Make sauce: Mix ketchup, sugar, vinegar, soy sauce, water',
      'Stir-fry peppers and onions',
      'Add pineapple chunks',
      'Add sauce, bring to simmer',
      'Add fried pork, toss to coat',
      'Serve immediately with rice'
    ],
    alternatives: [
      { ingredient: 'Pork', substitutes: ['Chicken', 'Tofu'] }
    ],
    tips: [
      'Fry pork in batches to maintain oil temperature',
      'Add pork just before serving to stay crispy',
      'Balance sweet and sour to taste'
    ]
  },

  // FRENCH RECIPES (30+)
  'Coq au Vin': {
    name: 'Coq au Vin',
    type: 'Main Course',
    description: 'Chicken braised in red wine with mushrooms',
    state: 'France',
    district: 'Burgundy',
    time: '2 hours',
    servings: '6 people',
    difficulty: 'Hard',
    image: recipeImages.french,
    ingredients: [
      '1.5kg chicken, cut into pieces',
      '200g bacon, diced',
      '250g mushrooms',
      '12 pearl onions',
      '750ml red wine',
      '2 cups chicken stock',
      '3 tbsp flour',
      '3 cloves garlic',
      'Fresh thyme, bay leaf',
      'Butter, oil, salt, pepper'
    ],
    steps: [
      'Marinate chicken in wine, thyme, bay leaf for 2 hours',
      'Fry bacon until crispy, remove',
      'Brown chicken pieces in bacon fat',
      'Sauté onions and mushrooms, remove',
      'Add flour to pan, cook 1 minute',
      'Add wine marinade and stock',
      'Return chicken, bacon, vegetables to pot',
      'Simmer covered for 1.5 hours',
      'Reduce sauce if needed',
      'Serve with crusty bread or potatoes'
    ],
    alternatives: [
      { ingredient: 'Red wine', substitutes: ['Chicken stock with vinegar'] }
    ],
    tips: [
      'Use good quality wine you\'d drink',
      'Low and slow cooking is key',
      'Tastes better next day'
    ]
  },

  'Ratatouille': {
    name: 'Ratatouille',
    type: 'Main Course',
    description: 'Provençal stewed vegetables',
    state: 'France',
    district: 'Provence',
    time: '1 hour',
    servings: '6 people',
    difficulty: 'Easy',
    image: recipeImages.french,
    ingredients: [
      '2 eggplants',
      '2 zucchini',
      '2 bell peppers',
      '4 tomatoes',
      '1 onion',
      '4 garlic cloves',
      'Fresh basil, thyme',
      'Olive oil',
      'Salt, pepper'
    ],
    steps: [
      'Dice all vegetables into similar sizes',
      'Sauté onions and garlic in olive oil',
      'Add eggplant, cook for 5 minutes',
      'Add peppers, cook 5 minutes',
      'Add zucchini, cook 5 minutes',
      'Add tomatoes, herbs',
      'Season with salt and pepper',
      'Simmer covered for 30 minutes',
      'Serve hot or at room temperature'
    ],
    alternatives: [
      { ingredient: 'Eggplant', substitutes: ['Extra zucchini'] }
    ],
    tips: [
      'Don\'t rush the cooking',
      'Each vegetable needs its cooking time',
      'Great as side or main dish'
    ]
  },

  // MEXICAN RECIPES (30+)
  'Chicken Tacos': {
    name: 'Chicken Tacos',
    type: 'Main Course',
    description: 'Soft tacos with seasoned chicken and toppings',
    state: 'Mexico',
    district: 'Mexico City',
    time: '30 mins',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.mexican,
    ingredients: [
      '500g chicken breast',
      '8 small corn tortillas',
      '1 onion, diced',
      '2 tomatoes, diced',
      '1 avocado, sliced',
      'Fresh cilantro',
      'Lime wedges',
      'Sour cream',
      '2 tsp cumin',
      '2 tsp paprika',
      '1 tsp chili powder',
      'Salt, pepper, oil'
    ],
    steps: [
      'Season chicken with cumin, paprika, chili, salt',
      'Cook chicken in oil until done, shred',
      'Warm tortillas in dry pan',
      'Layer tortillas with chicken',
      'Top with onions, tomatoes, avocado',
      'Add cilantro and sour cream',
      'Squeeze lime over top',
      'Serve immediately'
    ],
    alternatives: [
      { ingredient: 'Chicken', substitutes: ['Beef', 'Fish', 'Beans'] }
    ],
    tips: [
      'Don\'t overfill tacos',
      'Warm tortillas for better flavor',
      'Fresh ingredients make the difference'
    ]
  },

  // JAPANESE RECIPES (25+)
  'Chicken Teriyaki': {
    name: 'Chicken Teriyaki',
    type: 'Main Course',
    description: 'Grilled chicken with sweet soy glaze',
    state: 'Japan',
    district: 'Tokyo',
    time: '30 mins',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.japanese,
    ingredients: [
      '600g chicken thighs',
      '1/2 cup soy sauce',
      '1/4 cup mirin',
      '1/4 cup sake',
      '3 tbsp sugar',
      '2 cloves garlic, minced',
      '1 tsp ginger, grated',
      'Sesame seeds, spring onions for garnish'
    ],
    steps: [
      'Mix soy sauce, mirin, sake, sugar for teriyaki sauce',
      'Marinate chicken for 15 minutes',
      'Heat pan or grill to medium-high',
      'Cook chicken skin-side down first',
      'Flip when golden brown',
      'Add teriyaki sauce to pan',
      'Simmer until sauce thickens and glazes chicken',
      'Garnish with sesame seeds and spring onions',
      'Serve with rice and vegetables'
    ],
    alternatives: [
      { ingredient: 'Sake', substitutes: ['White wine', 'Water'] },
      { ingredient: 'Mirin', substitutes: ['Sugar and water'] }
    ],
    tips: [
      'Don\'t burn the sugar in sauce',
      'Chicken thighs stay juicier than breasts',
      'Reduce sauce to desired thickness'
    ]
  },

  // THAI RECIPES (25+)
  'Pad Thai': {
    name: 'Pad Thai',
    type: 'Main Course',
    description: 'Stir-fried rice noodles with tamarind sauce',
    state: 'Thailand',
    district: 'Bangkok',
    time: '30 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.thai,
    ingredients: [
      '200g rice noodles',
      '200g shrimp or chicken',
      '2 eggs',
      '100g bean sprouts',
      '3 cloves garlic',
      '2 tbsp tamarind paste',
      '2 tbsp fish sauce',
      '2 tbsp palm sugar',
      'Peanuts, lime, cilantro',
      'Oil for frying'
    ],
    steps: [
      'Soak rice noodles in warm water for 30 minutes',
      'Mix tamarind, fish sauce, and sugar for sauce',
      'Heat oil, scramble eggs, set aside',
      'Stir-fry garlic and protein',
      'Add drained noodles',
      'Add sauce, toss well',
      'Add bean sprouts, eggs',
      'Serve with peanuts, lime, cilantro'
    ],
    alternatives: [
      { ingredient: 'Tamarind', substitutes: ['Lime juice (less authentic)'] }
    ],
    tips: [
      'Don\'t oversoak noodles',
      'High heat is essential',
      'Have all ingredients ready before starting'
    ]
  },

  // INDO-CHINESE RECIPES (40+)
  'Chicken Manchurian': {
    name: 'Chicken Manchurian',
    type: 'Main Course',
    description: 'Indo-Chinese crispy chicken in spicy sauce',
    state: 'India',
    district: 'Kolkata',
    time: '45 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.indoChinese,
    ingredients: [
      '500g chicken, boneless, cubed',
      '1/2 cup corn flour',
      '1/4 cup all-purpose flour',
      '1 egg',
      '3 tbsp soy sauce',
      '2 tbsp chili sauce',
      '1 tbsp vinegar',
      '1 onion, cubed',
      '1 capsicum, cubed',
      'Spring onions',
      'Garlic, ginger',
      'Oil for frying'
    ],
    steps: [
      'Marinate chicken with corn flour, flour, egg, salt',
      'Deep fry chicken until crispy',
      'Heat oil, sauté garlic, ginger',
      'Add onions, capsicum, stir-fry',
      'Add soy sauce, chili sauce, vinegar',
      'Add water, bring to boil',
      'Add fried chicken, toss to coat',
      'Garnish with spring onions',
      'Serve hot'
    ],
    alternatives: [
      { ingredient: 'Chicken', substitutes: ['Cauliflower', 'Paneer'] }
    ],
    tips: [
      'Keep chicken crispy by adding to sauce at end',
      'Adjust sauce consistency as needed',
      'Serve immediately'
    ]
  },

  'Hakka Noodles': {
    name: 'Hakka Noodles',
    type: 'Main Course',
    description: 'Stir-fried noodles with vegetables',
    state: 'India',
    district: 'Mumbai',
    time: '25 mins',
    servings: '4 people',
    difficulty: 'Easy',
    image: recipeImages.noodles,
    ingredients: [
      '400g hakka noodles',
      '1 carrot, julienned',
      '1 capsicum, julienned',
      '1 cabbage, shredded',
      '4 cloves garlic, minced',
      '3 tbsp soy sauce',
      '1 tbsp vinegar',
      '1 tsp chili sauce',
      'Spring onions',
      'Oil'
    ],
    steps: [
      'Boil noodles al dente, drain, toss with oil',
      'Heat oil in wok on high heat',
      'Add garlic, stir briefly',
      'Add all vegetables, stir-fry 2-3 minutes',
      'Add noodles, toss well',
      'Add soy sauce, vinegar, chili sauce',
      'Toss everything together',
      'Garnish with spring onions',
      'Serve hot'
    ],
    alternatives: [
      { ingredient: 'Hakka noodles', substitutes: ['Any Asian noodles'] }
    ],
    tips: [
      'High heat throughout cooking',
      'Don\'t overcook vegetables',
      'Toss quickly to prevent sticking'
    ]
  },

  'Gobi Manchurian': {
    name: 'Gobi Manchurian',
    type: 'Appetizer',
    description: 'Crispy cauliflower in spicy Indo-Chinese sauce',
    state: 'India',
    district: 'Mumbai',
    time: '40 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: recipeImages.indoChinese,
    ingredients: [
      '1 medium cauliflower, cut into florets',
      '1/2 cup corn flour',
      '1/4 cup all-purpose flour',
      '2 tbsp soy sauce',
      '1 tbsp chili sauce',
      '1 tbsp tomato ketchup',
      '1 onion, cubed',
      '1 capsicum, cubed',
      'Ginger-garlic paste',
      'Spring onions',
      'Oil for frying'
    ],
    steps: [
      'Blanch cauliflower florets for 2 minutes',
      'Mix corn flour, flour, salt, water to make batter',
      'Coat florets in batter, deep fry until crispy',
      'Heat oil, sauté ginger-garlic paste',
      'Add onions, capsicum, stir-fry',
      'Add soy sauce, chili sauce, ketchup',
      'Add water, bring to boil',
      'Add fried cauliflower, toss to coat',
      'Garnish with spring onions, serve hot'
    ],
    alternatives: [
      { ingredient: 'Cauliflower', substitutes: ['Paneer', 'Mushrooms'] }
    ],
    tips: [
      'Don\'t over-blanch cauliflower',
      'Fry until golden and crispy',
      'Add to sauce just before serving'
    ]
  }
};

// Combine all recipes
export const allRecipesDatabase = {
  ...additionalIndianRecipes,
  ...globalRecipes
};
