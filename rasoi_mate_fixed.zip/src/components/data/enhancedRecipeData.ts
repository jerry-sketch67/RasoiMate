// Enhanced Recipe Database with full details for all major districts in India
// Each recipe includes ingredients, steps, alternatives, and tips

export type DetailedRecipe = {
  name: string;
  type: string;
  description: string;
  rural?: boolean;
  time?: string;
  servings?: string;
  difficulty?: string;
  state?: string;
  district?: string;
  ingredients: string[];
  steps: string[];
  alternatives?: {
    ingredient: string;
    substitutes: string[];
  }[];
  tips?: string[];
  culturalNote?: string;
  ingredientSourcing?: string;
  image?: string;
};

// Recipe Image Mappings by Type (Category Defaults)
const recipeImages = {
  curry: 'https://images.unsplash.com/photo-1567337710282-00832b415979?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjdXJyeSUyMGZvb2R8ZW58MXx8fHwxNzYyMjY3Njg3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  breakfast: 'https://images.unsplash.com/photo-1708146464361-5c5ce4f9abb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBicmVha2Zhc3QlMjBkb3NhfGVufDF8fHx8MTc2MjMxMTkyNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  biryani: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBiaXJ5YW5pJTIwcmljZXxlbnwxfHx8fDE3NjIzMTE5Mjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  snack: 'https://images.unsplash.com/photo-1697155836252-d7f969108b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBzbmFja3MlMjBzYW1vc2F8ZW58MXx8fHwxNzYyMzExOTI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  tandoori: 'https://images.unsplash.com/photo-1617692855027-33b14f061079?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0YW5kb29yaSUyMGNoaWNrZW58ZW58MXx8fHwxNzYyMjI4NzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  thali: 'https://images.unsplash.com/photo-1572517499173-4e2cb8bef19b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB2ZWdldGFyaWFuJTIwdGhhbGl8ZW58MXx8fHwxNzYyMzExOTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  sweet: 'https://images.unsplash.com/photo-1635564981692-857482d9325f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBzd2VldHMlMjBkZXNzZXJ0fGVufDF8fHx8MTc2MjIzNDEyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  chutney: 'https://images.unsplash.com/photo-1587411768638-ec71f8e33b78?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjaHV0bmV5JTIwcGlja2xlfGVufDF8fHx8MTc2MjMxMTkyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  seafood: 'https://images.unsplash.com/photo-1736182146420-90da7d9fd0e2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmaXNoJTIwc2VhZm9vZHxlbnwxfHx8fDE3NjIzMTE5Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  dal: 'https://images.unsplash.com/photo-1663082076072-838f8dafec13?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBsZW50aWxzJTIwZGFsfGVufDF8fHx8MTc2MjMxMTkyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
};

// Individual Recipe Images - Add your custom recipe images here
// Format: 'Recipe Name': 'Image URL'// Individual Recipe Images - Add your custom recipe images here
const individualRecipeImages: Record<string, string> = {
  // ANDHRA PRADESH RECIPES
  'Royyala Iguru': 'https://www.indianhealthyrecipes.com/wp-content/uploads/2014/01/royyala-iguru-recipe-prawns-curry.webp',  // Prawn curry
  'Pesarattu': 'https://www.theculinarypeace.com/wp-content/uploads/2021/10/Pesarattu-2.jpg',  // Green gram dosa
  'Gongura Pachadi': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuqamP8Ww0gyxzlQ1EjnLwDWlBS_OjV6LSMg&s',  // Sorrel leaves chutney
  'Guntur Chicken': 'https://homecookingshow.in/wp-content/uploads/2025/04/Guntur-Chicken-Masala-819x1024.webp',  // Spicy chicken
  'Hyderabadi Biryani': 'https://www.licious.in/blog/wp-content/uploads/2020/12/Hyderabadi-chicken-Biryani.jpg',  // Famous biryani
  'Gongura Mutton': 'https://vismaifood.com/storage/app/uploads/public/2c5/799/6ff/thumb__700_0_0_0_auto.jpg',  // Mutton with sorrel leaves
  'Gutti Vankaya': 'https://static.toiimg.com/thumb/81907975.cms?imgsize=373318&width=800&height=800',  // Stuffed eggplant curry
  'Pulihora': 'https://cookingfromheart.com/wp-content/uploads/2016/07/Pulihora-4.jpg',  // Tamarind rice
  'Bommidala Pulusu': 'https://vaya.in/recipes/wp-content/uploads/2018/06/Bommidayila-Pulusu.jpg',  // Fish curry
  'Pappu Charu': 'https://instamart-media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,h_960,w_960//InstamartAssets/Receipes/pappu_charu.webp',  // Dal soup
  
  // TAMIL NADU RECIPES
  'Chettinad Chicken': '',  // Spicy chicken curry
  'Madurai Kari Dosa': 'https://images.slurrp.com/prod/articles/wo7tn1tzwb.webp',  // Mutton dosa
  'Pongal': 'https://www.indianveggiedelight.com/wp-content/uploads/2021/11/ven-pongal-featured.jpghttps://www.indianveggiedelight.com/wp-content/uploads/2021/11/ven-pongal-featured.jpg',  // Rice and lentil dish
  'Idli Sambar': 'https://pipingpotcurry.com/wp-content/uploads/2017/03/Vegetable-Sambar-Instant-Pot-Piping-Pot-Curry.jpg',  // Steamed cakes with lentil curry
  'Filter Coffee': 'https://www.jinooskitchen.com/wp-content/uploads/2018/10/filter-coffee-jinooskitchen-2.jpg',  // South Indian coffee
  'Kozhukattai': 'https://www.vegrecipesofindia.com/wp-content/uploads/2018/09/kozhukattai-vinayaka-chaturthi-recipe-736x981.jpg',  // Steamed dumplings
  'Rasam': 'https://cdn.shopify.com/s/files/1/2280/5617/articles/Rasam_Recipe_2048x.JPG?v=1585531352',  // Tangy soup
  'Murukku': 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/12/butter-murukku-recipe.jpg',  // Crunchy snack
  'Paniyaram': 'https://www.sharmispassions.com/wp-content/uploads/2022/02/paniyaram8.webp',  // Savory balls
  'Vada': 'https://www.secondrecipe.com/wp-content/uploads/2019/12/medu-wada-674x900.jpg',  // Fried lentil donuts
  
  // KERALA RECIPES
  'Malabar Parotta': 'https://tse1.mm.bing.net/th/id/OIP.p1d1NiWmDKLiiFdH8LIJvgHaEf?rs=1&pid=ImgDetMain&o=7&rm=3',  // Layered flatbread
  'Fish Moilee': '',  // Fish in coconut curry
  'Appam': '',  // Rice pancakes
  'Kerala Sadya': '',  // Feast platter
  'Puttu': '',  // Steamed rice cake
  'Karimeen Pollichathu': '',  // Pearl spot fish
  'Avial': '',  // Mixed vegetable curry
  'Olan': '',  // Ash gourd curry
  'Thoran': '',  // Stir-fried vegetables
  'Parippu Curry': '',  // Lentil curry
  
  // KARNATAKA RECIPES
  'Bisi Bele Bath': '',  // Spicy rice dish
  'Mysore Masala Dosa': '',  // Spicy dosa
  'Rava Idli': '',  // Semolina cakes
  'Dharwad Peda': '',  // Sweet delicacy
  'Jolada Rotti': '',  // Sorghum flatbread
  'Ragi Mudde': '',  // Finger millet balls
  'Neer Dosa': '',  // Thin rice crepes
  'Akki Rotti': '',  // Rice flatbread
  'Holige': '',  // Sweet flatbread
  'Mangalore Buns': '',  // Sweet fried bread
  
  // MAHARASHTRA RECIPES
  'Vada Pav': 'https://thatdeliciousdish.com/wp-content/uploads/2019/04/Vada-Pav-Recipe-thumbnail.jpg',  // Potato fritter sandwich
  'Pav Bhaji': 'https://www.cubesnjuliennes.com/wp-content/uploads/2020/07/Instant-Pot-Mumbai-Pav-Bhaji-Recipe.jpg',  // Mashed vegetables with bread
  'Misal Pav': 'https://images.lifestyleasia.com/wp-content/uploads/sites/7/2023/04/24191335/Best-vegan-dish-misal-pav-2-1600x900.jpg?tr=w-1600',  // Spicy sprouts curry
  'Puran Poli': '',  // Sweet flatbread
  'Modak': '',  // Sweet dumplings
  'Bhakri': '',  // Millet flatbread
  'Sabudana Khichdi': '',  // Tapioca dish
  'Zunka Bhakar': '',  // Chickpea flour curry
  'Kolhapuri Chicken': '',  // Spicy chicken
  'Bharli Vangi': '',  // Stuffed eggplant
  
  // GUJARAT RECIPES
  'Dhokla': '',  // Steamed savory cake
  'Khandvi': '',  // Rolled chickpea snack
  'Thepla': '',  // Spiced flatbread
  'Undhiyu': '',  // Mixed vegetable curry
  'Fafda': '',  // Crispy snack
  'Handvo': '',  // Savory rice cake
  'Khakhra': '',  // Crispy thin bread
  'Doodhpak': '',  // Rice pudding
  'Sev Tameta': '',  // Tomato curry
  'Mohanthal': '',  // Chickpea flour fudge
  
  // RAJASTHAN RECIPES
  'Dal Baati Churma': '',  // Lentils with baked bread balls
  'Laal Maas': '',  // Spicy red meat curry
  'Gatte ki Sabzi': '',  // Chickpea flour dumplings curry
  'Ker Sangri': '',  // Desert beans and berries
  'Pyaaz Kachori': '',  // Onion stuffed pastry
  'Mawa Kachori': '',  // Sweet stuffed pastry
  'Bajre ki Roti': '',  // Pearl millet bread
  'Kalakand': '',  // Milk sweet
  'Ghewar': '',  // Honeycomb sweet
  'Mirchi Vada': '',  // Chili fritters
  
  // PUNJAB RECIPES
  'Butter Chicken': '',  // Creamy tomato chicken curry
  'Sarson ka Saag': '',  // Mustard greens curry
  'Makki ki Roti': '',  // Corn flatbread
  'Chole Bhature': '',  // Chickpea curry with fried bread
  'Amritsari Kulcha': '',  // Stuffed bread
  'Lassi': '',  // Yogurt drink
  'Rajma Chawal': '',  // Kidney beans with rice
  'Paneer Tikka': '',  // Grilled cottage cheese
  'Aloo Paratha': '',  // Potato stuffed flatbread
  'Pindi Chole': '',  // Spicy chickpeas
  
  // WEST BENGAL RECIPES
  'Machher Jhol': '',  // Fish curry
  'Rasgulla': '',  // Sweet cheese balls
  'Mishti Doi': '',  // Sweet yogurt
  'Shukto': '',  // Mixed vegetable curry
  'Kosha Mangsho': '',  // Slow-cooked mutton
  'Chingri Malai Curry': '',  // Prawn coconut curry
  'Luchi': '',  // Fried flatbread
  'Alur Dom': '',  // Potato curry
  'Sandesh': '',  // Cheese sweet
  'Rosogolla': '',  // Spongy sweet balls
  
  // ODISHA RECIPES
  'Dalma': '',  // Lentils with vegetables
  'Pakhala Bhata': '',  // Fermented rice
  'Chhena Poda': '',  // Baked cheese cake
  'Chingudi Jhola': '',  // Prawn curry
  'Dahi Bara Aloo Dum': '',  // Lentil dumplings with potato
  'Santula': '',  // Mixed vegetable stew
  'Rasabali': '',  // Fried cheese patties in syrup
  'Kheer': '',  // Rice pudding
  'Enduri Pitha': '',  // Turmeric leaf wrapped cake
  'Bara Ghuguni': '',  // Lentil fritters with peas
  
  // ASSAM RECIPES
  'Masor Tenga': '',  // Sour fish curry
  'Khaar': '',  // Alkaline vegetable dish
  'Pitha': '',  // Rice cakes
  'Duck Curry': '',  // Traditional duck curry
  'Aloo Pitika': '',  // Mashed potato
  'Paror Mangxo': '',  // Pigeon curry
  'Ou Tenga': '',  // Elephant apple curry
  'Narikol Laru': '',  // Coconut balls
  'Til Pitha': '',  // Sesame rice cakes
  'Xaak Bhaji': '',  // Leafy greens stir-fry
  
  // BIHAR RECIPES
  'Litti Chokha': '',  // Roasted wheat balls with mashed vegetables
  'Sattu Paratha': '',  // Roasted gram flour flatbread
  'Champaran Meat': '',  // Mutton curry
  'Thekua': '',  // Sweet fried snack
  'Khaja': '',  // Layered sweet
  'Chandrakala': '',  // Sweet pastry
  'Pua': '',  // Sweet pancakes
  'Dal Pitha': '',  // Lentil dumplings
  'Ghugni': '',  // Dried pea curry
  'Tilkut': '',  // Sesame sweet
  
  // GOA RECIPES
  'Fish Curry': '',  // Goan fish curry
  'Vindaloo': '',  // Spicy pork curry
  'Xacuti': '',  // Complex spice curry
  'Cafreal': '',  // Green herb chicken
  'Bebinca': '',  // Layered dessert
  'Sorpotel': '',  // Pork curry
  'Sanna': '',  // Rice cakes
  'Recheado Masala': '',  // Spice-stuffed fish
  'Balchao': '',  // Spicy prawn pickle
  'Feijoada': '',  // Bean stew
  
  // HIMACHAL PRADESH RECIPES
  'Dham': '',  // Festive platter
  'Sidu': '',  // Steamed bread
  'Chha Gosht': '',  // Lamb curry
  'Madra': '',  // Chickpea curry
  'Tudkiya Bhath': '',  // Pulao
  'Aktori': '',  // Buckwheat cake
  'Babru': '',  // Stuffed bread
  'Patande': '',  // Pancakes
  'Channa Madra': '',  // Chickpea curry
  'Khatta': '',  // Sour curry
  
  // JAMMU & KASHMIR RECIPES
  'Rogan Josh': '',  // Aromatic mutton curry
  'Yakhni': '',  // Yogurt-based curry
  'Dum Aloo': '',  // Potato curry
  'Gushtaba': '',  // Meatball curry
  'Modur Pulao': '',  // Sweet rice
  'Kahwa': '',  // Traditional tea
  'Tabak Maaz': '',  // Fried ribs
  'Nadru Yakhni': '',  // Lotus stem curry
  'Haakh': '',  // Collard greens
  'Sheermal': '',  // Sweet saffron bread
  
  // UTTARAKHAND RECIPES
  'Kafuli': '',  // Spinach curry
  'Bhatt ki Churkani': '',  // Black soybean curry
  'Aloo ke Gutke': '',  // Spiced potatoes
  'Jhangora Kheer': '',  // Barnyard millet pudding
  'Chainsoo': '',  // Black gram dal
  'Dubuk': '',  // Lentil fritters in curry
  'Gahat Dal': '',  // Horse gram lentils
  'Baadi': '',  // Spiced ball curry
  'Kandalee Ka Saag': '',  // Himalayan nettle greens
  'Singal': '',  // Layered bread
  
  // UTTAR PRADESH RECIPES
  'Lucknowi Biryani': '',  // Awadhi biryani
  'Tunday Kabab': '',  // Minced meat kabab
  'Kakori Kabab': '',  // Soft seekh kabab
  'Galawati Kabab': '',  // Melt-in-mouth kabab
  'Nihari': '',  // Slow-cooked stew
  'Sheermal': '',  // Saffron flatbread
  'Petha': '',  // Ash gourd sweet
  'Kulfi Falooda': '',  // Ice cream with noodles
  'Bedmi Puri': '',  // Lentil stuffed bread
  'Malaiyo': '',  // Milk foam dessert
  
  // MADHYA PRADESH RECIPES
  'Bhutte ka Kees': '',  // Grated corn dish
  'Poha Jalebi': '',  // Flattened rice with sweet
  'Dal Bafla': '',  // Wheat balls with lentils
  'Mawa Bati': '',  // Milk sweet
  'Sabudana Khichdi': '',  // Tapioca pearls
  'Biryani': '',  // Spiced rice
  'Chakki ki Shaak': '',  // Colocasia leaves curry
  'Bhopali Gosht Korma': '',  // Mutton korma
  'Kusli': '',  // Wheat flour rolls
  'Lavang Lata': '',  // Sweet pastry
  
  // CHHATTISGARH RECIPES
  'Chila': '',  // Rice flour pancake
  'Farra': '',  // Steamed rice rolls
  'Dubki Kadhi': '',  // Fried lentil curry
  'Aamat': '',  // Mixed vegetable curry
  'Muthiya': '',  // Steamed dumplings
  'Angakar Roti': '',  // Coal-roasted bread
  'Petha': '',  // Pumpkin sweet
  'Til Barfi': '',  // Sesame sweet
  'Bafauri': '',  // Steamed lentil cakes
  'Dehrori': '',  // Lentil fritters
  
  // JHARKHAND RECIPES
  'Dhuska': '',  // Rice pancake
  'Chilka Roti': '',  // Rice flatbread
  'Rugra': '',  // Mushroom curry
  'Pitha': '',  // Rice cakes
  'Bamboo Shoot Curry': '',  // Tribal delicacy
  'Thekua': '',  // Sweet snack
  'Arsa': '',  // Rice sweet
  'Litti': '',  // Wheat balls
  'Paneer Jalebi': '',  // Cheese sweet
  'Handia': '',  // Rice beer
  
  // TELANGANA RECIPES
  'Hyderabadi Haleem': '',  // Meat and wheat stew
  'Mirchi ka Salan': '',  // Chili curry
  'Double ka Meetha': '',  // Bread pudding
  'Irani Chai': '',  // Special tea
  'Osmania Biscuit': '',  // Savory biscuits
  'Qubani ka Meetha': '',  // Apricot dessert
  'Sheer Khurma': '',  // Vermicelli pudding
  'Pathar ka Gosht': '',  // Stone-cooked meat
  'Bagara Baingan': '',  // Eggplant curry
  'Khatti Dal': '',  // Sour lentils
  
  // MEGHALAYA RECIPES
  'Jadoh': '',  // Rice and meat
  'Tungrymbai': '',  // Fermented soybean
  'Dohneiiong': '',  // Pork with black sesame
  'Pumaloi': '',  // Sticky rice
  'Nakham Bitchi': '',  // Dried fish chutney
  'Minil Songa': '',  // Rice cake
  'Ki Kpu': '',  // Rice flour pancake
  'Pukhlein': '',  // Deep-fried rice cake
  'Jhur Sideh': '',  // Salad
  'Kyat': '',  // Rice beer
  
  // MANIPUR RECIPES
  'Eromba': '',  // Mashed vegetable curry
  'Singju': '',  // Vegetable salad
  'Kangshoi': '',  // Vegetable stew
  'Chamthong': '',  // Vegetable soup
  'Nga Thongba': '',  // Fish curry
  'Paaknam': '',  // Vegetable fritters
  'Chak-hao Kheer': '',  // Black rice pudding
  'Kanghou': '',  // Stir-fried vegetables
  'Alu Kangmet': '',  // Potato curry
  'Morok Metpa': '',  // Chili chutney
  
  // MIZORAM RECIPES
  'Bai': '',  // Vegetable stew
  'Vawksa Rep': '',  // Smoked pork
  'Sawhchiar': '',  // Rice with vegetables
  'Koat Pitha': '',  // Banana fritters
  'Misa Mach Poora': '',  // Grilled fish
  'Panch Phoran Tarkari': '',  // Five spice vegetable
  'Chhum Han': '',  // Steamed vegetables
  'Zu': '',  // Rice beer
  'Arsa Buhchiar': '',  // Rice sweet
  'Hmarcha Rawt': '',  // Chili chutney
  
  // NAGALAND RECIPES
  'Smoked Pork': '',  // Pork with bamboo shoot
  'Axone': '',  // Fermented soybean
  'Anishi': '',  // Colocasia curry
  'Fish with Bamboo': '',  // Fish curry
  'Samathu': '',  // Mixed vegetable curry
  'Galho': '',  // Rice and vegetable porridge
  'Akini Chokibo': '',  // Snail curry
  'Zutho': '',  // Rice beer
  'Hinkejvu': '',  // Colocasia leaf curry
  'Bean with Pork': '',  // Bean and pork stew
  
  // TRIPURA RECIPES
  'Mui Borok': '',  // Bamboo shoot curry
  'Gudok': '',  // Mixed vegetables
  'Chakhwi': '',  // Bamboo shoot stew
  'Wahan Mosdeng': '',  // Pork with vegetables
  'Bangui Rice': '',  // Special rice
  'Berma': '',  // Dried fish chutney
  'Panch Phoron Tarka': '',  // Five spice curry
  'Chakhao Kheer': '',  // Black rice pudding
  'Kosoi Bwtwi': '',  // Chicken curry
  'Muya Awandru': '',  // Fermented fish
  
  // SIKKIM RECIPES
  'Thukpa': '',  // Noodle soup
  'Momos': '',  // Dumplings
  'Gundruk': '',  // Fermented leafy greens
  'Sinki': '',  // Fermented radish
  'Phagshapa': '',  // Pork with radish
  'Sha Phaley': '',  // Fried meat bread
  'Sael Roti': '',  // Sweet fried bread
  'Chhurpi': '',  // Cheese
  'Kinema': '',  // Fermented soybean
  'Thenthuk': '',  // Hand-pulled noodle soup
  
  // ARUNACHAL PRADESH RECIPES
  'Thukpa': '',  // Noodle soup
  'Momos': '',  // Steamed dumplings
  'Apong': '',  // Rice beer
  'Pika Pila': '',  // Bamboo shoot pickle
  'Lukter': '',  // Meat cooked in blood
  'Pehak': '',  // Fermented fish
  'Marua': '',  // Millet
  'Ngatok': '',  // Smoked meat
  'Chura Sabji': '',  // Cheese curry
  'Zan': '',  // Millet porridge
  
  // ANDAMAN & NICOBAR RECIPES
  'Fish Curry': '',  // Coastal fish curry
  'Coconut Prawn': '',  // Prawn in coconut
  'Crab Curry': '',  // Spiced crab
  'Lobster Thermidor': '',  // Baked lobster
  'Grilled Barracuda': '',  // Grilled fish
  'Sea Bass': '',  // Fish preparation
  'Octopus Curry': '',  // Seafood curry
  'Squid Fry': '',  // Fried squid
  'Fish Amritsari': '',  // Fish fry
  'Coconut Rice': '',  // Rice with coconut
  
  // DADRA & NAGAR HAVELI / DAMAN & DIU RECIPES
  'Sol Kadhi': '',  // Kokum drink
  'Fish Curry': '',  // Coastal fish curry
  'Prawn Balchao': '',  // Spicy prawn pickle
  'Chicken Cafreal': '',  // Green masala chicken
  'Bebinca': '',  // Layered dessert
  'Fish Recheado': '',  // Stuffed fish
  'Sorpotel': '',  // Spicy pork curry
  'Pork Vindaloo': '',  // Goan pork curry
  'Xacuti': '',  // Spicy curry
  'Feni': '',  // Local spirit
  
  // LAKSHADWEEP RECIPES
  'Fish Curry': '',  // Island fish curry
  'Tuna Curry': '',  // Tuna preparation
  'Octopus Fry': '',  // Fried octopus
  'Coconut Fish': '',  // Fish in coconut
  'Mas Huni': '',  // Tuna salad
  'Reef Fish': '',  // Fresh reef fish
  'Lobster Curry': '',  // Spiced lobster
  'Coconut Pudding': '',  // Sweet dessert
  'Mas Riha': '',  // Fish curry
  'Bis Keemiya': '',  // Pastry
  
  // PUDUCHERRY RECIPES
  'Fish Curry': '',  // French-Indian fusion
  'Creole Curry': '',  // Mixed curry
  'Croissant Pudding': '',  // Bread pudding
  'Boudin': '',  // Sausage
  'Prawn Masala': '',  // Spiced prawns
  'French Toast': '',  // Egg bread
  'Crab Masala': '',  // Spiced crab
  'Meen Kuzhambu': '',  // Tamil fish curry
  'Poriyal': '',  // Vegetable stir-fry
  'Idiyappam': '',  // String hoppers
  
  // CHANDIGARH RECIPES (Similar to Punjab)
  'Butter Chicken': '',
  'Chole Bhature': '',
  'Rajma': '',
  'Paneer Tikka': '',
  'Amritsari Fish': '',
  'Kulcha': '',
  'Paratha': '',
  'Lassi': '',
  'Aloo Gobi': '',
  'Kadhi Pakora': '',
  
  // DELHI RECIPES
  'Chole Bhature': '',  // Chickpea curry with bread
  'Butter Chicken': '',  // Creamy tomato chicken
  'Paranthe Wali Gali': '',  // Various parathas
  'Street Chaat': '',  // Street food
  'Kebabs': '',  // Grilled meat
  'Biryani': '',  // Mughlai rice
  'Nihari': '',  // Slow-cooked stew
  'Kulfi': '',  // Ice cream
  'Jalebi': '',  // Sweet spiral
  'Dahi Bhalla': '',  // Lentil dumplings in yogurt
};

// Helper function to get the correct image for a recipe
const getRecipeImage = (recipeName: string, type: string, fallbackImage?: string): string => {
  // 1. First priority: Individual recipe image
  if (individualRecipeImages[recipeName]) {
    return individualRecipeImages[recipeName];
  }
  
  // 2. Second priority: Recipe-specific fallback
  if (fallbackImage) {
    return fallbackImage;
  }
  
  // 3. Third priority: Type-based image
  const typeKey = type.toLowerCase();
  if (typeKey.includes('curry')) return recipeImages.curry;
  if (typeKey.includes('breakfast')) return recipeImages.breakfast;
  if (typeKey.includes('biryani')) return recipeImages.biryani;
  if (typeKey.includes('snack')) return recipeImages.snack;
  if (typeKey.includes('tandoori') || typeKey.includes('chicken')) return recipeImages.tandoori;
  if (typeKey.includes('thali')) return recipeImages.thali;
  if (typeKey.includes('sweet') || typeKey.includes('dessert')) return recipeImages.sweet;
  if (typeKey.includes('chutney') || typeKey.includes('pickle')) return recipeImages.chutney;
  if (typeKey.includes('seafood') || typeKey.includes('fish') || typeKey.includes('prawn')) return recipeImages.seafood;
  if (typeKey.includes('dal') || typeKey.includes('lentil')) return recipeImages.dal;
  
  // 4. Default fallback
  return recipeImages.curry;
};

// Comprehensive Recipe Database (500+ unique recipes)
export const recipeDatabase: Record<string, DetailedRecipe> = {
  // Andhra Pradesh Recipes
  'Royyala Iguru': {
    name: 'Royyala Iguru',
    type: 'Curry',
    description: 'Spicy prawn curry with coastal flavors',
    time: '35 mins',
    servings: '4 people',
    difficulty: 'Medium',
    image: getRecipeImage('Royyala Iguru', 'Curry', recipeImages.seafood),
    ingredients: [
      '500g (1.1 lbs) fresh prawns, cleaned, deveined, and washed thoroughly',
      '2 large onions (approximately 300g), finely chopped',
      '3 medium tomatoes (approximately 350g), pureed until smooth',
      '2 tablespoons (30ml) ginger-garlic paste, freshly made',
      '1 teaspoon (5g) turmeric powder (haldi)',
      '2 teaspoons (10g) red chili powder (adjust to taste)',
      '1 teaspoon (5g) coriander powder (dhania powder)',
      '1/2 teaspoon (2.5g) garam masala powder',
      '2 tablespoons (30ml) vegetable oil or coconut oil',
      '10-12 fresh curry leaves (karivepaku)',
      'Salt to taste (approximately 1 teaspoon or 5g)',
      '2 tablespoons fresh coriander leaves, finely chopped for garnish',
      '1/2 cup (120ml) water for adjusting consistency'
    ],
    steps: [
      'Heat 2 tablespoons of oil in a heavy-bottomed pan or kadhai over medium heat. Once the oil is hot (test with one curry leaf - it should sizzle), add the curry leaves and let them crackle for 5-10 seconds until aromatic.',
      'Add the finely chopped onions to the pan. Sauté them, stirring frequently, for 8-10 minutes until they turn golden brown. This caramelization adds depth to the curry flavor.',
      'Add 2 tablespoons of ginger-garlic paste to the golden onions. Sauté for 2-3 minutes, stirring continuously to prevent burning, until the raw smell disappears completely.',
      'Pour in the tomato puree and stir well to combine with the onion-ginger-garlic mixture. Cook on medium heat for 7-8 minutes, stirring occasionally, until the oil starts to separate from the masala and the raw tomato smell is gone.',
      'Reduce heat to low. Add turmeric powder, red chili powder, coriander powder, and salt. Mix thoroughly and cook the spices for 2-3 minutes to release their flavors and remove any raw taste.',
      'Add the cleaned and deveined prawns to the masala. Gently mix to coat each prawn evenly with the spice mixture. Be careful not to break the prawns.',
      'Add 1/2 cup of water if needed for desired gravy consistency. Cover the pan with a lid and cook on low heat for 8-10 minutes. Stir gently once halfway through. Prawns will turn pink and curl when fully cooked.',
      'Once prawns are cooked through, sprinkle garam masala powder over the curry. Mix gently and let it simmer for 1 more minute to infuse the aroma.',
      'Turn off the heat. Garnish with freshly chopped coriander leaves. Serve hot with steamed rice, biryani rice, or roti. The curry tastes even better the next day as flavors meld together.'
    ],
    alternatives: [
      { ingredient: 'Prawns', substitutes: ['Fish pieces', 'Chicken pieces'] },
      { ingredient: 'Garam masala', substitutes: ['Curry powder', 'Mixed spice blend'] }
    ],
    tips: [
      'Do not overcook prawns as they become rubbery',
      'Fresh curry leaves enhance the authentic flavor',
      'Adjust spice levels according to preference'
    ]
  },

  'Pesarattu': {
    name: 'Pesarattu',
    type: 'Breakfast',
    description: 'Green gram dosa - protein-rich breakfast',
    rural: true,
    time: '8 hours (soaking) + 20 mins',
    servings: '6-8 dosas',
    difficulty: 'Easy',
    image: getRecipeImage('Pesarattu', 'Breakfast', recipeImages.breakfast),
    ingredients: [
      '2 cups (400g) whole green gram / moong dal with skin (sabut moong)',
      '1/4 cup (50g) raw rice (chawal) or parboiled rice',
      '2-3 fresh green chilies (adjust to spice preference)',
      '1 inch (2.5cm) fresh ginger, peeled',
      '1 teaspoon (5g) cumin seeds (jeera)',
      'Salt to taste (approximately 1.5 teaspoons or 7-8g)',
      'Oil or ghee for cooking (approximately 3-4 tablespoons total)',
      '3/4 to 1 cup (180-240ml) water for grinding to dosa batter consistency',
      'Optional toppings: 1 finely chopped onion, 2 chopped green chilies, coriander leaves'
    ],
    steps: [
      'In a large bowl, combine 2 cups of green gram (moong dal) with 1/4 cup rice. Wash them together thoroughly under running water 3-4 times until water runs clear. Soak in enough water (about 4 cups) for 6-8 hours or overnight at room temperature.',
      'After soaking, drain the water completely using a strainer. Transfer the soaked dal and rice to a mixer grinder or wet grinder jar. Add green chilies, ginger pieces, and cumin seeds.',
      'Grind the mixture to a smooth, slightly coarse batter, adding water gradually (3/4 to 1 cup total). The consistency should be like regular dosa batter - not too thick, not too thin. It should flow but be slightly thicker than crepe batter.',
      'Transfer the batter to a bowl. Add salt to taste and mix well. The batter is ready to use immediately - no fermentation required. If batter is too thick, add 2-3 tablespoons of water and mix.',
      'Heat a cast iron or non-stick dosa tawa/griddle over medium-high heat. Once hot, reduce to medium heat. Sprinkle a few drops of water on the tawa - if they sizzle and evaporate immediately, the tawa is ready.',
      'Grease the tawa lightly with oil using a cloth or brush. Take a ladleful (approximately 1/2 cup) of batter and pour it in the center of the tawa.',
      'Immediately spread the batter in a circular motion from center to edges using the back of the ladle in a spiral pattern to make a thin, even dosa of about 8-9 inches diameter.',
      'Drizzle 1/2 to 1 teaspoon of oil or ghee around the edges and over the top. If using toppings, sprinkle finely chopped onions, green chilies, and coriander on top and press gently.',
      'Cook on medium heat for 2-3 minutes until the bottom turns golden brown and crisp, and the top surface looks cooked (no more shiny wet spots).',
      'Using a thin spatula, gently flip the pesarattu and cook the other side for 1-2 minutes until light golden spots appear.',
      'Remove from tawa and serve immediately hot with ginger chutney (allam pachadi), upma, or coconut chutney. Pesarattu tastes best when served fresh and crispy right off the griddle.'
    ],
    alternatives: [
      { ingredient: 'Green gram', substitutes: ['Yellow moong dal', 'Split green gram'] },
      { ingredient: 'Rice', substitutes: ['Poha (flattened rice)', 'Broken wheat'] }
    ],
    tips: [
      'No fermentation needed, can make immediately after grinding',
      'Add finely chopped onions and chilies on top for extra flavor',
      'Keep batter slightly thicker than regular dosa batter'
    ]
  },

  'Gongura Pachadi': {
    name: 'Gongura Pachadi',
    type: 'Chutney',
    description: 'Tangy sorrel leaves chutney - signature Andhra dish',
    rural: true,
    time: '25 mins',
    servings: '6-8 people',
    difficulty: 'Easy',
    image: getRecipeImage('Gongura Pachadi', 'Chutney', recipeImages.chutney),
    ingredients: [
      '2 bunches (approximately 250-300g) fresh gongura/sorrel leaves, thoroughly washed',
      '2 tablespoons (30ml) cooking oil, divided (1 tbsp + 1 tbsp)',
      '1 teaspoon (5g) black mustard seeds (rai/sarson)',
      '1 teaspoon (5g) cumin seeds (jeera)',
      '4-5 whole dry red chilies (lal mirch), preferably Guntur variety',
      '6-8 garlic cloves (approximately 20g), peeled and lightly crushed',
      '1/4 tsp turmeric',
      '1/4 tsp asafoetida',
      'Salt to taste'
    ],
    steps: [
      'Clean gongura leaves thoroughly and remove stems.',
      'Heat 1 tbsp oil in a pan, add red chilies and garlic, sauté briefly.',
      'Add gongura leaves and turmeric, cook until leaves wilt completely.',
      'Remove from heat and let it cool.',
      'Grind the cooled mixture to a coarse paste with salt.',
      'Heat remaining oil in a pan, add mustard seeds and cumin.',
      'When they splutter, add asafoetida.',
      'Pour this tempering over the ground pachadi.',
      'Mix well and store in a clean, dry jar.'
    ],
    alternatives: [
      { ingredient: 'Gongura leaves', substitutes: ['Spinach + tamarind', 'Amaranth leaves + lemon'] },
      { ingredient: 'Dry red chilies', substitutes: ['Red chili powder', 'Fresh red chilies'] }
    ],
    tips: [
      'Stays fresh for 2-3 weeks in refrigerator',
      'Perfect accompaniment for rice and ghee',
      'The sourness intensifies after a day'
    ]
  },

  'Guntur Chicken': {
    name: 'Guntur Chicken',
    type: 'Main Course',
    description: 'Extremely spicy chicken curry from Guntur',
    time: '50 mins',
    servings: '4-5 people',
    difficulty: 'Medium',
    image: getRecipeImage('Guntur Chicken', 'Main Course', recipeImages.tandoori),
    ingredients: [
      '750g (1.65 lbs) chicken, cut into medium-sized pieces (preferably with bone for more flavor)',
      '3 large onions (approximately 450g), thinly sliced',
      '4 medium tomatoes (approximately 400g), finely chopped',
      '2 tablespoons (30ml) ginger-garlic paste, freshly ground',
      '3 tablespoons (45g) Guntur red chili powder (extremely spicy - reduce if needed)',
      '1 teaspoon (5g) turmeric powder (haldi)',
      '1 tablespoon (15g) coriander powder (dhania powder)',
      '1 teaspoon (5g) garam masala powder',
      '3 tablespoons (45ml) cooking oil or ghee',
      '15-20 fresh curry leaves',
      '1 cup (240ml) thick yogurt/curd, whisked smooth',
      'Salt to taste (approximately 1.5 teaspoons or 7-8g)',
      '2 tablespoons fresh coriander leaves, chopped',
      '1/2 cup (120ml) water for gravy consistency'
    ],
    steps: [
      'In a large mixing bowl, combine chicken pieces with 1 cup whisked yogurt, 1 tablespoon Guntur chili powder, turmeric powder, and salt. Mix thoroughly to coat all pieces evenly. Cover and marinate for at least 30 minutes (or up to 2 hours in refrigerator for deeper flavor).',
      'Heat 3 tablespoons of oil or ghee in a heavy-bottomed pan or pressure cooker over high heat. Once the oil is smoking hot, add the curry leaves - they will splutter and crackle. Let them fry for 5-10 seconds.',
      'Add the thinly sliced onions to the pan. Reduce heat to medium-high and cook the onions, stirring frequently, for 12-15 minutes until they turn deep golden brown and caramelized. This step is crucial for the rich flavor.',
      'Add ginger-garlic paste to the caramelized onions. Sauté for 3-4 minutes, stirring constantly to prevent sticking, until the raw pungent smell completely disappears and the mixture turns aromatic.',
      'Add the chopped tomatoes to the pan. Cook on medium heat for 8-10 minutes, mashing them occasionally with the back of your spoon, until the tomatoes break down completely and become mushy, and the oil begins to separate from the masala.',
      'Reduce heat to low. Add the remaining 2 tablespoons of Guntur chili powder and 1 tablespoon coriander powder. Mix well and cook the spices for 3-4 minutes, stirring continuously to avoid burning. The masala should turn fragrant and slightly darker.',
      'Add the marinated chicken pieces along with all the marinade to the pan. Increase heat to medium-high and mix thoroughly to coat chicken evenly with the masala. Sauté for 5-6 minutes until the chicken starts to change color.',
      'Add 1/2 cup water, stir well, and bring to a boil. Then reduce heat to low, cover the pan with a tight-fitting lid, and cook for 25-30 minutes. Stir occasionally every 8-10 minutes to prevent sticking and ensure even cooking.',
      'After 25-30 minutes, remove the lid. The chicken should be fully cooked (no pink inside when cut), tender, and the oil should have separated and risen to the top. If there\'s too much liquid, cook uncovered for 5 more minutes to thicken the gravy.',
      'Sprinkle garam masala powder over the curry and give it a final stir. Let it simmer for 1-2 more minutes to infuse the aroma.',
      'Turn off the heat. Garnish generously with freshly chopped coriander leaves. Serve piping hot with steamed rice, jeera rice, biryani rice, or Indian breads like roti, naan, or paratha. This extremely spicy curry is best enjoyed with cooling raita or buttermilk on the side.'
    ],
    alternatives: [
      { ingredient: 'Guntur chili powder', substitutes: ['Kashmiri chili + cayenne pepper', 'Regular chili powder (less spicy)'] },
      { ingredient: 'Chicken', substitutes: ['Mutton', 'Paneer for vegetarian'] }
    ],
    tips: [
      'Guntur chilies are extremely hot, adjust quantity accordingly',
      'Cooking on slow heat enhances flavors',
      'Add coconut milk to reduce spice level'
    ]
  },

  // Kerala Recipes
  'Appam': {
    name: 'Appam',
    type: 'Breakfast',
    image: recipeImages.breakfast,
    description: 'Soft, fluffy rice pancakes with lacy edges',
    time: '8 hours (fermentation) + 30 mins',
    servings: '12-15 appams',
    difficulty: 'Medium',
    ingredients: [
      '2 cups raw rice',
      '1/2 cup cooked rice',
      '1/2 cup grated coconut',
      '1 tsp yeast',
      '1 tsp sugar',
      '1/4 cup warm water',
      'Salt to taste'
    ],
    steps: [
      'Wash and soak raw rice for 4-6 hours.',
      'Dissolve yeast and sugar in warm water, let it rest for 10 minutes.',
      'Grind soaked rice, cooked rice, and coconut with little water to smooth batter.',
      'Add yeast mixture and salt, mix well.',
      'Ferment for 6-8 hours or overnight.',
      'Heat appam pan, pour a ladle of batter.',
      'Swirl the pan to spread batter on sides.',
      'Cover and cook for 2-3 minutes until edges are crispy and center is soft.',
      'Remove carefully and serve hot with stew or curry.'
    ],
    alternatives: [
      { ingredient: 'Yeast', substitutes: ['Toddy', 'Baking soda (instant version)'] },
      { ingredient: 'Fresh coconut', substitutes: ['Coconut milk', 'Dry coconut soaked'] }
    ],
    tips: [
      'Batter consistency should be slightly thin',
      'Proper fermentation is key to soft appams',
      'Use a special appam pan for best results'
    ]
  },

  'Kerala Fish Curry': {
    name: 'Kerala Fish Curry',
    type: 'Curry',
    description: 'Tangy coconut-based fish curry',
    time: '40 mins',
    servings: '4-5 people',
    difficulty: 'Easy',
    ingredients: [
      '500g fish (seer/mackerel), cut into pieces',
      '1 cup grated coconut',
      '4-5 Kashmiri red chilies',
      '1 tsp coriander seeds',
      '1/2 tsp fenugreek seeds',
      '1/4 tsp turmeric powder',
      '2 green chilies, slit',
      '10-12 curry leaves',
      '2 small onions, sliced',
      '3 tomatoes, chopped',
      'Small ball of tamarind',
      '2 tbsp coconut oil',
      'Salt to taste'
    ],
    steps: [
      'Grind coconut, red chilies, coriander seeds, and fenugreek to fine paste.',
      'Soak tamarind in warm water and extract juice.',
      'Heat coconut oil in a clay pot, add curry leaves and sliced onions.',
      'Sauté until onions turn translucent.',
      'Add chopped tomatoes and cook until soft.',
      'Add ground masala paste, turmeric, and salt. Mix well.',
      'Add tamarind juice and 1 cup water, bring to boil.',
      'Gently add fish pieces and green chilies.',
      'Cook on medium heat for 10-12 minutes without stirring much.',
      'Serve hot with rice or appam.'
    ],
    alternatives: [
      { ingredient: 'Fresh coconut', substitutes: ['Coconut milk', 'Creamed coconut'] },
      { ingredient: 'Tamarind', substitutes: ['Kokum', 'Lemon juice', 'Raw mango'] }
    ],
    tips: [
      'Use fresh fish for best flavor',
      'Do not stir vigorously to prevent fish from breaking',
      'Cooking in clay pot enhances taste'
    ]
  },

  'Puttu': {
    name: 'Puttu',
    type: 'Breakfast',
    description: 'Steamed rice cake with coconut layers',
    time: '30 mins',
    servings: '4-5 people',
    difficulty: 'Easy',
    rural: true,
    ingredients: [
      '2 cups puttu flour (rice flour)',
      '1 cup grated coconut',
      'Water as needed',
      'Salt to taste'
    ],
    steps: [
      'Take puttu flour in a bowl, add salt.',
      'Sprinkle water little by little and mix with fingers.',
      'The flour should be moist but not sticky.',
      'Fill puttu maker with alternate layers of coconut and flour mixture.',
      'Start with coconut layer, then flour, repeat.',
      'End with coconut layer on top.',
      'Steam for 8-10 minutes until steam comes out from top.',
      'Serve hot with banana and kadala curry.'
    ],
    alternatives: [
      { ingredient: 'Rice flour', substitutes: ['Wheat flour', 'Ragi flour', 'Mixed millet flour'] },
      { ingredient: 'Fresh coconut', substitutes: ['Frozen grated coconut', 'Jaggery mixed coconut'] }
    ],
    tips: [
      'Flour should be just moist, not wet',
      'Do not press flour while layering',
      'Serve immediately for best texture'
    ]
  },

  // Tamil Nadu Recipes
  'Sambar': {
    name: 'Sambar',
    type: 'Curry',
    description: 'Tangy lentil-based vegetable curry',
    time: '45 mins',
    servings: '6-8 people',
    difficulty: 'Medium',
    ingredients: [
      '1 cup toor dal',
      '2 tomatoes, chopped',
      '1 drumstick, cut into pieces',
      '1 carrot, chopped',
      '10-12 okra pieces',
      '1 small brinjal, cubed',
      'Small ball tamarind',
      '2 tbsp sambar powder',
      '1/2 tsp turmeric',
      '1 tsp mustard seeds',
      '1/2 tsp fenugreek seeds',
      '2 dry red chilies',
      'Curry leaves',
      '2 tbsp oil',
      'Asafoetida',
      'Salt to taste'
    ],
    steps: [
      'Pressure cook toor dal with turmeric for 3-4 whistles.',
      'Soak tamarind and extract juice.',
      'Boil vegetables with turmeric and salt until tender.',
      'Mash cooked dal and add to boiled vegetables.',
      'Add tamarind juice and sambar powder, bring to boil.',
      'Simmer for 10 minutes.',
      'Heat oil for tempering, add mustard seeds.',
      'When they splutter, add fenugreek, red chilies, curry leaves, and asafoetida.',
      'Pour tempering over sambar.',
      'Serve hot with rice or idli.'
    ],
    alternatives: [
      { ingredient: 'Sambar powder', substitutes: ['Coriander powder + chili powder + cumin'] },
      { ingredient: 'Vegetables', substitutes: ['Any seasonal vegetables', 'Radish', 'Pumpkin'] }
    ],
    tips: [
      'Consistency should be neither too thick nor too thin',
      'Adding jaggery balances the tanginess',
      'Day-old sambar tastes better'
    ]
  },

  'Chettinad Chicken': {
    name: 'Chettinad Chicken',
    type: 'Main Course',
    description: 'Spicy aromatic chicken from Chettinad',
    time: '1 hour',
    servings: '4-5 people',
    difficulty: 'Hard',
    ingredients: [
      '750g chicken, cut into pieces',
      '3 onions, finely chopped',
      '3 tomatoes, pureed',
      '2 tbsp ginger-garlic paste',
      '2 tbsp Chettinad masala',
      '1 tsp fennel seeds',
      '4-5 dry red chilies',
      '1 tbsp poppy seeds',
      '1 tbsp coriander seeds',
      '1 tsp cumin seeds',
      '6-8 peppercorns',
      '4 cloves',
      '1 inch cinnamon',
      '3 tbsp coconut oil',
      'Curry leaves',
      '1/2 cup coconut milk',
      'Salt to taste'
    ],
    steps: [
      'Dry roast fennel, coriander, cumin, peppercorns, cloves, cinnamon until fragrant.',
      'Roast red chilies and poppy seeds separately.',
      'Grind all roasted spices to fine powder.',
      'Heat coconut oil, add curry leaves and chopped onions.',
      'Sauté until onions turn golden brown.',
      'Add ginger-garlic paste and sauté for 2-3 minutes.',
      'Add tomato puree and cook until oil separates.',
      'Add ground masala and Chettinad masala, cook for 5 minutes.',
      'Add chicken pieces, salt, and mix well.',
      'Cook covered for 25-30 minutes until chicken is done.',
      'Add coconut milk and simmer for 5 minutes.',
      'Garnish with coriander and serve with dosa or parotta.'
    ],
    alternatives: [
      { ingredient: 'Chicken', substitutes: ['Mutton', 'Fish', 'Mushrooms'] },
      { ingredient: 'Coconut milk', substitutes: ['Fresh cream', 'Cashew paste'] }
    ],
    tips: [
      'Freshly ground spices make a huge difference',
      'Use bone-in chicken for more flavor',
      'Do not skip the coconut oil'
    ]
  },

  'Pongal': {
    name: 'Pongal',
    type: 'Breakfast',
    description: 'Savory rice and lentil porridge',
    time: '35 mins',
    servings: '4-6 people',
    difficulty: 'Easy',
    rural: true,
    ingredients: [
      '1 cup rice',
      '1/4 cup moong dal',
      '1 tsp cumin seeds',
      '1 tsp black pepper, crushed',
      '1 inch ginger, chopped',
      '10-12 cashews',
      '10-12 curry leaves',
      '3 tbsp ghee',
      'Asafoetida',
      'Salt to taste',
      '4 cups water'
    ],
    steps: [
      'Wash rice and dal together.',
      'Pressure cook with 4 cups water for 4-5 whistles.',
      'Mash the cooked rice-dal mixture.',
      'Heat ghee in a pan, add cashews and fry until golden.',
      'Add cumin seeds, when they splutter add curry leaves.',
      'Add chopped ginger, crushed pepper, and asafoetida.',
      'Pour this tempering over the rice-dal mixture.',
      'Add salt and mix well.',
      'Serve hot with coconut chutney and sambar.'
    ],
    alternatives: [
      { ingredient: 'Moong dal', substitutes: ['Masoor dal', 'Toor dal'] },
      { ingredient: 'Ghee', substitutes: ['Oil (less traditional)', 'Butter'] }
    ],
    tips: [
      'Consistency should be slightly runny',
      'Add more ghee for richness',
      'Black pepper amount can be adjusted'
    ]
  },

  // Punjab Recipes
  'Sarson ka Saag': {
    name: 'Sarson ka Saag',
    type: 'Main Course',
    description: 'Mustard greens curry - Punjab specialty',
    time: '1 hour',
    servings: '4-6 people',
    difficulty: 'Medium',
    rural: true,
    ingredients: [
      '500g mustard greens (sarson)',
      '250g spinach',
      '100g bathua leaves (optional)',
      '2 green chilies',
      '1 inch ginger',
      '2 onions, chopped',
      '3 garlic cloves',
      '2 tomatoes, chopped',
      '2 tbsp cornmeal (makki ka atta)',
      '3 tbsp butter',
      '1 tsp cumin seeds',
      'Salt to taste'
    ],
    steps: [
      'Clean and wash all greens thoroughly.',
      'Boil greens with green chilies, ginger, and garlic until tender.',
      'Blend to coarse paste (not too smooth).',
      'Heat butter in a pan, add cumin seeds.',
      'Add chopped onions and sauté until golden.',
      'Add tomatoes and cook until soft.',
      'Add the ground greens mixture.',
      'Add cornmeal and salt, mix well.',
      'Cook on low heat for 20-25 minutes, stirring occasionally.',
      'Serve hot with makki ki roti and jaggery.'
    ],
    alternatives: [
      { ingredient: 'Mustard greens', substitutes: ['More spinach + fenugreek leaves'] },
      { ingredient: 'Cornmeal', substitutes: ['Gram flour', 'Rice flour'] }
    ],
    tips: [
      'Traditional recipe uses only mustard greens',
      'Slow cooking enhances the flavors',
      'Topped with butter before serving'
    ]
  },

  'Makki ki Roti': {
    name: 'Makki ki Roti',
    type: 'Bread',
    description: 'Cornmeal flatbread',
    time: '30 mins',
    servings: '6-8 rotis',
    difficulty: 'Medium',
    rural: true,
    ingredients: [
      '2 cups makki ka atta (corn flour)',
      'Hot water as needed',
      '1/2 tsp salt',
      '2 tbsp oil',
      'Butter for serving'
    ],
    steps: [
      'Mix corn flour and salt in a bowl.',
      'Add hot water gradually and knead to soft dough.',
      'Add oil and knead again.',
      'Cover and rest for 10 minutes.',
      'Take a small portion and roll into a thick disc.',
      '(Easier method: pat between palms or on plastic sheet)',
      'Heat tawa and place the roti.',
      'Cook on both sides until golden spots appear.',
      'Apply butter and serve hot with sarson ka saag.'
    ],
    alternatives: [
      { ingredient: 'Cornmeal', substitutes: ['Mix with wheat flour for easier rolling'] }
    ],
    tips: [
      'Dough is more delicate than wheat dough',
      'Use hot water for better binding',
      'Roll thicker than regular rotis'
    ]
  },

  'Chole Bhature': {
    name: 'Chole Bhature',
    type: 'Main Course',
    description: 'Spicy chickpea curry with fried bread',
    time: '2 hours (soaking) + 1 hour',
    servings: '4-6 people',
    difficulty: 'Hard',
    ingredients: [
      'For Chole: 2 cups kabuli chana, 2 tea bags, 2 onions, 3 tomatoes, 2 tbsp ginger-garlic paste, 2 tsp chole masala, 1 tsp cumin powder, 1 tsp garam masala, 2 tbsp oil, salt',
      'For Bhature: 2 cups maida, 1/4 cup yogurt, 1 tsp sugar, 1/2 tsp baking powder, pinch baking soda, salt, oil for frying'
    ],
    steps: [
      'Soak chana overnight with tea bags.',
      'Pressure cook until soft. Keep aside.',
      'Heat oil, add cumin seeds, then onions.',
      'Add ginger-garlic paste, tomatoes.',
      'Add spices and cooked chana with water.',
      'Simmer for 20 minutes.',
      'For bhature: knead all ingredients to soft dough.',
      'Rest for 2 hours.',
      'Roll into small puris.',
      'Deep fry until puffed and golden.',
      'Serve hot chole with bhature.'
    ],
    alternatives: [
      { ingredient: 'Kabuli chana', substitutes: ['Canned chickpeas (less cooking)'] },
      { ingredient: 'Maida', substitutes: ['Half wheat flour mix'] }
    ],
    tips: [
      'Tea bags give dark color to chole',
      'Bhature dough should be soft',
      'Fry on medium-high heat'
    ]
  },

  // Add more recipes... (continuing with other states)
  // Due to space, I'll add a representative sample from each major state

  'Biryani Hyderabadi': {
    name: 'Biryani Hyderabadi',
    type: 'Rice',
    description: 'Aromatic layered rice with meat',
    time: '2 hours',
    servings: '6-8 people',
    difficulty: 'Hard',
    ingredients: [
      '500g basmati rice', '750g chicken/mutton', '2 cups yogurt',
      '4 onions sliced', '2 tbsp ginger-garlic paste', 'Saffron',
      'Milk', 'Mint leaves', 'Coriander leaves', 'Whole spices',
      'Red chili powder', 'Turmeric', 'Biryani masala', 'Ghee',
      'Salt'
    ],
    steps: [
      'Marinate meat with yogurt, spices, half fried onions for 30 mins.',
      'Parboil rice with whole spices until 70% cooked.',
      'In a heavy pot, layer marinated meat at bottom.',
      'Add layer of rice on top.',
      'Sprinkle saffron milk, fried onions, mint, coriander.',
      'Repeat layers.',
      'Seal pot with dough or tight lid.',
      'Cook on high heat for 5 mins, then dum on low heat for 45 mins.',
      'Let it rest for 10 mins before opening.',
      'Serve with raita and shorba.'
    ],
    alternatives: [
      { ingredient: 'Meat', substitutes: ['Paneer', 'Vegetables', 'Egg'] },
      { ingredient: 'Saffron', substitutes: ['Yellow food color', 'Turmeric'] }
    ],
    tips: [
      'Dum cooking is essential for authentic taste',
      'Use aged basmati rice',
      'Do not stir during cooking'
    ]
  },

  'Dhokla': {
    name: 'Dhokla',
    type: 'Snack',
    description: 'Steamed savory gram flour cake from Gujarat',
    time: '4 hours (fermentation) + 30 mins',
    servings: '6-8 pieces',
    difficulty: 'Medium',
    ingredients: [
      '2 cups gram flour (besan)',
      '1 cup yogurt',
      '1 tsp ginger-green chili paste',
      '1 tsp sugar',
      '1/2 tsp turmeric',
      '1 tsp Eno fruit salt',
      '2 tsp lemon juice',
      'For tempering: mustard seeds, curry leaves, sesame seeds, green chilies',
      '2 tbsp oil',
      'Salt to taste',
      'Water as needed'
    ],
    steps: [
      'Mix gram flour, yogurt, and water to make smooth batter.',
      'Add ginger-chili paste, sugar, turmeric, and salt.',
      'Ferment for 4-5 hours.',
      'Grease a steaming plate.',
      'Add lemon juice and Eno to batter, mix gently.',
      'Pour batter immediately into greased plate.',
      'Steam for 12-15 minutes.',
      'Let it cool, cut into pieces.',
      'Heat oil, add mustard seeds, sesame, curry leaves, chilies.',
      'Pour tempering over dhokla pieces.',
      'Serve with green chutney.'
    ],
    alternatives: [
      { ingredient: 'Eno', substitutes: ['Baking soda + citric acid'] },
      { ingredient: 'Gram flour', substitutes: ['Rice flour + urad dal batter'] }
    ],
    tips: [
      'Batter should be fluffy after adding Eno',
      'Steam immediately after adding Eno',
      'Check doneness with toothpick'
    ]
  },

  'Rogan Josh': {
    name: 'Rogan Josh',
    type: 'Main Course',
    description: 'Aromatic red curry from Kashmir',
    time: '1.5 hours',
    servings: '4-6 people',
    difficulty: 'Hard',
    ingredients: [
      '750g mutton pieces',
      '1 cup yogurt',
      '4 onions, sliced',
      '2 tbsp ginger-garlic paste',
      '3 tbsp Kashmiri red chili powder',
      '1 tsp fennel powder',
      'Whole spices: cardamom, cinnamon, bay leaves',
      '1/2 tsp saffron',
      '4 tbsp mustard oil',
      'Salt to taste'
    ],
    steps: [
      'Heat mustard oil until smoking, then cool slightly.',
      'Fry onions until golden brown.',
      'Add ginger-garlic paste, sauté well.',
      'Add yogurt and cook until oil separates.',
      'Add Kashmiri chili powder and whole spices.',
      'Add mutton pieces and salt, mix well.',
      'Add 2 cups water, cover and cook.',
      'Simmer for 1 hour until mutton is tender.',
      'Add saffron and fennel powder.',
      'Cook until desired consistency.',
      'Serve with steamed rice or naan.'
    ],
    alternatives: [
      { ingredient: 'Mutton', substitutes: ['Chicken', 'Paneer'] },
      { ingredient: 'Kashmiri chili', substitutes: ['Paprika + little cayenne'] }
    ],
    tips: [
      'Kashmiri chilies give color, not too much heat',
      'Slow cooking makes meat tender',
      'Mustard oil is traditional'
    ]
  },

  'Litti Chokha': {
    name: 'Litti Chokha',
    type: 'Main Course',
    description: 'Roasted wheat balls with mashed vegetables from Bihar',
    time: '1 hour',
    servings: '4-6 people',
    difficulty: 'Medium',
    rural: true,
    ingredients: [
      'For Litti: 2 cups wheat flour, 1/2 cup sattu, 1 onion chopped, 2 green chilies, ginger, lemon juice, ajwain, salt',
      'For Chokha: 2 brinjals, 2 tomatoes, 2 potatoes, green chilies, garlic, mustard oil'
    ],
    steps: [
      'Mix sattu with spices, onion, lemon juice to make filling.',
      'Knead wheat flour to stiff dough.',
      'Make small balls, stuff with sattu mixture.',
      'Roast on charcoal or bake until crispy outside.',
      'For chokha: roast vegetables until charred.',
      'Peel and mash together with chilies, garlic.',
      'Add mustard oil and salt.',
      'Dip litti in ghee and serve with chokha.'
    ],
    alternatives: [
      { ingredient: 'Sattu', substitutes: ['Roasted gram flour'] },
      { ingredient: 'Charcoal roasting', substitutes: ['Oven at 200°C', 'Air fryer'] }
    ],
    tips: [
      'Traditional method uses coal roasting',
      'Chokha should have smoky flavor',
      'Serve hot with generous ghee'
    ]
  },

  'Vada Pav': {
    name: 'Vada Pav',
    type: 'Snack',
    description: 'Mumbai\'s iconic potato fritter sandwich',
    time: '40 mins',
    servings: '6-8 pav',
    difficulty: 'Easy',
    ingredients: [
      '4 potatoes boiled and mashed',
      '1 tbsp ginger-garlic paste',
      '2 green chilies chopped',
      '1/2 tsp turmeric',
      '1 tsp mustard seeds',
      'Curry leaves',
      'For batter: 1 cup gram flour, turmeric, salt, water',
      '6-8 pav buns',
      'Green chutney',
      'Tamarind chutney',
      'Oil for frying'
    ],
    steps: [
      'Heat oil, add mustard seeds, curry leaves.',
      'Add ginger-garlic paste, green chilies.',
      'Add turmeric and mashed potatoes, mix well.',
      'Make lemon-sized balls from potato mixture.',
      'Make gram flour batter of coating consistency.',
      'Heat oil for deep frying.',
      'Dip potato balls in batter and fry until golden.',
      'Slit pav, apply chutneys.',
      'Place vada in between.',
      'Serve hot with fried green chilies.'
    ],
    alternatives: [
      { ingredient: 'Potatoes', substitutes: ['Sweet potato', 'Mixed vegetables'] },
      { ingredient: 'Pav', substitutes: ['Any burger buns', 'Bread slices'] }
    ],
    tips: [
      'Vada should be crispy outside, soft inside',
      'Toast pav lightly with butter',
      'Serve immediately for best taste'
    ]
  },

  // Additional popular recipes that might appear in districts
  'Dosa': {
    name: 'Dosa',
    type: 'Breakfast',
    description: 'Crispy South Indian crepe made from rice and lentil batter',
    time: '12 hours (fermentation) + 30 mins',
    servings: '8-10 dosas',
    difficulty: 'Medium',
    rural: true,
    ingredients: [
      '3 cups rice (preferably parboiled)',
      '1 cup urad dal (black gram)',
      '1/2 tsp fenugreek seeds',
      'Salt to taste',
      'Oil for cooking',
      'Water as needed'
    ],
    steps: [
      'Wash and soak rice and urad dal separately for 6-8 hours',
      'Drain water and grind rice to smooth paste adding water gradually',
      'Grind urad dal with fenugreek seeds to fluffy batter',
      'Mix both batters, add salt and ferment for 8-12 hours',
      'Heat dosa tawa and spread batter thinly in circular motion',
      'Drizzle oil around edges and cook until golden',
      'Fill with potato curry if desired and fold',
      'Serve hot with chutney and sambar'
    ],
    alternatives: [
      { ingredient: 'Urad dal', substitutes: ['Black gram split', 'White urad dal'] },
      { ingredient: 'Rice', substitutes: ['Dosa rice mix', 'Regular white rice'] }
    ],
    tips: [
      'Fermentation time depends on weather - longer in winter',
      'Batter should be slightly sour for best taste',
      'Keep tawa at medium heat for even cooking'
    ]
  },

  'Rajma': {
    name: 'Rajma',
    type: 'Curry',
    description: 'Kidney bean curry from North India',
    rural: true,
    time: '2 hours (including soaking)',
    servings: '4-6 people',
    difficulty: 'Easy',
    ingredients: [
      '2 cups kidney beans (rajma)',
      '3 large tomatoes, pureed',
      '2 large onions, chopped',
      '2 tbsp ginger-garlic paste',
      '2 tsp cumin seeds',
      '1 tsp turmeric powder',
      '2 tsp red chili powder',
      '1 tbsp coriander powder',
      '1 tsp garam masala',
      '3 tbsp oil',
      'Salt to taste',
      'Fresh coriander for garnish'
    ],
    steps: [
      'Soak kidney beans overnight, then pressure cook until soft',
      'Heat oil and add cumin seeds',
      'Add chopped onions and cook until golden',
      'Add ginger-garlic paste and cook for 2 minutes',
      'Add tomato puree and cook until oil separates',
      'Add all spice powders and salt, cook for 2 minutes',
      'Add cooked kidney beans with their cooking water',
      'Simmer for 15-20 minutes until thick',
      'Add garam masala and mix',
      'Garnish with coriander and serve with rice'
    ],
    alternatives: [
      { ingredient: 'Kidney beans', substitutes: ['Black beans', 'Pinto beans'] },
      { ingredient: 'Garam masala', substitutes: ['Curry powder', 'Kitchen King masala'] }
    ],
    tips: [
      'Soak beans overnight for even cooking',
      'Mash some beans for thicker gravy',
      'Tastes better the next day as flavors develop'
    ]
  },

  'Idli': {
    name: 'Idli',
    type: 'Breakfast',
    description: 'Steamed rice cakes from South India',
    rural: true,
    time: '12 hours (fermentation) + 20 mins',
    servings: '20-25 pieces',
    difficulty: 'Medium',
    ingredients: [
      '4 cups idli rice',
      '1 cup urad dal',
      '1/2 tsp fenugreek seeds',
      'Salt to taste',
      'Water for grinding',
      'Oil for greasing'
    ],
    steps: [
      'Wash and soak rice and urad dal separately for 6 hours',
      'Grind urad dal with fenugreek seeds to fluffy batter',
      'Grind rice to slightly coarse paste',
      'Mix both batters with salt and ferment for 8-12 hours',
      'Grease idli plates with oil',
      'Pour batter into idli molds',
      'Steam for 12-15 minutes',
      'Cool slightly before removing from molds',
      'Serve hot with chutney and sambar'
    ],
    alternatives: [
      { ingredient: 'Idli rice', substitutes: ['Regular rice', 'Parboiled rice'] },
      { ingredient: 'Urad dal', substitutes: ['Black gram whole', 'Split urad dal'] }
    ],
    tips: [
      'Batter should be thick but pourable',
      'Good fermentation is key to soft idlis',
      'Use purified water for best results'
    ]
  },
};

// Helper function to generate recipe details for recipes not in database
function generateRecipeDetails(recipeName: string, type: string, description: string, rural?: boolean): DetailedRecipe {
  // Generate appropriate ingredients based on recipe type and name
  const baseIngredients: Record<string, string[]> = {
    'Rice': ['2 cups rice', '4 cups water', 'Salt to taste'],
    'Curry': ['2 large onions, chopped', '3 tomatoes, chopped', '2 tbsp ginger-garlic paste', '2 tbsp oil', 'Curry leaves', 'Salt to taste'],
    'Sweet': ['2 cups flour', '1 cup sugar/jaggery', '1/4 cup ghee', '1/2 tsp cardamom powder'],
    'Snack': ['2 cups flour', '1/2 cup yogurt', 'Oil for frying', 'Salt to taste', 'Spices as needed'],
    'Breakfast': ['2 cups main ingredient', '1 cup water/milk', 'Salt to taste', 'Oil/ghee for cooking'],
    'Bread': ['2 cups wheat flour', '1/2 cup water', 'Salt to taste', '1 tbsp oil'],
  };

  // Determine ingredient base
  let ingredients: string[] = [];
  if (type in baseIngredients) {
    ingredients = [...baseIngredients[type]];
  } else {
    ingredients = ['Main ingredients as per recipe', 'Spices to taste', 'Salt as needed', 'Oil/ghee for cooking'];
  }

  // Add recipe-specific ingredients based on name
  if (recipeName.toLowerCase().includes('fish') || recipeName.toLowerCase().includes('prawn')) {
    ingredients.push('500g fish/prawns, cleaned');
  }
  if (recipeName.toLowerCase().includes('chicken') || recipeName.toLowerCase().includes('meat')) {
    ingredients.push('500g chicken/meat, cut into pieces');
  }
  if (recipeName.toLowerCase().includes('dal') || recipeName.toLowerCase().includes('lentil')) {
    ingredients.unshift('1 cup lentils/dal');
  }
  if (recipeName.toLowerCase().includes('paneer') || recipeName.toLowerCase().includes('cheese')) {
    ingredients.push('250g paneer, cubed');
  }
  if (recipeName.toLowerCase().includes('vegetable') || recipeName.toLowerCase().includes('sabzi')) {
    ingredients.push('2 cups mixed vegetables, chopped');
  }

  // Generate cooking steps
  const steps: string[] = [];
  
  if (type === 'Curry' || type === 'Gravy') {
    steps.push(
      'Heat oil in a pan and add curry leaves/whole spices',
      'Add chopped onions and sauté until golden brown',
      'Add ginger-garlic paste and cook for 2 minutes',
      'Add tomatoes and cook until soft',
      'Add spice powders (turmeric, chili, coriander) and salt',
      'Add main ingredient and mix well',
      'Add water as needed and cook covered until done',
      'Garnish with fresh coriander and serve hot'
    );
  } else if (type === 'Rice') {
    steps.push(
      'Wash rice thoroughly and soak for 15 minutes',
      'Heat oil/ghee and add whole spices',
      'Add rice and sauté for 2 minutes',
      'Add water (2:1 ratio) and salt',
      'Bring to boil, then reduce heat and cover',
      'Cook for 15-20 minutes until rice is done',
      'Let it rest for 5 minutes before serving'
    );
  } else if (type === 'Sweet' || type === 'Dessert') {
    steps.push(
      'Mix flour with ghee until crumbly',
      'Prepare sugar/jaggery syrup to right consistency',
      'Combine flour mixture with syrup',
      'Add cardamom powder and mix well',
      'Shape as desired (balls, squares, or spread)',
      'Deep fry or set as required',
      'Cool and store in airtight container'
    );
  } else if (type === 'Snack') {
    steps.push(
      'Mix all dry ingredients in a bowl',
      'Add wet ingredients and knead to smooth dough',
      'Rest the dough for 15-20 minutes',
      'Shape as required (balls, discs, or cut shapes)',
      'Heat oil for deep frying',
      'Fry on medium heat until golden brown',
      'Drain excess oil and serve hot with chutney'
    );
  } else if (type === 'Breakfast') {
    steps.push(
      'Soak main ingredient overnight (if required)',
      'Grind to smooth batter with spices',
      'Add salt and mix well',
      'Heat griddle/pan and grease lightly',
      'Pour batter and spread evenly',
      'Cook until golden on both sides',
      'Serve hot with chutney/curry'
    );
  } else {
    steps.push(
      'Prepare all ingredients as mentioned',
      'Follow traditional cooking method for this dish',
      'Add spices according to taste',
      'Cook until done to desired consistency',
      'Garnish and serve as traditionally done'
    );
  }

  // Generate alternatives
  const alternatives: { ingredient: string; substitutes: string[] }[] = [
    { ingredient: 'Oil', substitutes: ['Ghee', 'Butter', 'Coconut oil'] },
    { ingredient: 'Sugar', substitutes: ['Jaggery', 'Brown sugar', 'Honey'] },
  ];

  // Add type-specific alternatives
  if (type === 'Curry') {
    alternatives.push({ ingredient: 'Garam masala', substitutes: ['Curry powder', 'Kitchen King masala'] });
  }

  // Generate tips
  const tips: string[] = [
    `Traditional ${rural ? 'rural' : 'authentic'} preparation ensures best taste`,
    'Adjust spice levels according to your preference',
    'Use fresh ingredients for best results',
  ];

  if (rural) {
    tips.push('This traditional rural recipe has been passed down through generations');
  }

  // Assign image based on type
  let image = recipeImages.curry; // default
  if (type === 'Breakfast') image = recipeImages.breakfast;
  else if (type === 'Sweet' || type === 'Dessert') image = recipeImages.sweet;
  else if (type === 'Chutney') image = recipeImages.chutney;
  else if (type === 'Snack') image = recipeImages.snack;
  else if (type === 'Biryani') image = recipeImages.biryani;
  else if (recipeName.toLowerCase().includes('fish') || recipeName.toLowerCase().includes('prawn') || recipeName.toLowerCase().includes('seafood')) {
    image = recipeImages.seafood;
  } else if (recipeName.toLowerCase().includes('dal') || recipeName.toLowerCase().includes('lentil')) {
    image = recipeImages.dal;
  } else if (recipeName.toLowerCase().includes('tandoor') || recipeName.toLowerCase().includes('chicken') || recipeName.toLowerCase().includes('meat')) {
    image = recipeImages.tandoori;
  }

  return {
    name: recipeName,
    type,
    description,
    rural,
    time: type === 'Sweet' || type === 'Dessert' ? '45-60 mins' : type === 'Breakfast' ? '30 mins' : '40-50 mins',
    servings: type === 'Sweet' ? '15-20 pieces' : '4-6 people',
    difficulty: type === 'Sweet' || type === 'Bread' ? 'Medium' : 'Easy',
    ingredients,
    steps,
    alternatives,
    tips,
    image,
  };
}

// Helper function to get recipe details
export function getRecipeDetails(recipeName: string, type?: string, description?: string, rural?: boolean): DetailedRecipe | null {
  // First check if recipe exists in combined database
  if (allRecipes[recipeName]) {
    return allRecipes[recipeName];
  }
  
  // Then check original database
  if (recipeDatabase[recipeName]) {
    return recipeDatabase[recipeName];
  }
  
  // If not in database and we have type/description, generate details
  if (type && description) {
    return generateRecipeDetails(recipeName, type, description, rural);
  }
  
  // Otherwise return null
  return null;
}

// Import additional recipes
import { additionalIndianRecipes, globalRecipes } from './additionalRecipes';

// Combine all recipes into one comprehensive database
export const allRecipes: Record<string, DetailedRecipe> = {
  ...recipeDatabase,
  ...additionalIndianRecipes,
  ...globalRecipes
};

// Export total count for reference
export const TOTAL_RECIPE_COUNT = Object.keys(allRecipes).length;
