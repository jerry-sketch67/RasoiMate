import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Search, Clock, Star, Users, Volume2, Sparkles, ChefHat, Flame, Minus, Plus, X, Check, Info, Download, Globe, StopCircle } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { getFigmaSafeImage } from './utils/imagePlaceholder';
import { Footer } from './Footer';

export const mockRecipes = [
  // Newly Added Recipes with Unique Images
  {
    id: 101,
    name: 'Tandoori Chicken Tikka',
    image: 'https://images.unsplash.com/photo-1617692855027-33b14f061079?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0YW5kb29yaSUyMGNoaWNrZW58ZW58MXx8fHwxNzYyMjI4NzQ1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    time: '40 mins + marination',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 423,
    cooked: 1850,
    baseServings: 4,
    newlyAdded: true,
    ingredients: [
      { name: 'Chicken (boneless)', amount: 750, unit: 'grams', alternatives: ['Chicken Thighs', 'Paneer for Veg'] },
      { name: 'Hung Yogurt', amount: 1, unit: 'cup', alternatives: ['Greek Yogurt', 'Thick Curd'] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: ['Fresh Ginger & Garlic'] },
      { name: 'Tandoori Masala', amount: 3, unit: 'tablespoons', alternatives: ['Homemade Spice Mix'] },
      { name: 'Kashmiri Red Chili', amount: 1, unit: 'teaspoon', alternatives: ['Paprika', 'Regular Chili Powder'] },
      { name: 'Lemon Juice', amount: 3, unit: 'tablespoons', alternatives: ['Lime Juice'] },
      { name: 'Mustard Oil', amount: 2, unit: 'tablespoons', alternatives: ['Vegetable Oil'] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: ['Mixed Spices'] },
      { name: 'Kasoori Methi', amount: 1, unit: 'tablespoon', alternatives: ['Dried Fenugreek Leaves'] },
      { name: 'Salt', amount: 1.5, unit: 'teaspoons', alternatives: ['Sea Salt', 'Pink Salt'] },
    ],
    steps: [
      'Cut chicken into bite-sized cubes and make shallow cuts.',
      'Mix yogurt with all spices, ginger-garlic paste, lemon juice, and salt.',
      'Marinate chicken thoroughly for at least 2-4 hours (overnight for best results).',
      'Preheat oven to 220°C or prepare charcoal grill.',
      'Thread marinated chicken onto skewers.',
      'Grill or bake for 20-25 minutes, turning occasionally.',
      'Baste with butter and sprinkle kasoori methi.',
      'Serve hot with mint chutney and onion rings.',
    ]
  },
  {
    id: 102,
    name: 'Dal Tadka',
    image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2016/02/instant-pot-dal-tadka-1.jpg',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 567,
    cooked: 2340,
    baseServings: 6,
    newlyAdded: true,
    ingredients: [
      { name: 'Toor Dal (Yellow Lentils)', amount: 1, unit: 'cup', alternatives: ['Moong Dal', 'Mixed Lentils'] },
      { name: 'Onions (chopped)', amount: 2, unit: 'medium', alternatives: ['Shallots'] },
      { name: 'Tomatoes (chopped)', amount: 2, unit: 'medium', alternatives: ['Tomato Puree'] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: ['Oil', 'Butter'] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: ['Mustard Seeds'] },
      { name: 'Garlic Cloves', amount: 6, unit: 'pieces', alternatives: ['Garlic Paste'] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: ['Red Chili Powder'] },
      { name: 'Turmeric Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Fresh Turmeric'] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Cayenne Pepper'] },
      { name: 'Garam Masala', amount: 0.5, unit: 'teaspoon', alternatives: ['Curry Powder'] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: ['Parsley'] },
    ],
    steps: [
      'Pressure cook dal with turmeric and salt for 3-4 whistles until soft.',
      'Mash dal lightly with a spoon.',
      'Heat ghee in a pan, add cumin seeds.',
      'Add chopped garlic and green chilies, sauté until golden.',
      'Add onions and cook until translucent.',
      'Add tomatoes, red chili powder, and cook until soft.',
      'Pour this tadka over cooked dal and mix well.',
      'Simmer for 5 minutes, garnish with coriander and serve with rice or roti.',
    ]
  },
  {
    id: 103,
    name: 'Garlic Naan',
    image: 'https://images.unsplash.com/photo-1725483990150-61a9fbd746d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBuYWFuJTIwYnJlYWR8ZW58MXx8fHwxNzYyMjI4NzUwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    time: '90 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 789,
    cooked: 3120,
    baseServings: 6,
    newlyAdded: true,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2.5, unit: 'cups', alternatives: ['Maida', 'Bread Flour'] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: ['Curd', 'Buttermilk'] },
      { name: 'Milk (warm)', amount: 0.5, unit: 'cup', alternatives: ['Water', 'Plant Milk'] },
      { name: 'Sugar', amount: 1, unit: 'teaspoon', alternatives: ['Honey'] },
      { name: 'Active Dry Yeast', amount: 1, unit: 'teaspoon', alternatives: ['Instant Yeast'] },
      { name: 'Baking Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Baking Soda'] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: ['Sea Salt'] },
      { name: 'Garlic Cloves (minced)', amount: 8, unit: 'pieces', alternatives: ['Garlic Paste'] },
      { name: 'Butter (melted)', amount: 4, unit: 'tablespoons', alternatives: ['Ghee'] },
      { name: 'Coriander Leaves (chopped)', amount: 0.25, unit: 'cup', alternatives: ['Parsley'] },
    ],
    steps: [
      'Mix warm milk, sugar, and yeast. Let it sit for 10 minutes until frothy.',
      'In a bowl, combine flour, baking powder, and salt.',
      'Add yogurt and yeast mixture, knead into a soft dough.',
      'Cover and let it rise for 1-1.5 hours until doubled.',
      'Divide dough into 6 equal portions.',
      'Roll each portion into an oval shape, brush with water.',
      'Sprinkle minced garlic and coriander on one side.',
      'Heat a tawa or griddle, cook naan (garlic side down first).',
      'Flip and cook until puffed and golden. Brush with melted butter and serve hot.',
    ]
  },
  {
    id: 104,
    name: 'Papdi Chaat',
    image: 'https://assets.tastemadecdn.net/images/27ccf8/2aa81449f58d572964b8/1c2bf4.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'Street Food',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 456,
    cooked: 1670,
    baseServings: 4,
    newlyAdded: true,
    ingredients: [
      { name: 'Papdi (Crispy Wafers)', amount: 30, unit: 'pieces', alternatives: ['Store-bought', 'Homemade'] },
      { name: 'Boiled Potatoes (diced)', amount: 2, unit: 'medium', alternatives: ['Sweet Potatoes'] },
      { name: 'Boiled Chickpeas', amount: 1, unit: 'cup', alternatives: ['White Peas', 'Moong'] },
      { name: 'Yogurt (whisked)', amount: 1, unit: 'cup', alternatives: ['Hung Curd'] },
      { name: 'Tamarind Chutney', amount: 0.5, unit: 'cup', alternatives: ['Store-bought', 'Homemade'] },
      { name: 'Green Chutney', amount: 0.5, unit: 'cup', alternatives: ['Mint-Coriander Chutney'] },
      { name: 'Sev (Crispy Noodles)', amount: 0.5, unit: 'cup', alternatives: ['Crushed Papad'] },
      { name: 'Chaat Masala', amount: 2, unit: 'teaspoons', alternatives: ['Homemade Chaat Masala'] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Cayenne'] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: ['Mint Leaves'] },
      { name: 'Pomegranate Seeds', amount: 0.25, unit: 'cup', alternatives: ['Optional garnish'] },
    ],
    steps: [
      'Arrange papdi on a serving plate.',
      'Top each papdi with boiled potatoes and chickpeas.',
      'Drizzle whisked yogurt over them.',
      'Add tamarind chutney and green chutney.',
      'Sprinkle chaat masala and red chili powder.',
      'Top with generous amount of sev.',
      'Garnish with coriander leaves and pomegranate seeds.',
      'Serve immediately before the papdi gets soggy.',
    ]
  },
  {
    id: 105,
    name: 'Mixed Vegetable Curry',
    image: 'https://images.unsplash.com/photo-1595959524165-0d395008e55b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB2ZWdldGFibGUlMjBjdXJyeXxlbnwxfHx8fDE3NjIyMjg3NTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'Pan-Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 345,
    cooked: 1450,
    baseServings: 4,
    newlyAdded: true,
    ingredients: [
      { name: 'Mixed Vegetables (carrots, beans, peas)', amount: 3, unit: 'cups', alternatives: ['Seasonal Vegetables'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: ['Shallots'] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: ['Tomato Puree'] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: ['Fresh Ginger & Garlic'] },
      { name: 'Coconut Milk', amount: 1, unit: 'cup', alternatives: ['Cashew Paste', 'Cream'] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: ['Bay Leaves'] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: ['Cumin Seeds'] },
      { name: 'Turmeric Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Fresh Turmeric'] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: ['Ground Coriander'] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: ['Curry Powder'] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: ['Coconut Oil', 'Ghee'] },
    ],
    steps: [
      'Heat oil, add mustard seeds and curry leaves.',
      'Add onions and sauté until golden brown.',
      'Add ginger-garlic paste and cook for 2 minutes.',
      'Add chopped tomatoes and all spices, cook until soft.',
      'Add mixed vegetables and salt, mix well.',
      'Pour coconut milk and bring to a boil.',
      'Cover and simmer for 15 minutes until vegetables are cooked.',
      'Garnish with coriander and serve with rice or roti.',
    ]
  },
  {
    id: 1,
    name: 'Paneer Butter Masala',
    image: 'https://tse2.mm.bing.net/th/id/OIP.Pdhx2yLiW4jRKd5eR-K-8QHaJ4?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 245,
    cooked: 1200,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (cubed)', amount: 400, unit: 'grams', alternatives: ['Tofu', 'Cottage Cheese', 'Halloumi'] },
      { name: 'Tomatoes', amount: 4, unit: 'medium', alternatives: ['Canned Tomatoes (400g)', 'Tomato Puree (1 cup)'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: ['Shallots (4-5)', 'Red Onions'] },
      { name: 'Cashew Nuts', amount: 20, unit: 'pieces', alternatives: ['Almonds', 'Coconut Cream (1/4 cup)'] },
      { name: 'Fresh Cream', amount: 0.5, unit: 'cup', alternatives: ['Coconut Cream', 'Greek Yogurt'] },
      { name: 'Butter', amount: 3, unit: 'tablespoons', alternatives: ['Ghee', 'Oil'] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: ['Fresh Ginger & Garlic (1 tbsp each)'] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: ['Kashmiri Chili Powder', 'Paprika'] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: ['Curry Powder', 'Mixed Spices'] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: ['Sea Salt', 'Rock Salt'] },
      { name: 'Kasuri Methi', amount: 1, unit: 'tablespoon', alternatives: ['Fresh Fenugreek Leaves', 'Omit if unavailable'] },
    ],
    steps: [
      'Soak cashew nuts in warm water for 15 minutes, then blend into a smooth paste.',
      'Heat butter in a pan and sauté ginger-garlic paste until fragrant.',
      'Add chopped tomatoes and cook until soft and mushy (about 10 minutes).',
      'Blend the tomato mixture into a smooth puree and strain to remove seeds.',
      'Return the puree to the pan, add cashew paste, red chili powder, garam masala, and salt.',
      'Simmer the gravy for 5-7 minutes until it thickens.',
      'Add paneer cubes and fresh cream, mix gently.',
      'Crush kasuri methi between your palms and sprinkle over the dish.',
      'Garnish with cream and serve hot with naan or rice.',
    ]
  },
  {
    id: 2,
    name: 'Chicken Biryani',
    image: 'https://tse2.mm.bing.net/th/id/OIP.2iWS4NJfB5y_mu30Nsq_bwHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '90 mins',
    difficulty: 'Hard',
    region: 'Hyderabadi',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 389,
    cooked: 2100,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken (cut into pieces)', amount: 750, unit: 'grams', alternatives: ['Mutton', 'Prawns', 'Mixed Vegetables'] },
      { name: 'Basmati Rice', amount: 2, unit: 'cups', alternatives: ['Regular Long Grain Rice', 'Brown Rice'] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: ['Sour Cream', 'Coconut Yogurt'] },
      { name: 'Onions (thinly sliced)', amount: 3, unit: 'large', alternatives: ['Shallots (6-8)'] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: ['Canned Tomatoes (200g)'] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: ['Fresh Ginger & Garlic (1 tbsp each)'] },
      { name: 'Biryani Masala', amount: 2, unit: 'tablespoons', alternatives: ['Garam Masala + Cumin Powder'] },
      { name: 'Mint Leaves', amount: 0.5, unit: 'cup', alternatives: ['Dried Mint (2 tbsp)', 'Coriander Leaves'] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: ['Butter', 'Oil'] },
      { name: 'Saffron strands', amount: 1, unit: 'pinch', alternatives: ['Yellow Food Color', 'Turmeric (for color)'] },
      { name: 'Salt', amount: 1.5, unit: 'teaspoons', alternatives: ['Sea Salt'] },
    ],
    steps: [
      'Marinate chicken with yogurt, half the ginger-garlic paste, biryani masala, and salt for 30 minutes.',
      'Soak basmati rice in water for 30 minutes, then parboil with salt until 70% cooked. Drain and set aside.',
      'Deep fry sliced onions until golden brown and crispy. Reserve half for garnish.',
      'In a heavy-bottomed pan, heat ghee and sauté remaining ginger-garlic paste.',
      'Add marinated chicken and cook on high heat for 5 minutes.',
      'Add tomatoes and cook until chicken is 80% done.',
      'Layer the rice over the chicken, sprinkle fried onions, mint leaves, and saffron soaked in milk.',
      'Cover with a tight lid and cook on low heat (dum) for 25-30 minutes.',
      'Gently mix the biryani and serve hot with raita and salad.',
    ]
  },
  {
    id: 3,
    name: 'Masala Dosa',
    image: 'https://tse1.explicit.bing.net/th/id/OIP.6Nx_C1m4YCujBiHe48YpHAHaE8?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Medium',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 178,
    cooked: 890,
    baseServings: 4,
    ingredients: [
      { name: 'Dosa Batter', amount: 2, unit: 'cups', alternatives: ['Rice & Urad Dal (fermented)', 'Instant Dosa Mix'] },
      { name: 'Potatoes', amount: 4, unit: 'medium', alternatives: ['Sweet Potatoes', 'Mixed Vegetables'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: ['Shallots (4-5)'] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: ['Red Chili Flakes (1 tsp)', 'Bell Peppers'] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: ['Cumin Seeds'] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: ['Bay Leaves', 'Omit if unavailable'] },
      { name: 'Turmeric Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Saffron (for color)'] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: ['Ghee', 'Butter'] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: ['Sea Salt'] },
    ],
    steps: [
      'Boil potatoes until soft, peel and mash them coarsely.',
      'Heat oil in a pan, add mustard seeds and let them splutter.',
      'Add curry leaves, green chilies, and chopped onions. Sauté until onions are translucent.',
      'Add turmeric powder, salt, and mashed potatoes. Mix well and cook for 2-3 minutes.',
      'Heat a non-stick griddle, pour a ladleful of dosa batter and spread in a circular motion.',
      'Drizzle oil around the edges and cook until the bottom is golden and crispy.',
      'Place the potato filling in the center of the dosa.',
      'Fold the dosa and serve hot with coconut chutney and sambar.',
    ]
  },
  {
    id: 4,
    name: 'Chole Bhature',
    image: 'https://static.vecteezy.com/system/resources/previews/015/933/726/non_2x/chole-bhature-is-a-north-indian-food-dish-a-combination-of-chana-masala-and-bhatura-or-puri-free-photo.jpg',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 156,
    cooked: 750,
    baseServings: 4,
    ingredients: [
      { name: 'Chickpeas (soaked overnight)', amount: 1.5, unit: 'cups', alternatives: ['Canned Chickpeas (2 cans)', 'White Beans'] },
      { name: 'All-Purpose Flour (for bhature)', amount: 2, unit: 'cups', alternatives: ['Wheat Flour', 'Gluten-Free Flour Mix'] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: ['Buttermilk', 'Lemon Juice + Milk'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: ['Shallots (4-5)'] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: ['Canned Tomatoes (300g)'] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: ['Fresh Ginger & Garlic'] },
      { name: 'Chole Masala', amount: 2, unit: 'tablespoons', alternatives: ['Garam Masala + Cumin Powder'] },
      { name: 'Tea Bags', amount: 2, unit: 'pieces', alternatives: ['Black Tea Leaves (2 tsp)', 'Omit for lighter color'] },
      { name: 'Baking Powder', amount: 1, unit: 'teaspoon', alternatives: ['Baking Soda'] },
      { name: 'Oil (for frying)', amount: 1, unit: 'cup', alternatives: ['Ghee'] },
      { name: 'Salt', amount: 1.5, unit: 'teaspoons', alternatives: ['Sea Salt'] },
    ],
    steps: [
      'Pressure cook soaked chickpeas with tea bags, salt, and water for 4-5 whistles until soft.',
      'For bhature: Mix flour, yogurt, baking powder, salt, and water to form a soft dough. Rest for 2 hours.',
      'Heat oil in a pan, sauté onions until golden, add ginger-garlic paste.',
      'Add chopped tomatoes and cook until soft, then add chole masala and cook for 2 minutes.',
      'Add boiled chickpeas (without tea bags) to the masala and simmer for 15 minutes.',
      'Mash a few chickpeas to thicken the gravy.',
      'Divide bhature dough into balls, roll into circles.',
      'Deep fry bhature in hot oil until they puff up and turn golden.',
      'Serve hot chole with bhature, pickled onions, and green chutney.',
    ]
  },
  {
    id: 5,
    name: 'Samosa',
    image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/12/samosa-recipe.jpg',
    time: '40 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.5,
    reviews: 234,
    cooked: 1500,
    baseServings: 6,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: ['Wheat Flour', 'Pastry Sheets (store-bought)'] },
      { name: 'Potatoes', amount: 4, unit: 'medium', alternatives: ['Sweet Potatoes', 'Mixed Vegetables'] },
      { name: 'Green Peas', amount: 0.5, unit: 'cup', alternatives: ['Corn', 'Carrots (diced)'] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: ['Caraway Seeds', 'Fennel Seeds'] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: ['Ginger Powder (1 tsp)'] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: ['Red Chili Powder (1 tsp)'] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: ['Curry Powder'] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: ['Ground Cumin'] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: ['Oil', 'Butter'] },
      { name: 'Oil (for frying)', amount: 2, unit: 'cups', alternatives: ['Ghee'] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: ['Sea Salt'] },
    ],
    steps: [
      'Mix flour with 2 tbsp ghee and salt. Add water gradually to form a stiff dough. Rest for 30 minutes.',
      'Boil potatoes, peel and mash them coarsely.',
      'Heat oil, add cumin seeds, ginger, and green chilies. Sauté for 30 seconds.',
      'Add mashed potatoes, peas, garam masala, coriander powder, and salt. Mix well and cool.',
      'Divide dough into balls, roll into thin ovals, and cut in half.',
      'Form a cone with each half, fill with potato mixture, and seal the edges with water.',
      'Heat oil for deep frying.',
      'Fry samosas on medium heat until golden and crispy.',
      'Serve hot with mint chutney or tamarind sauce.',
    ]
  },
  {
    id: 6,
    name: 'Gulab Jamun',
    image: 'https://tse3.mm.bing.net/th/id/OIP.B32bansRI7RS3yfbUSEBNwHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '50 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 412,
    cooked: 1800,
    baseServings: 4,
    ingredients: [
      { name: 'Milk Powder', amount: 1, unit: 'cup', alternatives: ['Khoya/Mawa', 'Instant Gulab Jamun Mix'] },
      { name: 'All-Purpose Flour', amount: 3, unit: 'tablespoons', alternatives: ['Semolina'] },
      { name: 'Baking Soda', amount: 0.25, unit: 'teaspoon', alternatives: ['Baking Powder (1/2 tsp)'] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: ['Melted Butter'] },
      { name: 'Milk', amount: 0.25, unit: 'cup', alternatives: ['Water', 'Cream'] },
      { name: 'Sugar', amount: 1.5, unit: 'cups', alternatives: ['Jaggery', 'Honey (reduce quantity)'] },
      { name: 'Water (for syrup)', amount: 1.5, unit: 'cups', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: ['Rose Water (1 tsp)', 'Saffron'] },
      { name: 'Rose Water', amount: 1, unit: 'teaspoon', alternatives: ['Kewra Water', 'Vanilla Extract'] },
      { name: 'Oil (for frying)', amount: 2, unit: 'cups', alternatives: ['Ghee'] },
    ],
    steps: [
      'Make sugar syrup by boiling sugar and water until slightly sticky. Add cardamom powder and rose water. Keep warm.',
      'Mix milk powder, flour, and baking soda in a bowl.',
      'Add ghee and mix well until crumbly.',
      'Gradually add milk to form a soft, smooth dough (do not knead too much).',
      'Grease your palms and roll the dough into small, smooth balls (no cracks).',
      'Heat oil/ghee on medium-low heat for frying.',
      'Gently slide the balls into the oil and fry, stirring continuously, until deep golden brown.',
      'Remove and immediately place in warm sugar syrup.',
      'Let them soak for at least 2 hours before serving.',
    ]
  },
  {
    id: 7,
    name: 'Palak Paneer',
    image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2022/04/palak-paneer-recipe.jpg',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 198,
    cooked: 950,
    baseServings: 4,
    ingredients: [
      { name: 'Spinach (washed)', amount: 500, unit: 'grams', alternatives: ['Frozen Spinach', 'Mixed Greens'] },
      { name: 'Paneer (cubed)', amount: 250, unit: 'grams', alternatives: ['Tofu', 'Cottage Cheese'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: ['Shallots'] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: ['Tomato Puree'] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: ['Red Chili Powder'] },
      { name: 'Cream', amount: 3, unit: 'tablespoons', alternatives: ['Coconut Cream', 'Cashew Paste'] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: ['Ghee'] },
    ],
    steps: [
      'Blanch spinach in boiling water for 2 minutes, then transfer to ice water.',
      'Blend blanched spinach with green chilies into a smooth puree.',
      'Heat oil, add cumin seeds, then sauté onions until golden.',
      'Add ginger-garlic paste and tomatoes, cook until soft.',
      'Add spinach puree and cook for 5 minutes.',
      'Add paneer cubes, garam masala, and cream.',
      'Simmer for 5 minutes and serve hot with naan or rice.',
    ]
  },
  {
    id: 8,
    name: 'Butter Chicken',
    image: 'https://tse4.mm.bing.net/th/id/OIP.p6A2ne9Hl33Wf6ZwbmXeZAHaHb?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 567,
    cooked: 2800,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken (boneless)', amount: 750, unit: 'grams', alternatives: ['Chicken Thighs'] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: ['Buttermilk'] },
      { name: 'Tomato Puree', amount: 2, unit: 'cups', alternatives: ['Fresh Tomatoes'] },
      { name: 'Butter', amount: 4, unit: 'tablespoons', alternatives: ['Ghee'] },
      { name: 'Heavy Cream', amount: 0.5, unit: 'cup', alternatives: ['Coconut Cream'] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: ['Kashmiri Chili'] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'teaspoon', alternatives: ['Honey'] },
    ],
    steps: [
      'Marinate chicken with yogurt, half ginger-garlic paste, and salt for 30 minutes.',
      'Grill or pan-fry marinated chicken until cooked.',
      'In a pan, melt butter and sauté remaining ginger-garlic paste.',
      'Add tomato puree, chili powder, and cook for 10 minutes.',
      'Add sugar, cream, and garam masala.',
      'Add cooked chicken and simmer for 10 minutes.',
      'Crush kasuri methi and sprinkle on top. Serve with naan.',
    ]
  },
  {
    id: 9,
    name: 'Aloo Gobi',
    image: 'https://tse2.mm.bing.net/th/id/OIP.kKVGxIOrwkFS_Ta5QxxwFgHaLH?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.4,
    reviews: 156,
    cooked: 720,
    baseServings: 4,
    ingredients: [
      { name: 'Potatoes', amount: 3, unit: 'medium', alternatives: ['Sweet Potatoes'] },
      { name: 'Cauliflower', amount: 1, unit: 'small head', alternatives: ['Broccoli'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Turmeric Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Cut potatoes and cauliflower into bite-sized pieces.',
      'Heat oil, add cumin seeds, then sauté onions.',
      'Add ginger-garlic paste and tomatoes.',
      'Add turmeric, coriander powder, and salt.',
      'Add potatoes and cauliflower, mix well.',
      'Cover and cook on low heat until vegetables are tender.',
      'Sprinkle garam masala and serve hot.',
    ]
  },
  {
    id: 10,
    name: 'Rajma Masala',
    image: 'https://tse4.mm.bing.net/th/id/OIP.2jnlx3wNggCLMaPOIOp_vQHaJ4?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '40 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 234,
    cooked: 1100,
    baseServings: 4,
    ingredients: [
      { name: 'Kidney Beans (soaked)', amount: 1.5, unit: 'cups', alternatives: ['Canned Beans'] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: ['Tomato Puree'] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Bay Leaf', amount: 1, unit: 'piece', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Pressure cook soaked kidney beans with salt for 4-5 whistles.',
      'Heat oil, add bay leaf and cumin seeds.',
      'Sauté onions until golden brown.',
      'Add ginger-garlic paste and cook for 2 minutes.',
      'Add tomatoes and all spices, cook until oil separates.',
      'Add cooked rajma with water, simmer for 15 minutes.',
      'Mash some beans to thicken gravy. Garnish with coriander.',
    ]
  },
  {
    id: 11,
    name: 'Sambar',
    image: 'https://tse4.mm.bing.net/th/id/OIP.tqqKblY4Vy7zGw-WgIYpyQHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 189,
    cooked: 890,
    baseServings: 6,
    ingredients: [
      { name: 'Toor Dal', amount: 1, unit: 'cup', alternatives: ['Mixed Lentils'] },
      { name: 'Mixed Vegetables', amount: 2, unit: 'cups', alternatives: ['Drumsticks', 'Carrots'] },
      { name: 'Tamarind', amount: 1, unit: 'small ball', alternatives: ['Tamarind Paste'] },
      { name: 'Sambar Powder', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Onions', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Pressure cook dal with turmeric until soft.',
      'Extract tamarind juice in warm water.',
      'Boil vegetables with sambar powder and tamarind water.',
      'Add cooked dal and simmer for 10 minutes.',
      'Heat oil, add mustard seeds, curry leaves, and asafoetida.',
      'Pour tempering over sambar and mix well.',
      'Serve hot with rice, dosa, or idli.',
    ]
  },
  {
    id: 12,
    name: 'Pav Bhaji',
    image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400',
    time: '40 mins',
    difficulty: 'Easy',
    region: 'West Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 345,
    cooked: 1650,
    baseServings: 4,
    ingredients: [
      { name: 'Potatoes', amount: 4, unit: 'medium', alternatives: [] },
      { name: 'Mixed Vegetables', amount: 2, unit: 'cups', alternatives: ['Peas', 'Cauliflower'] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Capsicum', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Pav Bhaji Masala', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Butter', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Pav Buns', amount: 8, unit: 'pieces', alternatives: ['Bread Rolls'] },
    ],
    steps: [
      'Boil and mash all vegetables together.',
      'Heat butter, sauté onions until translucent.',
      'Add capsicum and tomatoes, cook until soft.',
      'Add pav bhaji masala, chili powder, and salt.',
      'Add mashed vegetables and mix well, mashing with masher.',
      'Add water to adjust consistency, simmer for 10 minutes.',
      'Toast pav buns with butter.',
      'Serve bhaji hot with pav, onions, and lemon.',
    ]
  },
  {
    id: 13,
    name: 'Hyderabadi Haleem',
    image: 'https://recipes.timesofindia.com/thumb/54672891.cms?imgsize=226897&width=800&height=800',
    time: '120 mins',
    difficulty: 'Hard',
    region: 'Hyderabadi',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 289,
    cooked: 980,
    baseServings: 6,
    ingredients: [
      { name: 'Mutton (boneless)', amount: 500, unit: 'grams', alternatives: ['Chicken'] },
      { name: 'Mixed Lentils', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Wheat (broken)', amount: 0.5, unit: 'cup', alternatives: ['Daliya'] },
      { name: 'Onions (fried)', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Whole Spices', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Fresh Mint', amount: 0.5, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Pressure cook mutton with ginger-garlic paste and spices until very tender.',
      'Cook lentils and wheat separately until completely soft.',
      'Mash and mix mutton, lentils, and wheat together.',
      'Heat ghee, add half the fried onions and cook the mixture.',
      'Continuously stir and mash for 30-40 minutes until smooth.',
      'Adjust consistency with water.',
      'Garnish with remaining fried onions, mint, lemon, and ginger.',
    ]
  },
  {
    id: 14,
    name: 'Fish Curry (Bengali Style)',
    image: 'https://th.bing.com/th/id/OIP.srxkhYIWxEQqdWo4w2halwHaEK?o=7&cb=12rm=3&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '35 mins',
    difficulty: 'Medium',
    region: 'Bengali',
    diet: 'Non-Vegetarian',
    rating: 4.7,
    reviews: 178,
    cooked: 650,
    baseServings: 4,
    ingredients: [
      { name: 'Fish (Rohu/Katla)', amount: 500, unit: 'grams', alternatives: ['Any Firm Fish'] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Turmeric Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Mustard Oil', amount: 3, unit: 'tablespoons', alternatives: ['Any Cooking Oil'] },
      { name: 'Nigella Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
    ],
    steps: [
      'Marinate fish with turmeric and salt for 15 minutes.',
      'Lightly fry fish pieces in mustard oil and set aside.',
      'In the same oil, add nigella seeds and sliced onions.',
      'Add ginger paste, tomatoes, and all spices.',
      'Cook until oil separates from the masala.',
      'Add water and bring to boil.',
      'Gently add fish pieces and simmer for 10 minutes.',
      'Garnish with green chilies and serve with rice.',
    ]
  },
  {
    id: 15,
    name: 'Dhokla',
    image: 'https://www.cookwithnabeela.com/wp-content/uploads/2024/02/KhamanDhokla1.webp',
    time: '30 mins',
    difficulty: 'Medium',
    region: 'Gujarati',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 234,
    cooked: 890,
    baseServings: 4,
    ingredients: [
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: ['Besan'] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: ['Buttermilk'] },
      { name: 'Eno (Fruit Salt)', amount: 1, unit: 'teaspoon', alternatives: ['Baking Soda'] },
      { name: 'Ginger-Green Chili Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 8, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix gram flour, yogurt, ginger-chili paste, sugar, turmeric, and salt.',
      'Add water to make a smooth batter.',
      'Just before steaming, add eno and mix gently.',
      'Pour into greased steaming tray and steam for 15 minutes.',
      'Let cool, then cut into pieces.',
      'Heat oil, add mustard seeds, curry leaves, and chilies.',
      'Pour tempering over dhokla pieces.',
      'Garnish with coriander and coconut, serve with chutney.',
    ]
  },
  {
    id: 16,
    name: 'Rogan Josh',
    image: 'https://recipes.timesofindia.com/photo/53192600.cms',
    time: '90 mins',
    difficulty: 'Hard',
    region: 'Kashmiri',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 267,
    cooked: 780,
    baseServings: 4,
    ingredients: [
      { name: 'Mutton', amount: 750, unit: 'grams', alternatives: ['Lamb'] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 3, unit: 'large', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 2, unit: 'teaspoons', alternatives: ['Paprika'] },
      { name: 'Fennel Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ginger Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cardamom', amount: 4, unit: 'pieces', alternatives: [] },
      { name: 'Bay Leaves', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat ghee, add whole spices and sauté.',
      'Add sliced onions and cook until deep brown.',
      'Add ginger-garlic paste and cook for 2 minutes.',
      'Add mutton pieces and sear on high heat.',
      'Add yogurt, all powdered spices, and salt.',
      'Cover and cook on low heat for 60-75 minutes until tender.',
      'Adjust gravy consistency and simmer.',
      'Garnish with ginger julienne and serve with naan or rice.',
    ]
  },
  {
    id: 17,
    name: 'Idli',
    image: 'https://recipes.timesofindia.com/thumb/53239358.cms?imgsize=176260&width=800&height=800',
    time: '20 mins + fermentation',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 423,
    cooked: 2100,
    baseServings: 4,
    ingredients: [
      { name: 'Idli Rice', amount: 2, unit: 'cups', alternatives: ['Regular Rice'] },
      { name: 'Urad Dal', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Fenugreek Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Water', amount: 1, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Soak rice and dal separately with fenugreek for 4-6 hours.',
      'Grind dal first into fluffy batter.',
      'Grind rice into slightly coarse batter.',
      'Mix both batters with salt and ferment for 8-12 hours.',
      'Grease idli molds and pour batter.',
      'Steam for 10-12 minutes until cooked.',
      'Serve hot with sambar and chutney.',
    ]
  },
  {
    id: 18,
    name: 'Vada Pav',
    image: 'https://tse1.mm.bing.net/th/id/OIP.UoMdRCrgOp_sn0N1o9T35wHaLG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '35 mins',
    difficulty: 'Medium',
    region: 'West Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 312,
    cooked: 1450,
    baseServings: 4,
    ingredients: [
      { name: 'Potatoes', amount: 4, unit: 'medium', alternatives: [] },
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: ['Besan'] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 8, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Garlic Cloves', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Pav Buns', amount: 4, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Boil and mash potatoes with salt.',
      'Heat oil, add mustard, curry leaves, chilies, and garlic.',
      'Add turmeric and chili powder, then mix with mashed potatoes.',
      'Make potato balls and set aside.',
      'Make batter with gram flour, turmeric, salt, and water.',
      'Dip potato balls in batter and deep fry until golden.',
      'Slit pav buns and toast with butter.',
      'Place vada in pav with chutney and serve hot.',
    ]
  },
  {
    id: 19,
    name: 'Mysore Pak',
    image: 'https://images.herzindagi.info/image/2019/Apr/mysore-pak-image.jpg',
    time: '40 mins',
    difficulty: 'Hard',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 189,
    cooked: 560,
    baseServings: 6,
    ingredients: [
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: ['Besan'] },
      { name: 'Sugar', amount: 1.5, unit: 'cups', alternatives: [] },
      { name: 'Ghee', amount: 1.5, unit: 'cups', alternatives: [] },
      { name: 'Water', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Roast gram flour in 2 tbsp ghee until aromatic.',
      'Make sugar syrup with water to one-string consistency.',
      'Add roasted gram flour to syrup and mix quickly.',
      'Keep adding ghee gradually while stirring continuously.',
      'Cook until mixture becomes glossy and leaves sides.',
      'Add cardamom powder.',
      'Pour into greased tray and cut into pieces when warm.',
    ]
  },
  {
    id: 20,
    name: 'Tandoori Chicken',
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?w=400',
    time: '45 mins + marination',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken (with bone)', amount: 750, unit: 'grams', alternatives: [] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Tandoori Masala', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: ['Kashmiri Chili'] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Mustard Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chaat Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Food Color (red)', amount: 0.25, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Make deep cuts in chicken pieces.',
      'Mix all marinade ingredients with yogurt.',
      'Coat chicken thoroughly and marinate for 4-6 hours.',
      'Preheat oven to 220°C or use tandoor.',
      'Place chicken on skewers or baking tray.',
      'Cook for 25-30 minutes, basting with butter.',
      'Turn pieces halfway through cooking.',
      'Serve hot with mint chutney and onion rings.',
    ]
  },
  {
    id: 21,
    name: 'Pani Puri',
    image: 'https://tse3.mm.bing.net/th/id/OIP.purgjJxr2zpGEnhekm6TFgHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'Street Food',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 389,
    cooked: 1670,
    baseServings: 4,
    ingredients: [
      { name: 'Pani Puri', amount: 40, unit: 'pieces', alternatives: ['Store-bought puris'] },
      { name: 'Boiled Chickpeas', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Boiled Potatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Mint Leaves', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small ball', alternatives: ['Tamarind Chutney'] },
      { name: 'Chaat Masala', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Black Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Blend mint, coriander, green chilies with water for pani.',
      'Add tamarind water, chaat masala, black salt, cumin.',
      'Strain and chill the pani.',
      'Mash boiled potatoes lightly, mix with chickpeas.',
      'Make a hole in each puri.',
      'Fill with potato-chickpea mixture.',
      'Fill with spicy pani and eat immediately.',
    ]
  },
  {
    id: 22,
    name: 'Dum Aloo',
    image: 'https://tse2.mm.bing.net/th/id/OIP.sRp0b-Pu4snNSbgWnWdRzAHaGx?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '50 mins',
    difficulty: 'Medium',
    region: 'Kashmiri',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 198,
    cooked: 750,
    baseServings: 4,
    ingredients: [
      { name: 'Baby Potatoes', amount: 500, unit: 'grams', alternatives: ['Regular Potatoes'] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onion Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Fennel Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ginger Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Bay Leaves', amount: 2, unit: 'pieces', alternatives: [] },
    ],
    steps: [
      'Boil potatoes, peel and prick with fork.',
      'Shallow fry potatoes until golden.',
      'Heat ghee, add bay leaves and onion paste.',
      'Add ginger-garlic paste and all spices.',
      'Whisk yogurt and add to the mixture.',
      'Add fried potatoes and coat with gravy.',
      'Cover and cook on low heat (dum) for 15 minutes.',
      'Garnish with ginger julienne and serve.',
    ]
  },
  {
    id: 23,
    name: 'Masala Dosa',
    image: 'https://tse3.mm.bing.net/th/id/OIP.XSCo5S6kP3o-7-jVqH4vGgHaE8?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins + fermentation',
    difficulty: 'Medium',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.8,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Dosa Batter', amount: 3, unit: 'cups', alternatives: ['Rice & Urad Dal Batter'] },
      { name: 'Potatoes (boiled)', amount: 4, unit: 'medium', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Oil', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Make potato masala: heat oil, add mustard and curry leaves.',
      'Add onions, ginger, chilies, cook until soft.',
      'Add turmeric, mashed potatoes, and salt.',
      'Heat tawa, spread dosa batter thin and circular.',
      'Drizzle oil around edges and cook until crispy.',
      'Place potato masala in center and fold dosa.',
      'Serve hot with sambar and coconut chutney.',
    ]
  },
  {
    id: 24,
    name: 'Chole Bhature',
    image: 'https://static.vecteezy.com/system/resources/previews/015/933/726/non_2x/chole-bhature-is-a-north-indian-food-dish-a-combination-of-chana-masala-and-bhatura-or-puri-free-photo.jpg',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 678,
    cooked: 2890,
    baseServings: 4,
    ingredients: [
      { name: 'Chickpeas (soaked)', amount: 2, unit: 'cups', alternatives: ['Canned Chickpeas'] },
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Chole Masala', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Tea Bags', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Baking Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Pressure cook chickpeas with tea bags for color.',
      'Make bhature dough with flour, yogurt, baking powder.',
      'Rest dough for 2 hours.',
      'Make chole: sauté onions, add ginger-garlic paste.',
      'Add tomatoes, chole masala, cook until oil separates.',
      'Add chickpeas, simmer for 15 minutes.',
      'Roll bhature and deep fry until puffed.',
      'Serve hot chole with bhature.',
    ]
  },
  {
    id: 25,
    name: 'Medu Vada',
    image: 'https://tse4.mm.bing.net/th/id/OIP.AeU2YlpCsr2KL669w0SyJwHaKe?cb=12&w=1587&h=2245&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Medium',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 234,
    cooked: 1120,
    baseServings: 4,
    ingredients: [
      { name: 'Urad Dal', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Black Pepper', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Onions (chopped)', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Soak urad dal for 4 hours, drain well.',
      'Grind to fluffy, thick batter without water.',
      'Add chilies, ginger, curry leaves, spices.',
      'Mix well, batter should be thick.',
      'Wet hands, make donut shapes with hole.',
      'Deep fry in hot oil until golden.',
      'Serve hot with sambar and chutney.',
    ]
  },
  {
    id: 44,
    name: 'Chicken Tikka',
    image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400',
    time: '40 mins + marination',
    difficulty: 'Easy',
    region: 'Punjabi',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken (boneless)', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Hung Curd', amount: 0.5, unit: 'cup', alternatives: ['Greek Yogurt'] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Mustard Oil', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Chaat Masala', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Cut chicken into bite-sized cubes.',
      'Mix all marinade ingredients with yogurt.',
      'Marinate chicken for 2-4 hours.',
      'Thread chicken on skewers.',
      'Grill in oven at 200°C for 20 minutes.',
      'Baste with butter halfway through.',
      'Garnish with chaat masala and serve.',
    ]
  },
  {
    id: 26,
    name: 'Poha',
    image: 'https://tse3.mm.bing.net/th/id/OIP.7COAqQSB_p6pxTIpIvtV2QHaLH?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'West Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 345,
    cooked: 1560,
    baseServings: 4,
    ingredients: [
      { name: 'Poha (flattened rice)', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Onions', amount: 1, unit: 'large', alternatives: [] },
      { name: 'Potatoes', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Peanuts', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 8, unit: 'leaves', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Rinse poha gently, drain and set aside.',
      'Heat oil, add mustard seeds, curry leaves.',
      'Add peanuts, fry until golden.',
      'Add onions, chilies, cook until soft.',
      'Add diced potatoes, turmeric, cook covered.',
      'Add poha, salt, mix gently.',
      'Add lemon juice, garnish with coriander.',
    ]
  },
  {
    id: 27,
    name: 'Malai Kofta',
    image: 'https://tse2.mm.bing.net/th/id/OIP.Q9Au0pSwH8dBYHEpXmfO6gHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '60 mins',
    difficulty: 'Hard',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (grated)', amount: 250, unit: 'grams', alternatives: [] },
      { name: 'Potatoes (boiled)', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Raisins', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix paneer, mashed potatoes, cornflour, salt.',
      'Make small balls with cashew-raisin stuffing.',
      'Deep fry koftas until golden, set aside.',
      'Make gravy: blend onions and tomatoes.',
      'Cook gravy with spices until oil separates.',
      'Add cream and simmer.',
      'Add koftas just before serving.',
    ]
  },
  {
    id: 28,
    name: 'Upma',
    image: 'https://d36v5spmfzyapc.cloudfront.net/wp-content/uploads/2021/02/Veg-Upma-2.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.4,
    reviews: 234,
    cooked: 980,
    baseServings: 4,
    ingredients: [
      { name: 'Rava (Semolina)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Mixed Vegetables', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chana Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Dry roast rava until aromatic.',
      'Heat oil, add mustard, dals, curry leaves.',
      'Add onions, ginger, chilies, sauté.',
      'Add vegetables, cook for 3 minutes.',
      'Add 2.5 cups hot water, bring to boil.',
      'Slowly add rava while stirring.',
      'Cook covered on low heat for 5 minutes.',
    ]
  },
  {
    id: 29,
    name: 'Keema',
    image: 'https://tse4.mm.bing.net/th/id/OIP.uwiBbT0ndPEH-rrEgsrBYAHaJ4?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Non-Vegetarian',
    rating: 4.7,
    reviews: 345,
    cooked: 1450,
    baseServings: 4,
    ingredients: [
      { name: 'Minced Meat', amount: 500, unit: 'grams', alternatives: ['Mutton/Chicken'] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Green Peas', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Bay Leaves', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add bay leaves and onions.',
      'Cook onions until golden brown.',
      'Add ginger-garlic paste, cook for 2 minutes.',
      'Add minced meat, cook on high heat.',
      'Add tomatoes and all spices.',
      'Add peas and water, simmer for 20 minutes.',
      'Garnish with coriander and ginger.',
    ]
  },
  {
    id: 30,
    name: 'Pesarattu',
    image: 'https://tse1.explicit.bing.net/th/id/OIP.4Ydu4mI2owu1Y9mtIEAiZQHaLG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '20 mins + soaking',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 189,
    cooked: 760,
    baseServings: 4,
    ingredients: [
      { name: 'Green Gram (Moong Dal)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Rice', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Onions (chopped)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Curry Leaves', amount: 8, unit: 'leaves', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Soak moong dal and rice for 4 hours.',
      'Grind to smooth batter with chilies, ginger.',
      'Add cumin, salt, asafoetida.',
      'Heat tawa, spread batter thin.',
      'Sprinkle onions and curry leaves on top.',
      'Drizzle oil, cook until crispy.',
      'Serve hot with ginger chutney.',
    ]
  },
  {
    id: 31,
    name: 'Paneer Tikka',
    image: 'https://www.indianveggiedelight.com/wp-content/uploads/2021/08/air-fryer-paneer-tikka-featured.jpg',
    time: '35 mins + marination',
    difficulty: 'Easy',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (cubed)', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Bell Peppers', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Hung Curd', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chaat Masala', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix yogurt with all spices and lemon juice.',
      'Marinate paneer cubes for 30 minutes.',
      'Cut vegetables into cubes.',
      'Thread paneer and vegetables on skewers.',
      'Grill or bake at 200°C for 20 minutes.',
      'Brush with oil and flip halfway.',
      'Sprinkle chaat masala and serve hot.',
    ]
  },
  {
    id: 32,
    name: 'Dal Makhani',
    image: 'https://tse1.mm.bing.net/th/id/OIP.cwFK6CnTHRYA0mXsvAwD5QHaLO?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '120 mins',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 789,
    cooked: 3240,
    baseServings: 6,
    ingredients: [
      { name: 'Black Urad Dal', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Rajma (Kidney Beans)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Butter', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Tomato Puree', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Soak dal and rajma overnight.',
      'Pressure cook with salt for 6-7 whistles.',
      'Melt butter, add ginger-garlic paste.',
      'Add tomato puree and spices, cook well.',
      'Add cooked dal, simmer on low for 45 mins.',
      'Stir occasionally, add water as needed.',
      'Add cream and kasuri methi before serving.',
    ]
  },
  {
    id: 33,
    name: 'Bhindi Masala',
    image: 'https://smithakalluraya.com/wp-content/uploads/2019/04/bhindi-masala.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 234,
    cooked: 980,
    baseServings: 4,
    ingredients: [
      { name: 'Okra (Bhindi)', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Amchur Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Wash and dry okra completely.',
      'Cut into 1-inch pieces.',
      'Heat oil, add cumin seeds.',
      'Add okra, fry on medium heat until crisp.',
      'Add onions, cook until golden.',
      'Add ginger-garlic paste, tomatoes, spices.',
      'Cook covered for 10 minutes.',
      'Add amchur powder and serve.',
    ]
  },
  {
    id: 34,
    name: 'Aloo Paratha',
    image: 'https://www.whiskaffair.com/wp-content/uploads/2020/06/Aloo-Paratha-2-3.jpg',
    time: '40 mins',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 890,
    cooked: 3890,
    baseServings: 4,
    ingredients: [
      { name: 'Whole Wheat Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Potatoes (boiled)', amount: 4, unit: 'medium', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Amchur Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Make dough with wheat flour and water.',
      'Mash potatoes with spices, chilies, coriander.',
      'Roll small dough ball, place potato filling.',
      'Seal and roll into flat circle.',
      'Cook on hot tawa, apply ghee.',
      'Flip and cook until golden spots appear.',
      'Serve hot with yogurt and pickle.',
    ]
  },
  {
    id: 35,
    name: 'Rasam',
    image: 'https://tse4.mm.bing.net/th/id/OIP.PS2y-c0HckBbWwnShvQ98QHaFj?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 345,
    cooked: 1450,
    baseServings: 6,
    ingredients: [
      { name: 'Toor Dal (cooked)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small ball', alternatives: [] },
      { name: 'Rasam Powder', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Jaggery', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 1, unit: 'tablespoon', alternatives: [] },
    ],
    steps: [
      'Extract tamarind juice in warm water.',
      'Blend tomatoes, add to tamarind water.',
      'Add rasam powder, jaggery, salt.',
      'Add cooked dal water, bring to boil.',
      'Simmer for 10 minutes.',
      'Heat oil, add mustard, curry leaves, asafoetida.',
      'Pour tempering over rasam.',
      'Garnish with coriander, serve hot.',
    ]
  },
  {
    id: 36,
    name: 'Kadhi Pakora',
    image: 'https://tse4.mm.bing.net/th/id/OIP.LfsOyYxqdwkkzDQ_ZksJsgHaLH?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Yogurt', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Onions (for pakora)', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Fenugreek Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Make pakora batter with half gram flour, onions, spices.',
      'Deep fry small pakoras, set aside.',
      'Mix yogurt with remaining gram flour, turmeric, water.',
      'Bring to boil while stirring continuously.',
      'Simmer on low heat for 20 minutes.',
      'Heat oil, add cumin, fenugreek, curry leaves, asafoetida.',
      'Pour tempering into kadhi.',
      'Add pakoras just before serving.',
    ]
  },
  {
    id: 37,
    name: 'Rava Kesari',
    image: 'https://tse1.mm.bing.net/th/id/OIP.4p0hDZDQcPszmVqPVYcMxQHaIG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 234,
    cooked: 890,
    baseServings: 6,
    ingredients: [
      { name: 'Semolina (Rava)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Raisins', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Food Color (orange)', amount: 0.25, unit: 'teaspoon', alternatives: ['Saffron'] },
      { name: 'Milk', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Water', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Heat ghee, fry cashews and raisins.',
      'Add rava, roast until aromatic.',
      'Boil water with food color.',
      'Add hot water to rava, stir quickly.',
      'Cook covered on low heat for 5 minutes.',
      'Add sugar, mix well.',
      'Add cardamom powder and milk.',
      'Garnish with fried nuts and serve warm.',
    ]
  },
  {
    id: 38,
    name: 'Chicken Curry',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '50 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 678,
    cooked: 2890,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken', amount: 750, unit: 'grams', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Coriander Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Cumin Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add sliced onions.',
      'Cook until golden brown.',
      'Add ginger-garlic paste, cook for 2 minutes.',
      'Add chicken pieces, sear on high heat.',
      'Add tomatoes and all spices.',
      'Add water, cover and simmer for 30 minutes.',
      'Garnish with coriander and serve.',
    ]
  },
  {
    id: 39,
    name: 'Litti Chokha',
    image: 'https://tse1.mm.bing.net/th/id/OIP.lM9hEe5whiScIRuQNl6engHaIN?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '60 mins',
    difficulty: 'Hard',
    region: 'Bihar',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 234,
    cooked: 670,
    baseServings: 4,
    ingredients: [
      { name: 'Whole Wheat Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Sattu (Roasted Gram Flour)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Brinjal', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Potatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Mustard Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Carom Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Make dough with wheat flour, carom seeds.',
      'Mix sattu with spices, mustard oil, water.',
      'Make balls from dough, stuff with sattu mixture.',
      'Bake in oven or roast directly on flame.',
      'Roast brinjal, tomatoes, potatoes until charred.',
      'Mash vegetables with mustard oil, chilies.',
      'Serve hot litti with chokha and ghee.',
    ]
  },
  {
    id: 40,
    name: 'Baingan Bharta',
    image: 'https://tse1.mm.bing.net/th/id/OIP.XGoRwvGfssrhw9pTQH6r0QHaLO?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 345,
    cooked: 1450,
    baseServings: 4,
    ingredients: [
      { name: 'Brinjal (large)', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Roast brinjal directly on flame until charred.',
      'Peel skin and mash the pulp.',
      'Heat oil, add cumin seeds.',
      'Add onions, cook until golden.',
      'Add ginger-garlic paste, chilies, tomatoes.',
      'Add spices and mashed brinjal.',
      'Cook for 10 minutes.',
      'Garnish with coriander and serve.',
    ]
  },
  {
    id: 41,
    name: 'Pongal',
    image: 'https://i.pinimg.com/originals/1e/45/2e/1e452eb95555db02bd494d872b5eaef6.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.5,
    reviews: 234,
    cooked: 890,
    baseServings: 4,
    ingredients: [
      { name: 'Rice', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Moong Dal', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Black Pepper', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Dry roast moong dal until aromatic.',
      'Pressure cook rice and dal with 4 cups water.',
      'Heat ghee, fry cashews.',
      'Add cumin, pepper, ginger, curry leaves.',
      'Add asafoetida and pour tempering over pongal.',
      'Mix well and serve hot.',
    ]
  },
  {
    id: 42,
    name: 'Egg Curry',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Non-Vegetarian',
    rating: 4.6,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Eggs (boiled)', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add sliced onions.',
      'Cook until golden brown.',
      'Add ginger-garlic paste, cook for 2 minutes.',
      'Add tomatoes and all spices.',
      'Cook until oil separates.',
      'Add water and bring to boil.',
      'Add halved boiled eggs.',
      'Simmer for 10 minutes and serve.',
    ]
  },
  {
    id: 43,
    name: 'Khichdi',
    image: 'https://tse2.mm.bing.net/th/id/OIP.iZq3IEJSpRVvU0klAQA0SgHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.5,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Rice', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Moong Dal', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Mixed Vegetables', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Heat ghee, add cumin seeds and asafoetida.',
      'Add ginger, chilies, sauté.',
      'Add rice, dal, vegetables.',
      'Add turmeric, salt, 4 cups water.',
      'Pressure cook for 3 whistles.',
      'Serve hot with yogurt and papad.',
    ]
  },
  {
    id: 45,
    name: 'Mutton Biryani',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400',
    time: '120 mins',
    difficulty: 'Hard',
    region: 'Hyderabadi',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 890,
    cooked: 3450,
    baseServings: 6,
    ingredients: [
      { name: 'Mutton', amount: 1, unit: 'kg', alternatives: [] },
      { name: 'Basmati Rice', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions (fried)', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Whole Spices', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Saffron', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Mint Leaves', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 0.5, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Marinate mutton with yogurt, spices for 1 hour.',
      'Cook mutton with fried onions until tender.',
      'Boil rice until 70% cooked.',
      'Layer rice over mutton in pot.',
      'Add saffron milk, mint, coriander, ghee.',
      'Cover and cook on dum for 30 minutes.',
      'Serve hot with raita.',
    ]
  },
  {
    id: 121,
    name: 'Mirchi Ka Salan',
    image: 'https://tse1.mm.bing.net/th/id/OIP.PMbCiTZAw5VteRXoMkK1zQHaJ4?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '40 mins',
    difficulty: 'Medium',
    region: 'Hyderabadi',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 234,
    cooked: 670,
    baseServings: 4,
    ingredients: [
      { name: 'Green Chilies (long)', amount: 12, unit: 'pieces', alternatives: [] },
      { name: 'Peanuts', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Sesame Seeds', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Coconut (grated)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small ball', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Slit green chilies lengthwise.',
      'Roast peanuts, sesame, coconut, grind to paste.',
      'Fry chilies in oil until slightly cooked.',
      'In same oil, fry onions until brown.',
      'Add ginger-garlic paste, turmeric.',
      'Add ground paste, tamarind water.',
      'Add chilies, simmer for 15 minutes.',
      'Serve with biryani or rice.',
    ]
  },
  {
    id: 122,
    name: 'Thepla',
    image: 'https://tse2.mm.bing.net/th/id/OIP.mLPze5nnmiRJ9culplB2rAHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'Gujarati',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Whole Wheat Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Gram Flour', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Fenugreek Leaves', amount: 1, unit: 'cup', alternatives: ['Methi Leaves'] },
      { name: 'Yogurt', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Sesame Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mix all flours, fenugreek leaves, spices.',
      'Add yogurt and knead into soft dough.',
      'Rest dough for 15 minutes.',
      'Roll into thin circles.',
      'Cook on hot tawa with oil until brown spots.',
      'Serve with pickle and yogurt.',
    ]
  },
  {
    id: 123,
    name: 'Prawn Curry',
    image: 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400',
    time: '35 mins',
    difficulty: 'Medium',
    region: 'Coastal',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 345,
    cooked: 1230,
    baseServings: 4,
    ingredients: [
      { name: 'Prawns (cleaned)', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Coconut Milk', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add curry leaves and onions.',
      'Add ginger-garlic paste, cook for 2 minutes.',
      'Add tomatoes and all spices.',
      'Cook until oil separates.',
      'Add prawns, cook for 5 minutes.',
      'Add coconut milk, simmer for 10 minutes.',
      'Garnish with coriander and serve.',
    ]
  },
  {
    id: 124,
    name: 'Matar Paneer',
    image: 'https://tse2.mm.bing.net/th/id/OIP.TF4t3JnZQtP8RtPd8oQmywHaLG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (cubed)', amount: 250, unit: 'grams', alternatives: [] },
      { name: 'Green Peas', amount: 1.5, unit: 'cups', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Cream', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, sauté onions until golden.',
      'Add ginger-garlic paste, cook for 2 minutes.',
      'Add tomatoes and spices, cook until soft.',
      'Blend the gravy until smooth.',
      'Add peas and cook for 5 minutes.',
      'Add paneer cubes and cream.',
      'Simmer for 5 minutes and serve.',
    ]
  },
  {
    id: 48,
    name: 'Appam',
    image: 'https://tse1.mm.bing.net/th/id/OIP.ker83kSqIy9p6BXVobaeawHaFE?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins + fermentation',
    difficulty: 'Medium',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 234,
    cooked: 890,
    baseServings: 4,
    ingredients: [
      { name: 'Rice', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Coconut (grated)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Yeast', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Water', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Soak rice for 4 hours.',
      'Grind rice and coconut into smooth batter.',
      'Add yeast and sugar, ferment for 8 hours.',
      'Add salt and water to adjust consistency.',
      'Heat appam pan, pour batter and swirl.',
      'Cover and cook until edges are crispy.',
      'Serve with vegetable stew or coconut milk.',
    ]
  },
  {
    id: 49,
    name: 'Pav',
    image: 'https://rumkisgoldenspoon.com/wp-content/uploads/2021/06/Ladi-pav-recipe.jpg',
    time: '90 mins',
    difficulty: 'Medium',
    region: 'West Indian',
    diet: 'Vegetarian',
    rating: 4.5,
    reviews: 345,
    cooked: 1230,
    baseServings: 8,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Milk (warm)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Yeast', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Sugar', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Butter', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Activate yeast in warm milk with sugar.',
      'Mix flour, salt, butter.',
      'Add yeast mixture, knead into soft dough.',
      'Let rise for 1 hour until doubled.',
      'Punch down, divide into 8 portions.',
      'Shape into balls, place in greased pan.',
      'Let rise for 30 minutes.',
      'Bake at 180°C for 20 minutes until golden.',
    ]
  },
  {
    id: 50,
    name: 'Kofta Curry',
    image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2022/06/malai-kofta-recipe.webp',
    time: '55 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 456,
    cooked: 1670,
    baseServings: 4,
    ingredients: [
      { name: 'Mixed Vegetables (grated)', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Gram Flour', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Bread Crumbs', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Cashew Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Cream', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix grated vegetables with gram flour, bread crumbs.',
      'Make small balls and deep fry.',
      'Blend onions and tomatoes.',
      'Cook gravy with cashew paste and spices.',
      'Add cream and simmer.',
      'Add koftas just before serving.',
    ]
  },
  {
    id: 51,
    name: 'Puttu',
    image: 'https://i.pinimg.com/originals/21/8b/71/218b71c56dcbf994863fc7d5882aff7d.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'Kerala',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 234,
    cooked: 780,
    baseServings: 4,
    ingredients: [
      { name: 'Rice Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Coconut (grated)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Water', amount: 0.75, unit: 'cup', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mix rice flour with water and salt.',
      'The mixture should be like breadcrumbs.',
      'Layer coconut and rice mixture in puttu maker.',
      'Steam for 8-10 minutes.',
      'Serve hot with kadala curry or banana.',
    ]
  },
  {
    id: 52,
    name: 'Vegetable Pulao',
    image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2013/03/vegetable-pulao.jpg',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Basmati Rice', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Mixed Vegetables', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Onions', amount: 1, unit: 'large', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Whole Spices', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Mint Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Bay Leaves', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Soak rice for 20 minutes.',
      'Heat ghee, add whole spices and bay leaves.',
      'Add onions, cook until golden.',
      'Add ginger-garlic paste, chilies.',
      'Add vegetables, sauté for 3 minutes.',
      'Add rice, water (1:2 ratio), salt.',
      'Cover and cook on low heat for 15 minutes.',
      'Garnish with mint and serve.',
    ]
  },
  {
    id: 53,
    name: 'Bombil Fry',
    image: 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'Coastal',
    diet: 'Non-Vegetarian',
    rating: 4.7,
    reviews: 234,
    cooked: 670,
    baseServings: 4,
    ingredients: [
      { name: 'Bombay Duck Fish', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Rice Flour', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Clean fish and pat dry.',
      'Marinate with spices, garlic, lemon for 15 mins.',
      'Coat fish with rice flour.',
      'Heat oil for deep frying.',
      'Fry fish until golden and crispy.',
      'Drain on paper towels.',
      'Serve hot with lemon wedges.',
    ]
  },
  {
    id: 54,
    name: 'Aloo Tikki',
    image: 'https://cdn.cdnparenting.com/articles/2020/01/26120549/Aloo-tikki-recipe.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Potatoes (boiled)', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Bread Crumbs', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cornflour', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Amchur Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mash potatoes with all spices.',
      'Add cornflour, coriander, chilies.',
      'Shape into flat round patties.',
      'Coat with bread crumbs.',
      'Shallow fry until golden on both sides.',
      'Serve hot with mint chutney.',
    ]
  },
  {
    id: 55,
    name: 'Kadai Chicken',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 678,
    cooked: 2670,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken', amount: 750, unit: 'grams', alternatives: [] },
      { name: 'Bell Peppers', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Coriander Seeds (crushed)', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add crushed coriander seeds.',
      'Add onions, cook until golden.',
      'Add ginger-garlic paste, tomatoes.',
      'Add chicken pieces and all spices.',
      'Cook covered until chicken is done.',
      'Add bell peppers, cook for 5 minutes.',
      'Garnish with kasuri methi and serve.',
    ]
  },
  {
    id: 56,
    name: 'Parotta',
    image: 'https://tse1.mm.bing.net/th/id/OIP.lLJ9tJeHAsgrzSL4VahxOgHaE7?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '90 mins',
    difficulty: 'Hard',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 456,
    cooked: 1560,
    baseServings: 4,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Milk', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Egg', amount: 1, unit: 'piece', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mix flour, milk, egg, sugar, salt into dough.',
      'Rest for 30 minutes.',
      'Divide into balls, coat with oil.',
      'Roll very thin, apply ghee.',
      'Pleat like accordion, coil into spiral.',
      'Rest for 30 minutes.',
      'Roll gently and cook on tawa.',
      'Clap between hands to separate layers.',
    ]
  },
  {
    id: 57,
    name: 'Aloo Matar',
    image: 'https://www.cubesnjuliennes.com/wp-content/uploads/2020/07/Punjabi-Aloo-Matar-Recipe.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 345,
    cooked: 1340,
    baseServings: 4,
    ingredients: [
      { name: 'Potatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Green Peas', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add cumin seeds.',
      'Add onions, cook until golden.',
      'Add ginger-garlic paste, tomatoes.',
      'Add all spices and cook well.',
      'Add diced potatoes and peas.',
      'Add water, cover and cook until done.',
      'Garnish with coriander and serve.',
    ]
  },
  {
    id: 58,
    name: 'Chicken 65',
    image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400',
    time: '35 mins + marination',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 789,
    cooked: 3120,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken (boneless)', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Yogurt', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Curry Leaves', amount: 15, unit: 'leaves', alternatives: [] },
      { name: 'Cornflour', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Food Color (red)', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Green Chilies', amount: 4, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Cut chicken into bite-sized pieces.',
      'Mix all marinade ingredients.',
      'Marinate chicken for 1 hour.',
      'Deep fry chicken until golden.',
      'In another pan, fry curry leaves and chilies.',
      'Toss fried chicken in it.',
      'Serve hot with lemon wedges.',
    ]
  },
  {
    id: 59,
    name: 'Kachori',
    image: 'https://tse1.mm.bing.net/th/id/OIP.DQ-HhfiFiNwW9SLQJRaJfgHaKk?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 456,
    cooked: 1780,
    baseServings: 4,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Moong Dal', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Fennel Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Make dough with flour, oil, water.',
      'Soak dal for 2 hours, grind coarsely.',
      'Mix ground dal with spices for filling.',
      'Roll small dough circles.',
      'Place filling, seal edges.',
      'Deep fry until golden and puffed.',
      'Serve with tamarind chutney.',
    ]
  },
  {
    id: 60,
    name: 'Avial',
    image: 'https://i.pinimg.com/originals/97/9d/ed/979deda7792de5a41b66fd7c287e3e47.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'Kerala',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 234,
    cooked: 780,
    baseServings: 4,
    ingredients: [
      { name: 'Mixed Vegetables', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Coconut (grated)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Curry Leaves', amount: 15, unit: 'leaves', alternatives: [] },
      { name: 'Coconut Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small piece', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Cut vegetables into thick strips.',
      'Grind coconut, cumin, chilies to paste.',
      'Cook vegetables with turmeric, salt, tamarind.',
      'Add coconut paste, mix well.',
      'Cook for 5 minutes.',
      'Add coconut oil and curry leaves.',
      'Serve with rice.',
    ]
  },
  {
    id: 61,
    name: 'Shahi Paneer',
    image: 'https://tse1.mm.bing.net/th/id/OIP.9Gcof8tZSHlQYs87PZM-BQHaGr?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '40 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 789,
    cooked: 3120,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (cubed)', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Cashews', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Soak cashews in warm water.',
      'Blend onions and tomatoes separately.',
      'Cook onion paste in ghee until golden.',
      'Add ginger-garlic paste and tomato puree.',
      'Add ground cashew paste and spices.',
      'Add cream and cardamom powder.',
      'Add paneer cubes, simmer gently.',
      'Garnish with cream swirl and serve.',
    ]
  },
  {
    id: 62,
    name: 'Uttapam',
    image: 'https://ministryofcurry.com/wp-content/uploads/2020/09/uttapam-5-850x1275.jpg',
    time: '25 mins + fermentation',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Dosa Batter', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Onions (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Tomatoes (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Capsicum (chopped)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Cumin Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Heat tawa, pour thick batter in circle.',
      'Sprinkle onions, tomatoes, capsicum on top.',
      'Add chilies, coriander, cumin seeds.',
      'Drizzle oil around edges.',
      'Cook on medium heat until base is crispy.',
      'Flip and cook for 2 minutes.',
      'Serve hot with coconut chutney.',
    ]
  },
  {
    id: 63,
    name: 'Mutton Korma',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '90 mins',
    difficulty: 'Hard',
    region: 'Hyderabadi',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 567,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Mutton', amount: 750, unit: 'grams', alternatives: [] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 3, unit: 'large', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Poppy Seeds', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Coconut (grated)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Whole Spices', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Marinate mutton with yogurt, ginger-garlic paste.',
      'Fry onions until golden brown.',
      'Grind cashews, poppy seeds, coconut to paste.',
      'Cook mutton with fried onions.',
      'Add ground paste and whole spices.',
      'Cook on low heat until mutton is tender.',
      'Add saffron milk before serving.',
    ]
  },
  {
    id: 64,
    name: 'Momos (Chicken)',
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=400',
    time: '60 mins',
    difficulty: 'Hard',
    region: 'Northeast',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 1234,
    cooked: 5670,
    baseServings: 4,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Chicken (minced)', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Cabbage (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Soy Sauce', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Spring Onions', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Black Pepper', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Make dough with flour and water, rest 30 mins.',
      'Mix chicken, vegetables, spices for filling.',
      'Roll thin circles from dough.',
      'Place filling, fold into pleats.',
      'Steam momos for 10-12 minutes.',
      'Serve hot with spicy chutney.',
    ]
  },
  {
    id: 65,
    name: 'Rasgulla',
    image: 'https://recipes.net/wp-content/uploads/2022/07/rasgulla.jpg',
    time: '45 mins',
    difficulty: 'Hard',
    region: 'Bengali',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 890,
    cooked: 3450,
    baseServings: 6,
    ingredients: [
      { name: 'Milk', amount: 1, unit: 'liter', alternatives: [] },
      { name: 'Lemon Juice', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Sugar', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Water', amount: 4, unit: 'cups', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Rose Water', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Boil milk, add lemon juice to curdle.',
      'Strain and rinse chenna (paneer).',
      'Knead chenna until smooth for 10 minutes.',
      'Make small smooth balls.',
      'Boil sugar and water for syrup.',
      'Add chenna balls, boil for 15 minutes.',
      'Let cool in syrup, add cardamom and rose water.',
    ]
  },
  {
    id: 66,
    name: 'Bhel Puri',
    image: 'https://www.livofy.com/health/wp-content/uploads/2023/06/Untitled-design-4-2-1024x576.png',
    time: '15 mins',
    difficulty: 'Easy',
    region: 'Street Food',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 678,
    cooked: 2890,
    baseServings: 4,
    ingredients: [
      { name: 'Puffed Rice', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Sev', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Tomatoes (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Boiled Potatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tamarind Chutney', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Green Chutney', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Chaat Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix puffed rice and sev in large bowl.',
      'Add chopped onions, tomatoes, potatoes.',
      'Add both chutneys and mix well.',
      'Add chaat masala and lemon juice.',
      'Toss everything together.',
      'Garnish with coriander and serve immediately.',
    ]
  },
  {
    id: 67,
    name: 'Navratan Korma',
    image: 'https://www.cookclickndevour.com/wp-content/uploads/2016/04/navratan-korma-recipe-e.jpg',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 456,
    cooked: 1670,
    baseServings: 4,
    ingredients: [
      { name: 'Mixed Vegetables', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Paneer (cubed)', amount: 200, unit: 'grams', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Fruits (pineapple)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Blanch mixed vegetables.',
      'Grind cashews to paste.',
      'Cook onion-tomato gravy with spices.',
      'Add cashew paste and cream.',
      'Add vegetables and paneer.',
      'Add diced fruits.',
      'Simmer for 10 minutes and serve.',
    ]
  },
  {
    id: 68,
    name: 'Tandoori Roti',
    image: 'https://www.cookwithmanali.com/wp-content/uploads/2021/07/Tandoori-Roti-1014x1536.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'Punjabi',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 789,
    cooked: 3450,
    baseServings: 6,
    ingredients: [
      { name: 'Whole Wheat Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Water', amount: 0.75, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix flour and salt.',
      'Add water gradually, knead into soft dough.',
      'Rest for 15 minutes.',
      'Roll into thin circles.',
      'Cook on hot tawa until bubbles appear.',
      'Apply ghee and serve hot.',
    ]
  },
  {
    id: 69,
    name: 'Fish Fry',
    image: 'https://images.unsplash.com/photo-1626645738196-c2a7c87a8f58?w=400',
    time: '30 mins + marination',
    difficulty: 'Easy',
    region: 'Coastal',
    diet: 'Non-Vegetarian',
    rating: 4.7,
    reviews: 567,
    cooked: 2230,
    baseServings: 4,
    ingredients: [
      { name: 'Fish Fillets', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Red Chili Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Ginger Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Cornflour', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Clean and pat dry fish.',
      'Marinate with all spices for 30 mins.',
      'Coat fish with cornflour.',
      'Heat oil for deep frying.',
      'Fry fish until golden and crispy.',
      'Fry curry leaves separately.',
      'Garnish and serve with lemon.',
    ]
  },
  {
    id: 70,
    name: 'Aloo Bonda',
    image: 'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=400',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 345,
    cooked: 1230,
    baseServings: 4,
    ingredients: [
      { name: 'Potatoes (boiled)', amount: 4, unit: 'medium', alternatives: [] },
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Rice Flour', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mash potatoes with turmeric, chilies, salt.',
      'Make small balls from potato mixture.',
      'Make batter with gram flour, rice flour, water.',
      'Add mustard, curry leaves, asafoetida to batter.',
      'Dip potato balls in batter.',
      'Deep fry until golden brown.',
      'Serve hot with coconut chutney.',
    ]
  },
  {
    id: 71,
    name: 'Kaju Katli',
    image: 'https://recipes.timesofindia.com/thumb/55048826.cms?imgsize=392932&width=800&height=800',
    time: '30 mins',
    difficulty: 'Hard',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 1234,
    cooked: 5670,
    baseServings: 6,
    ingredients: [
      { name: 'Cashews', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Water', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Silver Foil', amount: 1, unit: 'sheet', alternatives: [] },
    ],
    steps: [
      'Grind cashews to fine powder.',
      'Make sugar syrup to one-string consistency.',
      'Add cashew powder, mix quickly.',
      'Cook until mixture leaves sides.',
      'Add cardamom powder and ghee.',
      'Pour on greased surface, roll thin.',
      'Cut into diamond shapes, apply silver foil.',
    ]
  },
  {
    id: 72,
    name: 'Ragi Mudde',
    image: 'https://www.sharmispassions.com/wp-content/uploads/2019/06/ragi-mudde5.jpg',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'Karnataka',
    diet: 'Vegan',
    rating: 4.4,
    reviews: 234,
    cooked: 670,
    baseServings: 4,
    ingredients: [
      { name: 'Ragi Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Water', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Boil water with salt.',
      'Add ragi flour slowly while stirring.',
      'Cook on low heat, stirring continuously.',
      'When thick, remove from heat.',
      'Wet hands and make smooth balls.',
      'Serve hot with sambar or curry.',
    ]
  },
  {
    id: 73,
    name: 'Goan Fish Curry',
    image: 'https://ichef.bbci.co.uk/food/ic/food_16x9_1600/recipes/fish_curry_09718_16x9.jpg',
    time: '40 mins',
    difficulty: 'Medium',
    region: 'Goan',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 456,
    cooked: 1560,
    baseServings: 4,
    ingredients: [
      { name: 'Fish', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Coconut (grated)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Red Chilies (dried)', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small ball', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Kokum', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Grind coconut, red chilies to paste.',
      'Extract tamarind juice.',
      'Heat oil, add onions, tomatoes.',
      'Add ground paste, turmeric, kokum.',
      'Add water and bring to boil.',
      'Add fish pieces, simmer for 10 minutes.',
      'Add curry leaves and serve.',
    ]
  },
  {
    id: 74,
    name: 'Jalebi',
    image: 'https://www.funfoodfrolic.com/wp-content/uploads/2020/11/Jalebi-1.jpg',
    time: '45 mins + fermentation',
    difficulty: 'Hard',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 890,
    cooked: 3450,
    baseServings: 6,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Yogurt', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Baking Powder', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Sugar', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Water', amount: 1.5, unit: 'cups', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Lemon Juice', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Food Color (orange)', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Make batter with flour, yogurt, baking powder.',
      'Ferment for 8-10 hours.',
      'Make sugar syrup with saffron, cardamom.',
      'Heat ghee for frying.',
      'Pipe batter in circular shapes.',
      'Fry until crispy golden.',
      'Soak in warm sugar syrup.',
      'Serve immediately.',
    ]
  },
  {
    id: 75,
    name: 'Methi Thepla',
    image: 'https://tse2.mm.bing.net/th/id/OIP.pziRYS1tfRxUOh6mMu1K9AHaLG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'Gujarati',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 456,
    cooked: 1670,
    baseServings: 4,
    ingredients: [
      { name: 'Whole Wheat Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Fenugreek Leaves (methi)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Gram Flour', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Yogurt', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mix all flours with chopped methi leaves.',
      'Add spices, yogurt, oil.',
      'Knead into soft dough.',
      'Roll into thin circles.',
      'Cook on hot tawa with oil.',
      'Serve with pickle or yogurt.',
    ]
  },
  {
    id: 76,
    name: 'Chicken Korma',
    image: 'https://www.teaforturmeric.com/wp-content/uploads/2018/06/Chicken-Korma.jpg',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 678,
    cooked: 2450,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken', amount: 750, unit: 'grams', alternatives: [] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Onions (fried)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Whole Spices', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Marinate chicken with yogurt, spices.',
      'Grind cashews and fried onions.',
      'Cook chicken in ghee with whole spices.',
      'Add ground paste and ginger-garlic.',
      'Add cream and saffron milk.',
      'Simmer until chicken is tender.',
      'Garnish with cream and serve.',
    ]
  },
  {
    id: 77,
    name: 'Lassi (Sweet)',
    image: 'https://www.cookwithmanali.com/wp-content/uploads/2021/06/Salty-Lassi-1014x1536.jpg',
    time: '10 mins',
    difficulty: 'Easy',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 789,
    cooked: 4560,
    baseServings: 2,
    ingredients: [
      { name: 'Yogurt', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Sugar', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Milk', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Ice Cubes', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Rose Water', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Saffron', amount: 5, unit: 'strands', alternatives: [] },
    ],
    steps: [
      'Blend yogurt, sugar, milk until smooth.',
      'Add cardamom powder and rose water.',
      'Add ice cubes and blend again.',
      'Pour in glasses.',
      'Garnish with saffron strands.',
      'Serve chilled.',
    ]
  },
  {
    id: 78,
    name: 'Bisi Bele Bath',
    image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/07/bisi-bele-bath-recipe.jpg',
    time: '45 mins',
    difficulty: 'Medium',
    region: 'Karnataka',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 456,
    cooked: 1670,
    baseServings: 4,
    ingredients: [
      { name: 'Rice', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Toor Dal', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Mixed Vegetables', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small ball', alternatives: [] },
      { name: 'Bisi Bele Bath Powder', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Jaggery', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Pressure cook rice, dal, vegetables together.',
      'Extract tamarind juice.',
      'Add tamarind, bisi bele bath powder, jaggery.',
      'Mix well and simmer for 15 minutes.',
      'Heat ghee, fry mustard, curry leaves, cashews.',
      'Pour tempering over bath.',
      'Serve hot with papad.',
    ]
  },
  {
    id: 79,
    name: 'Seekh Kebab',
    image: 'https://tse2.mm.bing.net/th/id/OIP.b37T3iSlR-hzNTSlDRWduAHaFj?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '40 mins + marination',
    difficulty: 'Medium',
    region: 'Mughlai',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 1123,
    cooked: 4560,
    baseServings: 4,
    ingredients: [
      { name: 'Minced Meat', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Onions (grated)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Garam Masala', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Mint Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Egg', amount: 1, unit: 'piece', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix minced meat with all ingredients.',
      'Marinate for 2 hours.',
      'Thread meat on skewers in long shapes.',
      'Grill or bake at 200°C.',
      'Brush with oil while grilling.',
      'Cook until golden brown.',
      'Serve with mint chutney and onion rings.',
    ]
  },
  {
    id: 80,
    name: 'Pav Bhaji Masala',
    image: 'https://3.bp.blogspot.com/-rEuGh7FJxe4/WvrwkvYuXxI/AAAAAAAAIWs/rk_TM41iNwkH1QN7Rcbc5vNsiu1Ui5RaACLcBGAs/s1600/Pav%2BBhaji%2B2.jpg',
    time: '50 mins',
    difficulty: 'Medium',
    region: 'West Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 567,
    cooked: 2340,
    baseServings: 6,
    ingredients: [
      { name: 'Potatoes', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Cauliflower', amount: 1, unit: 'small', alternatives: [] },
      { name: 'Peas', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Carrots', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Capsicum', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Onions', amount: 3, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Pav Bhaji Masala', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Butter', amount: 6, unit: 'tablespoons', alternatives: [] },
      { name: 'Lemon Juice', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Boil and mash all vegetables.',
      'Heat butter in large pan.',
      'Sauté finely chopped onions.',
      'Add tomatoes and cook until soft.',
      'Add pav bhaji masala generously.',
      'Add mashed vegetables and mix well.',
      'Mash with masher while cooking.',
      'Add water for desired consistency.',
      'Add butter and lemon juice.',
      'Serve with buttered pav.',
    ]
  },
  {
    id: 81,
    name: 'Coconut Chutney',
    image: 'https://tse1.mm.bing.net/th/id/OIP.5QxIbzJpyH-zYwDsSMtjfwHaJ4?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '15 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 456,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Coconut (grated)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Roasted Chana Dal', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 0.5, unit: 'inch piece', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 8, unit: 'leaves', alternatives: [] },
      { name: 'Oil', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Grind coconut, chana dal, chilies, ginger.',
      'Add salt and water for consistency.',
      'Heat oil, add mustard, urad dal.',
      'Add curry leaves when dal turns brown.',
      'Pour tempering over chutney.',
      'Serve with dosa, idli, vada.',
    ]
  },
  {
    id: 82,
    name: 'Mushroom Masala',
    image: 'https://ministryofcurry.com/wp-content/uploads/2020/02/mushroom-masala-2-2.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 345,
    cooked: 1230,
    baseServings: 4,
    ingredients: [
      { name: 'Mushrooms', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Green Peas', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Clean and slice mushrooms.',
      'Heat oil, sauté onions until golden.',
      'Add ginger-garlic paste.',
      'Add tomatoes and all spices.',
      'Cook until oil separates.',
      'Add mushrooms and peas.',
      'Cook covered for 10 minutes.',
      'Garnish with coriander.',
    ]
  },
  {
    id: 83,
    name: 'Sevai (Vermicelli Upma)',
    image: 'https://femina.wwmindia.com/content/2020/jul/vermicelli-sevai-upma-011594302946.jpg',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 234,
    cooked: 890,
    baseServings: 4,
    ingredients: [
      { name: 'Vermicelli', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Onions', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chana Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Peanuts', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Dry roast vermicelli until light brown.',
      'Heat oil, add mustard, dals, peanuts.',
      'Add onions, chilies, curry leaves.',
      'Add 3 cups hot water.',
      'Add roasted vermicelli.',
      'Cook covered on low heat.',
      'Add lemon juice and serve.',
    ]
  },
  {
    id: 84,
    name: 'Paneer Butter Masala',
    image: 'https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400',
    time: '40 mins',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 1234,
    cooked: 5670,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (cubed)', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Butter', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'tablespoon', alternatives: [] },
    ],
    steps: [
      'Blanch tomatoes, make puree.',
      'Soak cashews, grind to paste.',
      'Heat butter, sauté onions.',
      'Add ginger-garlic paste.',
      'Add tomato puree and cashew paste.',
      'Add spices and cook well.',
      'Add paneer cubes and cream.',
      'Crush kasuri methi on top.',
      'Serve with naan or rice.',
    ]
  },
  {
    id: 85,
    name: 'Dhokla (Khaman)',
    image: 'https://www.cookwithnabeela.com/wp-content/uploads/2024/02/KhamanDhokla1.webp',
    time: '35 mins',
    difficulty: 'Medium',
    region: 'Gujarati',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 567,
    cooked: 2120,
    baseServings: 4,
    ingredients: [
      { name: 'Gram Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Eno', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Sugar', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Ginger-Green Chili Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Sesame Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix gram flour, yogurt, sugar, turmeric.',
      'Add water to make smooth batter.',
      'Add ginger-chili paste.',
      'Just before steaming, add eno.',
      'Steam for 15-20 minutes.',
      'Cut into pieces.',
      'Heat oil, add mustard, sesame, curry leaves.',
      'Pour tempering over dhokla.',
      'Garnish with coriander and coconut.',
    ]
  },
  {
    id: 86,
    name: 'Kerala Beef Fry',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '90 mins',
    difficulty: 'Medium',
    region: 'Kerala',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 456,
    cooked: 1560,
    baseServings: 4,
    ingredients: [
      { name: 'Beef', amount: 750, unit: 'grams', alternatives: [] },
      { name: 'Onions (sliced)', amount: 3, unit: 'large', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Curry Leaves', amount: 20, unit: 'leaves', alternatives: [] },
      { name: 'Black Pepper', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Turmeric', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Coriander Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Coconut Oil', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Pressure cook beef with spices until tender.',
      'Drain and reserve stock.',
      'Heat coconut oil, fry onions until brown.',
      'Add curry leaves and ginger-garlic paste.',
      'Add cooked beef and fry on high heat.',
      'Add reserved stock little by little.',
      'Fry until all moisture evaporates.',
      'Serve with parotta or rice.',
    ]
  },
  {
    id: 87,
    name: 'Pongal (Sweet)',
    image: 'https://tse2.mm.bing.net/th/id/OIP.IFMIL7KsBYbLvKA4dOqVxwHaFj?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'Tamil Nadu',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 345,
    cooked: 1230,
    baseServings: 4,
    ingredients: [
      { name: 'Rice', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Moong Dal', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Jaggery', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Raisins', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Dry Ginger Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Milk', amount: 0.5, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Pressure cook rice and dal together.',
      'Melt jaggery with little water.',
      'Strain and add to cooked rice.',
      'Add cardamom and dry ginger powder.',
      'Heat ghee, fry cashews and raisins.',
      'Add to pongal.',
      'Add milk and mix well.',
      'Serve warm.',
    ]
  },
  {
    id: 88,
    name: 'Dal Tadka',
    image: 'https://www.cookwithmanali.com/wp-content/uploads/2014/08/Restaurant-Style-Dal-Tadka.jpg',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 890,
    cooked: 3890,
    baseServings: 4,
    ingredients: [
      { name: 'Toor Dal', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Pressure cook dal with turmeric.',
      'Mash dal lightly.',
      'Heat ghee, add cumin seeds.',
      'Add onions, cook until golden.',
      'Add ginger-garlic paste, tomatoes.',
      'Add spices and cook well.',
      'Add cooked dal and simmer.',
      'Garnish with coriander and serve.',
    ]
  },
  {
    id: 89,
    name: 'Gujiya',
    image: 'https://i.pinimg.com/originals/cd/5a/61/cd5a61577e5dadf1571a41e05983169a.jpg',
    time: '60 mins',
    difficulty: 'Hard',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 678,
    cooked: 2450,
    baseServings: 6,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Khoya', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Coconut (grated)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Powdered Sugar', amount: 0.75, unit: 'cup', alternatives: [] },
      { name: 'Almonds (chopped)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Ghee', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Make dough with flour, ghee, water.',
      'Rest for 30 minutes.',
      'Roast khoya, add coconut, sugar, nuts.',
      'Add cardamom powder to filling.',
      'Roll small circles from dough.',
      'Place filling, fold and seal edges.',
      'Deep fry on low heat until golden.',
      'Cool and store.',
    ]
  },
  {
    id: 90,
    name: 'Veg Biryani',
    image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2019/04/veg-biryani-recipe-680x510.jpg',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'Hyderabadi',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 789,
    cooked: 3120,
    baseServings: 6,
    ingredients: [
      { name: 'Basmati Rice', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Mixed Vegetables', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Onions (fried)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Biryani Masala', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Mint Leaves', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 4, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Soak rice for 30 minutes.',
      'Cook vegetables with yogurt and spices.',
      'Boil rice until 70% cooked.',
      'Layer vegetables and rice.',
      'Add fried onions, mint, coriander.',
      'Add saffron milk and ghee.',
      'Cover and cook on dum for 20 minutes.',
      'Serve hot with raita.',
    ]
  },
  {
    id: 91,
    name: 'Paneer Pakora',
    image: 'https://tse2.mm.bing.net/th/id/OIP.dwGmB2R6lHasEXrBbB6VIAHaFj?cb=12&rs=1&pid=ImgDetMain&o=7&rm=30',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (sliced)', amount: 300, unit: 'grams', alternatives: [] },
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Rice Flour', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Carom Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Chaat Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Baking Soda', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Make batter with gram flour, rice flour, spices.',
      'Add water to make thick batter.',
      'Add baking soda just before frying.',
      'Dip paneer slices in batter.',
      'Deep fry until golden and crispy.',
      'Drain on paper towels.',
      'Sprinkle chaat masala and serve hot.',
    ]
  },
  {
    id: 92,
    name: 'Mysore Masala Dosa',
    image: 'https://premasculinary.com/wp-content/uploads/2023/06/Mysore-Masala-Dosa-Recipe-2.jpg',
    time: '35 mins + fermentation',
    difficulty: 'Medium',
    region: 'Karnataka',
    diet: 'Vegan',
    rating: 4.8,
    reviews: 789,
    cooked: 3450,
    baseServings: 4,
    ingredients: [
      { name: 'Dosa Batter', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Red Chilies (dried)', amount: 10, unit: 'pieces', alternatives: [] },
      { name: 'Garlic Cloves', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Coconut (grated)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'small piece', alternatives: [] },
      { name: 'Potatoes (for masala)', amount: 4, unit: 'medium', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Curry Leaves', amount: 15, unit: 'leaves', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 4, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Grind red chilies, garlic, coconut, tamarind.',
      'Make potato masala separately.',
      'Heat tawa, spread dosa batter thin.',
      'Apply red chutney generously.',
      'Place potato masala in center.',
      'Drizzle oil and cook until crispy.',
      'Fold and serve hot.',
    ]
  },
  {
    id: 93,
    name: 'Chicken Tikka Masala',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '50 mins + marination',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 1456,
    cooked: 6780,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken Tikka', amount: 500, unit: 'grams', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomato Puree', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cashew Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Butter', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Grill marinated chicken tikka pieces.',
      'Heat butter, sauté onions until golden.',
      'Add ginger-garlic paste.',
      'Add tomato puree and all spices.',
      'Add cashew paste and cook well.',
      'Add grilled chicken tikka.',
      'Add cream and kasuri methi.',
      'Simmer for 10 minutes and serve.',
    ]
  },
  {
    id: 94,
    name: 'Rava Idli',
    image: 'https://www.funfoodfrolic.com/wp-content/uploads/2020/07/Rava-Idli-Thumbnail.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Semolina (Rava)', amount: 1.5, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Eno', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chana Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cashews', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Roast rava lightly.',
      'Heat oil, add mustard, dals, cashews.',
      'Add curry leaves, chilies.',
      'Mix with rava, yogurt, water.',
      'Rest for 10 minutes.',
      'Add eno just before steaming.',
      'Pour in greased idli molds.',
      'Steam for 10-12 minutes.',
    ]
  },
  {
    id: 95,
    name: 'Lauki Kofta',
    image: 'https://tse1.mm.bing.net/th/id/OIP.My-6YDL6BbzHOI0JzustQAHaLO?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '50 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 345,
    cooked: 1120,
    baseServings: 4,
    ingredients: [
      { name: 'Bottle Gourd (grated)', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Gram Flour', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Bread Crumbs', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Cream', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Squeeze excess water from grated lauki.',
      'Mix with gram flour, bread crumbs, spices.',
      'Make small balls and fry.',
      'Make gravy with onion-tomato paste.',
      'Add spices and cream.',
      'Add koftas just before serving.',
    ]
  },
  {
    id: 96,
    name: 'Curd Rice',
    image: 'https://www.indianveggiedelight.com/wp-content/uploads/2022/08/curd-rice-featured.jpg',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegetarian',
    rating: 4.5,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Rice (cooked)', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Milk', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 0.5, unit: 'inch piece', alternatives: [] },
      { name: 'Pomegranate', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 1, unit: 'tablespoon', alternatives: [] },
    ],
    steps: [
      'Mash cooked rice while warm.',
      'Add yogurt and milk, mix well.',
      'Heat oil, add mustard, urad dal.',
      'Add curry leaves, chilies, ginger.',
      'Pour tempering over curd rice.',
      'Garnish with pomegranate.',
      'Serve chilled.',
    ]
  },
  {
    id: 97,
    name: 'Zunka',
    image: 'https://tse4.mm.bing.net/th/id/OIP.30UWr04h6LE1lphVkt12twHaE7?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'Maharashtra',
    diet: 'Vegan',
    rating: 4.5,
    reviews: 234,
    cooked: 780,
    baseServings: 4,
    ingredients: [
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Garlic Cloves', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Mustard Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Asafoetida', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add mustard, cumin, asafoetida.',
      'Add chopped onions, chilies, garlic.',
      'Add turmeric and chili powder.',
      'Add gram flour and roast well.',
      'Add water gradually while stirring.',
      'Cook until mixture thickens.',
      'Serve hot with bhakri.',
    ]
  },
  {
    id: 98,
    name: 'Malai Kofta Curry',
    image: 'https://tse2.mm.bing.net/th/id/OIP.Q9Au0pSwH8dBYHEpXmfO6gHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '65 mins',
    difficulty: 'Hard',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 789,
    cooked: 2890,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (grated)', amount: 300, unit: 'grams', alternatives: [] },
      { name: 'Potatoes (boiled)', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Cornflour', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Cashews', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cream', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Mix paneer, mashed potatoes, cornflour.',
      'Make balls and deep fry until golden.',
      'Blend onions, tomatoes, cashews.',
      'Cook gravy with spices.',
      'Add cream and kasuri methi.',
      'Soak koftas in gravy before serving.',
    ]
  },
  {
    id: 99,
    name: 'Kuzhi Paniyaram',
    image: 'https://live.staticflickr.com/65535/32787114477_38fd558291_c.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'Tamil Nadu',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 456,
    cooked: 1670,
    baseServings: 4,
    ingredients: [
      { name: 'Dosa Batter', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Onions (chopped)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mix dosa batter with onions, chilies, ginger.',
      'Add curry leaves and coriander.',
      'Heat paniyaram pan, add oil in each cavity.',
      'Pour batter in each cavity.',
      'Cook until golden on both sides.',
      'Serve hot with coconut chutney.',
    ]
  },
  {
    id: 100,
    name: 'Kadai Paneer',
    image: 'https://tse4.mm.bing.net/th/id/OIP.QQ6qsoGmgA2SktvfzRk6KAHaJl?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '35 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 890,
    cooked: 3670,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (cubed)', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Bell Peppers', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Coriander Seeds (crushed)', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Kasuri Methi', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add crushed coriander seeds.',
      'Add onions and bell peppers.',
      'Add ginger-garlic paste.',
      'Add tomatoes and spices.',
      'Cook until oil separates.',
      'Add paneer cubes.',
      'Add kasuri methi.',
      'Toss and serve hot.',
    ]
  },
  {
    id: 101,
    name: 'Kheer (Rice Pudding)',
    image: 'https://i1.wp.com/www.honeywhatscooking.com/wp-content/uploads/2020/10/Rice-Kheer-Indian-Rice-Pudding45.jpg?fit=699,780&ssl=1',
    time: '45 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 1234,
    cooked: 5670,
    baseServings: 6,
    ingredients: [
      { name: 'Rice', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Milk', amount: 1, unit: 'liter', alternatives: [] },
      { name: 'Sugar', amount: 0.75, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Almonds (sliced)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Cashews (chopped)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Raisins', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Ghee', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Wash and soak rice for 30 minutes.',
      'Boil milk in heavy bottom pan.',
      'Add rice and cook on low heat.',
      'Stir frequently until rice is soft.',
      'Add sugar and cardamom.',
      'Add saffron soaked in milk.',
      'Fry nuts in ghee and add.',
      'Serve warm or chilled.',
    ]
  },
  {
    id: 102,
    name: 'Misal Pav',
    image: 'https://thumbs.dreamstime.com/b/misal-pav-buns-smeared-butter-served-spicy-sprouts-curry-trail-mixture-chopped-onions-chilli-lemons-bun-indian-starter-171494146.jpg',
    time: '50 mins',
    difficulty: 'Medium',
    region: 'Maharashtra',
    diet: 'Vegan',
    rating: 4.8,
    reviews: 678,
    cooked: 2450,
    baseServings: 4,
    ingredients: [
      { name: 'Mixed Sprouts', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'large', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Misal Masala', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Potato (boiled)', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Farsan/Sev', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Pav Buns', amount: 4, unit: 'pieces', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Lemon Juice', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Pressure cook sprouts until soft.',
      'Make gravy with onions, tomatoes, misal masala.',
      'Add cooked sprouts to gravy.',
      'Top with chopped onions, farsan.',
      'Add potato pieces.',
      'Garnish with coriander and lemon.',
      'Toast pav and serve hot.',
    ]
  },
  {
    id: 103,
    name: 'Gajar Halwa',
    image: 'https://tse1.mm.bing.net/th/id/OIP.GpNAJnq3nKa3yaAiDhAL_QHaGX?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.9,
    reviews: 1456,
    cooked: 6780,
    baseServings: 6,
    ingredients: [
      { name: 'Carrots (grated)', amount: 1, unit: 'kg', alternatives: [] },
      { name: 'Milk', amount: 1, unit: 'liter', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Almonds (sliced)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Cashews (chopped)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Raisins', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Khoya', amount: 0.5, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Cook grated carrots in milk until soft.',
      'Add sugar and cook until absorbed.',
      'Add ghee gradually while stirring.',
      'Cook until carrots turn glossy.',
      'Add khoya and cardamom.',
      'Fry nuts in ghee separately.',
      'Garnish halwa with fried nuts.',
      'Serve hot.',
    ]
  },
  {
    id: 104,
    name: 'Tomato Rice',
    image: 'https://tse2.mm.bing.net/th/id/OIP.7QjjnIyWde5j5mcDgtPWjAHaHa?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 567,
    cooked: 2120,
    baseServings: 4,
    ingredients: [
      { name: 'Rice (cooked)', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Tomatoes', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Peanuts', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Puree tomatoes.',
      'Heat oil, add mustard, urad dal, peanuts.',
      'Add onions, chilies, curry leaves.',
      'Add tomato puree and turmeric.',
      'Cook until oil separates.',
      'Add cooked rice and mix gently.',
      'Garnish with coriander.',
    ]
  },
  {
    id: 105,
    name: 'Palak Puri',
    image: 'https://smithakalluraya.com/wp-content/uploads/2019/10/palak-Puri.jpg',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 345,
    cooked: 1230,
    baseServings: 4,
    ingredients: [
      { name: 'Whole Wheat Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Spinach (blanched)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Carom Seeds', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Blend spinach and chilies to paste.',
      'Mix flour with spinach paste, spices.',
      'Knead into soft dough.',
      'Rest for 15 minutes.',
      'Roll into small circles.',
      'Deep fry until puffed and golden.',
      'Serve hot with curry.',
    ]
  },
  {
    id: 106,
    name: 'Mutton Rogan Josh',
    image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400',
    time: '100 mins',
    difficulty: 'Hard',
    region: 'Kashmiri',
    diet: 'Non-Vegetarian',
    rating: 4.9,
    reviews: 890,
    cooked: 3120,
    baseServings: 4,
    ingredients: [
      { name: 'Mutton', amount: 800, unit: 'grams', alternatives: [] },
      { name: 'Yogurt', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Onions', amount: 3, unit: 'large', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Kashmiri Red Chili', amount: 3, unit: 'teaspoons', alternatives: [] },
      { name: 'Fennel Powder', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Ginger Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cardamom', amount: 6, unit: 'pieces', alternatives: [] },
      { name: 'Bay Leaves', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Ghee', amount: 5, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat ghee, add whole spices.',
      'Add sliced onions, fry until dark brown.',
      'Add ginger-garlic paste.',
      'Add mutton pieces, sear well.',
      'Add yogurt and all powdered spices.',
      'Cover and cook on low heat for 75 mins.',
      'Adjust gravy consistency.',
      'Garnish with ginger julienne.',
    ]
  },
  {
    id: 107,
    name: 'Veg Manchurian',
    image: 'https://holycowvegan.net/wp-content/uploads/2020/03/veg-manchurian-7.jpg',
    time: '40 mins',
    difficulty: 'Medium',
    region: 'Indo-Chinese',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 789,
    cooked: 3450,
    baseServings: 4,
    ingredients: [
      { name: 'Cabbage (grated)', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Carrots (grated)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Capsicum (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Cornflour', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'All-Purpose Flour', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Soy Sauce', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Tomato Sauce', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Mix grated vegetables with cornflour, flour.',
      'Make balls and deep fry until golden.',
      'Heat oil, add ginger-garlic, chilies.',
      'Add capsicum, sauté briefly.',
      'Add sauces and water.',
      'Add cornflour slurry to thicken.',
      'Add fried balls, toss.',
      'Serve hot with fried rice.',
    ]
  },
  {
    id: 108,
    name: 'Chicken Lollipop',
    image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400',
    time: '45 mins + marination',
    difficulty: 'Medium',
    region: 'Indo-Chinese',
    diet: 'Non-Vegetarian',
    rating: 4.8,
    reviews: 1234,
    cooked: 5670,
    baseServings: 4,
    ingredients: [
      { name: 'Chicken Wings', amount: 12, unit: 'pieces', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Soy Sauce', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Red Chili Sauce', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Cornflour', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'All-Purpose Flour', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Egg', amount: 1, unit: 'piece', alternatives: [] },
      { name: 'Red Food Color', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Black Pepper', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Cut chicken wings to form lollipop shape.',
      'Marinate with ginger-garlic, sauces, spices.',
      'Refrigerate for 2 hours.',
      'Make batter with cornflour, flour, egg.',
      'Coat chicken in batter.',
      'Deep fry until golden and crispy.',
      'Toss in spicy sauce if desired.',
      'Serve hot with sauce.',
    ]
  },
  {
    id: 109,
    name: 'Aam Panna',
    image: 'https://www.funfoodfrolic.com/wp-content/uploads/2020/05/Aam-Panna-3.jpg',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 567,
    cooked: 2340,
    baseServings: 4,
    ingredients: [
      { name: 'Raw Mangoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Sugar', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Black Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Roasted Cumin Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Mint Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Black Pepper', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Salt', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Water', amount: 4, unit: 'cups', alternatives: [] },
      { name: 'Ice Cubes', amount: 8, unit: 'pieces', alternatives: [] },
    ],
    steps: [
      'Boil raw mangoes until soft.',
      'Peel and extract pulp.',
      'Blend pulp with sugar, salts, cumin.',
      'Add mint leaves.',
      'Mix with water.',
      'Strain if desired.',
      'Add ice cubes and serve chilled.',
    ]
  },
  {
    id: 110,
    name: 'Peda',
    image: 'https://th.bing.com/th/id/R.a5e7dd2fceddbdb4338ed4719cb4267a?rik=YOqKgalq7SRzfQ&riu=http%3a%2f%2fhonestcooking.com%2fwp-content%2fuploads%2f2015%2f08%2fDSC_0868.jpg&ehk=CDgE%2f5B4hSX9eEHCmIrUt%2batD3tesJmJ7Cp3dYB3eD8%3d&risl=&pid=ImgRaw&r=0',
    time: '30 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 890,
    cooked: 3670,
    baseServings: 8,
    ingredients: [
      { name: 'Milk Powder', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Condensed Milk', amount: 0.75, unit: 'cup', alternatives: [] },
      { name: 'Ghee', amount: 3, unit: 'tablespoons', alternatives: [] },
      { name: 'Cardamom Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Pistachios (chopped)', amount: 0.25, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Mix milk powder and condensed milk.',
      'Heat ghee, add mixture.',
      'Cook on low heat, stirring continuously.',
      'Add cardamom and saffron.',
      'Cook until mixture leaves sides.',
      'Cool slightly, make small balls.',
      'Flatten and garnish with pistachios.',
      'Let set for 2 hours.',
    ]
  },
  {
    id: 111,
    name: 'Lemon Rice',
    image: 'https://tse2.mm.bing.net/th/id/OIP.hR4Q69nDAw0TTxv40DLWeAHaLO?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 678,
    cooked: 2890,
    baseServings: 4,
    ingredients: [
      { name: 'Rice (cooked)', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Lemon Juice', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Peanuts', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chana Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 15, unit: 'leaves', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat oil, add mustard seeds.',
      'Add dals and peanuts.',
      'Add chilies and curry leaves.',
      'Add turmeric.',
      'Add cooked rice and mix gently.',
      'Add lemon juice.',
      'Mix well and serve.',
    ]
  },
  {
    id: 112,
    name: 'Bread Pakora',
    image: 'https://tse2.mm.bing.net/th/id/OIP.0PoFzagTb0yMKamEMxLvTAHaLG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 456,
    cooked: 1890,
    baseServings: 4,
    ingredients: [
      { name: 'Bread Slices', amount: 8, unit: 'pieces', alternatives: [] },
      { name: 'Potatoes (boiled)', amount: 3, unit: 'medium', alternatives: [] },
      { name: 'Gram Flour', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Baking Soda', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Mash potatoes with spices, chilies, coriander.',
      'Make batter with gram flour, water, spices.',
      'Spread potato filling on bread slices.',
      'Make sandwich with two slices.',
      'Dip sandwich in batter.',
      'Deep fry until golden brown.',
      'Cut and serve hot with chutney.',
    ]
  },
  {
    id: 113,
    name: 'Paneer Bhurji',
    image: 'https://tse4.mm.bing.net/th/id/OIP.dwS2Qel-FKaSpS-YuR3ewgHaGs?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '25 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.7,
    reviews: 789,
    cooked: 3450,
    baseServings: 4,
    ingredients: [
      { name: 'Paneer (crumbled)', amount: 400, unit: 'grams', alternatives: [] },
      { name: 'Onions', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Green Chilies', amount: 2, unit: 'pieces', alternatives: [] },
      { name: 'Ginger-Garlic Paste', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Red Chili Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Butter', amount: 2, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Heat butter, add onions.',
      'Add ginger-garlic paste, chilies.',
      'Add tomatoes and spices.',
      'Cook until tomatoes are soft.',
      'Add crumbled paneer.',
      'Mix well and cook for 5 minutes.',
      'Garnish with coriander.',
      'Serve with roti or bread.',
    ]
  },
  {
    id: 114,
    name: 'Naan',
    image: 'https://cafedelites.com/wp-content/uploads/2020/06/Garlic-Naan-Recipe-IMAGE-27.jpg',
    time: '90 mins',
    difficulty: 'Medium',
    region: 'Punjabi',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 1234,
    cooked: 5670,
    baseServings: 6,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Yogurt', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Milk (warm)', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'Yeast', amount: 2, unit: 'teaspoons', alternatives: [] },
      { name: 'Sugar', amount: 1, unit: 'tablespoon', alternatives: [] },
      { name: 'Baking Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Salt', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Butter', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Nigella Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
    ],
    steps: [
      'Activate yeast in warm milk with sugar.',
      'Mix flour, yogurt, baking powder, salt.',
      'Add yeast mixture, knead into soft dough.',
      'Rest for 1-2 hours until doubled.',
      'Divide into portions.',
      'Roll into oval or teardrop shape.',
      'Sprinkle nigella seeds.',
      'Cook on hot tawa or in oven.',
      'Apply butter and serve hot.',
    ]
  },
  {
    id: 115,
    name: 'Vegetable Samosa',
    image: 'https://www.unileverfoodsolutions.com.ph/dam/global-ufs/mcos/SEA/calcmenu/recipes/PH-recipes/appetisers/vegetable-samosa/vegetable-samosa-main.jpg',
    time: '60 mins',
    difficulty: 'Medium',
    region: 'North Indian',
    diet: 'Vegan',
    rating: 4.9,
    reviews: 1890,
    cooked: 8900,
    baseServings: 6,
    ingredients: [
      { name: 'All-Purpose Flour', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Potatoes (boiled)', amount: 4, unit: 'large', alternatives: [] },
      { name: 'Green Peas', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Garam Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Amchur Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Make dough with flour, oil, water.',
      'Heat oil, add cumin, ginger, chilies.',
      'Add peas, cook briefly.',
      'Add mashed potatoes and all spices.',
      'Add coriander, mix well.',
      'Roll dough, cut semicircles.',
      'Make cone, fill with mixture.',
      'Seal edges and deep fry until golden.',
      'Serve hot with chutney.',
    ]
  },
  {
    id: 116,
    name: 'Gulab Jamun from Mix',
    image: 'https://media.chefdehome.com/740/0/0/gulab-jamun/indian-gulab-jamun-chefdehome-1.jpg',
    time: '35 mins',
    difficulty: 'Easy',
    region: 'North Indian',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 1567,
    cooked: 7890,
    baseServings: 6,
    ingredients: [
      { name: 'Gulab Jamun Mix', amount: 1, unit: 'packet', alternatives: [] },
      { name: 'Milk', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Sugar', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Water', amount: 2, unit: 'cups', alternatives: [] },
      { name: 'Cardamom Powder', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Rose Water', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Saffron', amount: 5, unit: 'strands', alternatives: [] },
      { name: 'Oil', amount: 2, unit: 'cups', alternatives: [] },
    ],
    steps: [
      'Mix gulab jamun powder with milk.',
      'Make smooth, soft dough.',
      'Make small smooth balls (no cracks).',
      'Make sugar syrup, add cardamom, rose water.',
      'Heat oil on low-medium heat.',
      'Fry balls slowly until deep brown.',
      'Soak in warm syrup for 2 hours.',
      'Garnish with saffron and serve.',
    ]
  },
  {
    id: 117,
    name: 'Rava Dosa',
    image: 'https://www.indianhealthyrecipes.com/wp-content/uploads/2021/06/rava-dosa-1024x1536.jpg',
    time: '25 mins',
    difficulty: 'Medium',
    region: 'Karnataka',
    diet: 'Vegan',
    rating: 4.7,
    reviews: 678,
    cooked: 2670,
    baseServings: 4,
    ingredients: [
      { name: 'Semolina (Rava)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Rice Flour', amount: 0.5, unit: 'cup', alternatives: [] },
      { name: 'All-Purpose Flour', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Onions (chopped)', amount: 1, unit: 'cup', alternatives: [] },
      { name: 'Green Chilies', amount: 3, unit: 'pieces', alternatives: [] },
      { name: 'Ginger', amount: 1, unit: 'inch piece', alternatives: [] },
      { name: 'Cumin Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Curry Leaves', amount: 10, unit: 'leaves', alternatives: [] },
      { name: 'Coriander Leaves', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Mix rava, rice flour, all-purpose flour.',
      'Add water to make thin batter.',
      'Add onions, chilies, ginger, cumin, curry leaves.',
      'Add coriander leaves.',
      'Rest for 10 minutes.',
      'Heat tawa, pour batter in circular motion.',
      'Drizzle oil, cook until crispy.',
      'Serve hot with chutney.',
    ]
  },
  {
    id: 118,
    name: 'Pav Sandwich',
    image: 'https://tse3.mm.bing.net/th/id/OIP.Co5H2CGVUA43PQqMJ85b3wHaLG?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '20 mins',
    difficulty: 'Easy',
    region: 'Street Food',
    diet: 'Vegetarian',
    rating: 4.6,
    reviews: 456,
    cooked: 1890,
    baseServings: 2,
    ingredients: [
      { name: 'Pav Buns', amount: 4, unit: 'pieces', alternatives: [] },
      { name: 'Potatoes (boiled)', amount: 2, unit: 'medium', alternatives: [] },
      { name: 'Butter', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Green Chutney', amount: 4, unit: 'tablespoons', alternatives: [] },
      { name: 'Onions (sliced)', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Tomatoes (sliced)', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Capsicum (sliced)', amount: 1, unit: 'medium', alternatives: [] },
      { name: 'Chaat Masala', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Cheese (optional)', amount: 4, unit: 'slices', alternatives: [] },
    ],
    steps: [
      'Slit pav buns.',
      'Apply butter and green chutney.',
      'Layer mashed potatoes.',
      'Add onions, tomatoes, capsicum.',
      'Sprinkle chaat masala.',
      'Add cheese if using.',
      'Grill until golden.',
      'Serve hot with sauce.',
    ]
  },
  {
    id: 119,
    name: 'Tamarind Rice',
    image: 'https://www.yummefy.com/uploads/1586349154Tamarind-Rice-Yummefy.jpg',
    time: '30 mins',
    difficulty: 'Easy',
    region: 'South Indian',
    diet: 'Vegan',
    rating: 4.6,
    reviews: 567,
    cooked: 2120,
    baseServings: 4,
    ingredients: [
      { name: 'Rice (cooked)', amount: 3, unit: 'cups', alternatives: [] },
      { name: 'Tamarind', amount: 1, unit: 'lemon sized', alternatives: [] },
      { name: 'Peanuts', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Mustard Seeds', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Urad Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Chana Dal', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Dried Red Chilies', amount: 4, unit: 'pieces', alternatives: [] },
      { name: 'Curry Leaves', amount: 15, unit: 'leaves', alternatives: [] },
      { name: 'Turmeric', amount: 0.5, unit: 'teaspoon', alternatives: [] },
      { name: 'Jaggery', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Oil', amount: 3, unit: 'tablespoons', alternatives: [] },
    ],
    steps: [
      'Extract tamarind juice.',
      'Heat oil, add mustard seeds.',
      'Add dals, peanuts, red chilies.',
      'Add curry leaves and turmeric.',
      'Add tamarind juice, jaggery, salt.',
      'Cook until thickens.',
      'Add cooked rice and mix gently.',
      'Serve at room temperature.',
    ]
  },
  {
    id: 120,
    name: 'Shrikhand',
    image: 'https://tse2.mm.bing.net/th/id/OIP.iA0TfBuHr1n8-98ZCrynCwHaLH?cb=12&rs=1&pid=ImgDetMain&o=7&rm=3',
    time: '20 mins + hanging time',
    difficulty: 'Easy',
    region: 'Gujarati',
    diet: 'Vegetarian',
    rating: 4.8,
    reviews: 890,
    cooked: 3560,
    baseServings: 4,
    ingredients: [
      { name: 'Yogurt (thick)', amount: 4, unit: 'cups', alternatives: [] },
      { name: 'Powdered Sugar', amount: 0.75, unit: 'cup', alternatives: [] },
      { name: 'Cardamom Powder', amount: 1, unit: 'teaspoon', alternatives: [] },
      { name: 'Saffron', amount: 0.25, unit: 'teaspoon', alternatives: [] },
      { name: 'Milk (warm)', amount: 2, unit: 'tablespoons', alternatives: [] },
      { name: 'Pistachios (chopped)', amount: 0.25, unit: 'cup', alternatives: [] },
      { name: 'Almonds (chopped)', amount: 0.25, unit: 'cup', alternatives: [] },
    ],
    steps: [
      'Hang yogurt in muslin cloth for 4 hours.',
      'Transfer hung curd to bowl.',
      'Add powdered sugar and mix well.',
      'Soak saffron in warm milk.',
      'Add saffron milk and cardamom.',
      'Mix until smooth and creamy.',
      'Chill for 2 hours.',
      'Garnish with nuts and serve cold.',
    ]
  },
];

interface RecipesPageProps {
  onRecipeSelect: (recipe: any) => void;
  onNavigate?: (page: string) => void;
}

export function RecipesPage({ onRecipeSelect, onNavigate }: RecipesPageProps) {
  const liveRecipes = useLiveRecipes(200);
  const recipesToShow = liveRecipes && liveRecipes.length? liveRecipes : recipeDatabase;

  const [searchQuery, setSearchQuery] = useState('');
  const [regionFilter, setRegionFilter] = useState('all');
  const [dietFilter, setDietFilter] = useState('all');
  const [difficultyFilter, setDifficultyFilter] = useState('all');
  const [selectedRecipe, setSelectedRecipe] = useState<any>(null);
  const [servings, setServings] = useState(4);
  const [voiceLanguage, setVoiceLanguage] = useState('en-IN');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [customRecipes, setCustomRecipes] = useState<any[]>([]);
  
  // Combine all recipes: mockRecipes only (restaurant recipes removed)
  const [allRecipes, setAllRecipes] = useState<any[]>([...mockRecipes]);
  const [translatedRecipe, setTranslatedRecipe] = useState<any>(null);
  const [isTranslating, setIsTranslating] = useState(false);

  // Load custom recipes from localStorage
  useEffect(() => {
    const loadCustomRecipes = () => {
      const saved = localStorage.getItem('customRecipes');
      if (saved) {
        const parsed = JSON.parse(saved);
        setCustomRecipes(parsed);
        setAllRecipes([...mockRecipes, ...restaurantRecipes, ...generatedRecipes, ...parsed]);
      }
    };

    loadCustomRecipes();

    // Listen for storage changes (when developer adds new recipe)
    const handleStorageChange = () => {
      loadCustomRecipes();
    };

    window.addEventListener('storage', handleStorageChange);
    // Also check periodically for updates
    const interval = setInterval(loadCustomRecipes, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  // Translate recipe when language changes
  useEffect(() => {
    if (selectedRecipe && voiceLanguage !== 'en-IN') {
      translateRecipe(selectedRecipe, voiceLanguage);
    } else {
      setTranslatedRecipe(null);
    }
  }, [voiceLanguage, selectedRecipe]);

  const translateRecipe = async (recipe: any, targetLang: string) => {
    if (targetLang === 'en-IN') {
      setTranslatedRecipe(null);
      return;
    }

    setIsTranslating(true);
    try {
      const langCode = targetLang.split('-')[0];
      
      // Translate recipe name
      const translatedName = await translateTextSimple(recipe.name, langCode);
      
      // Translate ingredients
      const translatedIngredients = await Promise.all(
        (recipe.ingredients || []).map(async (ing: any) => {
          if (typeof ing === 'string') {
            return await translateTextSimple(ing, langCode);
          }
          return {
            ...ing,
            name: await translateTextSimple(ing.name, langCode),
            unit: await translateTextSimple(ing.unit || '', langCode)
          };
        })
      );

      // Translate steps if available
      const translatedSteps = recipe.steps ? await Promise.all(
        recipe.steps.map((step: string) => translateTextSimple(step, langCode))
      ) : [];

      setTranslatedRecipe({
        ...recipe,
        name: translatedName,
        ingredients: translatedIngredients,
        steps: translatedSteps
      });
    } catch (error) {
      console.error('Translation error:', error);
      toast.error('Translation failed. Showing original content.');
    } finally {
      setIsTranslating(false);
    }
  };

  const translateTextSimple = async (text: string, langCode: string): Promise<string> => {
    // Translation disabled for compatibility
    // In production, integrate with a translation service
    return text;
  };

  const languageOptions = [
    { value: 'en-IN', label: 'English (India)' },
    { value: 'hi-IN', label: 'हिन्दी (Hindi)' },
    { value: 'ta-IN', label: 'தமிழ் (Tamil)' },
    { value: 'bn-IN', label: 'বাংলা (Bengali)' },
    { value: 'mr-IN', label: 'मराठी (Marathi)' },
    { value: 'te-IN', label: 'తెలుగు (Telugu)' },
    { value: 'gu-IN', label: 'ગુજરાતી (Gujarati)' },
  ];

  const filteredRecipes = allRecipes.filter(recipe => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Handle both mockRecipes (region) and restaurantRecipes (cuisine) structure
    const recipeRegion = recipe.region || recipe.cuisine;
    const matchesRegion = regionFilter === 'all' || recipeRegion === regionFilter || 
                         (recipe.cuisine && regionFilter.toLowerCase().replace(/\s+/g, '-') === recipe.cuisine);
    
    // Handle both mockRecipes (diet) and restaurantRecipes (dietType) structure
    const recipeDiet = recipe.diet || recipe.dietType;
    const matchesDiet = dietFilter === 'all' || recipeDiet === dietFilter || 
                       (recipe.dietType && dietFilter.toLowerCase().replace(/\s+/g, '-') === recipe.dietType);
    
    // Handle difficulty (mockRecipes have difficulty, restaurantRecipes have spiceLevel)
    const matchesDifficulty = difficultyFilter === 'all' || recipe.difficulty === difficultyFilter;
    
    return matchesSearch && matchesRegion && matchesDiet && matchesDifficulty;
  });

  const calculateScaledAmount = (amount: number, baseServings: number) => {
    const scaleFactor = servings / baseServings;
    const scaledAmount = amount * scaleFactor;
    
    // Round to sensible precision
    if (scaledAmount < 1) {
      return scaledAmount.toFixed(2);
    } else if (scaledAmount < 10) {
      return scaledAmount.toFixed(1);
    } else {
      return Math.round(scaledAmount).toString();
    }
  };

  const speakRecipe = () => {
    if (!selectedRecipe) return;

    window.speechSynthesis.cancel();

    // Use translated recipe if available, otherwise use original
    const recipeToSpeak = translatedRecipe || selectedRecipe;

    const ingredientsText = (recipeToSpeak.ingredients || []).map((ing: any) => {
      if (typeof ing === 'string') {
        return ing;
      }
      return `${ing.name}, ${calculateScaledAmount(ing.amount, selectedRecipe.baseServings || selectedRecipe.servings || 4)} ${ing.unit}`;
    }).join('. ');

    const stepsText = (recipeToSpeak.steps || []).map((step: string, index: number) => 
      `Step ${index + 1}. ${step}`
    ).join('. ');

    const timeInfo = selectedRecipe.time || `${selectedRecipe.prepTime} minutes` || 'Unknown';
    const difficultyInfo = selectedRecipe.difficulty || selectedRecipe.spiceLevel || 'Medium';
    
    let fullText = `Recipe for ${recipeToSpeak.name}, serving ${servings} people. Time required: ${timeInfo}. Difficulty: ${difficultyInfo}.`;
    
    if (ingredientsText) {
      fullText += ` Ingredients: ${ingredientsText}.`;
    }
    
    if (stepsText) {
      fullText += ` Cooking steps: ${stepsText}`;
    } else {
      fullText += ` For detailed cooking instructions, please ask our AI assistant.`;
    }

    const utterance = new SpeechSynthesisUtterance(fullText);
    utterance.lang = voiceLanguage;
    utterance.rate = 0.85;
    utterance.pitch = 1;

    // Wait for voices to load
    const setVoiceAndSpeak = () => {
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(voice => voice.lang.startsWith(voiceLanguage.split('-')[0]));
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      utterance.onstart = () => {
        setIsSpeaking(true);
        const langName = languageOptions.find(opt => opt.value === voiceLanguage)?.label || voiceLanguage;
        toast.success(`🔊 Speaking recipe in ${langName}...`);
      };
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => {
        setIsSpeaking(false);
        toast.error('Speech synthesis error');
      };

      window.speechSynthesis.speak(utterance);
    };

    // Ensure voices are loaded
    if (window.speechSynthesis.getVoices().length === 0) {
      window.speechSynthesis.onvoiceschanged = setVoiceAndSpeak;
    } else {
      setVoiceAndSpeak();
    }
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
    toast.info('Stopped speaking');
  };

  const downloadRecipe = () => {
    if (!selectedRecipe) return;

    const ingredientsList = (selectedRecipe.ingredients || []).map((ing: any) => {
      if (typeof ing === 'string') {
        return `• ${ing}`;
      }
      return `• ${ing.name}: ${calculateScaledAmount(ing.amount, selectedRecipe.baseServings || selectedRecipe.servings || 4)} ${ing.unit}${
        ing.alternatives && ing.alternatives.length > 0 ? `\n  Alternatives: ${ing.alternatives.join(', ')}` : ''
      }`;
    }).join('\n');

    const stepsList = (selectedRecipe.steps || []).map((step: string, index: number) => 
      `${index + 1}. ${step}`
    ).join('\n\n');

    const timeInfo = selectedRecipe.time || `${selectedRecipe.prepTime} minutes` || 'Unknown';
    const difficultyInfo = selectedRecipe.difficulty || selectedRecipe.spiceLevel || 'Medium';
    const dietInfo = selectedRecipe.diet || (selectedRecipe.dietType ? selectedRecipe.dietType.charAt(0).toUpperCase() + selectedRecipe.dietType.slice(1).replace('-', ' ') : 'Vegetarian');
    
    let recipeText = `
RASOI MATE - RECIPE CARD
${'='.repeat(50)}

${selectedRecipe.name.toUpperCase()}

⏱️  Time: ${timeInfo}
👥 Servings: ${servings} people
📊 Difficulty: ${difficultyInfo}
🍽️  Diet: ${dietInfo}

${'='.repeat(50)}

INGREDIENTS:
${ingredientsList}

${'='.repeat(50)}
`;

    if (stepsList) {
      recipeText += `
COOKING STEPS:
${stepsList}

${'='.repeat(50)}
`;
    } else {
      recipeText += `
COOKING STEPS:
For detailed cooking instructions, please visit Rasoi Mate and ask our AI assistant!

${'='.repeat(50)}
`;
    }

    recipeText += `

${'='.repeat(50)}

💡 TIP: You can adjust the servings and get different proportions!

Downloaded from Rasoi Mate - Your AI Kitchen Assistant
Date: ${new Date().toLocaleString()}
`;

    const blob = new Blob([recipeText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedRecipe.name.replace(/\s+/g, '-').toLowerCase()}-recipe.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success('✅ Recipe downloaded!');
  };

  const RecipeCard = ({ recipe }: { recipe: any }) => {
    // Handle both mockRecipes and restaurantRecipes structure
    const recipeImage = recipe.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400'; // Food placeholder
    const recipeTime = recipe.time || `${recipe.prepTime} mins`;
    const recipeDifficulty = recipe.difficulty || recipe.spiceLevel || 'Medium';
    const recipeDiet = recipe.diet || (recipe.dietType ? 
      recipe.dietType.charAt(0).toUpperCase() + recipe.dietType.slice(1).replace('-', ' ') : 'Vegetarian');
    const recipeRegion = recipe.region || (recipe.cuisine ? 
      recipe.cuisine.split('-').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') : 'Indian');
    
    return (
      <Card 
        className="overflow-hidden hover:shadow-xl transition-all cursor-pointer group"
        onClick={() => {
          setSelectedRecipe(recipe);
          setServings(recipe.baseServings || recipe.servings || 4);
        }}
      >
        <div className="relative aspect-[4/3] overflow-hidden">
          <ImageWithFallback
            src={getFigmaSafeImage(recipeImage)}
            alt={recipe.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          
          {/* Voice Icon */}
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="absolute top-3 left-3 p-2 rounded-full bg-white/90 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <Volume2 className="h-4 w-4" style={{ color: 'var(--tech-blue)' }} />
          </motion.button>


        </div>

        <div className="p-4">
          <h3 className="mb-2">{recipe.name}</h3>
          <div className="flex flex-wrap gap-2 mb-3">
            <Badge variant="outline" className="text-xs">
              <Clock className="h-3 w-3 mr-1" />
              {recipeTime}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {recipeDifficulty}
            </Badge>
            <Badge variant="outline" className="text-xs">
              {recipeDiet}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            {recipeRegion}
          </p>
          <Button
            size="sm"
            className="w-full"
            onClick={(e) => {
              e.stopPropagation();
              onRecipeSelect(recipe);
            }}
            style={{ background: 'linear-gradient(135deg, var(--tech-blue), var(--tech-blue-light))' }}
          >
            <Sparkles className="mr-2 h-3 w-3" />
            Ask AI for Proportions
          </Button>
        </div>
      </Card>
    );
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto max-w-7xl px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <Badge className="mb-4" style={{ background: 'var(--green)', color: 'white' }}>
            <ChefHat className="mr-1 h-3 w-3" />
            500+ Recipes
          </Badge>
          <h1 className="text-3xl md:text-5xl mb-4">Recipe Library</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Explore authentic Indian recipes with AI-powered proportions and alternatives
          </p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-4 lg:col-span-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search recipes..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>

              <Select value={regionFilter} onValueChange={setRegionFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Regions</SelectItem>
                  <SelectItem value="North Indian">North Indian</SelectItem>
                  <SelectItem value="South Indian">South Indian</SelectItem>
                  <SelectItem value="Hyderabadi">Hyderabadi</SelectItem>
                  <SelectItem value="Bengali">Bengali</SelectItem>
                  <SelectItem value="Gujarati">Gujarati</SelectItem>
                </SelectContent>
              </Select>

              <Select value={dietFilter} onValueChange={setDietFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Diet" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Diets</SelectItem>
                  <SelectItem value="Vegetarian">Vegetarian</SelectItem>
                  <SelectItem value="Non-Vegetarian">Non-Vegetarian</SelectItem>
                  <SelectItem value="Vegan">Vegan</SelectItem>
                </SelectContent>
              </Select>

              <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Difficulty" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="Easy">Easy</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Card>
        </motion.div>

        {/* Most Cooked This Week */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <div className="flex items-center gap-2 mb-4">
            <Flame className="h-5 w-5" style={{ color: 'var(--saffron)' }} />
            <h2 className="text-2xl">Most Cooked This Week</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.slice(0, 3).map((recipe, index) => (
              <motion.div
                key={`most-cooked-${recipe.id}-${recipe.name}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ y: -8 }}
              >
                <RecipeCard recipe={recipe} />
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* AI Recommended for You */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Sparkles className="h-5 w-5" style={{ color: 'var(--tech-blue)' }} />
            <h2 className="text-2xl">AI Recommended for You</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.slice(3).map((recipe, index) => (
              <motion.div
                key={`ai-recommended-${recipe.id}-${recipe.name}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ y: -8 }}
              >
                <RecipeCard recipe={recipe} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recipe Detail Dialog */}
      <AnimatePresence>
        {selectedRecipe && (
          <Dialog open={!!selectedRecipe} onOpenChange={() => setSelectedRecipe(null)}>
            <DialogContent className="max-w-4xl max-h-[90vh] p-0">
              <DialogTitle className="sr-only">{selectedRecipe?.name}</DialogTitle>
              <DialogDescription className="sr-only">
                Recipe details for {selectedRecipe?.name} including ingredients, proportions, and cooking steps.
              </DialogDescription>
              <ScrollArea className="max-h-[90vh]">
                <div className="relative">
                  {/* Recipe Image Header */}
                  <div className="relative h-64 overflow-hidden">
                    <ImageWithFallback
                      src={getFigmaSafeImage(selectedRecipe.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400')}
                      alt={(translatedRecipe || selectedRecipe).name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                    
                    <div className="absolute bottom-0 left-0 right-0 p-6">
                      <div className="flex items-start justify-between">
                        <div>
                          <h2 className="text-white text-3xl mb-2">
                            {(translatedRecipe || selectedRecipe).name}
                            {isTranslating && <span className="ml-2 text-sm animate-pulse">⏳ Translating...</span>}
                          </h2>
                          <div className="flex flex-wrap gap-2">
                            <Badge className="bg-white/90 text-black">
                              <Clock className="h-3 w-3 mr-1" />
                              {selectedRecipe.time || `${selectedRecipe.prepTime} mins`}
                            </Badge>
                            <Badge className="bg-white/90 text-black">
                              {selectedRecipe.difficulty || selectedRecipe.spiceLevel || 'Medium'}
                            </Badge>
                            <Badge className="bg-white/90 text-black">
                              {selectedRecipe.diet || (selectedRecipe.dietType ? 
                                selectedRecipe.dietType.charAt(0).toUpperCase() + selectedRecipe.dietType.slice(1).replace('-', ' ') : 'Vegetarian')}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    {/* Servings Selector */}
                    <Card className="p-4 mb-6" style={{ borderColor: 'var(--tech-blue)', borderWidth: '2px' }}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Users className="h-5 w-5" style={{ color: 'var(--tech-blue)' }} />
                          <span>Servings</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setServings(Math.max(1, servings - 1))}
                            className="h-8 w-8 p-0"
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="min-w-8 text-center">{servings}</span>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setServings(servings + 1)}
                            className="h-8 w-8 p-0"
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      {servings !== (selectedRecipe.baseServings || selectedRecipe.servings) && (
                        <p className="text-xs text-muted-foreground mt-2">
                          <Info className="h-3 w-3 inline mr-1" />
                          Proportions adjusted from original recipe (serves {selectedRecipe.baseServings || selectedRecipe.servings})
                        </p>
                      )}
                    </Card>

                    {/* Voice & Download Controls */}
                    <Card className="p-4 mb-6 bg-gradient-to-r from-[var(--saffron)]/5 to-[var(--tech-blue)]/5">
                      <div className="flex flex-col sm:flex-row gap-3">
                        <div className="flex items-center gap-2 flex-1">
                          <Globe className="h-4 w-4 text-muted-foreground" />
                          <Select value={voiceLanguage} onValueChange={setVoiceLanguage}>
                            <SelectTrigger className="flex-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {languageOptions.map(lang => (
                                <SelectItem key={lang.value} value={lang.value}>
                                  {lang.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={isSpeaking ? stopSpeaking : speakRecipe}
                            style={isSpeaking ? { borderColor: 'var(--saffron)' } : {}}
                          >
                            {isSpeaking ? (
                              <>
                                <StopCircle className="h-4 w-4 mr-2 animate-pulse" />
                                Stop
                              </>
                            ) : (
                              <>
                                <Volume2 className="h-4 w-4 mr-2" />
                                Speak Recipe
                              </>
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={downloadRecipe}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </Card>

                    {/* Ingredients */}
                    <div className="mb-6">
                      <h3 className="text-xl mb-4 flex items-center gap-2">
                        <ChefHat className="h-5 w-5" style={{ color: 'var(--saffron)' }} />
                        Ingredients
                      </h3>
                      <div className="space-y-3">
                        {((translatedRecipe || selectedRecipe)?.ingredients || []).map((ingredient: any, index: number) => (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                          >
                            <Card className="p-4">
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Check className="h-4 w-4" style={{ color: 'var(--green)' }} />
                                    {/* Handle both mockRecipes (object) and restaurantRecipes (string) structure */}
                                    <span>{typeof ingredient === 'string' ? ingredient : ingredient.name}</span>
                                  </div>
                                  {typeof ingredient === 'object' && ingredient.amount && (
                                    <p className="text-muted-foreground ml-6">
                                      {calculateScaledAmount(ingredient.amount, selectedRecipe.baseServings || selectedRecipe.servings)} {ingredient.unit}
                                    </p>
                                  )}
                                </div>
                                {typeof ingredient === 'object' && ingredient.alternatives && ingredient.alternatives.length > 0 && (
                                  <div className="text-xs">
                                    <Badge variant="secondary" className="mb-1">Alternatives</Badge>
                                    <div className="text-muted-foreground space-y-1">
                                      {ingredient.alternatives.map((alt: string, altIndex: number) => (
                                        <div key={altIndex}>• {alt}</div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            </Card>
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    <Separator className="my-6" />

                    {/* Cooking Steps */}
                    {((translatedRecipe || selectedRecipe)?.steps || []).length > 0 && (
                      <div className="mb-6">
                        <h3 className="text-xl mb-4 flex items-center gap-2">
                          <Sparkles className="h-5 w-5" style={{ color: 'var(--tech-blue)' }} />
                          Cooking Steps
                        </h3>
                        <div className="space-y-3">
                          {((translatedRecipe || selectedRecipe)?.steps || []).map((step: string, index: number) => (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.05 }}
                          >
                            <Card className="p-4">
                              <div className="flex gap-3">
                                <div 
                                  className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-white"
                                  style={{ background: 'var(--tech-blue)' }}
                                >
                                  {index + 1}
                                </div>
                                <p className="flex-1 pt-1">{step}</p>
                              </div>
                            </Card>
                          </motion.div>
                        ))}
                        </div>
                      </div>
                    )}

                    {/* Note if steps are not available */}
                    {!((translatedRecipe || selectedRecipe)?.steps || []).length && (
                      <Card className="p-4 mb-6" style={{ borderColor: 'var(--tech-blue)', borderWidth: 2 }}>
                        <div className="flex items-start gap-3">
                          <Info className="h-5 w-5 mt-0.5" style={{ color: 'var(--tech-blue)' }} />
                          <div>
                            <p className="mb-2">
                              Detailed cooking steps are not available for this restaurant recipe.
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Click "Ask AI for Help" below to get personalized cooking instructions from our AI assistant!
                            </p>
                          </div>
                        </div>
                      </Card>
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <Button
                        className="flex-1"
                        onClick={() => {
                          onRecipeSelect(selectedRecipe);
                          setSelectedRecipe(null);
                        }}
                        style={{ background: 'linear-gradient(135deg, var(--tech-blue), var(--tech-blue-light))' }}
                      >
                        <Sparkles className="mr-2 h-4 w-4" />
                        Ask AI for Help
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setSelectedRecipe(null)}
                      >
                        Close
                      </Button>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </DialogContent>
          </Dialog>
        )}
      </AnimatePresence>

      {/* Footer */}
      {onNavigate && <Footer onNavigate={onNavigate} />}
    </div>
  );
}
