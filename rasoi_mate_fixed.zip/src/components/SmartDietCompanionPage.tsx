import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Slider } from './ui/slider';
import { Progress } from './ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Switch } from './ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from './ui/dialog';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  User, 
  Edit, 
  Activity, 
  Dumbbell, 
  Heart, 
  Bike, 
  Flame,
  Apple,
  Coffee,
  Utensils,
  Moon,
  Sun,
  Sparkles,
  Mic,
  TrendingUp,
  Calendar,
  Clock,
  ChevronDown,
  ChevronUp,
  Target,
  Zap,
  Lock,
  LogIn,
  UserPlus,
  MessageCircle,
  Link as LinkIcon,
  Check,
  Upload,
  Send
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useAuth } from './AuthContext';
import { toast } from 'sonner@2.0.3';
import { getMealPlanRecipes, calculateBMR, calculateDailyCalories, allRestaurantRecipes } from './data/restaurantRecipes';
import { AIChatbot } from './AIChatbot';
import { RecipeDetailDialog, type DetailedRecipe } from './RecipeDetailDialog';
import { Footer } from './Footer';

interface MealPlan {
  id: string;
  name: string;
  time: string;
  image: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  tags: string[];
  customized: boolean;
}

interface WorkoutActivity {
  id: string;
  name: string;
  icon: any;
  duration: number;
  caloriesBurned: number;
  time: string;
}

interface SmartDietCompanionPageProps {
  onNavigate?: (page: string) => void;
}

export function SmartDietCompanionPage({ onNavigate }: SmartDietCompanionPageProps) {
  const { user, isLoggedIn, updateHealthProfile } = useAuth();
  const [editProfileOpen, setEditProfileOpen] = useState(false);
  const [selectedWorkout, setSelectedWorkout] = useState('');
  const [workoutDuration, setWorkoutDuration] = useState(30);
  const [autoSync, setAutoSync] = useState(false);
  const [googleFitConnected, setGoogleFitConnected] = useState(false);
  const [expandedMeal, setExpandedMeal] = useState<string | null>(null);
  const [dailyScore, setDailyScore] = useState(78);
  const [calorieGoal, setCalorieGoal] = useState(2000);
  const [caloriesConsumed, setCaloriesConsumed] = useState(1456);
  const [chatbotOpen, setChatbotOpen] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<DetailedRecipe | null>(null);
  const [editRoutineOpen, setEditRoutineOpen] = useState(false);
  const [dietQuery, setDietQuery] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Edit form states
  const [editForm, setEditForm] = useState({
    gender: '',
    age: 0,
    weight: 0,
    height: 0,
    goal: '',
    activityLevel: '',
    dietaryPreference: ''
  });

  // Initialize edit form when user data is available
  useEffect(() => {
    if (user?.healthProfile) {
      setEditForm({
        gender: user.healthProfile.gender || '',
        age: user.healthProfile.age || 0,
        weight: user.healthProfile.weight || 0,
        height: user.healthProfile.height || 0,
        goal: user.healthProfile.goal || '',
        activityLevel: user.healthProfile.activityLevel || '',
        dietaryPreference: user.healthProfile.dietaryPreference || ''
      });
    }
  }, [user]);

  // Initialize speech recognition for diet queries
  useEffect(() => {
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-IN';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setDietQuery(transcript);
        toast.success(`Heard: "${transcript}"`);
        handleDietQuery(transcript);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        toast.error('Could not understand. Please try again.');
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  // Calculate calorie goal based on user profile
  useEffect(() => {
    if (user?.healthProfile && user.healthProfile.weight > 0) {
      const baseCalories = user.healthProfile.gender === 'male' ? 2000 : 1800;
      const activityMultiplier = {
        'sedentary': 1.2,
        'light': 1.375,
        'moderate': 1.55,
        'active': 1.725,
        'very-active': 1.9
      };
      const multiplier = activityMultiplier[user.healthProfile.activityLevel as keyof typeof activityMultiplier] || 1.2;
      const calculatedGoal = Math.round(baseCalories * multiplier);
      
      if (user.healthProfile.goal === 'weight-loss') {
        setCalorieGoal(calculatedGoal - 500);
      } else if (user.healthProfile.goal === 'weight-gain') {
        setCalorieGoal(calculatedGoal + 500);
      } else {
        setCalorieGoal(calculatedGoal);
      }
    }
  }, [user?.healthProfile]);

  // Today's Activities
  const [todayActivities, setTodayActivities] = useState<WorkoutActivity[]>([]);

  // Generate dynamic meal plans based on user profile and restaurant recipes
  const [mealPlans, setMealPlans] = useState<MealPlan[]>([]);
  
  useEffect(() => {
    if (user?.healthProfile && user.healthProfile.weight > 0 && user.healthProfile.age > 0) {
      // Calculate BMR and daily calorie needs
      const bmr = calculateBMR(
        user.healthProfile.gender || 'male',
        user.healthProfile.age,
        user.healthProfile.weight,
        user.healthProfile.height || 170
      );
      
      const dailyCalories = calculateDailyCalories(
        bmr,
        user.healthProfile.activityLevel || 'moderate',
        user.healthProfile.goal || 'maintain'
      );
      
      // Get personalized meal plan from restaurant recipes
      const mealPlan = getMealPlanRecipes(
        dailyCalories,
        user.healthProfile.dietaryPreference || 'vegetarian',
        {
          spiceLevel: 'medium'
        }
      );
      
      // Convert restaurant recipes to MealPlan format
      const generatedMeals: MealPlan[] = [
        {
          id: 'breakfast',
          name: mealPlan.breakfast.name,
          time: '8:00 AM',
          image: 'https://images.unsplash.com/photo-1630409351211-d62ab2d24da4?w=400',
          calories: mealPlan.breakfast.calories,
          protein: mealPlan.breakfast.protein,
          carbs: mealPlan.breakfast.carbs,
          fats: mealPlan.breakfast.fats,
          tags: mealPlan.breakfast.tags,
          customized: true
        },
        {
          id: 'lunch',
          name: mealPlan.lunch.name,
          time: '1:00 PM',
          image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400',
          calories: mealPlan.lunch.calories,
          protein: mealPlan.lunch.protein,
          carbs: mealPlan.lunch.carbs,
          fats: mealPlan.lunch.fats,
          tags: mealPlan.lunch.tags,
          customized: true
        },
        {
          id: 'snack',
          name: mealPlan.snack.name,
          time: '4:30 PM',
          image: 'https://images.unsplash.com/photo-1599490659213-e2b9527c8838?w=400',
          calories: mealPlan.snack.calories,
          protein: mealPlan.snack.protein,
          carbs: mealPlan.snack.carbs,
          fats: mealPlan.snack.fats,
          tags: mealPlan.snack.tags,
          customized: true
        },
        {
          id: 'dinner',
          name: mealPlan.dinner.name,
          time: '8:00 PM',
          image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400',
          calories: mealPlan.dinner.calories,
          protein: mealPlan.dinner.protein,
          carbs: mealPlan.dinner.carbs,
          fats: mealPlan.dinner.fats,
          tags: mealPlan.dinner.tags,
          customized: true
        }
      ];
      
      setMealPlans(generatedMeals);
      setCaloriesConsumed(mealPlan.totalCalories);
    }
  }, [user?.healthProfile, calorieGoal]);

  // AI Suggestions
  const aiSuggestions = [
    `🔥 Based on your ${user?.healthProfile?.goal || 'goal'}, I've selected from 1000+ authentic 5-star restaurant recipes!`,
    `💡 Your ${user?.healthProfile?.dietaryPreference || 'dietary preference'} meal plan includes dishes from top Indian restaurants.`,
    `✨ All ${mealPlans.length} meals are tailored to your ${calorieGoal} calorie target and nutritional needs!`
  ];

  // Workout Options
  const workoutOptions = [
    { id: 'yoga', name: 'Yoga', icon: Heart, color: '#FF9933' },
    { id: 'gym', name: 'Gym', icon: Dumbbell, color: '#3F51B5' },
    { id: 'running', name: 'Running', icon: Activity, color: '#4CAF50' },
    { id: 'cycling', name: 'Cycling', icon: Bike, color: '#FF9933' },
    { id: 'meditation', name: 'Meditation', icon: Sparkles, color: '#3F51B5' }
  ];

  // Daily Timeline
  const dailyTimeline = [
    { time: '6:00 AM', icon: Sun, label: 'Wake Up', color: '#FF9933' },
    { time: '8:00 AM', icon: Coffee, label: 'Breakfast', color: '#4CAF50' },
    { time: '1:00 PM', icon: Utensils, label: 'Lunch', color: '#3F51B5' },
    { time: '4:30 PM', icon: Apple, label: 'Snack', color: '#FF9933' },
    { time: '8:00 PM', icon: Utensils, label: 'Dinner', color: '#4CAF50' },
    { time: '11:00 PM', icon: Moon, label: 'Sleep', color: '#3F51B5' }
  ];

  const handleAddWorkout = () => {
    if (selectedWorkout) {
      const workout = workoutOptions.find(w => w.id === selectedWorkout);
      if (workout) {
        const newActivity: WorkoutActivity = {
          id: Date.now().toString(),
          name: workout.name,
          icon: workout.icon,
          duration: workoutDuration,
          caloriesBurned: Math.round(workoutDuration * 5),
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
        };
        setTodayActivities([...todayActivities, newActivity]);
        toast.success(`${workout.name} added to today's activities!`);
        setSelectedWorkout('');
      }
    }
  };

  const handleSaveProfile = () => {
    if (!editForm.weight || editForm.weight <= 0) {
      toast.error('Please enter a valid weight');
      return;
    }
    if (!editForm.age || editForm.age <= 0) {
      toast.error('Please enter a valid age');
      return;
    }

    updateHealthProfile(editForm);
    setEditProfileOpen(false);
    
    // Regenerate plan
    setTimeout(() => {
      setDailyScore(Math.floor(Math.random() * 20) + 75);
      toast.success('Diet plan updated based on your new profile! 🎯');
    }, 500);
  };

  const handleGenerateNewPlan = () => {
    toast.success('Generating new personalized diet plan...');
    setTimeout(() => {
      setDailyScore(Math.floor(Math.random() * 20) + 75);
      toast.success('New diet plan generated based on your latest activity!');
    }, 1500);
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      try {
        setIsListening(true);
        recognitionRef.current.start();
        toast.info('🎤 Listening... Speak now!');
      } catch (error) {
        console.error('Error starting recognition:', error);
        setIsListening(false);
        toast.error('Microphone access denied or not available');
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const handleDietQuery = (query: string) => {
    if (!query.trim()) {
      toast.error('Please enter a question');
      return;
    }

    // Generate AI response based on user profile
    const lowerQuery = query.toLowerCase();
    let response = '';

    if (lowerQuery.includes('calorie') || lowerQuery.includes('calories')) {
      response = `Based on your profile, your daily calorie goal is ${calorieGoal} calories. You've consumed ${caloriesConsumed} calories today. ${netCalories > 0 ? `You have ${netCalories} net calories remaining.` : 'Great job staying within your goal!'}`;
    } else if (lowerQuery.includes('protein') || lowerQuery.includes('macro')) {
      const totalProtein = mealPlans.reduce((sum, meal) => sum + meal.protein, 0);
      response = `Your meal plan today includes ${totalProtein}g of protein. This is distributed across: ${mealPlans.map(m => `${m.name} (${m.protein}g)`).join(', ')}.`;
    } else if (lowerQuery.includes('workout') || lowerQuery.includes('exercise')) {
      response = `You've completed ${todayActivities.length} workout${todayActivities.length !== 1 ? 's' : ''} today, burning ${totalCaloriesBurned} calories. ${todayActivities.length === 0 ? 'Try adding a workout to boost your daily activity!' : 'Great work staying active!'}`;
    } else if (lowerQuery.includes('meal') || lowerQuery.includes('food')) {
      response = `Your personalized meal plan includes: ${mealPlans.map(m => `${m.name} (${m.calories} cal)`).join(', ')}. All meals are customized for your ${user?.healthProfile?.dietaryPreference || 'dietary'} preferences!`;
    } else if (lowerQuery.includes('goal') || lowerQuery.includes('target')) {
      response = `Your current goal is ${user?.healthProfile?.goal?.replace('-', ' ') || 'not set'}. ${user?.healthProfile?.goal === 'weight-loss' ? `You're on track with a ${calorieGoal} calorie diet.` : user?.healthProfile?.goal === 'weight-gain' ? `You're following a ${calorieGoal} calorie plan to support muscle growth.` : 'Keep maintaining your balanced lifestyle!'}`;
    } else if (lowerQuery.includes('score') || lowerQuery.includes('progress')) {
      response = `Your Rasoi Score today is ${dailyScore}/100! ${dailyScore >= 80 ? '🌟 Excellent work!' : dailyScore >= 60 ? '👍 Good progress!' : '💪 Keep it up!'} You're maintaining a balanced diet and staying active.`;
    } else {
      response = `I can help you with:\n• Your daily calorie intake and goals\n• Meal plan details and macros\n• Workout tracking and calories burned\n• Progress and Rasoi Score\n\nWhat would you like to know about your diet plan?`;
    }

    setAiResponse(response);
    toast.success('AI Response generated!');
    
    // Clear query after processing
    setTimeout(() => setDietQuery(''), 500);
  };

  const totalCaloriesBurned = todayActivities.reduce((sum, activity) => sum + activity.caloriesBurned, 0);
  const netCalories = caloriesConsumed - totalCaloriesBurned;
  const progressPercentage = (caloriesConsumed / calorieGoal) * 100;

  const isProfileComplete = user?.healthProfile && 
    user.healthProfile.age > 0 && 
    user.healthProfile.weight > 0 && 
    user.healthProfile.goal !== '';

  // Locked State Component
  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="container mx-auto max-w-3xl"
        >
          <Card className="p-12 rounded-3xl shadow-2xl border-2 text-center relative overflow-hidden">
            {/* Decorative background elements */}
            <div className="absolute inset-0 opacity-5">
              <div className="absolute top-10 left-10 w-32 h-32 rounded-full" style={{ background: '#FF9933' }} />
              <div className="absolute bottom-10 right-10 w-40 h-40 rounded-full" style={{ background: '#4CAF50' }} />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full" style={{ background: '#3F51B5' }} />
            </div>

            <div className="relative z-10 space-y-8">
              {/* Lock Icon */}
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: 'spring' }}
                className="mx-auto w-32 h-32 rounded-full flex items-center justify-center"
                style={{ 
                  background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
                  boxShadow: '0 10px 40px rgba(255, 153, 51, 0.3)'
                }}
              >
                <Lock className="w-16 h-16 text-white" />
              </motion.div>

              {/* Title */}
              <div className="space-y-4">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <h1 style={{
                    background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    backgroundClip: 'text',
                  }}>
                    Smart Diet Companion
                  </h1>
                </motion.div>

                <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="text-xl text-muted-foreground max-w-lg mx-auto"
                >
                  Sign in to unlock your personalized Rasoi diet plan
                </motion.p>
              </div>

              {/* Features Preview */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="grid md:grid-cols-3 gap-4 py-6"
              >
                <div className="p-4 rounded-2xl" style={{ background: '#FF993311' }}>
                  <Target className="w-8 h-8 mx-auto mb-2" style={{ color: '#FF9933' }} />
                  <p className="text-sm">Personalized Goals</p>
                </div>
                <div className="p-4 rounded-2xl" style={{ background: '#4CAF5011' }}>
                  <Activity className="w-8 h-8 mx-auto mb-2" style={{ color: '#4CAF50' }} />
                  <p className="text-sm">Track Workouts</p>
                </div>
                <div className="p-4 rounded-2xl" style={{ background: '#3F51B511' }}>
                  <Utensils className="w-8 h-8 mx-auto mb-2" style={{ color: '#3F51B5' }} />
                  <p className="text-sm">Smart Meal Plans</p>
                </div>
              </motion.div>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="flex flex-col sm:flex-row gap-4 justify-center pt-4"
              >
                <Button
                  size="lg"
                  onClick={() => onNavigate?.('login')}
                  className="rounded-full shadow-xl"
                  style={{ 
                    background: 'linear-gradient(135deg, #FF9933, #4CAF50)',
                    color: 'white'
                  }}
                >
                  <LogIn className="mr-2 w-5 h-5" />
                  Login to Continue
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => onNavigate?.('signup')}
                  className="rounded-full border-2"
                  style={{ borderColor: '#3F51B5', color: '#3F51B5' }}
                >
                  <UserPlus className="mr-2 w-5 h-5" />
                  Create Account
                </Button>
              </motion.div>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="text-sm text-muted-foreground"
              >
                Join thousands of users achieving their health goals with Rasoi Mate! 🎯
              </motion.p>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  // Main Content (Logged In)
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 dark:from-gray-900 dark:to-gray-800 py-12 px-4">
      <div className="container mx-auto max-w-7xl space-y-8">
        
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <div className="flex items-center justify-center gap-3">
            <Sparkles className="w-10 h-10" style={{ color: '#FF9933' }} />
            <h1 style={{
              background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}>
              Smart Diet Companion
            </h1>
          </div>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Welcome back, {user?.name}! Your personalized meal plans are ready.
          </p>
        </motion.div>

        {/* Profile Incomplete Warning */}
        {!isProfileComplete && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="p-6 rounded-2xl border-2" style={{ 
              borderColor: '#FF9933',
              background: 'linear-gradient(135deg, #FF993311, #4CAF5011)'
            }}>
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-full" style={{ background: '#FF9933' }}>
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3>Complete Your Health Profile</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Add your details to get personalized meal plans and nutrition recommendations!
                  </p>
                  <Button
                    onClick={() => setEditProfileOpen(true)}
                    className="mt-3 rounded-full"
                    style={{ background: '#FF9933', color: 'white' }}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Complete Profile
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        )}

        {/* User Profile Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-6 hover-lift rounded-3xl shadow-lg border-2">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <Avatar className="w-24 h-24 border-4 shadow-lg" style={{ borderColor: '#FF9933' }}>
                <AvatarImage src={user?.avatar} />
                <AvatarFallback style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)' }}>
                  {user?.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="flex items-center gap-2">
                      {user?.name}
                      {isProfileComplete && (
                        <Badge style={{ background: '#4CAF50', color: 'white' }}>
                          {user.healthProfile?.activityLevel?.replace('-', ' ') || 'Active'}
                        </Badge>
                      )}
                    </h3>
                    {isProfileComplete ? (
                      <div className="flex flex-wrap gap-4 mt-2 text-muted-foreground">
                        {user.healthProfile?.gender && (
                          <span>Gender: {user.healthProfile.gender.charAt(0).toUpperCase() + user.healthProfile.gender.slice(1)}</span>
                        )}
                        {user.healthProfile?.age > 0 && (
                          <span>Age: {user.healthProfile.age}</span>
                        )}
                        {user.healthProfile?.weight > 0 && (
                          <span>Weight: {user.healthProfile.weight}kg</span>
                        )}
                        {user.healthProfile?.goal && (
                          <span>Goal: {user.healthProfile.goal.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                        )}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground mt-2">
                        Complete your profile to get started
                      </p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setEditProfileOpen(true)}
                    className="rounded-full"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <Sparkles className="w-4 h-4" style={{ color: '#FF9933' }} />
                  Rasoi Mate customizes your meals based on this data.
                </p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Only show the rest of the content if profile is complete */}
        {isProfileComplete ? (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column - Activities and Meals */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* Routine & Workout Section */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="p-6 rounded-3xl shadow-lg hover-lift border-2">
                  <div className="flex items-center gap-3 mb-6">
                    <Activity className="w-6 h-6" style={{ color: '#3F51B5' }} />
                    <h3>Today's Activity</h3>
                  </div>

                  {/* Workout Type Selection */}
                  <div className="space-y-4 mb-6">
                    <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                      {workoutOptions.map((workout) => (
                        <motion.button
                          key={workout.id}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => setSelectedWorkout(workout.id)}
                          className={`flex flex-col items-center gap-2 p-4 rounded-2xl border-2 transition-all ${
                            selectedWorkout === workout.id 
                              ? 'border-primary shadow-lg' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          style={{
                            background: selectedWorkout === workout.id 
                              ? `linear-gradient(135deg, ${workout.color}22, ${workout.color}11)` 
                              : 'transparent'
                          }}
                        >
                          <workout.icon className="w-6 h-6" style={{ color: workout.color }} />
                          <span className="text-xs">{workout.name}</span>
                        </motion.button>
                      ))}
                    </div>

                    {/* Duration Slider */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <label>Duration: {workoutDuration} minutes</label>
                        <span className="text-muted-foreground">~{workoutDuration * 5} cal</span>
                      </div>
                      <Slider
                        value={[workoutDuration]}
                        onValueChange={(value) => setWorkoutDuration(value[0])}
                        min={10}
                        max={120}
                        step={5}
                        className="w-full"
                      />
                    </div>

                    <div className="flex items-center justify-between flex-wrap gap-4">
                      <Button 
                        onClick={handleAddWorkout}
                        disabled={!selectedWorkout}
                        className="rounded-full"
                        style={{ 
                          background: selectedWorkout ? 'linear-gradient(135deg, #FF9933, #4CAF50)' : undefined,
                          color: 'white'
                        }}
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Add Workout
                      </Button>
                      
                      <div className="flex flex-col gap-3">
                        <div className="flex items-center gap-2">
                          <Switch checked={autoSync} onCheckedChange={setAutoSync} />
                          <span className="text-sm">Auto Sync with Fitness App</span>
                        </div>
                        <Button
                          variant={googleFitConnected ? "default" : "outline"}
                          size="sm"
                          onClick={() => {
                            if (!googleFitConnected) {
                              toast.success('Connecting to Google Fit...');
                              setTimeout(() => {
                                setGoogleFitConnected(true);
                                toast.success('Google Fit connected successfully! 🎯');
                              }, 1500);
                            } else {
                              setGoogleFitConnected(false);
                              toast.info('Google Fit disconnected');
                            }
                          }}
                          className="rounded-full"
                          style={googleFitConnected ? { background: '#4CAF50', color: 'white' } : {}}
                        >
                          {googleFitConnected ? (
                            <>
                              <Check className="w-4 h-4 mr-2" />
                              Google Fit Connected
                            </>
                          ) : (
                            <>
                              <LinkIcon className="w-4 h-4 mr-2" />
                              Connect Google Fit
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Today's Activities List */}
                  {todayActivities.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="flex items-center gap-2">
                        <Flame className="w-5 h-5" style={{ color: '#FF9933' }} />
                        Completed Activities
                      </h4>
                      <div className="space-y-2">
                        {todayActivities.map((activity) => (
                          <div
                            key={activity.id}
                            className="flex items-center justify-between p-3 rounded-xl bg-muted/50 border"
                          >
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-full" style={{ background: '#FF993322' }}>
                                <activity.icon className="w-5 h-5" style={{ color: '#FF9933' }} />
                              </div>
                              <div>
                                <p className="text-sm">{activity.name}</p>
                                <p className="text-xs text-muted-foreground">{activity.time}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm">{activity.duration} min</p>
                              <p className="text-xs text-muted-foreground">-{activity.caloriesBurned} cal</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Daily Timeline */}
                  <div className="mt-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="flex items-center gap-2">
                        <Clock className="w-5 h-5" style={{ color: '#4CAF50' }} />
                        Daily Routine Timeline
                      </h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditRoutineOpen(true)}
                        className="rounded-full"
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Routine
                      </Button>
                    </div>
                    <div className="relative">
                      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gradient-to-b from-saffron via-green to-tech-blue" />
                      
                      <div className="space-y-4">
                        {dailyTimeline.map((item, index) => (
                          <motion.div
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 0.3 + index * 0.05 }}
                            className="flex items-center gap-4 relative"
                          >
                            <div 
                              className="w-8 h-8 rounded-full flex items-center justify-center z-10 border-2 border-white shadow-md"
                              style={{ background: item.color }}
                            >
                              <item.icon className="w-4 h-4 text-white" />
                            </div>
                            <div className="flex-1 flex items-center justify-between p-3 rounded-xl bg-muted/30">
                              <span className="text-sm">{item.label}</span>
                              <span className="text-xs text-muted-foreground">{item.time}</span>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>

              {/* Personalized Diet Plan Section */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
              >
                <Card className="p-6 rounded-3xl shadow-lg hover-lift border-2">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <Utensils className="w-6 h-6" style={{ color: '#4CAF50' }} />
                      <h3>Your Personalized Diet Plan</h3>
                    </div>
                    <Badge style={{ background: '#4CAF50', color: 'white' }}>
                      Customized for You
                    </Badge>
                  </div>

                  <div className="space-y-4">
                    {mealPlans.map((meal, index) => (
                      <motion.div
                        key={meal.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4 + index * 0.1 }}
                      >
                        <Card className="overflow-hidden hover-lift border-2 rounded-2xl">
                          <div
                            className="p-4 cursor-pointer"
                            onClick={() => setExpandedMeal(expandedMeal === meal.id ? null : meal.id)}
                          >
                            <div className="flex items-start gap-4">
                              <div className="relative w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 shadow-md">
                                <ImageWithFallback
                                  src={meal.image}
                                  alt={meal.name}
                                  className="w-full h-full object-cover"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                                <div className="absolute bottom-1 right-1 bg-white/90 rounded-full px-2 py-0.5">
                                  <span className="text-xs">{meal.time}</span>
                                </div>
                              </div>

                              <div className="flex-1 space-y-2">
                                <div className="flex items-start justify-between">
                                  <div>
                                    <h4 className="mb-1">{meal.name}</h4>
                                    <div className="flex flex-wrap gap-1">
                                      {meal.tags.slice(0, 2).map((tag, i) => (
                                        <Badge key={i} variant="outline" className="text-xs">
                                          {tag}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                  {expandedMeal === meal.id ? (
                                    <ChevronUp className="w-5 h-5 text-muted-foreground" />
                                  ) : (
                                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                                  )}
                                </div>

                                <div className="flex items-center gap-4 text-sm">
                                  <span className="flex items-center gap-1">
                                    <Flame className="w-4 h-4" style={{ color: '#FF9933' }} />
                                    {meal.calories} cal
                                  </span>
                                  <span>P: {meal.protein}g</span>
                                  <span>C: {meal.carbs}g</span>
                                  <span>F: {meal.fats}g</span>
                                </div>
                              </div>
                            </div>

                            <AnimatePresence>
                              {expandedMeal === meal.id && (
                                <motion.div
                                  initial={{ opacity: 0, height: 0 }}
                                  animate={{ opacity: 1, height: 'auto' }}
                                  exit={{ opacity: 0, height: 0 }}
                                  className="mt-4 pt-4 border-t space-y-3"
                                >
                                  {/* Macros Breakdown */}
                                  <div className="grid grid-cols-3 gap-3">
                                    <div className="text-center p-3 rounded-xl" style={{ background: '#FF993311' }}>
                                      <p className="text-xs text-muted-foreground">Protein</p>
                                      <p className="font-medium">{meal.protein}g</p>
                                      <Progress 
                                        value={(meal.protein / 50) * 100} 
                                        className="h-1 mt-1"
                                      />
                                    </div>
                                    <div className="text-center p-3 rounded-xl" style={{ background: '#4CAF5011' }}>
                                      <p className="text-xs text-muted-foreground">Carbs</p>
                                      <p className="font-medium">{meal.carbs}g</p>
                                      <Progress 
                                        value={(meal.carbs / 100) * 100} 
                                        className="h-1 mt-1"
                                      />
                                    </div>
                                    <div className="text-center p-3 rounded-xl" style={{ background: '#3F51B511' }}>
                                      <p className="text-xs text-muted-foreground">Fats</p>
                                      <p className="font-medium">{meal.fats}g</p>
                                      <Progress 
                                        value={(meal.fats / 30) * 100} 
                                        className="h-1 mt-1"
                                      />
                                    </div>
                                  </div>

                                  <div className="flex gap-2">
                                    <Button 
                                      className="flex-1 rounded-full"
                                      style={{ 
                                        background: 'linear-gradient(135deg, #FF9933, #4CAF50)',
                                        color: 'white'
                                      }}
                                      onClick={() => {
                                        // Find the recipe from allRestaurantRecipes
                                        const recipe = allRestaurantRecipes.find(r => r.name === meal.name);
                                        if (recipe) {
                                          setSelectedRecipe({
                                            name: recipe.name,
                                            type: recipe.category,
                                            description: recipe.description,
                                            state: 'Multi-regional',
                                            district: 'India',
                                            time: `${recipe.prepTime} mins`,
                                            servings: `${recipe.servings} people`,
                                            difficulty: recipe.prepTime < 20 ? 'Easy' : recipe.prepTime < 40 ? 'Medium' : 'Hard',
                                            ingredients: recipe.ingredients,
                                            steps: [
                                              'Gather all ingredients listed above.',
                                              'Prepare ingredients according to recipe requirements.',
                                              'Follow traditional cooking methods for best results.',
                                              'Cook with love and patience for authentic flavors.',
                                              'Serve hot with suggested accompaniments.'
                                            ],
                                            tags: recipe.tags,
                                            culturalNote: `This dish from ${recipe.restaurant || 'renowned restaurants'} represents the authentic flavors of ${recipe.cuisine} cuisine.`,
                                            healthBenefits: recipe.healthBenefits
                                          });
                                        }
                                      }}
                                    >
                                      View Recipe
                                    </Button>
                                    <Button variant="outline" className="rounded-full">
                                      <Heart className="w-4 h-4" />
                                    </Button>
                                  </div>

                                  <div className="text-xs text-muted-foreground italic p-2 rounded-lg bg-muted/50 flex items-center gap-2">
                                    <Sparkles className="w-4 h-4" style={{ color: '#FF9933' }} />
                                    Customized for your {user.healthProfile?.goal?.replace('-', ' ')} goal and {todayActivities.length > 0 ? 'workout' : 'rest day'}.
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </Card>
              </motion.div>
            </div>

            {/* Right Column - AI and Analytics */}
            <div className="space-y-6">
              
              {/* AI Suggestion Box */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Card className="p-6 rounded-3xl shadow-lg hover-lift border-2" style={{
                  background: 'linear-gradient(135deg, #FF993311, #4CAF5011)'
                }}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-full" style={{ background: '#FF9933' }}>
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <h3>AI Suggestions</h3>
                  </div>

                  <div className="space-y-3 mb-4">
                    {aiSuggestions.map((suggestion, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.5 + index * 0.1 }}
                        className="p-3 rounded-xl bg-white dark:bg-gray-800 shadow-sm border"
                      >
                        <p className="text-sm">{suggestion}</p>
                      </motion.div>
                    ))}
                  </div>

                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <Input 
                        value={dietQuery}
                        onChange={(e) => setDietQuery(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && dietQuery.trim()) {
                            handleDietQuery(dietQuery);
                          }
                        }}
                        placeholder="Ask anything about your diet..."
                        className="flex-1 rounded-full"
                      />
                      <Button 
                        size="icon" 
                        onClick={() => dietQuery.trim() && handleDietQuery(dietQuery)}
                        disabled={!dietQuery.trim()}
                        className="rounded-full flex-shrink-0" 
                        style={{ 
                          background: dietQuery.trim() 
                            ? 'linear-gradient(135deg, #3F51B5, #5C6BC0)' 
                            : undefined,
                          color: 'white'
                        }}
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                      <Button 
                        size="icon" 
                        onClick={isListening ? stopListening : startListening}
                        className="rounded-full flex-shrink-0" 
                        style={{ 
                          background: isListening 
                            ? 'linear-gradient(135deg, #FF9933, #F44336)' 
                            : 'linear-gradient(135deg, #FF9933, #4CAF50)',
                          color: 'white'
                        }}
                      >
                        <Mic className={`w-4 h-4 ${isListening ? 'animate-pulse' : ''}`} />
                      </Button>
                    </div>
                    
                    {/* AI Response Display */}
                    <AnimatePresence>
                      {aiResponse && (
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="p-4 rounded-xl bg-white dark:bg-gray-800 shadow-md border-2"
                          style={{ borderColor: '#4CAF50' }}
                        >
                          <div className="flex items-start gap-2 mb-2">
                            <Sparkles className="w-4 h-4 mt-1 flex-shrink-0" style={{ color: '#FF9933' }} />
                            <div className="flex-1">
                              <p className="text-sm whitespace-pre-line">{aiResponse}</p>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setAiResponse(null)}
                              className="h-6 w-6 p-0 rounded-full"
                            >
                              ✕
                            </Button>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                    
                    <p className="text-xs text-muted-foreground text-center">
                      {isListening ? '🎤 Listening... Speak now!' : 'Voice or text - I\'m here to help! 🎤'}
                    </p>
                  </div>
                </Card>
              </motion.div>

              {/* Recipe Database Stats */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.45 }}
              >
                <Card className="p-6 rounded-3xl shadow-lg hover-lift border-2" style={{
                  background: 'linear-gradient(135deg, #3F51B511, #FF993311)'
                }}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-full" style={{ background: '#3F51B5' }}>
                      <Utensils className="w-5 h-5 text-white" />
                    </div>
                    <h3>Recipe Database</h3>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 text-center">
                      <div className="text-3xl mb-1" style={{ color: '#FF9933' }}>1000+</div>
                      <div className="text-xs text-muted-foreground">Total Recipes</div>
                    </div>
                    <div className="p-4 rounded-2xl bg-white dark:bg-gray-800 text-center">
                      <div className="text-3xl mb-1" style={{ color: '#4CAF50' }}>50+</div>
                      <div className="text-xs text-muted-foreground">Restaurants</div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Your dietary preference:</span>
                      <Badge style={{ background: '#4CAF50', color: 'white' }}>
                        {user?.healthProfile?.dietaryPreference || 'Vegetarian'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Recipes match:</span>
                      <span style={{ color: '#FF9933' }}>
                        {allRestaurantRecipes.filter(r => 
                          r.dietType === user?.healthProfile?.dietaryPreference || 
                          r.dietType === 'vegan'
                        ).length}+ dishes
                      </span>
                    </div>
                  </div>
                </Card>
              </motion.div>

              {/* Analytics Section */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 }}
              >
                <Card className="p-6 rounded-3xl shadow-lg hover-lift border-2">
                  <div className="flex items-center gap-3 mb-6">
                    <TrendingUp className="w-6 h-6" style={{ color: '#3F51B5' }} />
                    <h3>Health Analytics</h3>
                  </div>

                  {/* Rasoi Score */}
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Rasoi Score</span>
                      <span className="text-2xl font-bold" style={{ color: '#4CAF50' }}>
                        {dailyScore}/100
                      </span>
                    </div>
                    <Progress value={dailyScore} className="h-3 rounded-full" />
                    <p className="text-xs text-muted-foreground mt-2">
                      Great job! You're maintaining a balanced diet. 🎯
                    </p>
                  </div>

                  {/* Calorie Tracking */}
                  <div className="space-y-4 mb-6">
                    <div className="text-center">
                      <div className="relative inline-flex items-center justify-center">
                        <svg className="w-32 h-32 transform -rotate-90">
                          <circle
                            cx="64"
                            cy="64"
                            r="56"
                            stroke="currentColor"
                            strokeWidth="8"
                            fill="none"
                            className="text-muted"
                          />
                          <circle
                            cx="64"
                            cy="64"
                            r="56"
                            stroke="url(#gradient)"
                            strokeWidth="8"
                            fill="none"
                            strokeDasharray={`${2 * Math.PI * 56}`}
                            strokeDashoffset={`${2 * Math.PI * 56 * (1 - progressPercentage / 100)}`}
                            strokeLinecap="round"
                          />
                          <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                              <stop offset="0%" stopColor="#FF9933" />
                              <stop offset="50%" stopColor="#4CAF50" />
                              <stop offset="100%" stopColor="#3F51B5" />
                            </linearGradient>
                          </defs>
                        </svg>
                        <div className="absolute text-center">
                          <p className="text-2xl font-bold">{caloriesConsumed}</p>
                          <p className="text-xs text-muted-foreground">of {calorieGoal}</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-xl text-center" style={{ background: '#4CAF5011' }}>
                        <Target className="w-5 h-5 mx-auto mb-1" style={{ color: '#4CAF50' }} />
                        <p className="text-xs text-muted-foreground">Goal</p>
                        <p className="font-medium">{calorieGoal} cal</p>
                      </div>
                      <div className="p-3 rounded-xl text-center" style={{ background: '#FF993311' }}>
                        <Flame className="w-5 h-5 mx-auto mb-1" style={{ color: '#FF9933' }} />
                        <p className="text-xs text-muted-foreground">Burned</p>
                        <p className="font-medium">{totalCaloriesBurned} cal</p>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-gradient-to-r from-saffron/10 to-green/10 border-2 border-saffron/20">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Net Calories</span>
                        <span className="font-medium">{netCalories} cal</span>
                      </div>
                    </div>
                  </div>

                  {/* Generate New Plan Button */}
                  <Button 
                    onClick={handleGenerateNewPlan}
                    className="w-full rounded-full"
                    style={{ 
                      background: 'linear-gradient(135deg, #3F51B5, #5C6BC0)',
                      color: 'white'
                    }}
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate New Plan
                  </Button>
                </Card>
              </motion.div>

              {/* Quick Stats Card */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.6 }}
              >
                <Card className="p-6 rounded-3xl shadow-lg hover-lift border-2">
                  <div className="flex items-center gap-3 mb-4">
                    <Calendar className="w-6 h-6" style={{ color: '#FF9933' }} />
                    <h3>This Week</h3>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
                      <span className="text-sm">Workouts Completed</span>
                      <Badge style={{ background: '#4CAF50', color: 'white' }}>{todayActivities.length}</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
                      <span className="text-sm">Meals on Track</span>
                      <Badge style={{ background: '#3F51B5', color: 'white' }}>4/4</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-xl bg-muted/50">
                      <span className="text-sm">Avg. Daily Score</span>
                      <Badge style={{ background: '#FF9933', color: 'white' }}>{dailyScore}/100</Badge>
                    </div>
                  </div>
                </Card>
              </motion.div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <Card className="p-8 rounded-3xl max-w-2xl mx-auto">
              <Sparkles className="w-16 h-16 mx-auto mb-4" style={{ color: '#FF9933' }} />
              <h2>Almost There!</h2>
              <p className="text-muted-foreground mt-2 mb-6">
                Complete your health profile to unlock personalized meal plans and nutrition insights.
              </p>
              <Button
                onClick={() => setEditProfileOpen(true)}
                size="lg"
                className="rounded-full"
                style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)', color: 'white' }}
              >
                <Edit className="w-5 h-5 mr-2" />
                Complete Your Profile
              </Button>
            </Card>
          </div>
        )}
      </div>

      {/* Edit Profile Dialog */}
      <Dialog open={editProfileOpen} onOpenChange={setEditProfileOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="w-5 h-5" style={{ color: '#FF9933' }} />
              Edit Health Profile
            </DialogTitle>
            <DialogDescription>
              Update your details to get more personalized meal recommendations
            </DialogDescription>
          </DialogHeader>

          <div className="grid md:grid-cols-2 gap-6 py-4">
            {/* Gender */}
            <div className="space-y-2">
              <Label>Gender</Label>
              <Select value={editForm.gender} onValueChange={(value) => setEditForm({...editForm, gender: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Age */}
            <div className="space-y-2">
              <Label>Age (years)</Label>
              <Input
                type="number"
                value={editForm.age || ''}
                onChange={(e) => setEditForm({...editForm, age: parseInt(e.target.value) || 0})}
                placeholder="e.g., 28"
                min="1"
                max="120"
              />
            </div>

            {/* Weight */}
            <div className="space-y-2">
              <Label>Current Weight (kg)</Label>
              <Input
                type="number"
                value={editForm.weight || ''}
                onChange={(e) => setEditForm({...editForm, weight: parseFloat(e.target.value) || 0})}
                placeholder="e.g., 70"
                min="1"
                step="0.1"
              />
            </div>

            {/* Height */}
            <div className="space-y-2">
              <Label>Height (cm)</Label>
              <Input
                type="number"
                value={editForm.height || ''}
                onChange={(e) => setEditForm({...editForm, height: parseInt(e.target.value) || 0})}
                placeholder="e.g., 170"
                min="1"
                max="300"
              />
            </div>

            {/* Goal */}
            <div className="space-y-2">
              <Label>Health Goal</Label>
              <Select value={editForm.goal} onValueChange={(value) => setEditForm({...editForm, goal: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="weight-loss">Weight Loss</SelectItem>
                  <SelectItem value="weight-gain">Weight Gain</SelectItem>
                  <SelectItem value="maintain">Maintain Weight</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Activity Level */}
            <div className="space-y-2">
              <Label>Activity Level</Label>
              <Select value={editForm.activityLevel} onValueChange={(value) => setEditForm({...editForm, activityLevel: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select activity level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                  <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                  <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                  <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                  <SelectItem value="very-active">Very Active (2x per day)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Dietary Preference */}
            <div className="space-y-2 md:col-span-2">
              <Label>Dietary Preference</Label>
              <Select value={editForm.dietaryPreference} onValueChange={(value) => setEditForm({...editForm, dietaryPreference: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select dietary preference" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vegetarian">Vegetarian</SelectItem>
                  <SelectItem value="vegan">Vegan</SelectItem>
                  <SelectItem value="non-vegetarian">Non-Vegetarian</SelectItem>
                  <SelectItem value="eggetarian">Eggetarian</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setEditProfileOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSaveProfile}
              style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)', color: 'white' }}
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Recipe Detail Dialog */}
      <RecipeDetailDialog
        open={!!selectedRecipe}
        onOpenChange={(open) => !open && setSelectedRecipe(null)}
        recipe={selectedRecipe}
      />

      {/* AI Chatbot */}
      <AIChatbot
        isOpen={chatbotOpen}
        onClose={() => setChatbotOpen(false)}
      />

      {/* Floating AI Chatbot Button */}
      {!chatbotOpen && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="fixed bottom-6 right-6 z-40"
        >
          <Button
            size="lg"
            onClick={() => setChatbotOpen(true)}
            className="rounded-full w-16 h-16 shadow-2xl"
            style={{ 
              background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
              animation: 'pulse 2s ease-in-out infinite'
            }}
          >
            <MessageCircle className="w-8 h-8 text-white" />
          </Button>
        </motion.div>
      )}

      {/* Decorative Background Elements */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <motion.div
          className="absolute top-20 left-10 w-32 h-32 rounded-full opacity-10"
          style={{ background: '#FF9933' }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        <motion.div
          className="absolute bottom-20 right-20 w-48 h-48 rounded-full opacity-10"
          style={{ background: '#4CAF50' }}
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        <motion.div
          className="absolute top-1/2 left-1/4 w-64 h-64 rounded-full opacity-5"
          style={{ background: '#3F51B5' }}
          animate={{
            scale: [1, 1.4, 1],
            opacity: [0.05, 0.1, 0.05],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
        {/* Additional decorative elements */}
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-3 h-3 rounded-full"
            style={{
              background: i % 3 === 0 ? '#FF9933' : i % 3 === 1 ? '#4CAF50' : '#3F51B5',
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              opacity: 0.1,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>
    <Footer />
    </div>
  );
{
