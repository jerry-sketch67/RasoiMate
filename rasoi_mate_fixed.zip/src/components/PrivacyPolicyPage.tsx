import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Shield, Lock, Eye, Database, UserCheck, Bell, FileText, Trash2, ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface PrivacyPolicyPageProps {
  onNavigate?: (page: string) => void;
}

export function PrivacyPolicyPage({ onNavigate }: PrivacyPolicyPageProps = {}) {
  const sections = [
    {
      icon: Database,
      title: 'Information We Collect',
      content: `We collect information you provide directly to us, including:
      • Name and email address when you create an account
      • Voice recordings for AI recipe assistance (processed in real-time, not permanently stored)
      • Recipe preferences and search history
      • Dietary restrictions and allergies you specify
      • Feedback and support communications`,
    },
    {
      icon: Lock,
      title: 'How We Use Your Information',
      content: `Your information is used to:
      • Provide personalized recipe recommendations
      • Process voice commands for AI assistance
      • Send recipe suggestions and cooking tips
      • Improve our AI models and service quality
      • Communicate important updates and features`,
    },
    {
      icon: Shield,
      title: 'Data Security',
      content: `We implement industry-standard security measures:
      • End-to-end encryption for data transmission
      • Secure cloud storage with regular backups
      • Regular security audits and updates
      • Access controls and authentication protocols
      • No sale of personal data to third parties`,
    },
    {
      icon: Eye,
      title: 'Voice Data Privacy',
      content: `Voice interactions are handled with utmost care:
      • Voice commands are processed in real-time using secure AI providers
      • Audio is converted to text and immediately discarded
      • No voice recordings are permanently stored
      • Voice data is never shared with advertisers
      • You can disable voice features at any time`,
    },
    {
      icon: UserCheck,
      title: 'Your Rights',
      content: `You have the right to:
      • Access your personal data at any time
      • Request correction of inaccurate information
      • Delete your account and associated data
      • Export your data in a portable format
      • Opt-out of marketing communications
      • Withdraw consent for data processing`,
    },
    {
      icon: Bell,
      title: 'Cookies and Tracking',
      content: `We use cookies to:
      • Remember your preferences and settings
      • Analyze site traffic and usage patterns
      • Provide personalized content
      • Improve user experience
      You can control cookies through your browser settings.`,
    },
    {
      icon: FileText,
      title: 'Third-Party Services',
      content: `We work with trusted service providers:
      • Google AI (Gemini) for recipe assistance
      • OpenAI for advanced AI features
      • EmailJS for contact form submissions
      • Analytics services for site improvement
      All providers comply with strict privacy standards.`,
    },
    {
      icon: Trash2,
      title: 'Data Deletion',
      content: `You can request complete data deletion:
      • Account deletion removes all personal information
      • Data is permanently deleted within 30 days
      • Some information may be retained for legal compliance
      • Aggregated, anonymized data may be retained for analytics
      Contact us at privacy@rasoi-mate.com for deletion requests.`,
    },
  ];

  return (
    <div className="bg-gradient-to-br from-background via-accent/20 to-background py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Back Button */}
        {onNavigate && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Button
              variant="ghost"
              onClick={() => onNavigate('home')}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </motion.div>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-full gradient-tech-blue flex items-center justify-center">
              <Shield className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-[var(--tech-blue)] to-[var(--saffron)] bg-clip-text text-transparent">
            Privacy Policy
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            At Rasoi Mate, we are committed to protecting your privacy and ensuring the security of your personal information.
            This policy explains how we collect, use, and safeguard your data.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            Last Updated: October 25, 2025
          </p>
        </motion.div>

        {/* Important Notice */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card className="p-6 mb-8 border-2 border-[var(--tech-blue)]/30 bg-[var(--tech-blue)]/5">
            <h3 className="mb-3 flex items-center gap-2">
              <Bell className="h-5 w-5 text-[var(--tech-blue)]" />
              Important Notice
            </h3>
            <p className="text-sm text-muted-foreground">
              Rasoi Mate is designed for cooking assistance and recipe management. <strong>We do not collect or store sensitive personal information (PII) beyond what's necessary for account creation and service provision.</strong> This platform is not intended for collecting personal health information, financial data, or other highly sensitive data. All voice interactions are processed securely and are not permanently stored.
            </p>
          </Card>
        </motion.div>

        {/* Privacy Sections */}
        <div className="grid gap-6 mb-12">
          {sections.map((section, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="p-6 hover-lift hover-glow">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[var(--saffron)] to-[var(--tech-blue)] flex items-center justify-center flex-shrink-0">
                    <section.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="mb-3">{section.title}</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                      {section.content}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Contact Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card className="p-8 text-center bg-gradient-to-br from-[var(--saffron)]/10 to-[var(--tech-blue)]/10">
            <h3 className="mb-4">Questions About Privacy?</h3>
            <p className="text-muted-foreground mb-6">
              If you have any questions or concerns about our privacy practices, please don't hesitate to contact us.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center text-sm">
              <div>
                <strong>Email:</strong> privacy@rasoi-mate.com
              </div>
              <div className="hidden sm:block text-muted-foreground">•</div>
              <div>
                <strong>Response Time:</strong> Within 48 hours
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    <Footer />
    </div>
  );
{
