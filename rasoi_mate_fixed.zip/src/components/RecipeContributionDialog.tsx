import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Plus, Minus, Mic, StopCircle, Upload, X } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion } from 'motion/react';
import { stateDistrictData } from './data/stateDistrictData';

interface RecipeContributionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function RecipeContributionDialog({ open, onOpenChange }: RecipeContributionDialogProps) {
  const [recipeName, setRecipeName] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('');
  const [state, setState] = useState('');
  const [district, setDistrict] = useState('');
  const [isRural, setIsRural] = useState<boolean | null>(null);
  const [time, setTime] = useState('');
  const [servings, setServings] = useState('');
  const [difficulty, setDifficulty] = useState('');
  
  const [ingredients, setIngredients] = useState<string[]>(['']);
  const [steps, setSteps] = useState<string[]>(['']);
  const [alternatives, setAlternatives] = useState<{ ingredient: string; substitutes: string }[]>([]);
  const [tips, setTips] = useState<string[]>(['']);
  
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState<Blob | null>(null);
  const [storyText, setStoryText] = useState('');
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const states = Object.keys(stateDistrictData);
  const districts = state ? Object.keys(stateDistrictData[state].districts) : [];

  const handleStartRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        setRecordedAudio(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      toast.success('Recording started! Share your recipe story...');
    } catch (error) {
      toast.error('Could not access microphone');
    }
  };

  const handleStopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      toast.success('Recording stopped!');
    }
  };

  const addIngredient = () => setIngredients([...ingredients, '']);
  const removeIngredient = (index: number) => setIngredients(ingredients.filter((_, i) => i !== index));
  const updateIngredient = (index: number, value: string) => {
    const newIngredients = [...ingredients];
    newIngredients[index] = value;
    setIngredients(newIngredients);
  };

  const addStep = () => setSteps([...steps, '']);
  const removeStep = (index: number) => setSteps(steps.filter((_, i) => i !== index));
  const updateStep = (index: number, value: string) => {
    const newSteps = [...steps];
    newSteps[index] = value;
    setSteps(newSteps);
  };

  const addAlternative = () => setAlternatives([...alternatives, { ingredient: '', substitutes: '' }]);
  const removeAlternative = (index: number) => setAlternatives(alternatives.filter((_, i) => i !== index));
  const updateAlternative = (index: number, field: 'ingredient' | 'substitutes', value: string) => {
    const newAlternatives = [...alternatives];
    newAlternatives[index][field] = value;
    setAlternatives(newAlternatives);
  };

  const addTip = () => setTips([...tips, '']);
  const removeTip = (index: number) => setTips(tips.filter((_, i) => i !== index));
  const updateTip = (index: number, value: string) => {
    const newTips = [...tips];
    newTips[index] = value;
    setTips(newTips);
  };

  const handleSubmit = () => {
    // Validation
    if (!recipeName || !description || !type || !state || !district || isRural === null) {
      toast.error('Please fill all required fields');
      return;
    }

    const validIngredients = ingredients.filter(ing => ing.trim() !== '');
    const validSteps = steps.filter(step => step.trim() !== '');

    if (validIngredients.length === 0 || validSteps.length === 0) {
      toast.error('Please add at least one ingredient and one step');
      return;
    }

    // Create recipe object
    const newRecipe = {
      name: recipeName,
      description,
      type,
      state,
      district,
      rural: isRural,
      time,
      servings,
      difficulty,
      ingredients: validIngredients,
      steps: validSteps,
      alternatives: alternatives.filter(alt => alt.ingredient && alt.substitutes),
      tips: tips.filter(tip => tip.trim() !== ''),
      storyText,
      audioRecording: recordedAudio ? URL.createObjectURL(recordedAudio) : null,
      contributedBy: localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user') || '{}').name : 'Anonymous',
      contributedDate: new Date().toISOString(),
    };

    // Save to localStorage
    const existingRecipes = JSON.parse(localStorage.getItem('contributedRecipes') || '[]');
    existingRecipes.push(newRecipe);
    localStorage.setItem('contributedRecipes', JSON.stringify(existingRecipes));

    toast.success('🎉 Thank you for contributing your recipe!');
    
    // Reset form
    setRecipeName('');
    setDescription('');
    setType('');
    setState('');
    setDistrict('');
    setIsRural(null);
    setTime('');
    setServings('');
    setDifficulty('');
    setIngredients(['']);
    setSteps(['']);
    setAlternatives([]);
    setTips(['']);
    setStoryText('');
    setRecordedAudio(null);
    
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0 overflow-hidden">
        <div style={{ background: 'linear-gradient(135deg, #FFF8E1 0%, #FFFBF0 100%)' }}>
          <DialogHeader className="p-6 pb-4">
            <DialogTitle className="text-2xl" style={{ color: '#FF6B35' }}>
              🍳 Contribute Your Recipe
            </DialogTitle>
            <DialogDescription>
              Share your family recipe and preserve India's culinary heritage
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="h-[calc(90vh-180px)] px-6">
            <div className="space-y-6 pb-6">
              {/* Basic Information */}
              <div className="space-y-4">
                <h3 className="text-lg" style={{ color: '#FF9933' }}>Basic Information</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="recipeName">Recipe Name *</Label>
                    <Input
                      id="recipeName"
                      value={recipeName}
                      onChange={(e) => setRecipeName(e.target.value)}
                      placeholder="e.g., Grandma's Dal Makhani"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="type">Recipe Type *</Label>
                    <Input
                      id="type"
                      value={type}
                      onChange={(e) => setType(e.target.value)}
                      placeholder="e.g., Curry, Sweet, Snack"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief description of your recipe..."
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="state">State / UT *</Label>
                    <Select value={state} onValueChange={(value) => { setState(value); setDistrict(''); }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        {states.map((s) => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="district">District *</Label>
                    <Select value={district} onValueChange={setDistrict} disabled={!state}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select district" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((d) => (
                          <SelectItem key={d} value={d}>{d}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="time">Cooking Time</Label>
                    <Input
                      id="time"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      placeholder="e.g., 45 mins"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="servings">Servings</Label>
                    <Input
                      id="servings"
                      value={servings}
                      onChange={(e) => setServings(e.target.value)}
                      placeholder="e.g., 4 people"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="difficulty">Difficulty</Label>
                    <Select value={difficulty} onValueChange={setDifficulty}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Easy">Easy</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label>Recipe Origin *</Label>
                  <div className="flex gap-4 mt-2">
                    <Button
                      type="button"
                      variant={isRural === true ? 'default' : 'outline'}
                      onClick={() => setIsRural(true)}
                      style={isRural === true ? { background: '#4CAF50', color: 'white' } : {}}
                    >
                      🌾 Rural
                    </Button>
                    <Button
                      type="button"
                      variant={isRural === false ? 'default' : 'outline'}
                      onClick={() => setIsRural(false)}
                      style={isRural === false ? { background: '#3F51B5', color: 'white' } : {}}
                    >
                      🏙️ Urban
                    </Button>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Ingredients */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg" style={{ color: '#FF9933' }}>Ingredients *</h3>
                  <Button size="sm" onClick={addIngredient}>
                    <Plus className="w-4 h-4 mr-1" /> Add
                  </Button>
                </div>
                {ingredients.map((ingredient, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={ingredient}
                      onChange={(e) => updateIngredient(index, e.target.value)}
                      placeholder="e.g., 2 cups rice flour"
                    />
                    {ingredients.length > 1 && (
                      <Button size="sm" variant="outline" onClick={() => removeIngredient(index)}>
                        <Minus className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Separator />

              {/* Steps */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg" style={{ color: '#FF9933' }}>Preparation Steps *</h3>
                  <Button size="sm" onClick={addStep}>
                    <Plus className="w-4 h-4 mr-1" /> Add
                  </Button>
                </div>
                {steps.map((step, index) => (
                  <div key={index} className="flex gap-2">
                    <Badge className="mt-2" style={{ background: '#FF9933', color: 'white' }}>
                      {index + 1}
                    </Badge>
                    <Textarea
                      value={step}
                      onChange={(e) => updateStep(index, e.target.value)}
                      placeholder="Describe this step..."
                      rows={2}
                    />
                    {steps.length > 1 && (
                      <Button size="sm" variant="outline" onClick={() => removeStep(index)} className="mt-2">
                        <Minus className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Separator />

              {/* Alternatives (Optional) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg" style={{ color: '#4CAF50' }}>Ingredient Alternatives (Optional)</h3>
                  <Button size="sm" onClick={addAlternative}>
                    <Plus className="w-4 h-4 mr-1" /> Add
                  </Button>
                </div>
                {alternatives.map((alt, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={alt.ingredient}
                      onChange={(e) => updateAlternative(index, 'ingredient', e.target.value)}
                      placeholder="Ingredient name"
                    />
                    <Input
                      value={alt.substitutes}
                      onChange={(e) => updateAlternative(index, 'substitutes', e.target.value)}
                      placeholder="Substitutes (comma separated)"
                    />
                    <Button size="sm" variant="outline" onClick={() => removeAlternative(index)}>
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <Separator />

              {/* Tips (Optional) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg" style={{ color: '#FFD700' }}>Chef's Tips (Optional)</h3>
                  <Button size="sm" onClick={addTip}>
                    <Plus className="w-4 h-4 mr-1" /> Add
                  </Button>
                </div>
                {tips.map((tip, index) => (
                  <div key={index} className="flex gap-2">
                    <Textarea
                      value={tip}
                      onChange={(e) => updateTip(index, e.target.value)}
                      placeholder="Share a helpful tip..."
                      rows={2}
                    />
                    {tips.length > 1 && (
                      <Button size="sm" variant="outline" onClick={() => removeTip(index)} className="mt-2">
                        <Minus className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Separator />

              {/* Story */}
              <div className="space-y-3">
                <h3 className="text-lg" style={{ color: '#FF9933' }}>🎙️ Your Recipe Story</h3>
                <p className="text-sm text-muted-foreground">
                  Share the story behind this recipe - where it comes from, family traditions, memories, etc.
                </p>
                
                <Textarea
                  value={storyText}
                  onChange={(e) => setStoryText(e.target.value)}
                  placeholder="Write your story here... (You can also record it below!)"
                  rows={4}
                />

                <div className="p-4 rounded-lg" style={{ background: 'rgba(255, 153, 51, 0.1)', border: '2px solid #FF9933' }}>
                  <h4 className="mb-3 flex items-center gap-2" style={{ color: '#FF9933' }}>
                    <Mic className="w-5 h-5" />
                    Record Your Story (Optional)
                  </h4>
                  <p className="text-sm mb-3" style={{ color: '#666' }}>
                    Prefer to speak? Record your recipe story with your voice! This adds a personal touch to your contribution.
                  </p>
                  
                  <div className="flex gap-4 items-center flex-wrap">
                    <Button
                      type="button"
                      size="lg"
                      onClick={isRecording ? handleStopRecording : handleStartRecording}
                      style={{ 
                        background: isRecording ? 'linear-gradient(135deg, #DC143C, #FF6B35)' : 'linear-gradient(135deg, #FF9933, #FFB366)',
                        color: 'white',
                        border: 'none'
                      }}
                      className={isRecording ? 'animate-pulse' : ''}
                    >
                      {isRecording ? (
                        <>
                          <StopCircle className="w-5 h-5 mr-2" />
                          Stop Recording
                        </>
                      ) : (
                        <>
                          <Mic className="w-5 h-5 mr-2" />
                          {recordedAudio ? 'Re-record Story' : 'Start Recording'}
                        </>
                      )}
                    </Button>
                    
                    {recordedAudio && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: 'spring' }}
                      >
                        <Badge style={{ background: '#4CAF50', color: 'white', fontSize: '1rem', padding: '0.5rem 1rem' }}>
                          ✓ Audio Story Recorded!
                        </Badge>
                      </motion.div>
                    )}
                    
                    {isRecording && (
                      <motion.div
                        animate={{ opacity: [0.5, 1, 0.5] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                      >
                        <Badge variant="outline" style={{ borderColor: '#DC143C', color: '#DC143C' }}>
                          🔴 Recording...
                        </Badge>
                      </motion.div>
                    )}
                  </div>
                  
                  {!isRecording && !recordedAudio && (
                    <p className="text-xs mt-2" style={{ color: '#999' }}>
                      💡 Tip: Speak clearly and share personal memories, family traditions, or special techniques!
                    </p>
                  )}
                </div>
              </div>
            </div>
          </ScrollArea>

          <div className="p-6 pt-4 border-t flex justify-end gap-3">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)', color: 'white' }}
            >
              Submit Recipe
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
