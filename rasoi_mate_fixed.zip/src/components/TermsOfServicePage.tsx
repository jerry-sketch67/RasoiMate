import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { FileText, CheckCircle, AlertTriangle, Shield, Users, Gavel, Ban, RefreshCw, ArrowLeft } from 'lucide-react';
import { Footer } from './Footer';

interface TermsOfServicePageProps {
  onNavigate?: (page: string) => void;
}

export function TermsOfServicePage({ onNavigate }: TermsOfServicePageProps = {}) {
  const terms = [
    {
      icon: CheckCircle,
      title: 'Acceptance of Terms',
      content: `By accessing and using Rasoi Mate, you accept and agree to be bound by the terms and provisions of this agreement. If you do not agree to these terms, please do not use our service.

• You must be at least 13 years old to use Rasoi Mate
• You are responsible for maintaining the security of your account
• You agree to provide accurate and complete information
• These terms may be updated; continued use constitutes acceptance`,
    },
    {
      icon: Users,
      title: 'User Accounts',
      content: `When creating an account with Rasoi Mate:

• You must provide accurate and current information
• You are responsible for all activities under your account
• You must keep your password secure and confidential
• You must notify us immediately of any unauthorized use
• We reserve the right to suspend or terminate accounts that violate these terms
• One person may only create one account`,
    },
    {
      icon: Shield,
      title: 'Acceptable Use',
      content: `You agree to use Rasoi Mate only for lawful purposes:

✓ Personal cooking and recipe management
✓ Learning and exploring culinary techniques
✓ Sharing appropriate recipe contributions
✓ Respectful interaction with AI features

✗ Uploading harmful or malicious content
✗ Attempting to hack or compromise the service
✗ Impersonating others or providing false information
✗ Using the service for commercial purposes without authorization`,
    },
    {
      icon: FileText,
      title: 'Intellectual Property',
      content: `Content and ownership rights:

• Rasoi Mate owns all rights to the platform, AI technology, and original recipes
• User-contributed recipes remain the property of the contributor
• By contributing, you grant us a license to use, display, and share your recipes
• You may not copy, reproduce, or redistribute our proprietary content
• All trademarks and logos are property of Rasoi Mate
• AI-generated content is provided for personal use only`,
    },
    {
      icon: AlertTriangle,
      title: 'Disclaimer of Warranties',
      content: `Important limitations and disclaimers:

• Rasoi Mate is provided "as is" without warranties of any kind
• We do not guarantee uninterrupted or error-free service
• AI suggestions are for informational purposes only
• We are not responsible for the outcome of recipes followed
• Users with food allergies should verify all ingredients carefully
• Nutritional information is estimated and may not be 100% accurate
• We do not provide medical or dietary advice`,
    },
    {
      icon: Ban,
      title: 'Limitation of Liability',
      content: `To the fullest extent permitted by law:

• Rasoi Mate is not liable for any indirect, incidental, or consequential damages
• We are not responsible for food-related allergic reactions or health issues
• Our liability is limited to the amount you paid for the service (if any)
• We are not responsible for user-generated content
• We do not guarantee the accuracy of third-party information
• Users assume all risks associated with following recipes`,
    },
    {
      icon: Gavel,
      title: 'Termination',
      content: `Account termination provisions:

• We reserve the right to suspend or terminate accounts at our discretion
• Violations of these terms may result in immediate termination
• You may delete your account at any time through settings
• Upon termination, your data will be deleted within 30 days
• Some information may be retained for legal compliance
• Terminated users may not create new accounts without permission`,
    },
    {
      icon: RefreshCw,
      title: 'Changes to Terms',
      content: `Updates and modifications:

• We may modify these terms at any time
• Material changes will be communicated via email or platform notification
• Continued use after changes constitutes acceptance
• You are responsible for reviewing terms periodically
• If you disagree with changes, you must stop using the service
• The "Last Updated" date reflects the most recent revision`,
    },
  ];

  return (
    <div className="bg-gradient-to-br from-background via-accent/20 to-background py-12 px-4">
      <div className="container mx-auto max-w-5xl">
        {/* Back Button */}
        {onNavigate && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Button
              variant="ghost"
              onClick={() => onNavigate('home')}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </motion.div>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-full gradient-saffron flex items-center justify-center">
              <Gavel className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-[var(--saffron)] to-[var(--tech-blue)] bg-clip-text text-transparent">
            Terms of Service
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Please read these terms carefully before using Rasoi Mate. By using our service, you agree to these terms and conditions.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            Last Updated: October 25, 2025
          </p>
        </motion.div>

        {/* Quick Summary */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card className="p-6 mb-8 border-2 border-[var(--saffron)]/30 bg-[var(--saffron)]/5">
            <h3 className="mb-3 flex items-center gap-2">
              <FileText className="h-5 w-5 text-[var(--saffron)]" />
              Quick Summary
            </h3>
            <p className="text-sm text-muted-foreground">
              Rasoi Mate is an AI-powered cooking assistant designed to make your culinary journey easier. 
              By using our service, you agree to: (1) Use the platform responsibly and lawfully, (2) Respect intellectual property rights, 
              (3) Verify ingredients for allergies and dietary restrictions, and (4) Understand that AI suggestions are for informational purposes only. 
              We reserve the right to modify these terms and suspend accounts that violate our policies.
            </p>
          </Card>
        </motion.div>

        {/* Terms Sections */}
        <div className="grid gap-6 mb-12">
          {terms.map((term, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="p-6 hover-lift hover-glow">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[var(--tech-blue)] to-[var(--green)] flex items-center justify-center flex-shrink-0">
                    <term.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="mb-3">{term.title}</h3>
                    <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                      {term.content}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Governing Law */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <Card className="p-6 mb-8 border-[var(--tech-blue)]/30">
            <h3 className="mb-3">Governing Law</h3>
            <p className="text-sm text-muted-foreground">
              These terms are governed by the laws of India. Any disputes arising from these terms or your use of Rasoi Mate 
              shall be subject to the exclusive jurisdiction of the courts in Mumbai, India.
            </p>
          </Card>
        </motion.div>

        {/* Contact Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
        >
          <Card className="p-8 text-center bg-gradient-to-br from-[var(--tech-blue)]/10 to-[var(--green)]/10">
            <h3 className="mb-4">Questions About These Terms?</h3>
            <p className="text-muted-foreground mb-6">
              If you have any questions regarding our terms of service, please contact our legal team.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center text-sm">
              <div>
                <strong>Email:</strong> legal@rasoi-mate.com
              </div>
              <div className="hidden sm:block text-muted-foreground">•</div>
              <div>
                <strong>Support:</strong> support@rasoi-mate.com
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    <Footer />
    </div>
  );
{
