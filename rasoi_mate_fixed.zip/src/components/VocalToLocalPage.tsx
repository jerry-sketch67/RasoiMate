import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { MapPin, Volume2, Heart, Plus, Users, BookOpen, ChefHat, ArrowLeft, Search, Sparkles, Globe } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';
import { getFigmaSafeImage } from './utils/imagePlaceholder';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { stateDistrictData } from './data/stateDistrictData';
import { RecipeDetailDialog, type DetailedRecipe } from './RecipeDetailDialog';
import { getRecipeDetails } from './data/enhancedRecipeData';
import { RecipeContributionDialog } from './RecipeContributionDialog';
import { SpeakYourStoryDialog } from './SpeakYourStoryDialog';
import { translateText } from './utils/translateText';
import { useLanguage } from './LanguageContext';
import { Footer } from './Footer';

interface VocalToLocalPageProps {
  onNavigate?: (page: string) => void;
}

const chefProfiles = [
  {
    id: 1,
    name: 'Lakshmi Devi',
    location: 'Tamil Nadu',
    specialty: 'Traditional Chettinad Cuisine',
    image: 'https://images.unsplash.com/photo-1676832924885-e6900a18456d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFuZG1vdGhlciUyMGNvb2tpbmclMjB0cmFkaXRpb25hbHxlbnwxfHx8fDE3NjAzMjA2MzV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    recipes: 12,
    story: 'Cooking authentic recipes passed down through 5 generations',
  },
  {
    id: 2,
    name: 'Rajesh Kumar',
    location: 'Punjab',
    specialty: 'Punjabi Dhaba Style',
    image: 'https://images.unsplash.com/photo-1711790252168-079dad3ca226?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjaGVmJTIwY29va2luZ3xlbnwxfHx8fDE3NjAzMjA2Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    recipes: 18,
    story: 'Bringing authentic dhaba flavors from village to your kitchen',
  },
  {
    id: 3,
    name: 'Meera Nair',
    location: 'Kerala',
    specialty: 'Coastal Kerala Cuisine',
    image: 'https://images.unsplash.com/photo-1633536705119-bcc37bf6c84e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBraXRjaGVuJTIwY29va2luZ3xlbnwxfHx8fDE3NjAyNDUzOTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    recipes: 15,
    story: 'Sharing secrets of spice blends from Kerala backwaters',
  },
];

export function VocalToLocalPage({ onNavigate }: VocalToLocalPageProps = {}) {
  const [selectedState, setSelectedState] = useState<string | null>(null);
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'rural' | 'urban'>('all');
  const [selectedRecipe, setSelectedRecipe] = useState<DetailedRecipe | null>(null);
  const [showRecipeDialog, setShowRecipeDialog] = useState(false);
  const [showContributionDialog, setShowContributionDialog] = useState(false);
  const [showStoryDialog, setShowStoryDialog] = useState(false);
  const { language } = useLanguage();

  const handleStateClick = (stateName: string) => {
    setSelectedState(stateName);
    setSelectedDistrict(null);
    setSearchQuery('');
  };

  const handleDistrictClick = (districtName: string) => {
    setSelectedDistrict(districtName);
  };

  const handleRecipeClick = (recipe: any) => {
    const recipeDetails = getRecipeDetails(recipe.name, recipe.type, recipe.description, recipe.rural);
    if (recipeDetails && selectedState && selectedDistrict) {
      setSelectedRecipe({
        ...recipeDetails,
        state: selectedState,
        district: selectedDistrict,
      });
      setShowRecipeDialog(true);
    }
  };

  const handleBack = () => {
    if (selectedDistrict) {
      setSelectedDistrict(null);
    } else if (selectedState) {
      setSelectedState(null);
    }
  };

  const states = Object.keys(stateDistrictData);
  const filteredStates = states.filter((state) =>
    state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  let districts: string[] = [];
  if (selectedState) {
    const stateData = stateDistrictData[selectedState as keyof typeof stateDistrictData];
    districts = stateData ? Object.keys(stateData.districts) : [];
  }

  const filteredDistricts = districts.filter((district) =>
    district.toLowerCase().includes(searchQuery.toLowerCase())
  );

  let recipes: any[] = [];
  if (selectedState && selectedDistrict) {
    const stateData = stateDistrictData[selectedState as keyof typeof stateDistrictData];
    if (stateData && stateData.districts[selectedDistrict]) {
      recipes = stateData.districts[selectedDistrict].recipes || [];
    }
  }

  const filteredRecipes = recipes.filter((recipe) => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterType === 'all' || (filterType === 'rural' ? recipe.rural : !recipe.rural);
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="bg-gradient-to-b from-orange-50 via-white to-green-50">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-white py-16">
        <div className="container mx-auto max-w-7xl px-4 relative z-10">
          {/* Back Button */}
          {onNavigate && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6"
            >
              <Button
                variant="ghost"
                onClick={() => onNavigate('home')}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Button>
            </motion.div>
          )}

          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Badge className="mb-4 text-base px-6 py-2" style={{ 
              background: 'linear-gradient(135deg, #FF9933, #4CAF50)', 
              color: 'white'
            }}>
              <Heart className="mr-2 h-4 w-4" />
              Celebrating Indian Heritage
            </Badge>
          
          <motion.h1
            className="text-4xl md:text-6xl mb-4"
            style={{
              background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              fontWeight: 'bold'
            }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            Vocal to Local
          </motion.h1>
          
          <motion.p
            className="text-lg max-w-2xl mx-auto text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            🗺️ Discover authentic rural Indian recipes • 28 States + 8 UTs • 100+ Districts • 1000+ Recipes
          </motion.p>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-wrap gap-4 justify-center mt-8"
        >
          <Button
            onClick={() => setShowContributionDialog(true)}
            size="lg"
            className="rounded-full shadow-md hover-lift"
            style={{
              background: 'linear-gradient(135deg, #FF9933, #4CAF50)',
            }}
          >
            <Plus className="mr-2 h-5 w-5" />
            Contribute Recipe
          </Button>
          <Button
            onClick={() => setShowStoryDialog(true)}
            variant="outline"
            size="lg"
            className="rounded-full border-2 hover-lift"
            style={{ borderColor: '#3F51B5', color: '#3F51B5' }}
          >
            <Volume2 className="mr-2 h-5 w-5" />
            Share Your Story
          </Button>
        </motion.div>
      </div>
    </section>

      {/* Main Content */}
      <section className="py-12">
        <div className="container mx-auto max-w-7xl px-4">
          {/* Back Navigation */}
          <AnimatePresence>
            {(selectedState || selectedDistrict) && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="mb-6"
              >
                <Button
                  variant="ghost"
                  onClick={handleBack}
                  className="hover-lift"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back {selectedDistrict ? 'to Districts' : 'to States'}
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="relative max-w-2xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder={`Search ${selectedState ? (selectedDistrict ? 'recipes' : 'districts') : 'states'}...`}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 h-12 text-lg rounded-full shadow-sm"
              />
            </div>
          </motion.div>

          {/* Filter Buttons for Recipes */}
          {selectedDistrict && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 justify-center mb-8"
            >
              <Button
                variant={filterType === 'all' ? 'default' : 'outline'}
                onClick={() => setFilterType('all')}
                className="rounded-full"
              >
                All Recipes
              </Button>
              <Button
                variant={filterType === 'rural' ? 'default' : 'outline'}
                onClick={() => setFilterType('rural')}
                className="rounded-full"
              >
                Rural Traditional
              </Button>
              <Button
                variant={filterType === 'urban' ? 'default' : 'outline'}
                onClick={() => setFilterType('urban')}
                className="rounded-full"
              >
                Urban Modern
              </Button>
            </motion.div>
          )}

          {/* States Grid */}
          {!selectedState && (
            <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredStates.map((state, index) => (
                <motion.div
                  key={state}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ y: -8 }}
                >
                  <Card
                    className="cursor-pointer overflow-hidden hover-lift hover-glow"
                    onClick={() => handleStateClick(state)}
                  >
                    <div className="p-6 text-center">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center" style={{
                        background: 'linear-gradient(135deg, #FF9933, #4CAF50)'
                      }}>
                        <MapPin className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="mb-2">{state}</h3>
                      <p className="text-sm text-muted-foreground">
                        {Object.keys(stateDistrictData[state as keyof typeof stateDistrictData]?.districts || {}).length} Districts
                      </p>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}

          {/* Districts Grid */}
          {selectedState && !selectedDistrict && (
            <motion.div layout>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-8"
              >
                <h2 className="text-3xl mb-2" style={{ color: '#FF9933' }}>
                  {selectedState}
                </h2>
                <p className="text-muted-foreground">
                  Select a district to explore authentic local recipes
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredDistricts.map((district, index) => (
                  <motion.div
                    key={district}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    whileHover={{ y: -8 }}
                  >
                    <Card
                      className="cursor-pointer overflow-hidden hover-lift hover-glow"
                      onClick={() => handleDistrictClick(district)}
                    >
                      <div className="p-6 text-center">
                        <div className="w-14 h-14 mx-auto mb-4 rounded-full flex items-center justify-center bg-gradient-to-br from-green-100 to-blue-100">
                          <ChefHat className="h-7 w-7 text-green-600" />
                        </div>
                        <h3 className="mb-2">{district}</h3>
                        <Badge variant="secondary" className="mt-2">
                          <BookOpen className="mr-1 h-3 w-3" />
                          {(stateDistrictData[selectedState as keyof typeof stateDistrictData]?.districts[district]?.recipes || []).length} Recipes
                        </Badge>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Recipes Grid */}
          {selectedState && selectedDistrict && (
            <motion.div layout>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-8"
              >
                <h2 className="text-3xl mb-2" style={{ color: '#FF9933' }}>
                  {selectedDistrict}, {selectedState}
                </h2>
                <p className="text-muted-foreground">
                  Authentic recipes from this region
                </p>
              </motion.div>

              {filteredRecipes.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredRecipes.map((recipe, index) => (
                    <motion.div
                      key={recipe.name}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      whileHover={{ y: -8 }}
                    >
                      <Card
                        className="cursor-pointer overflow-hidden h-full hover-lift hover-glow"
                        onClick={() => handleRecipeClick(recipe)}
                      >
                        <div className="aspect-video bg-gradient-to-br from-orange-100 to-green-100 flex items-center justify-center text-6xl">
                          {recipe.type === 'Sweet' ? '🍰' : '🍛'}
                        </div>
                        <div className="p-5">
                          <div className="flex items-center gap-2 mb-2">
                            <h3>{recipe.name}</h3>
                            {recipe.rural && (
                              <Badge variant="secondary" className="text-xs">
                                Rural
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mb-3">
                            {recipe.description}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Badge variant="outline" style={{ borderColor: '#FF9933', color: '#FF9933' }}>
                              {recipe.type}
                            </Badge>
                          </div>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground text-lg">No recipes found. Try adjusting your search or filter.</p>
                </div>
              )}
            </motion.div>
          )}
        </div>
      </section>

      {/* Chef Profiles Section */}
      {!selectedState && (
        <section className="py-16 bg-white">
          <div className="container mx-auto max-w-7xl px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl md:text-4xl mb-4" style={{ color: '#FF9933' }}>
                Featured Local Chefs
              </h2>
              <p className="text-lg text-muted-foreground">
                Learn from the guardians of traditional recipes
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {chefProfiles.map((chef, index) => (
                <motion.div
                  key={chef.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -8 }}
                >
                  <Card className="overflow-hidden h-full hover-lift hover-glow">
                    <div className="aspect-square bg-gradient-to-br from-orange-100 to-green-100 relative">
                      <ImageWithFallback
                        src={getFigmaSafeImage(chef.image)}
                        alt={chef.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-4 right-4">
                        <Badge className="bg-white/90 text-primary">
                          {chef.recipes} Recipes
                        </Badge>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="mb-2">{chef.name}</h3>
                      <div className="flex items-center gap-2 mb-3 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4" />
                        {chef.location}
                      </div>
                      <p className="text-sm mb-3" style={{ color: '#4CAF50' }}>
                        {chef.specialty}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {chef.story}
                      </p>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Call to Action */}
      {!selectedState && (
        <section className="py-16 bg-gradient-to-br from-orange-50 to-green-50">
          <div className="container mx-auto max-w-4xl px-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="text-center"
            >
              <Card className="p-8 md:p-12 shadow-lg hover-lift">
                <Users className="h-16 w-16 mx-auto mb-6" style={{ color: '#FF9933' }} />
                <h2 className="text-3xl mb-4">Share Your Heritage</h2>
                <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
                  Help preserve India's culinary traditions by contributing recipes from your region. Every recipe tells a story.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button
                    size="lg"
                    onClick={() => setShowContributionDialog(true)}
                    className="rounded-full hover-lift"
                    style={{
                      background: 'linear-gradient(135deg, #FF9933, #4CAF50)',
                    }}
                  >
                    <Plus className="mr-2 h-5 w-5" />
                    Add Your Recipe
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    onClick={() => setShowStoryDialog(true)}
                    className="rounded-full border-2 hover-lift"
                    style={{ borderColor: '#3F51B5', color: '#3F51B5' }}
                  >
                    <Volume2 className="mr-2 h-5 w-5" />
                    Share Your Story
                  </Button>
                </div>
              </Card>
            </motion.div>
          </div>
        </section>
      )}

      {/* Dialogs */}
      <RecipeDetailDialog
        recipe={selectedRecipe}
        open={showRecipeDialog}
        onOpenChange={setShowRecipeDialog}
      />

      <RecipeContributionDialog
        open={showContributionDialog}
        onOpenChange={setShowContributionDialog}
      />

      <SpeakYourStoryDialog
        open={showStoryDialog}
        onOpenChange={setShowStoryDialog}
      />
    <Footer />
    </div>
  );
{
