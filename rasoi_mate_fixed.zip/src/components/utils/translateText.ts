// Translation utility for recipe content
// Using Google Translate API (placeholder - requires API key for production)

interface TranslationCache {
  [key: string]: string;
}

const translationCache: TranslationCache = {};

export async function translateText(text: string, targetLang: string): Promise<string> {
  // If target is English, return original
  if (targetLang === 'en-IN' || targetLang === 'en') {
    return text;
  }

  // Check cache
  const cacheKey = `${text}_${targetLang}`;
  if (translationCache[cacheKey]) {
    return translationCache[cacheKey];
  }

  // Return original text (translation disabled for compatibility)
  // In production, integrate with a translation service
  return text;
}

// Translate array of strings
export async function translateArray(texts: string[], targetLang: string): Promise<string[]> {
  if (targetLang === 'en-IN' || targetLang === 'en') {
    return texts;
  }

  const translations = await Promise.all(
    texts.map(text => translateText(text, targetLang))
  );

  return translations;
}

// Language names mapping
export const languageNames: Record<string, string> = {
  'en-IN': 'English',
  'hi-IN': 'हिन्दी',
  'ta-IN': 'தமிழ்',
  'bn-IN': 'বাংলা',
  'mr-IN': 'मराठी',
  'te-IN': 'తెలుగు',
  'gu-IN': 'ગુજરાતી'
};
