// Helper functions for intelligent recipe search

// Common non-recipe words to filter out
const stopWords = new Set([
  'hi', 'hello', 'hey', 'hola', 'namaste', 'how', 'what', 'when', 'where', 'why',
  'can', 'could', 'would', 'should', 'the', 'and', 'or', 'but', 'in', 'on', 'at',
  'to', 'for', 'of', 'with', 'from', 'by', 'a', 'an', 'is', 'are', 'was', 'were',
  'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
  'make', 'show', 'tell', 'give', 'get', 'me', 'you', 'i', 'we', 'they', 'my', 'your',
  'this', 'that', 'these', 'those', 'it', 'its'
]);

// Comprehensive ingredient alternatives database
export interface IngredientAlternative {
  ingredient: string;
  alternatives: Array<{
    name: string;
    ratio?: string;
    description?: string;
    category?: string;
  }>;
  category: string;
  searchTerms?: string[]; // Alternative names/spellings
}

export const ingredientAlternativesDatabase: IngredientAlternative[] = [
  // FLOURS & STARCHES
  {
    ingredient: "Cornflour",
    category: "Flours & Starches",
    searchTerms: ["corn flour", "corn starch", "cornstarch", "makai ka atta"],
    alternatives: [
      { name: "Arrowroot Powder", ratio: "1:1", description: "Best for clear sauces and glazes" },
      { name: "Potato Starch", ratio: "1:1", description: "Great thickening agent, gluten-free" },
      { name: "Tapioca Starch", ratio: "2 tsp for 1 tbsp", description: "Works well in baked goods" },
      { name: "Rice Flour", ratio: "2:1", description: "Use double the amount, gluten-free" },
      { name: "All-Purpose Flour", ratio: "2:1", description: "Use double the amount" },
      { name: "Wheat Flour", ratio: "2:1", description: "Common substitute but not gluten-free" }
    ]
  },
  {
    ingredient: "All-Purpose Flour",
    category: "Flours & Starches",
    searchTerms: ["maida", "plain flour", "refined flour", "white flour"],
    alternatives: [
      { name: "Whole Wheat Flour", ratio: "1:1", description: "Healthier option, denser texture" },
      { name: "Cake Flour", ratio: "1 cup + 2 tbsp", description: "For lighter, tender results" },
      { name: "Bread Flour", ratio: "1:1", description: "For chewier texture" },
      { name: "Oat Flour", ratio: "1.3:1", description: "Use 1⅓ cups for 1 cup" },
      { name: "Almond Flour", ratio: "1:1", description: "Low-carb, gluten-free option" },
      { name: "Rice Flour", ratio: "⅞ cup", description: "Gluten-free alternative" },
      { name: "Chickpea Flour (Besan)", ratio: "1:1", description: "Higher protein, distinct flavor" }
    ]
  },
  {
    ingredient: "Whole Wheat Flour",
    category: "Flours & Starches",
    searchTerms: ["atta", "gehun ka atta", "wheat flour", "whole grain flour"],
    alternatives: [
      { name: "All-Purpose Flour", ratio: "1:1", description: "Lighter texture" },
      { name: "Spelt Flour", ratio: "1:1", description: "Similar nutrition, easier to digest" },
      { name: "Quinoa Flour", ratio: "1:1", description: "High protein, gluten-free" },
      { name: "Oat Flour", ratio: "1.3:1", description: "Gluten-free option" },
      { name: "Millet Flour", ratio: "1:1", description: "Gluten-free, mild flavor" }
    ]
  },
  {
    ingredient: "Rice Flour",
    category: "Flours & Starches",
    searchTerms: ["chawal ka atta", "ground rice"],
    alternatives: [
      { name: "Potato Starch", ratio: "1:1", description: "Similar texture" },
      { name: "Tapioca Flour", ratio: "1:1", description: "Great for gluten-free baking" },
      { name: "Sorghum Flour", ratio: "1:1", description: "Whole grain alternative" },
      { name: "Cornstarch", ratio: "1:1", description: "For thickening" }
    ]
  },
  {
    ingredient: "Besan",
    category: "Flours & Starches",
    searchTerms: ["chickpea flour", "gram flour", "chana flour"],
    alternatives: [
      { name: "Yellow Pea Flour", ratio: "1:1", description: "Very similar taste" },
      { name: "Soy Flour", ratio: "1:1", description: "High protein alternative" },
      { name: "Quinoa Flour", ratio: "1:1", description: "Gluten-free option" },
      { name: "Almond Flour", ratio: "1:1", description: "Different flavor profile" }
    ]
  },
  
  // DAIRY PRODUCTS
  {
    ingredient: "Heavy Cream",
    category: "Dairy",
    searchTerms: ["fresh cream", "whipping cream", "double cream"],
    alternatives: [
      { name: "Coconut Cream", ratio: "1:1", description: "Dairy-free, rich alternative" },
      { name: "Cashew Cream", ratio: "1:1", description: "Blend soaked cashews with water" },
      { name: "Greek Yogurt", ratio: "1:1", description: "Lower fat, tangy flavor" },
      { name: "Evaporated Milk", ratio: "1:1", description: "Thinner consistency" },
      { name: "Butter + Milk", ratio: "⅓ cup butter + ¾ cup milk", description: "For 1 cup cream" },
      { name: "Silken Tofu", ratio: "Blend until smooth", description: "Vegan option" }
    ]
  },
  {
    ingredient: "Milk",
    category: "Dairy",
    searchTerms: ["doodh", "dairy milk", "cow milk"],
    alternatives: [
      { name: "Almond Milk", ratio: "1:1", description: "Dairy-free, nutty flavor" },
      { name: "Coconut Milk", ratio: "1:1", description: "Rich, creamy texture" },
      { name: "Soy Milk", ratio: "1:1", description: "High protein option" },
      { name: "Oat Milk", ratio: "1:1", description: "Creamy, neutral flavor" },
      { name: "Cashew Milk", ratio: "1:1", description: "Rich and creamy" },
      { name: "Rice Milk", ratio: "1:1", description: "Light, slightly sweet" },
      { name: "Evaporated Milk", ratio: "1:1", description: "Dilute with equal parts water" }
    ]
  },
  {
    ingredient: "Yogurt",
    category: "Dairy",
    searchTerms: ["dahi", "curd", "greek yogurt"],
    alternatives: [
      { name: "Sour Cream", ratio: "1:1", description: "Similar tanginess" },
      { name: "Buttermilk", ratio: "Thinner", description: "For marinades" },
      { name: "Coconut Yogurt", ratio: "1:1", description: "Dairy-free option" },
      { name: "Cashew Cream", ratio: "1:1", description: "Blend soaked cashews" },
      { name: "Silken Tofu", ratio: "Blend smooth", description: "Vegan alternative" },
      { name: "Milk + Lemon", ratio: "1 cup milk + 1 tbsp lemon", description: "Let sit 5 minutes" }
    ]
  },
  {
    ingredient: "Butter",
    category: "Dairy",
    searchTerms: ["makkhan", "salted butter", "unsalted butter"],
    alternatives: [
      { name: "Ghee", ratio: "1:1", description: "Clarified butter, nuttier flavor" },
      { name: "Coconut Oil", ratio: "1:1", description: "Vegan option" },
      { name: "Olive Oil", ratio: "¾ cup for 1 cup", description: "For savory dishes" },
      { name: "Vegetable Oil", ratio: "¾ cup for 1 cup", description: "Neutral flavor" },
      { name: "Applesauce", ratio: "½ cup for 1 cup", description: "For baking, fat-free" },
      { name: "Greek Yogurt", ratio: "½ cup for 1 cup", description: "For baking" },
      { name: "Avocado", ratio: "1:1", description: "Healthy fat alternative" }
    ]
  },
  {
    ingredient: "Paneer",
    category: "Dairy",
    searchTerms: ["cottage cheese", "indian cheese"],
    alternatives: [
      { name: "Tofu", ratio: "1:1", description: "Vegan alternative, similar texture" },
      { name: "Halloumi", ratio: "1:1", description: "Grilling cheese" },
      { name: "Ricotta Cheese", ratio: "1:1", description: "Softer texture" },
      { name: "Feta Cheese", ratio: "1:1", description: "Crumbly, saltier" },
      { name: "Queso Fresco", ratio: "1:1", description: "Similar mild flavor" },
      { name: "Mozzarella", ratio: "1:1", description: "Stretchy when melted" }
    ]
  },
  {
    ingredient: "Ghee",
    category: "Dairy",
    searchTerms: ["clarified butter", "desi ghee"],
    alternatives: [
      { name: "Butter", ratio: "1:1", description: "Contains milk solids" },
      { name: "Coconut Oil", ratio: "1:1", description: "Vegan, high smoke point" },
      { name: "Olive Oil", ratio: "1:1", description: "For low-heat cooking" },
      { name: "Avocado Oil", ratio: "1:1", description: "High smoke point" },
      { name: "Vegetable Oil", ratio: "1:1", description: "Neutral flavor" }
    ]
  },
  
  // SPICES
  {
    ingredient: "Cumin",
    category: "Spices",
    searchTerms: ["jeera", "cumin seeds", "ground cumin"],
    alternatives: [
      { name: "Caraway Seeds", ratio: "1:1", description: "Similar earthy flavor" },
      { name: "Coriander", ratio: "1:1", description: "Milder, citrusy" },
      { name: "Fennel Seeds", ratio: "½ amount", description: "Sweeter, anise-like" },
      { name: "Chili Powder", ratio: "½ amount", description: "Add heat and earthiness" }
    ]
  },
  {
    ingredient: "Coriander",
    category: "Spices",
    searchTerms: ["dhania", "cilantro seeds", "coriander seeds", "ground coriander"],
    alternatives: [
      { name: "Cumin", ratio: "1:1", description: "More earthy" },
      { name: "Caraway Seeds", ratio: "1:1", description: "Similar profile" },
      { name: "Curry Powder", ratio: "½ amount", description: "Contains coriander" },
      { name: "Garam Masala", ratio: "½ amount", description: "More complex" }
    ]
  },
  {
    ingredient: "Turmeric",
    category: "Spices",
    searchTerms: ["haldi", "turmeric powder"],
    alternatives: [
      { name: "Saffron", ratio: "Pinch", description: "For color and flavor" },
      { name: "Curry Powder", ratio: "1:1", description: "Contains turmeric" },
      { name: "Ginger", ratio: "1:1", description: "Similar earthiness" },
      { name: "Mustard Powder", ratio: "½ amount", description: "For color" },
      { name: "Paprika", ratio: "1:1", description: "For color only" }
    ]
  },
  {
    ingredient: "Garam Masala",
    category: "Spices",
    searchTerms: ["garam masala powder", "indian spice blend"],
    alternatives: [
      { name: "Curry Powder", ratio: "1:1", description: "Similar complexity" },
      { name: "DIY Mix", ratio: "Equal parts cumin, coriander, cardamom", description: "Fresh blend" },
      { name: "Chaat Masala", ratio: "1:1", description: "Tangier flavor" },
      { name: "Allspice", ratio: "½ amount", description: "Sweet and warm" }
    ]
  },
  {
    ingredient: "Red Chili Powder",
    category: "Spices",
    searchTerms: ["lal mirch", "cayenne pepper", "chili powder"],
    alternatives: [
      { name: "Paprika", ratio: "1:1", description: "Mild, for color" },
      { name: "Cayenne Pepper", ratio: "½ amount", description: "Very hot" },
      { name: "Red Pepper Flakes", ratio: "½ amount", description: "Texture difference" },
      { name: "Black Pepper", ratio: "½ amount", description: "Different heat" },
      { name: "Hot Sauce", ratio: "Few drops", description: "Adds moisture" },
      { name: "Fresh Chili", ratio: "1-2 chilies", description: "Fresh flavor" }
    ]
  },
  {
    ingredient: "Cardamom",
    category: "Spices",
    searchTerms: ["elaichi", "green cardamom", "cardamom pods"],
    alternatives: [
      { name: "Cinnamon", ratio: "½ amount", description: "Similar warmth" },
      { name: "Nutmeg", ratio: "¼ amount", description: "Warm, sweet" },
      { name: "Allspice", ratio: "½ amount", description: "Complex flavor" },
      { name: "Ginger", ratio: "1:1", description: "Different but aromatic" }
    ]
  },
  {
    ingredient: "Cinnamon",
    category: "Spices",
    searchTerms: ["dalchini", "cinnamon stick", "ground cinnamon"],
    alternatives: [
      { name: "Nutmeg", ratio: "½ amount", description: "Similar warmth" },
      { name: "Allspice", ratio: "½ amount", description: "Similar profile" },
      { name: "Cardamom", ratio: "½ amount", description: "Floral notes" },
      { name: "Cloves", ratio: "¼ amount", description: "Strong, use sparingly" }
    ]
  },
  {
    ingredient: "Mustard Seeds",
    category: "Spices",
    searchTerms: ["sarson", "rai", "mustard", "black mustard seeds"],
    alternatives: [
      { name: "Mustard Powder", ratio: "½ tsp per 1 tsp seeds", description: "More intense" },
      { name: "Horseradish", ratio: "To taste", description: "Similar pungency" },
      { name: "Wasabi", ratio: "Small amount", description: "Very strong" },
      { name: "Cumin Seeds", ratio: "1:1", description: "Different but aromatic" }
    ]
  },
  {
    ingredient: "Asafoetida",
    category: "Spices",
    searchTerms: ["hing", "asafetida"],
    alternatives: [
      { name: "Garlic Powder", ratio: "¼ tsp per pinch", description: "Similar umami" },
      { name: "Onion Powder", ratio: "¼ tsp per pinch", description: "Milder substitute" },
      { name: "Fresh Garlic", ratio: "1 clove per pinch", description: "Fresh alternative" },
      { name: "Garlic + Onion", ratio: "Combination", description: "Best substitute" }
    ]
  },
  {
    ingredient: "Fenugreek",
    category: "Spices",
    searchTerms: ["methi", "fenugreek seeds", "fenugreek leaves", "kasuri methi"],
    alternatives: [
      { name: "Mustard Seeds", ratio: "1:1", description: "For seeds" },
      { name: "Celery Leaves", ratio: "1:1", description: "For dried leaves" },
      { name: "Maple Syrup", ratio: "Few drops", description: "For sweetness" },
      { name: "Fennel Seeds", ratio: "½ amount", description: "Milder flavor" }
    ]
  },
  {
    ingredient: "Cloves",
    category: "Spices",
    searchTerms: ["laung", "whole cloves", "ground cloves"],
    alternatives: [
      { name: "Allspice", ratio: "1:1", description: "Similar warm flavor" },
      { name: "Cinnamon + Nutmeg", ratio: "½ tsp each", description: "Complex substitute" },
      { name: "Cardamom", ratio: "1:1", description: "Aromatic alternative" }
    ]
  },
  {
    ingredient: "Bay Leaves",
    category: "Spices",
    searchTerms: ["tej patta", "bay leaf", "indian bay leaf"],
    alternatives: [
      { name: "Thyme", ratio: "1:1", description: "Similar earthiness" },
      { name: "Oregano", ratio: "1:1", description: "Mediterranean alternative" },
      { name: "Basil", ratio: "1:1", description: "Sweeter profile" },
      { name: "Juniper Berries", ratio: "½ amount", description: "Pine-like flavor" }
    ]
  },
  {
    ingredient: "Curry Leaves",
    category: "Spices",
    searchTerms: ["kadi patta", "sweet neem leaves"],
    alternatives: [
      { name: "Bay Leaves", ratio: "1:1", description: "Different but aromatic" },
      { name: "Basil", ratio: "2:1", description: "Fresh alternative" },
      { name: "Lime Zest", ratio: "½ tsp", description: "Citrus notes" },
      { name: "Lemon Grass", ratio: "1 stalk", description: "Aromatic substitute" }
    ]
  },
  {
    ingredient: "Black Pepper",
    category: "Spices",
    searchTerms: ["kali mirch", "peppercorn", "ground pepper"],
    alternatives: [
      { name: "White Pepper", ratio: "1:1", description: "Milder heat" },
      { name: "Cayenne Pepper", ratio: "¼ amount", description: "More heat" },
      { name: "Red Pepper Flakes", ratio: "½ amount", description: "Visible flakes" },
      { name: "Paprika", ratio: "1:1", description: "Less heat, more color" }
    ]
  },
  {
    ingredient: "Saffron",
    category: "Spices",
    searchTerms: ["kesar", "saffron threads"],
    alternatives: [
      { name: "Turmeric", ratio: "¼ tsp", description: "For color only" },
      { name: "Safflower", ratio: "1:1", description: "Similar color" },
      { name: "Annatto Seeds", ratio: "1 tsp", description: "Orange color" },
      { name: "Marigold Petals", ratio: "1 tsp", description: "Color substitute" }
    ]
  },
  {
    ingredient: "Paprika",
    category: "Spices",
    searchTerms: ["sweet paprika", "smoked paprika"],
    alternatives: [
      { name: "Cayenne Pepper", ratio: "½ amount", description: "Much hotter" },
      { name: "Chili Powder", ratio: "1:1", description: "Similar heat" },
      { name: "Red Pepper Flakes", ratio: "½ amount", description: "More heat" },
      { name: "Tomato Powder", ratio: "1:1", description: "For color only" }
    ]
  },
  
  // OILS & FATS
  {
    ingredient: "Vegetable Oil",
    category: "Oils & Fats",
    searchTerms: ["cooking oil", "refined oil"],
    alternatives: [
      { name: "Canola Oil", ratio: "1:1", description: "Neutral flavor" },
      { name: "Sunflower Oil", ratio: "1:1", description: "High smoke point" },
      { name: "Coconut Oil", ratio: "1:1", description: "Slight coconut flavor" },
      { name: "Olive Oil", ratio: "1:1", description: "For low-medium heat" },
      { name: "Avocado Oil", ratio: "1:1", description: "High smoke point" },
      { name: "Ghee", ratio: "1:1", description: "Rich flavor" }
    ]
  },
  {
    ingredient: "Olive Oil",
    category: "Oils & Fats",
    searchTerms: ["extra virgin olive oil", "EVOO"],
    alternatives: [
      { name: "Avocado Oil", ratio: "1:1", description: "Similar health benefits" },
      { name: "Canola Oil", ratio: "1:1", description: "Neutral flavor" },
      { name: "Sunflower Oil", ratio: "1:1", description: "Light flavor" },
      { name: "Grapeseed Oil", ratio: "1:1", description: "Mild taste" }
    ]
  },
  {
    ingredient: "Coconut Oil",
    category: "Oils & Fats",
    searchTerms: ["virgin coconut oil", "refined coconut oil"],
    alternatives: [
      { name: "Butter", ratio: "1:1", description: "For baking" },
      { name: "Ghee", ratio: "1:1", description: "Similar properties" },
      { name: "Olive Oil", ratio: "1:1", description: "For cooking" },
      { name: "Vegetable Oil", ratio: "1:1", description: "Neutral alternative" }
    ]
  },
  {
    ingredient: "Sesame Oil",
    category: "Oils & Fats",
    searchTerms: ["til oil", "gingelly oil", "toasted sesame oil"],
    alternatives: [
      { name: "Peanut Oil", ratio: "1:1", description: "Similar nutty flavor" },
      { name: "Walnut Oil", ratio: "1:1", description: "Nutty alternative" },
      { name: "Olive Oil + Sesame Seeds", ratio: "1:1 + toasted seeds", description: "DIY option" },
      { name: "Tahini", ratio: "Diluted", description: "For flavor" }
    ]
  },
  
  // SWEETENERS
  {
    ingredient: "Sugar",
    category: "Sweeteners",
    searchTerms: ["white sugar", "granulated sugar", "chini"],
    alternatives: [
      { name: "Honey", ratio: "¾ cup for 1 cup", description: "Reduce liquid by ¼ cup" },
      { name: "Maple Syrup", ratio: "¾ cup for 1 cup", description: "Reduce liquid by 3 tbsp" },
      { name: "Coconut Sugar", ratio: "1:1", description: "Lower glycemic index" },
      { name: "Jaggery", ratio: "1:1", description: "Traditional Indian sweetener" },
      { name: "Stevia", ratio: "1 tsp for 1 cup", description: "Very sweet, calorie-free" },
      { name: "Agave Nectar", ratio: "⅔ cup for 1 cup", description: "Sweeter than sugar" },
      { name: "Date Sugar", ratio: "1:1", description: "Whole food option" }
    ]
  },
  {
    ingredient: "Honey",
    category: "Sweeteners",
    searchTerms: ["shahad", "raw honey"],
    alternatives: [
      { name: "Maple Syrup", ratio: "1:1", description: "Similar consistency" },
      { name: "Agave Nectar", ratio: "1:1", description: "Vegan option" },
      { name: "Golden Syrup", ratio: "1:1", description: "Similar texture" },
      { name: "Brown Rice Syrup", ratio: "1¼ cups for 1 cup", description: "Less sweet" },
      { name: "Date Syrup", ratio: "1:1", description: "Rich flavor" }
    ]
  },
  {
    ingredient: "Jaggery",
    category: "Sweeteners",
    searchTerms: ["gur", "guda", "shakkar"],
    alternatives: [
      { name: "Brown Sugar", ratio: "1:1", description: "Similar molasses flavor" },
      { name: "Palm Sugar", ratio: "1:1", description: "Very similar" },
      { name: "Coconut Sugar", ratio: "1:1", description: "Similar caramel notes" },
      { name: "Molasses", ratio: "1:1", description: "Darker, stronger" },
      { name: "Maple Syrup", ratio: "¾ cup for 1 cup", description: "Different flavor" }
    ]
  },
  
  // ACIDS & SOURING AGENTS
  {
    ingredient: "Lemon Juice",
    category: "Acids",
    searchTerms: ["nimbu", "lime juice", "citrus"],
    alternatives: [
      { name: "Lime Juice", ratio: "1:1", description: "Very similar" },
      { name: "Vinegar", ratio: "½ amount", description: "More acidic" },
      { name: "Citric Acid", ratio: "¼ tsp per 1 tbsp", description: "Powder form" },
      { name: "White Wine", ratio: "2:1", description: "Milder acidity" },
      { name: "Tamarind", ratio: "½ amount", description: "Tangy, darker" }
    ]
  },
  {
    ingredient: "Vinegar",
    category: "Acids",
    searchTerms: ["white vinegar", "apple cider vinegar", "sirka"],
    alternatives: [
      { name: "Lemon Juice", ratio: "1:1", description: "Fresh citrus flavor" },
      { name: "Lime Juice", ratio: "1:1", description: "Similar acidity" },
      { name: "Wine", ratio: "1:1", description: "For cooking" },
      { name: "Tamarind Paste", ratio: "½ amount", description: "Tangy substitute" }
    ]
  },
  {
    ingredient: "Tamarind",
    category: "Acids",
    searchTerms: ["imli", "tamarind paste", "tamarind pulp"],
    alternatives: [
      { name: "Lemon Juice", ratio: "1:1", description: "More citrusy" },
      { name: "Lime Juice + Brown Sugar", ratio: "1:1 + pinch", description: "Sweet-sour balance" },
      { name: "Pomegranate Molasses", ratio: "1:1", description: "Fruity tang" },
      { name: "Amchur", ratio: "½ tsp per 1 tbsp", description: "Dried mango powder" },
      { name: "Vinegar + Sugar", ratio: "Mix to taste", description: "DIY substitute" }
    ]
  },
  {
    ingredient: "Amchur",
    category: "Acids",
    searchTerms: ["dry mango powder", "amchoor"],
    alternatives: [
      { name: "Lemon Juice", ratio: "1 tbsp per 1 tsp", description: "Fresh citrus" },
      { name: "Tamarind Paste", ratio: "1 tsp per 1 tsp", description: "Similar tang" },
      { name: "Sumac", ratio: "1:1", description: "Citrusy, tangy" },
      { name: "Citric Acid", ratio: "¼ amount", description: "Pure sourness" }
    ]
  },
  
  // PROTEINS
  {
    ingredient: "Chicken",
    category: "Proteins",
    searchTerms: ["chicken breast", "chicken thigh", "murgh"],
    alternatives: [
      { name: "Turkey", ratio: "1:1", description: "Similar texture" },
      { name: "Paneer", ratio: "1:1", description: "Vegetarian option" },
      { name: "Tofu", ratio: "1:1", description: "Vegan alternative" },
      { name: "Mushrooms", ratio: "1:1", description: "Meaty texture" },
      { name: "Soya Chunks", ratio: "1:1", description: "High protein vegan" },
      { name: "Seitan", ratio: "1:1", description: "Wheat-based meat alternative" }
    ]
  },
  {
    ingredient: "Eggs",
    category: "Proteins",
    searchTerms: ["anda", "egg"],
    alternatives: [
      { name: "Flax Egg", ratio: "1 tbsp flax + 3 tbsp water per egg", description: "Vegan, for binding" },
      { name: "Chia Egg", ratio: "1 tbsp chia + 3 tbsp water per egg", description: "Similar to flax" },
      { name: "Banana", ratio: "¼ cup per egg", description: "For baking, adds flavor" },
      { name: "Applesauce", ratio: "¼ cup per egg", description: "For moisture" },
      { name: "Silken Tofu", ratio: "¼ cup per egg", description: "Protein-rich" },
      { name: "Aquafaba", ratio: "3 tbsp per egg", description: "Chickpea water" }
    ]
  },
  {
    ingredient: "Lentils",
    category: "Proteins",
    searchTerms: ["dal", "masoor", "moong", "toor dal"],
    alternatives: [
      { name: "Split Peas", ratio: "1:1", description: "Similar texture" },
      { name: "Chickpeas", ratio: "1:1", description: "Firmer texture" },
      { name: "Beans", ratio: "1:1", description: "Various types work" },
      { name: "Quinoa", ratio: "1:1", description: "Complete protein" }
    ]
  },
  
  // VEGETABLES
  {
    ingredient: "Onion",
    category: "Vegetables",
    searchTerms: ["pyaz", "red onion", "white onion"],
    alternatives: [
      { name: "Shallots", ratio: "1:1", description: "Milder, sweeter" },
      { name: "Leeks", ratio: "1:1", description: "Milder flavor" },
      { name: "Spring Onions", ratio: "3-4 for 1 onion", description: "Milder alternative" },
      { name: "Onion Powder", ratio: "1 tbsp per onion", description: "Dried form" },
      { name: "Fennel Bulb", ratio: "1:1", description: "Sweet, anise flavor" }
    ]
  },
  {
    ingredient: "Garlic",
    category: "Vegetables",
    searchTerms: ["lehsun", "garlic cloves"],
    alternatives: [
      { name: "Garlic Powder", ratio: "⅛ tsp per clove", description: "Dried form" },
      { name: "Shallots", ratio: "1 shallot per 2 cloves", description: "Milder" },
      { name: "Asafoetida", ratio: "Pinch per clove", description: "Strong substitute" },
      { name: "Garlic Salt", ratio: "½ tsp per clove", description: "Reduce other salt" },
      { name: "Elephant Garlic", ratio: "1:1", description: "Milder flavor" }
    ]
  },
  {
    ingredient: "Ginger",
    category: "Vegetables",
    searchTerms: ["adrak", "fresh ginger"],
    alternatives: [
      { name: "Ginger Powder", ratio: "¼ tsp per 1 tbsp fresh", description: "More concentrated" },
      { name: "Galangal", ratio: "1:1", description: "Similar but citrusy" },
      { name: "Ginger Paste", ratio: "1:1", description: "Convenient form" },
      { name: "Candied Ginger", ratio: "Rinse and chop", description: "Sweet alternative" }
    ]
  },
  {
    ingredient: "Tomato",
    category: "Vegetables",
    searchTerms: ["tamatar", "tomatoes", "fresh tomatoes"],
    alternatives: [
      { name: "Canned Tomatoes", ratio: "1 cup per 2 tomatoes", description: "More consistent" },
      { name: "Tomato Paste", ratio: "2 tbsp + water per tomato", description: "Concentrated" },
      { name: "Tomato Puree", ratio: "½ cup per 2 tomatoes", description: "Smooth texture" },
      { name: "Ketchup", ratio: "Use less, sweeter", description: "In a pinch" },
      { name: "Red Bell Pepper", ratio: "1:1", description: "For color, less acid" }
    ]
  },
  {
    ingredient: "Green Chili",
    category: "Vegetables",
    searchTerms: ["hari mirch", "green chilies", "jalapeño"],
    alternatives: [
      { name: "Red Chili Flakes", ratio: "½ tsp per chili", description: "Dried form" },
      { name: "Serrano Peppers", ratio: "1:1", description: "Similar heat" },
      { name: "Jalapeño", ratio: "1:1", description: "Slightly milder" },
      { name: "Bell Pepper + Cayenne", ratio: "1 pepper + pinch", description: "Color + heat" },
      { name: "Hot Sauce", ratio: "Few drops", description: "Liquid form" }
    ]
  },
  {
    ingredient: "Cilantro",
    category: "Vegetables",
    searchTerms: ["hara dhania", "coriander leaves", "fresh coriander"],
    alternatives: [
      { name: "Parsley", ratio: "1:1", description: "Milder flavor" },
      { name: "Basil", ratio: "1:1", description: "Different but fresh" },
      { name: "Mint", ratio: "½ amount", description: "Stronger flavor" },
      { name: "Celery Leaves", ratio: "1:1", description: "Similar look" },
      { name: "Dried Coriander", ratio: "1 tsp per ¼ cup fresh", description: "Less flavorful" }
    ]
  },
  
  // NUTS & SEEDS
  {
    ingredient: "Cashews",
    category: "Nuts & Seeds",
    searchTerms: ["kaju", "cashew nuts"],
    alternatives: [
      { name: "Almonds", ratio: "1:1", description: "Similar texture" },
      { name: "Sunflower Seeds", ratio: "1:1", description: "Nut-free option" },
      { name: "Macadamia Nuts", ratio: "1:1", description: "Rich and creamy" },
      { name: "Pine Nuts", ratio: "1:1", description: "Delicate flavor" },
      { name: "White Beans", ratio: "1:1 blended", description: "For creamy sauces" }
    ]
  },
  {
    ingredient: "Almonds",
    category: "Nuts & Seeds",
    searchTerms: ["badam", "almond"],
    alternatives: [
      { name: "Cashews", ratio: "1:1", description: "Creamier" },
      { name: "Hazelnuts", ratio: "1:1", description: "Richer flavor" },
      { name: "Walnuts", ratio: "1:1", description: "Different texture" },
      { name: "Sunflower Seeds", ratio: "1:1", description: "Nut-free" },
      { name: "Oats", ratio: "For almond flour", description: "Ground oats" }
    ]
  },
  {
    ingredient: "Peanuts",
    category: "Nuts & Seeds",
    searchTerms: ["moongphali", "groundnuts"],
    alternatives: [
      { name: "Cashews", ratio: "1:1", description: "Milder flavor" },
      { name: "Almonds", ratio: "1:1", description: "Harder texture" },
      { name: "Sunflower Seeds", ratio: "1:1", description: "Allergy-friendly" },
      { name: "Soy Nuts", ratio: "1:1", description: "Similar protein" }
    ]
  },
  {
    ingredient: "Sesame Seeds",
    category: "Nuts & Seeds",
    searchTerms: ["til", "white sesame", "black sesame"],
    alternatives: [
      { name: "Tahini", ratio: "1 tbsp per 2 tbsp seeds", description: "Paste form" },
      { name: "Sunflower Seeds", ratio: "1:1", description: "Similar texture" },
      { name: "Hemp Seeds", ratio: "1:1", description: "Nutty flavor" },
      { name: "Chia Seeds", ratio: "1:1", description: "Different texture" },
      { name: "Poppy Seeds", ratio: "1:1", description: "Visual substitute" }
    ]
  },
  
  // THICKENING AGENTS
  {
    ingredient: "Agar Agar",
    category: "Thickening Agents",
    searchTerms: ["agar", "vegetarian gelatin"],
    alternatives: [
      { name: "Gelatin", ratio: "1:1", description: "Not vegetarian" },
      { name: "Pectin", ratio: "1:1", description: "For jams" },
      { name: "Carrageenan", ratio: "1:1", description: "Seaweed-based" },
      { name: "Xanthan Gum", ratio: "½ amount", description: "Very strong" }
    ]
  },
  {
    ingredient: "Xanthan Gum",
    category: "Thickening Agents",
    searchTerms: ["xanthan", "gum"],
    alternatives: [
      { name: "Guar Gum", ratio: "1.5:1", description: "Use more" },
      { name: "Psyllium Husk", ratio: "2:1", description: "Fiber-rich" },
      { name: "Chia Seeds", ratio: "Ground", description: "Natural thickener" },
      { name: "Cornstarch", ratio: "2:1", description: "Traditional option" }
    ]
  },
  
  // RAISING AGENTS
  {
    ingredient: "Baking Powder",
    category: "Raising Agents",
    searchTerms: ["baking powder"],
    alternatives: [
      { name: "DIY Baking Powder", ratio: "¼ tsp baking soda + ½ tsp cream of tartar", description: "Per 1 tsp" },
      { name: "Baking Soda + Acid", ratio: "¼ tsp soda + ½ cup buttermilk", description: "For 1 tsp powder" },
      { name: "Self-Rising Flour", ratio: "Adjust recipe", description: "Contains baking powder" },
      { name: "Whipped Egg Whites", ratio: "For leavening", description: "Mechanical leavener" }
    ]
  },
  {
    ingredient: "Baking Soda",
    category: "Raising Agents",
    searchTerms: ["sodium bicarbonate", "meetha soda"],
    alternatives: [
      { name: "Baking Powder", ratio: "3:1", description: "Use 3x the amount" },
      { name: "Potassium Bicarbonate", ratio: "1:1", description: "Sodium-free" },
      { name: "Self-Rising Flour", ratio: "Adjust recipe", description: "Contains leavener" }
    ]
  },
  {
    ingredient: "Yeast",
    category: "Raising Agents",
    searchTerms: ["active dry yeast", "instant yeast"],
    alternatives: [
      { name: "Sourdough Starter", ratio: "1 cup per packet", description: "Reduce liquid" },
      { name: "Baking Powder", ratio: "1 tsp per tsp yeast", description: "Quick bread" },
      { name: "Beer", ratio: "For flavor", description: "Not for rising" },
      { name: "Self-Rising Flour", ratio: "In recipe", description: "No yeast needed" }
    ]
  },
  
  // MISCELLANEOUS
  {
    ingredient: "Coconut Milk",
    category: "Miscellaneous",
    searchTerms: ["nariyal ka doodh", "coconut cream"],
    alternatives: [
      { name: "Heavy Cream", ratio: "1:1", description: "Dairy option" },
      { name: "Cashew Cream", ratio: "1:1", description: "Nut-based" },
      { name: "Almond Milk + Coconut Oil", ratio: "¾ cup + ¼ cup", description: "DIY option" },
      { name: "Soy Milk", ratio: "1:1", description: "Thinner texture" },
      { name: "Evaporated Milk", ratio: "1:1", description: "Dairy alternative" }
    ]
  },
  {
    ingredient: "Chocolate",
    category: "Miscellaneous",
    searchTerms: ["dark chocolate", "cocoa chocolate"],
    alternatives: [
      { name: "Cocoa Powder + Oil", ratio: "3 tbsp cocoa + 1 tbsp oil per oz", description: "DIY chocolate" },
      { name: "Carob Powder", ratio: "1:1", description: "Caffeine-free" },
      { name: "Cocoa Nibs", ratio: "1:1", description: "Less sweet" }
    ]
  },
  {
    ingredient: "Cocoa Powder",
    category: "Miscellaneous",
    searchTerms: ["cocoa", "cacao powder"],
    alternatives: [
      { name: "Carob Powder", ratio: "1:1", description: "Naturally sweet" },
      { name: "Dark Chocolate", ratio: "1 oz per 3 tbsp", description: "Melted chocolate" },
      { name: "Cacao Powder", ratio: "1:1", description: "Raw version" }
    ]
  },
  {
    ingredient: "Soy Sauce",
    category: "Miscellaneous",
    searchTerms: ["soya sauce", "shoyu"],
    alternatives: [
      { name: "Tamari", ratio: "1:1", description: "Gluten-free soy sauce" },
      { name: "Coconut Aminos", ratio: "1:1", description: "Soy-free, sweeter" },
      { name: "Worcestershire Sauce", ratio: "1:1", description: "Different flavor" },
      { name: "Fish Sauce", ratio: "½ amount", description: "Very strong" },
      { name: "Miso Paste + Water", ratio: "1 tbsp + water", description: "Fermented alternative" }
    ]
  },
  {
    ingredient: "Vinegar (Apple Cider)",
    category: "Miscellaneous",
    searchTerms: ["ACV", "apple vinegar"],
    alternatives: [
      { name: "White Vinegar", ratio: "1:1", description: "More acidic" },
      { name: "Rice Vinegar", ratio: "1:1", description: "Milder flavor" },
      { name: "Lemon Juice", ratio: "1:1", description: "Fresh alternative" },
      { name: "Red Wine Vinegar", ratio: "1:1", description: "Deeper flavor" }
    ]
  },
  {
    ingredient: "Cornmeal",
    category: "Miscellaneous",
    searchTerms: ["corn meal", "makka atta", "polenta"],
    alternatives: [
      { name: "Polenta", ratio: "1:1", description: "Same product" },
      { name: "Corn Grits", ratio: "1:1", description: "Coarser texture" },
      { name: "Semolina", ratio: "1:1", description: "Wheat-based" },
      { name: "Ground Oats", ratio: "1:1", description: "Gluten-free option" }
    ]
  }
];

// Extract meaningful words from query (4+ chars, not stop words)
export const extractQueryWords = (text: string): string[] => {
  return text.toLowerCase()
    .split(/\s+/)
    .filter(word => word.length >= 4 && !stopWords.has(word));
};

// Check if a word exists as a complete word in text (word boundary matching)
export const hasWholeWord = (text: string, word: string): boolean => {
  const regex = new RegExp(`\\b${word}\\b`, 'i');
  return regex.test(text);
};

// Detect if user is asking for alternatives/similar recipes
export const isAlternativeRequest = (query: string): boolean => {
  const lowerQuery = query.toLowerCase();
  
  const alternativePatterns = [
    'alternative', 'alternatives',
    'substitute', 'substitutes', 'substitution',
    'replace', 'replacement',
    'instead', 'other option', 'other options',
    'what else', 'something else', 'anything else',
    'similar', 'like this', 'different version',
    'another', 'more recipes', 'more like',
    'same but', 'variation', 'variations',
    'other recipes', 'other dishes', 'different',
    'suggest', 'recommend', 'show me more'
  ];
  
  return alternativePatterns.some(pattern => lowerQuery.includes(pattern));
};

// Detect if user is asking a follow-up question
export const isFollowUpQuestion = (query: string): boolean => {
  const lowerQuery = query.toLowerCase();
  
  const followUpPatterns = [
    'and ', 'also ', 'what about', 'how about',
    'can i ', 'could i ', 'should i ',
    'any ', 'more ', 'other ',
    'else', 'different'
  ];
  
  // Short queries are likely follow-ups
  if (query.trim().split(/\s+/).length <= 4) {
    return followUpPatterns.some(pattern => lowerQuery.includes(pattern));
  }
  
  return false;
};

// Extract recipe category/type from recipe name
export const getRecipeCategory = (recipeName: string): string[] => {
  const lowerName = recipeName.toLowerCase();
  const categories: string[] = [];
  
  // Dish types
  if (lowerName.includes('curry') || lowerName.includes('masala')) categories.push('curry');
  if (lowerName.includes('biryani') || lowerName.includes('pulao')) categories.push('rice');
  if (lowerName.includes('dal') || lowerName.includes('lentil')) categories.push('dal');
  if (lowerName.includes('paneer') || lowerName.includes('cheese')) categories.push('paneer');
  if (lowerName.includes('chicken') || lowerName.includes('meat')) categories.push('non-veg');
  if (lowerName.includes('roti') || lowerName.includes('naan') || lowerName.includes('paratha')) categories.push('bread');
  if (lowerName.includes('dosa') || lowerName.includes('idli') || lowerName.includes('uttapam')) categories.push('south-indian');
  if (lowerName.includes('tikka') || lowerName.includes('kebab')) categories.push('grilled');
  if (lowerName.includes('samosa') || lowerName.includes('pakora')) categories.push('snacks');
  
  // Dietary
  if (!lowerName.includes('chicken') && !lowerName.includes('meat') && !lowerName.includes('egg')) {
    categories.push('vegetarian');
  }
  
  return categories;
};

// Find similar recipes based on category and ingredients
export const findSimilarRecipes = (recipe: any, allRecipes: any[], limit: number = 5): any[] => {
  if (!recipe) return [];
  
  const categories = getRecipeCategory(recipe.name);
  const recipeName = recipe.name.toLowerCase();
  
  // Score each recipe based on similarity
  const scoredRecipes = allRecipes
    .filter(r => r.name.toLowerCase() !== recipeName)
    .map(r => {
      let score = 0;
      const otherCategories = getRecipeCategory(r.name);
      
      // Same category gets points
      otherCategories.forEach(cat => {
        if (categories.includes(cat)) score += 3;
      });
      
      // Shared ingredients get points
      if (recipe.ingredients && r.ingredients) {
        const recipeIngredients = recipe.ingredients.map((ing: any) => 
          (typeof ing === 'string' ? ing : ing.name).toLowerCase()
        );
        const otherIngredients = r.ingredients.map((ing: any) => 
          (typeof ing === 'string' ? ing : ing.name).toLowerCase()
        );
        
        recipeIngredients.forEach((ing: string) => {
          if (otherIngredients.some((otherIng: string) => 
            otherIng.includes(ing) || ing.includes(otherIng)
          )) {
            score += 1;
          }
        });
      }
      
      return { recipe: r, score };
    })
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(item => item.recipe);
  
  return scoredRecipes;
};

// Detect if user is asking for ingredient alternatives
export const isIngredientAlternativeRequest = (query: string): boolean => {
  const lowerQuery = query.toLowerCase();
  
  const patterns = [
    'alternative for',
    'alternative to',
    'substitute for',
    'substitute of',
    'replace',
    'instead of',
    'what can i use instead',
    'what else can i use',
    'don\'t have',
    'out of',
    'replacement for'
  ];
  
  return patterns.some(pattern => lowerQuery.includes(pattern));
};

// Find ingredient in database (fuzzy matching)
export const findIngredient = (query: string): IngredientAlternative | null => {
  const cleanQuery = query.toLowerCase().trim();
  
  // Try exact match first
  let found = ingredientAlternativesDatabase.find(ing => 
    ing.ingredient.toLowerCase() === cleanQuery
  );
  
  if (found) return found;
  
  // Try search terms
  found = ingredientAlternativesDatabase.find(ing => 
    ing.searchTerms?.some(term => term.toLowerCase() === cleanQuery)
  );
  
  if (found) return found;
  
  // Try partial match in ingredient name
  found = ingredientAlternativesDatabase.find(ing => 
    ing.ingredient.toLowerCase().includes(cleanQuery) || 
    cleanQuery.includes(ing.ingredient.toLowerCase())
  );
  
  if (found) return found;
  
  // Try partial match in search terms
  found = ingredientAlternativesDatabase.find(ing => 
    ing.searchTerms?.some(term => 
      term.toLowerCase().includes(cleanQuery) || 
      cleanQuery.includes(term.toLowerCase())
    )
  );
  
  return found || null;
};

// Extract ingredient name from query
export const extractIngredientFromQuery = (query: string): string | null => {
  const lowerQuery = query.toLowerCase();
  
  // Patterns to extract ingredient
  const patterns = [
    /alternative (?:for|to|of) (.+?)(?:\?|$)/,
    /substitute (?:for|of) (.+?)(?:\?|$)/,
    /replace (.+?)(?: with| in)?(?:\?|$)/,
    /instead of (.+?)(?:\?|$)/,
    /don't have (.+?)(?:\?|$)/,
    /out of (.+?)(?:\?|$)/,
    /replacement for (.+?)(?:\?|$)/,
    /what (?:can i use|to use) (?:instead of|for) (.+?)(?:\?|$)/,
    /use (?:instead of|for) (.+?)(?:\?|$)/
  ];
  
  for (const pattern of patterns) {
    const match = lowerQuery.match(pattern);
    if (match && match[1]) {
      return match[1].trim();
    }
  }
  
  return null;
};

// Get formatted alternatives response
export const getIngredientAlternativesResponse = (ingredient: IngredientAlternative): string => {
  const alternativesList = ingredient.alternatives
    .map((alt, idx) => {
      let line = `${idx + 1}. **${alt.name}**`;
      if (alt.ratio) line += ` - Ratio: ${alt.ratio}`;
      if (alt.description) line += `\n   ${alt.description}`;
      return line;
    })
    .join('\n\n');
  
  return `Great question! Here are the best alternatives for **${ingredient.ingredient}** (${ingredient.category}):\n\n${alternativesList}\n\n💡 **Pro Tip:** Choose based on your dietary needs, availability, and the specific dish you're making!\n\nNeed alternatives for another ingredient? Just ask!`;
};

// Get all available ingredient categories
export const getIngredientCategories = (): string[] => {
  const categories = new Set(ingredientAlternativesDatabase.map(ing => ing.category));
  return Array.from(categories);
};

// Search ingredients by category
export const getIngredientsByCategory = (category: string): IngredientAlternative[] => {
  return ingredientAlternativesDatabase.filter(ing => 
    ing.category.toLowerCase() === category.toLowerCase()
  );
};
