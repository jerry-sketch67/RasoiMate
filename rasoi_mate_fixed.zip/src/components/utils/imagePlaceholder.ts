/**
 * Placeholder images for Figma environment compatibility
 *
 * These data URIs prevent "Failed to fetch" errors that occur when Figma's
 * build environment tries to validate external image URLs during compilation.
 *
 * In production, you would replace these with actual image URLs or use a CDN.
 */

// Placeholder image data URI to avoid external fetches in Figma environment
// This is a gradient with a food icon
export const PLACEHOLDER_IMAGE =
  "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImciIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiNGRjk5MzMiLz48c3RvcCBvZmZzZXQ9IjUwJSIgc3RvcC1jb2xvcj0iIzRDQUY1MCIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3RvcC1jb2xvcj0iIzNGNTFCNSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSI0MDAiIGhlaWdodD0iNDAwIiBmaWxsPSJ1cmwoI2cpIiBvcGFjaXR5PSIwLjIiLz48Y2lyY2xlIGN4PSIyMDAiIGN5PSIyMDAiIHI9IjYwIiBmaWxsPSIjZmZmIiBvcGFjaXR5PSIwLjgiLz48cGF0aCBkPSJNMTcwIDIwMGgzMHYzMGgtMzB6bTMwLTE1aDMwdjQ1aC0zMHoiIGZpbGw9IiMzRjUxQjUiLz48L3N2Zz4=";

export const PLACEHOLDER_AVATAR =
  "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImEiIHgxPSIwJSIgeTE9IjAlIiB4Mj0iMTAwJSIgeTI9IjEwMCUiPjxzdG9wIG9mZnNldD0iMCUiIHN0b3AtY29sb3I9IiNGRjk5MzMiLz48c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiMzRjUxQjUiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48Y2lyY2xlIGN4PSI1MCIgY3k9IjUwIiByPSI1MCIgZmlsbD0idXJsKCNhKSIvPjxjaXJjbGUgY3g9IjUwIiBjeT0iNDAiIHI9IjE1IiBmaWxsPSIjZmZmIi8+PGVsbGlwc2UgY3g9IjUwIiBjeT0iNzUiIHJ4PSIyNSIgcnk9IjIwIiBmaWxsPSIjZmZmIi8+PC9zdmc+";

// Helper function to convert external URLs to placeholders for Figma compatibility
export function getFigmaSafeImage(url: string): string {
  // If it's already a data URI or empty, return as is
  if (!url || url.startsWith("data:")) {
    return url || PLACEHOLDER_IMAGE;
  }

  // Return the actual URL - images should work in Figma Make
  return url;
}