// PDF Generation utility for recipes
// Note: This creates a formatted text file that can be easily printed as PDF

import type { DetailedRecipe } from '../RecipeDetailDialog';

export function generateRecipePDF(recipe: DetailedRecipe): void {
  // Create nicely formatted content for PDF printing
  const content = `
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                    RASOI MATE RECIPE                       ┃
┃                 Vocal to Local Collection                  ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

${recipe.name}
${'═'.repeat(recipe.name.length)}

${recipe.description}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📍 LOCATION
${recipe.district}, ${recipe.state}

⏱️  COOKING INFORMATION
• Time: ${recipe.time || 'As needed'}
• Servings: ${recipe.servings || 'Multiple'}
• Difficulty: ${recipe.difficulty || 'Medium'}
• Type: ${recipe.rural ? '🌾 Traditional Rural Recipe' : '🏙️ Urban Recipe'}

${recipe.culturalNote ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏛️  CULTURAL SIGNIFICANCE

${recipe.culturalNote}

` : ''}

${recipe.ingredientSourcing ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🌱 WHERE TO SOURCE INGREDIENTS

${recipe.ingredientSourcing}

` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🥘 INGREDIENTS

${recipe.ingredients.map((ing, i) => `${(i + 1).toString().padStart(2, ' ')}. ${ing}`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👨‍🍳 PREPARATION STEPS

${recipe.steps.map((step, i) => `
┌─ STEP ${i + 1} ${'─'.repeat(Math.max(0, 55 - (i + 1).toString().length))}
│
│ ${step.split('\n').join('\n│ ')}
│
└${'─'.repeat(60)}
`).join('\n')}

${recipe.alternatives && recipe.alternatives.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔄 INGREDIENT ALTERNATIVES

${recipe.alternatives.map(alt => `
▸ ${alt.ingredient}
  ➜ Substitutes: ${alt.substitutes.join(', ')}
`).join('\n')}
` : ''}

${recipe.tips && recipe.tips.length > 0 ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 CHEF'S TIPS

${recipe.tips.map((tip, i) => `${i + 1}. ${tip}`).join('\n\n')}
` : ''}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📱 Recipe from Rasoi Mate
🇮🇳 Preserving India's Culinary Heritage
🌐 AI-Powered Smart Kitchen Assistant

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Generated on: ${new Date().toLocaleDateString('en-IN', { 
  weekday: 'long',
  day: 'numeric', 
  month: 'long', 
  year: 'numeric' 
})}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOW TO PRINT AS PDF:
1. Open this file in any text editor
2. File → Print (or Ctrl+P / Cmd+P)
3. Select "Save as PDF" or "Print to PDF"
4. Choose your preferred paper size (A4 recommended)
5. Save the PDF file

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`.trim();

  // Create and download the file
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${recipe.name.replace(/\s+/g, '_')}_Recipe.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Alternative: Generate HTML that can be printed as PDF
export function generateRecipeHTML(recipe: DetailedRecipe): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${recipe.name} - Rasoi Mate Recipe</title>
  <style>
    @page {
      size: A4;
      margin: 2cm;
    }
    
    body {
      font-family: 'Georgia', serif;
      line-height: 1.6;
      color: #333;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .header {
      text-align: center;
      border-bottom: 3px solid #FF9933;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    
    .header h1 {
      color: #FF6B35;
      margin: 10px 0;
      font-size: 2.5em;
    }
    
    .header .subtitle {
      color: #4CAF50;
      font-size: 1.2em;
    }
    
    .info-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
      margin: 20px 0;
      padding: 20px;
      background: #FFF8E1;
      border-radius: 8px;
    }
    
    .info-item {
      display: flex;
      align-items: center;
    }
    
    .info-item strong {
      color: #FF9933;
      margin-right: 8px;
    }
    
    .section {
      margin: 30px 0;
      page-break-inside: avoid;
    }
    
    .section h2 {
      color: #FF6B35;
      border-left: 5px solid #FF9933;
      padding-left: 15px;
      margin-bottom: 15px;
    }
    
    .cultural-note, .sourcing {
      background: #E8F5E9;
      padding: 15px;
      border-radius: 8px;
      margin: 15px 0;
    }
    
    .ingredients-list, .steps-list {
      list-style: none;
      padding: 0;
    }
    
    .ingredients-list li {
      padding: 8px;
      margin: 5px 0;
      background: #FFF8E1;
      border-left: 3px solid #FF9933;
      padding-left: 15px;
    }
    
    .steps-list li {
      padding: 15px;
      margin: 15px 0;
      background: #FFFBF0;
      border-radius: 8px;
      border: 1px solid #FFE4B5;
    }
    
    .step-number {
      display: inline-block;
      background: #FF9933;
      color: white;
      width: 30px;
      height: 30px;
      border-radius: 50%;
      text-align: center;
      line-height: 30px;
      margin-right: 10px;
      font-weight: bold;
    }
    
    .alternatives {
      background: #E3F2FD;
      padding: 10px 15px;
      margin: 5px 0;
      border-radius: 5px;
    }
    
    .tips {
      background: #FFF9C4;
      padding: 15px;
      border-radius: 8px;
      margin: 10px 0;
    }
    
    .footer {
      text-align: center;
      margin-top: 40px;
      padding-top: 20px;
      border-top: 2px solid #FF9933;
      color: #666;
    }
    
    @media print {
      body {
        padding: 0;
      }
      
      .no-print {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="subtitle">Rasoi Mate Recipe Collection</div>
    <h1>${recipe.name}</h1>
    <p>${recipe.description}</p>
    <p><strong>📍 ${recipe.district}, ${recipe.state}</strong></p>
  </div>
  
  <div class="info-grid">
    <div class="info-item"><strong>⏱️ Time:</strong> ${recipe.time || 'As needed'}</div>
    <div class="info-item"><strong>👥 Servings:</strong> ${recipe.servings || 'Multiple'}</div>
    <div class="info-item"><strong>🔥 Difficulty:</strong> ${recipe.difficulty || 'Medium'}</div>
    <div class="info-item"><strong>📝 Type:</strong> ${recipe.rural ? '🌾 Rural' : '🏙️ Urban'}</div>
  </div>
  
  ${recipe.culturalNote ? `
  <div class="cultural-note">
    <h3>🏛️ Cultural Significance</h3>
    <p>${recipe.culturalNote}</p>
  </div>
  ` : ''}
  
  ${recipe.ingredientSourcing ? `
  <div class="sourcing">
    <h3>🌱 Where to Source Ingredients</h3>
    <p>${recipe.ingredientSourcing}</p>
  </div>
  ` : ''}
  
  <div class="section">
    <h2>🥘 Ingredients</h2>
    <ul class="ingredients-list">
      ${recipe.ingredients.map(ing => `<li>${ing}</li>`).join('\n')}
    </ul>
  </div>
  
  <div class="section">
    <h2>👨‍🍳 Preparation Steps</h2>
    <ol class="steps-list">
      ${recipe.steps.map((step, i) => `
        <li>
          <span class="step-number">${i + 1}</span>
          ${step}
        </li>
      `).join('\n')}
    </ol>
  </div>
  
  ${recipe.alternatives && recipe.alternatives.length > 0 ? `
  <div class="section">
    <h2>🔄 Ingredient Alternatives</h2>
    ${recipe.alternatives.map(alt => `
      <div class="alternatives">
        <strong>${alt.ingredient}:</strong> ${alt.substitutes.join(', ')}
      </div>
    `).join('\n')}
  </div>
  ` : ''}
  
  ${recipe.tips && recipe.tips.length > 0 ? `
  <div class="section">
    <h2>💡 Chef's Tips</h2>
    ${recipe.tips.map(tip => `
      <div class="tips">💡 ${tip}</div>
    `).join('\n')}
  </div>
  ` : ''}
  
  <div class="footer">
    <p><strong>🇮🇳 Rasoi Mate - Preserving India's Culinary Heritage</strong></p>
    <p>AI-Powered Smart Kitchen Assistant</p>
    <p>Generated on ${new Date().toLocaleDateString('en-IN', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    })}</p>
    <p class="no-print" style="margin-top: 20px; color: #FF9933;">
      <strong>To save as PDF: File → Print → Save as PDF</strong>
    </p>
  </div>
</body>
</html>
  `.trim();
}

export function downloadHTMLRecipe(recipe: DetailedRecipe): void {
  const html = generateRecipeHTML(recipe);
  const blob = new Blob([html], { type: 'text/html' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${recipe.name.replace(/\s+/g, '_')}_Recipe.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
