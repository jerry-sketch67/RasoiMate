import { ChefHat, Youtube, Instagram, Facebook, Twitter, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate?: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const handleNavigation = (page: string) => (e: React.MouseEvent) => {
    if (onNavigate) {
      e.preventDefault();
      onNavigate(page);
    }
  };

  return (
    <footer className="border-t bg-gray-50 mt-auto">
      <div className="container mx-auto max-w-7xl px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-3">
              <ChefHat className="h-5 w-5" style={{ color: '#FF9933' }} />
              <span className="font-semibold">Rasoi Mate</span>
            </div>
            <p className="text-sm text-gray-600">
              Where Tradition Meets Technology, One Recipe at a Time.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="mb-4 text-gray-900">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('about')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  About Us
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('ai-assistant')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  AI Assistant
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('recipes')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Recipes
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('drinks')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Drinks
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('vocal-to-local')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Vocal to Local
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="mb-4 text-gray-900">Support</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('help')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Help Center
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('contact')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Contact Us
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('privacy')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Privacy Policy
                </a>
              </li>
              <li>
                <a 
                  href="#" 
                  onClick={handleNavigation('terms')} 
                  className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>

          {/* Connect With Us */}
          <div>
            <h4 className="mb-4 text-gray-900">Connect With Us</h4>
            <div className="flex gap-3 mb-4">
              <a 
                href="https://www.youtube.com/@RasoiMate" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:opacity-70 transition-opacity"
                title="YouTube - @RasoiMate"
              >
                <Youtube className="h-5 w-5 text-red-600" />
              </a>
              <a 
                href="https://www.instagram.com/rasoi_mate" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:opacity-70 transition-opacity"
                title="Instagram - @rasoi_mate"
              >
                <Instagram className="h-5 w-5" style={{ color: '#FF9933' }} />
              </a>
              <a 
                href="#" 
                className="hover:opacity-70 transition-opacity"
                title="Facebook"
              >
                <Facebook className="h-5 w-5" style={{ color: '#3F51B5' }} />
              </a>
              <a 
                href="#" 
                className="hover:opacity-70 transition-opacity"
                title="Twitter"
              >
                <Twitter className="h-5 w-5" style={{ color: '#3F51B5' }} />
              </a>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="h-4 w-4" />
                <a href="mailto:contact@rasoimate.com" className="hover:text-gray-900 transition-colors">
                  contact@rasoimate.com
                </a>
              </div>
              <div className="text-xs text-gray-500">
                <p className="mb-1">For partnerships or developer queries:</p>
                <a href="mailto:sohamsingale775@gmail.com" className="hover:text-gray-900 transition-colors block">
                  sohamsingale775@gmail.com
                </a>
                <a href="mailto:jerry415721@gmail.com" className="hover:text-gray-900 transition-colors block">
                  jerry415721@gmail.com
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t pt-6 text-center space-y-1">
          <p className="text-sm text-gray-600">
            © 2025 Rasoi Mate – Where Tradition Meets Technology, One Recipe at a Time.
          </p>
          <p className="text-sm text-gray-600">
            Made with ❤️ for Indian Kitchens
          </p>
        </div>
      </div>
    </footer>
  );
}
