import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { HelpCircle, Mic, BookOpen, Settings, Globe, ChefHat, Shield, Zap } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Footer } from './Footer';

interface HelpCenterPageProps {
  onNavigate: (page: string) => void;
}

export function HelpCenterPage({ onNavigate }: HelpCenterPageProps) {
  const faqCategories = [
    {
      icon: Zap,
      title: 'Getting Started',
      color: '#FF9933',
      faqs: [
        {
          question: 'How do I create an account on Rasoi Mate?',
          answer: 'Click the "Login" button in the header, then select "Sign Up". Fill in your name, email, and create a password. You can also sign up quickly using your Google or Facebook account.',
        },
        {
          question: 'Is Rasoi Mate free to use?',
          answer: 'Yes! Rasoi Mate is completely free to use. All features including AI assistance, recipe library, and voice commands are available at no cost.',
        },
        {
          question: 'What makes Rasoi Mate different from other recipe apps?',
          answer: 'Rasoi Mate combines AI technology with Indian culinary traditions. It offers voice-activated cooking assistance, automatic ingredient scaling, smart substitutions, and supports multiple Indian languages. Our unique "Vocal to Local" feature preserves authentic regional recipes from across India.',
        },
      ],
    },
    {
      icon: Mic,
      title: 'Voice Features',
      color: '#3F51B5',
      faqs: [
        {
          question: 'How do I use voice commands?',
          answer: 'Go to the AI Assistant page and click the microphone icon. Grant microphone permissions when prompted. Speak clearly and say commands like "Show me recipes for Biryani" or "How do I make Paneer Butter Masala for 4 people?"',
        },
        {
          question: 'Which languages are supported for voice input?',
          answer: 'Rasoi Mate supports voice input in English, Hindi, Tamil, Bengali, Marathi, and several other Indian languages. The AI will understand your accent and regional variations.',
        },
        {
          question: 'Is my voice data stored?',
          answer: 'No. Voice commands are processed in real-time and immediately converted to text. The audio is never permanently stored. We prioritize your privacy - check our Privacy Policy for full details.',
        },
        {
          question: 'Voice commands are not working. What should I do?',
          answer: 'First, ensure you\'ve granted microphone permissions in your browser. Check that your microphone is working in other applications. Try speaking clearly and closer to the microphone. If issues persist, try refreshing the page or using the text input option.',
        },
      ],
    },
    {
      icon: BookOpen,
      title: 'Recipes & Cooking',
      color: '#4CAF50',
      faqs: [
        {
          question: 'How do I scale recipes for more or fewer people?',
          answer: 'On any recipe detail page, you\'ll find an "Adjust Servings" option. Simply enter the number of people you\'re cooking for, and all ingredients will automatically adjust to the correct proportions.',
        },
        {
          question: 'Can I substitute ingredients I don\'t have?',
          answer: 'Absolutely! Rasoi Mate\'s AI provides smart ingredient substitutions. Look for the "AI-Powered Alternatives" section in each recipe, or ask the AI assistant "What can I use instead of [ingredient]?"',
        },
        {
          question: 'How do I save my favorite recipes?',
          answer: 'Click the heart icon on any recipe card to add it to your favorites. Access all saved recipes from your Dashboard by clicking your profile icon.',
        },
        {
          question: 'Can I contribute my own recipes?',
          answer: 'Yes! Visit the "Vocal to Local" page and click "Share Your Story" or "Contribute Recipe". Fill in the details including ingredients, instructions, and cultural significance. Your contribution helps preserve culinary heritage!',
        },
        {
          question: 'What if a recipe doesn\'t turn out well?',
          answer: 'Cooking is an art that improves with practice! Common issues include: incorrect measurements (use our portion adjuster), wrong heat levels, or ingredient quality. Try the "Speak Recipe" feature for step-by-step voice guidance. Feel free to contact support for specific troubleshooting.',
        },
      ],
    },
    {
      icon: Globe,
      title: 'Languages & Localization',
      color: '#F7931E',
      faqs: [
        {
          question: 'How do I change the language?',
          answer: 'Use the Google Translate widget in the header to translate the entire site into your preferred language. For voice commands, simply speak in your language - our AI will understand!',
        },
        {
          question: 'Are regional recipes available in local languages?',
          answer: 'Yes! Our "Vocal to Local" section features authentic regional recipes. While the interface can be translated, many recipes include original regional terms to preserve authenticity.',
        },
        {
          question: 'Can the AI understand my regional accent?',
          answer: 'Yes! Our AI is trained on diverse Indian accents and dialects. It can understand regional variations in pronunciation and vocabulary.',
        },
      ],
    },
    {
      icon: Settings,
      title: 'Account & Settings',
      color: '#9C27B0',
      faqs: [
        {
          question: 'How do I change my password?',
          answer: 'Go to your Dashboard (click your profile icon), then select "Settings" or "Account Preferences". You\'ll find an option to update your password.',
        },
        {
          question: 'Can I delete my account?',
          answer: 'Yes. In your account settings, scroll to the bottom and click "Delete Account". All your data will be permanently removed within 30 days as per our Privacy Policy.',
        },
        {
          question: 'How do I update my dietary preferences?',
          answer: 'In your Dashboard, find the "Dietary Preferences" section. Mark any allergies, dietary restrictions (vegetarian, vegan, gluten-free, etc.), and the AI will provide relevant recipe suggestions.',
        },
        {
          question: 'Why do I need to enable certain permissions?',
          answer: 'Microphone permission is required only for voice commands. Location permission may be requested to suggest regional recipes. Camera permission is optional for scanning ingredients or sharing recipe photos. You can use Rasoi Mate without granting these permissions.',
        },
      ],
    },
    {
      icon: ChefHat,
      title: 'Vocal to Local Feature',
      color: '#FF6B35',
      faqs: [
        {
          question: 'What is "Vocal to Local"?',
          answer: 'Vocal to Local is our initiative to preserve authentic regional recipes from across India\'s 28 states and 8 union territories. It features traditional dishes with their cultural stories, passed down through generations.',
        },
        {
          question: 'How many recipes are in Vocal to Local?',
          answer: 'Currently, we have 1000+ authentic regional recipes covering all Indian states and union territories. New recipes are added regularly through community contributions.',
        },
        {
          question: 'Can I listen to recipe stories?',
          answer: 'Yes! Many Vocal to Local recipes include a "Listen to Story" feature where you can hear the cultural significance and history behind the dish.',
        },
        {
          question: 'How can I find recipes from my home state?',
          answer: 'On the Vocal to Local page, use the state/UT selection dropdown or search by district. You can also filter by cuisine type, cooking time, and dietary preferences.',
        },
      ],
    },
    {
      icon: Shield,
      title: 'Privacy & Security',
      color: '#607D8B',
      faqs: [
        {
          question: 'How is my data protected?',
          answer: 'We use industry-standard encryption for all data transmission and storage. Voice data is processed in real-time and not stored. Account information is secured with modern authentication protocols. Read our full Privacy Policy for details.',
        },
        {
          question: 'Do you share my information with third parties?',
          answer: 'We never sell your personal information. We only work with trusted AI providers (Google, OpenAI) to process recipe requests. These providers are bound by strict privacy agreements.',
        },
        {
          question: 'Can I use Rasoi Mate anonymously?',
          answer: 'You need an account to access personalized features like favorites and dashboard. However, you can browse recipes without logging in. We collect minimal information - just name and email.',
        },
      ],
    },
  ];

  const quickActions = [
    { label: 'Try AI Assistant', action: () => onNavigate('ai-assistant'), color: '#3F51B5' },
    { label: 'Browse Recipes', action: () => onNavigate('recipes'), color: '#4CAF50' },
    { label: 'Explore Vocal to Local', action: () => onNavigate('vocal-to-local'), color: '#FF9933' },
    { label: 'Contact Support', action: () => onNavigate('contact'), color: '#F7931E' },
  ];

  return (
    <div className="bg-gradient-to-br from-background via-accent/20 to-background py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="flex items-center justify-center mb-4">
            <div className="w-16 h-16 rounded-full gradient-green flex items-center justify-center">
              <HelpCircle className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl mb-4 bg-gradient-to-r from-[var(--green)] to-[var(--saffron)] bg-clip-text text-transparent">
            Help Center & FAQ
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions and learn how to make the most of Rasoi Mate's features.
          </p>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12"
        >
          <Card className="p-6">
            <h3 className="mb-4 text-center">Quick Actions</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  onClick={action.action}
                  className="hover-lift"
                  style={{ background: action.color }}
                >
                  {action.label}
                </Button>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* FAQ Categories */}
        <div className="grid gap-8">
          {faqCategories.map((category, categoryIndex) => (
            <motion.div
              key={categoryIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
            >
              <Card className="p-6 hover-lift">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center"
                    style={{ background: `${category.color}20` }}
                  >
                    <category.icon className="h-5 w-5" style={{ color: category.color }} />
                  </div>
                  <h2 className="text-2xl">{category.title}</h2>
                  <Badge className="ml-auto" style={{ background: category.color }}>
                    {category.faqs.length} FAQs
                  </Badge>
                </div>

                <Accordion type="single" collapsible className="w-full">
                  {category.faqs.map((faq, faqIndex) => (
                    <AccordionItem key={faqIndex} value={`item-${categoryIndex}-${faqIndex}`}>
                      <AccordionTrigger className="text-left hover:no-underline">
                        <span className="pr-4">{faq.question}</span>
                      </AccordionTrigger>
                      <AccordionContent>
                        <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
                          {faq.answer}
                        </p>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Still Need Help */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-12"
        >
          <Card className="p-8 text-center bg-gradient-to-br from-[var(--saffron)]/10 to-[var(--tech-blue)]/10">
            <h3 className="mb-4">Still Need Help?</h3>
            <p className="text-muted-foreground mb-6">
              Can't find what you're looking for? Our support team is here to assist you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={() => onNavigate('contact')}
                className="gradient-saffron hover-lift"
              >
                Contact Support
              </Button>
              <Button
                onClick={() => onNavigate('about')}
                variant="outline"
                className="hover-glow"
              >
                About Rasoi Mate
              </Button>
            </div>
            <div className="mt-6 text-sm text-muted-foreground">
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <div>
                  <strong>Email:</strong> support@rasoi-mate.com
                </div>
                <div className="hidden sm:block">•</div>
                <div>
                  <strong>Response Time:</strong> Within 24 hours
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    <Footer />
    </div>
  );
{
