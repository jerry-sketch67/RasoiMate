import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Mic, Send, Volume2, Download, Users, Globe, Sparkles, ChefHat, X, MicOff, StopCircle, Loader2, MessageSquare, Trash2, HelpCircle, ExternalLink } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { ScrollArea } from './ui/scroll-area';
import { db } from '../firebase';
import { doc, setDoc, updateDoc, arrayUnion, serverTimestamp } from 'firebase/firestore';
import { mockRecipes } from './RecipesPage';
import { recipeDatabase } from './data/enhancedRecipeData';
import { toast } from 'sonner@2.0.3';
import { translateText, translateArray } from './utils/translateText';
import { useLanguage } from './LanguageContext';
import { Footer } from './Footer';
import { KitchenBackground } from './KitchenBackground';
import { 
  extractQueryWords, 
  hasWholeWord, 
  isAlternativeRequest, 
  isFollowUpQuestion, 
  findSimilarRecipes, 
  getRecipeCategory,
  isIngredientAlternativeRequest,
  extractIngredientFromQuery,
  findIngredient,
  getIngredientAlternativesResponse,
  getIngredientCategories 
} from './utils/recipeSearchHelpers';

interface AIAssistantPageProps {
  selectedRecipe?: any;
  onClearRecipe: () => void;
  onNavigate: (page: string) => void;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
}

export function AIAssistantPage({ selectedRecipe, onClearRecipe, onNavigate }: AIAssistantPageProps) {
  const [input, setInput] = useState('');
  const [numPeople, setNumPeople] = useState('4');
  const { language, setLanguage } = useLanguage();
  const [currentRecipe, setCurrentRecipe] = useState<any>(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string>('');
  
  // Conversation context tracking
  const [lastDiscussedRecipe, setLastDiscussedRecipe] = useState<any>(null);
  const [lastTopic, setLastTopic] = useState<string>('');
  
  const recognitionRef = useRef<any>(null);
  const speechSynthRef = useRef<SpeechSynthesisUtterance | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // Language code mapping for speech recognition and synthesis
  const languageCodes: Record<string, { recognition: string; synthesis: string }> = {
    english: { recognition: 'en-IN', synthesis: 'en-IN' },
    hindi: { recognition: 'hi-IN', synthesis: 'hi-IN' },
    tamil: { recognition: 'ta-IN', synthesis: 'ta-IN' },
    bengali: { recognition: 'bn-IN', synthesis: 'bn-IN' },
    marathi: { recognition: 'mr-IN', synthesis: 'mr-IN' }
  };

  const getInitialMessage = (lang: string) => {
    const greetings: Record<string, string> = {
      english: "Hey there! 👋 I'm your AI kitchen buddy! Think of me as your personal chef who's always ready to help.\n\n**What can I do for you?**\n• Share step-by-step recipes for 1000+ Indian dishes 🍛\n• Help you find ingredient substitutes 🥄\n• Give you cooking tips and tricks 💡\n• Answer your food questions 💬\n\n**Just ask me naturally!**\nFor example:\n• \"Paneer Butter Masala\" (I'll give you the full recipe!)\n• \"How do I make biryani?\"\n• \"Alternative for cornflour\" (when you need substitutes)\n• \"What can I cook with paneer?\"\n\n💡 Pro tip: You can type or use the microphone button 🎤\n📚 I know recipes from all 28 Indian states!\n\nSo... what are you craving today? 😊",
      hindi: "नमस्ते! 🙏 मैं आपका AI रसोई मित्र हूं। मुझसे कुछ भी पूछें:\n\n• 1000+ व्यंजनों की विधि\n• सामग्री के विकल्प\n• खाना पकाने की युक्तियां\n• आहार संशोधन\n\nबस नाम बताएं और मैं पूरी विधि बताऊंगा! 🎤 आवाज का उपयोग करें!",
      tamil: "வணக்கம்! 🙏 நான் உங்கள் AI சமையல் நண்பர். என்னிடம் கேளுங்கள்:\n\n• 1000+ செய்முறைகள்\n• பொருள் மாற்றுகள்\n• சமையல் குறிப்புகள்\n• உணவு மாற்றங்கள்\n\nபெயர் சொல்லுங்கள், முழு செய்முறையும் கொடுப்பேன்! 🎤",
      bengali: "নমস্কার! 🙏 আমি আপনার AI রান্নাঘর বন্ধু। আমাকে জিজ্ঞাসা করুন:\n\n• 1000+ রেসিপি\n• উপাদান বিকল্প\n• রান্নার টিপস\n• খাদ্যতালিকাগত পরিবর্তন\n\nনাম বলুন, পূর্ণ রেসিপি দেব! 🎤",
      marathi: "नमस्कार! 🙏 मी तुमचा AI स्वयंपाकघर मित्र आहे. विचारा:\n\n• 1000+ पाककृती\n• घटक पर्याय\n• स्वयंपाक टिपा\n• आहार बदल\n\nनाव सांगा, संपूर्ण पाककृती देईन! 🎤"
    };
    return greetings[lang] || greetings.english;
  };

  // Initialize conversations
  useEffect(() => {
    const savedConversations = localStorage.getItem('aiConversations');
    if (savedConversations) {
      const parsed = JSON.parse(savedConversations);
      setConversations(parsed);
      if (parsed.length > 0) {
        setActiveConversationId(parsed[0].id);
      }
    } else {
      // Create initial conversation
      const initialConv: Conversation = {
        id: Date.now().toString(),
        title: 'New Chat',
        messages: [{
          role: 'assistant',
          content: getInitialMessage(language),
          timestamp: Date.now()
        }],
        createdAt: Date.now()
      };
      setConversations([initialConv]);
      setActiveConversationId(initialConv.id);
      localStorage.setItem('aiConversations', JSON.stringify([initialConv]));
    }
  }, []);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [conversations, activeConversationId]);

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined' && ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window)) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = languageCodes[language]?.recognition || 'en-IN';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
        setIsListening(false);
        toast.success(`Heard: "${transcript}"`);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'no-speech') {
          toast.error('No speech detected. Please try again.');
        } else if (event.error === 'not-allowed') {
          toast.error('Microphone access denied. Please enable it in browser settings.');
        } else {
          toast.error('Could not understand. Please try again.');
        }
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    } else {
      console.warn('Speech recognition not supported in this browser');
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // Already stopped
        }
      }
      window.speechSynthesis.cancel();
    };
  }, [language]);

  // Update language for speech recognition
  useEffect(() => {
    if (recognitionRef.current) {
      recognitionRef.current.lang = languageCodes[language]?.recognition || 'en-IN';
    }
  }, [language]);

  // Update Google Translate when language changes
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).google?.translate) {
      const languageMap: Record<string, string> = {
        english: 'en',
        hindi: 'hi',
        tamil: 'ta',
        bengali: 'bn',
        marathi: 'mr'
      };
      
      const googleTranslateElement = document.querySelector('.goog-te-combo') as HTMLSelectElement;
      if (googleTranslateElement) {
        googleTranslateElement.value = languageMap[language] || 'en';
        googleTranslateElement.dispatchEvent(new Event('change'));
      }
    }
  }, [language]);

  // Handle recipe selection from recipes page
  useEffect(() => {
    if (selectedRecipe) {
      const query = `How to make ${selectedRecipe.name} for ${numPeople} people`;
      addMessageToActiveConversation('user', query);
      handleAIResponse(query);
    }
  }, [selectedRecipe]);

  const getCurrentMessages = (): Message[] => {
    const activeConv = conversations.find(c => c.id === activeConversationId);
    return activeConv?.messages || [];
  };

  const addMessageToActiveConversation = (role: 'user' | 'assistant', content: string) => {
    setConversations(prev => {
      const updated = prev.map(conv => {
        if (conv.id === activeConversationId) {
          const newMessages = [...conv.messages, { role, content, timestamp: Date.now() }];
          // Update title based on first user message
          const firstUserMessage = newMessages.find(m => m.role === 'user');
          const title = firstUserMessage ? firstUserMessage.content.slice(0, 30) + '...' : 'New Chat';
          return { ...conv, messages: newMessages, title };
        }
        return conv;
      });
      localStorage.setItem('aiConversations', JSON.stringify(updated));
      return updated;
    });
  };

  const createNewConversation = () => {
    const newConv: Conversation = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [{
        role: 'assistant',
        content: getInitialMessage(language),
        timestamp: Date.now()
      }],
      createdAt: Date.now()
    };
    const updated = [newConv, ...conversations];
    setConversations(updated);
    setActiveConversationId(newConv.id);
    setCurrentRecipe(null);
    
    // Clear conversation context
    setLastDiscussedRecipe(null);
    setLastTopic('');
    
    localStorage.setItem('aiConversations', JSON.stringify(updated));
    toast.success('New conversation started');
  };

  const deleteConversation = (id: string) => {
    if (conversations.length === 1) {
      toast.error('Cannot delete the last conversation');
      return;
    }
    const updated = conversations.filter(c => c.id !== id);
    setConversations(updated);
    if (activeConversationId === id) {
      setActiveConversationId(updated[0].id);
    }
    localStorage.setItem('aiConversations', JSON.stringify(updated));
    toast.success('Conversation deleted');
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    addMessageToActiveConversation('user', input);
    const userQuery = input;
    setInput('');
    
    await handleAIResponse(userQuery);
  };

  const handleAIResponse = async (query: string) => {
    setIsLoading(true);
    
    try {
      // Mock AI response
      const response = await generateMockResponse(query, numPeople);
      const responseText = response.text;
      const recipeData = response.recipe;

      addMessageToActiveConversation('assistant', responseText);
      
      if (recipeData) {
        setCurrentRecipe(recipeData);
      }

      if (autoSpeak) {
        speakText(responseText);
      }
    } catch (error) {
      console.error('AI Error:', error);
      toast.error('Failed to get AI response.');
    } finally {
      setIsLoading(false);
    }
  };

  const startListening = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not available in this browser. Please use Chrome, Edge, or Safari.');
      return;
    }
    
    if (!isListening) {
      try {
        // Stop any ongoing recognition first
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // Ignore if not running
        }
        
        // Wait a bit before starting
        setTimeout(() => {
          try {
            recognitionRef.current.lang = languageCodes[language]?.recognition || 'en-IN';
            recognitionRef.current.start();
            setIsListening(true);
            toast.info('🎤 Listening... Speak now!');
          } catch (error: any) {
            console.error('Error starting recognition:', error);
            setIsListening(false);
            if (error.message && error.message.includes('already started')) {
              // Recognition already started, just update state
              setIsListening(true);
            } else {
              toast.error('Could not start microphone. Please check permissions and try again.');
            }
          }
        }, 100);
      } catch (error: any) {
        console.error('Error in startListening:', error);
        setIsListening(false);
        toast.error('Microphone error. Please try again.');
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  const speakText = (text: string) => {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = languageCodes[language]?.synthesis || 'en-IN';
    utterance.rate = 0.9;
    utterance.pitch = 1;

    // Try to find a voice that matches the language
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(voice => 
      voice.lang.startsWith(languageCodes[language]?.synthesis.split('-')[0] || 'en')
    );
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => {
      setIsSpeaking(false);
      toast.error('Speech synthesis error');
    };

    speechSynthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    toast.success('🔊 Speaking...');
  };

  const stopSpeaking = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  const downloadConversation = () => {
    const messages = getCurrentMessages();
    const conversationText = messages.map(msg => {
      const role = msg.role === 'user' ? 'You' : 'AI Chef';
      return `${role}:\n${msg.content}\n\n`;
    }).join('---\n\n');

    const header = `Rasoi Mate - AI Cooking Assistant\nConversation Export\nDate: ${new Date().toLocaleString()}\nLanguage: ${language}\nServings: ${numPeople}\n\n${'='.repeat(50)}\n\n`;

    const fullText = header + conversationText;

    const blob = new Blob([fullText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rasoi-mate-conversation-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast.success('✅ Conversation downloaded!');
  };

  // Create a combined list of all available recipes
  const getAllRecipes = () => {
    const combined: any[] = [...mockRecipes];
    
    // Add recipes from enhanced database
    Object.values(recipeDatabase).forEach(recipe => {
      combined.push({
        name: recipe.name,
        ingredients: recipe.ingredients.map((ing, idx) => ({
          name: ing,
          amount: 1,
          unit: 'as needed',
          alternatives: recipe.alternatives?.[idx]?.substitutes || []
        })),
        steps: recipe.steps,
        time: recipe.time || '45 mins',
        difficulty: recipe.difficulty || 'Medium',
        baseServings: 4,
        tips: recipe.tips || []
      });
    });
    
    return combined;
  };

  // Helper function to translate text based on current language
  const translateIfNeeded = async (text: string): Promise<string> => {
    if (language === 'english') return text;
    const langCode = languageCodes[language]?.recognition || 'en-IN';
    try {
      return await translateText(text, langCode);
    } catch (error) {
      console.error('Translation error:', error);
      return text; // Return original if translation fails
    }
  };

  // Handle contextual alternative requests
  const handleContextualAlternatives = (query: string) => {
    const allRecipes = getAllRecipes();
    
    // If user is asking for alternatives and we have a last discussed recipe
    if (isAlternativeRequest(query) && lastDiscussedRecipe) {
      const similarRecipes = findSimilarRecipes(lastDiscussedRecipe, allRecipes, 8);
      
      if (similarRecipes.length > 0) {
        const recipeList = similarRecipes.map((r, idx) => 
          `${idx + 1}. **${r.name}** - ${r.time || '45 mins'} - ${r.difficulty || 'Medium'}`
        ).join('\n');
        
        const categories = getRecipeCategory(lastDiscussedRecipe.name);
        const categoryText = categories.length > 0 
          ? ` (${categories.join(', ')} dishes)` 
          : '';
        
        return {
          text: `Great question! Based on **${lastDiscussedRecipe.name}**, here are similar recipes you might enjoy${categoryText}:\n\n${recipeList}\n\n💡 **Tip:** Just ask me "How to make [recipe name]" to get the full recipe!\n\nYou can also ask:\n• "Show me more curry recipes"\n• "What can I make with paneer?"\n• "Quick vegetarian dishes"`,
          recipe: null
        };
      }
    }
    
    // Check if asking for alternatives to a specific ingredient mentioned in query
    const queryWords = extractQueryWords(query);
    for (const recipe of allRecipes) {
      const recipeWords = extractQueryWords(recipe.name);
      const hasMatch = recipeWords.some(rWord => 
        queryWords.some(qWord => qWord === rWord || hasWholeWord(recipe.name.toLowerCase(), qWord))
      );
      
      if (hasMatch) {
        const similarRecipes = findSimilarRecipes(recipe, allRecipes, 6);
        
        if (similarRecipes.length > 0) {
          const recipeList = similarRecipes.map((r, idx) => 
            `${idx + 1}. **${r.name}** - ${r.time || '45 mins'}`
          ).join('\n');
          
          return {
            text: `Looking for alternatives to **${recipe.name}**? Here are some great options:\n\n${recipeList}\n\n💡 Just ask me about any of these recipes to get started!`,
            recipe: null
          };
        }
      }
    }
    
    return null;
  };

  // Handle "what else" type queries
  const handleWhatElseQuery = (query: string) => {
    const lowerQuery = query.toLowerCase();
    const allRecipes = getAllRecipes();
    
    // Detect category requests
    const categoryMap: Record<string, string[]> = {
      'curry': ['curry', 'masala'],
      'rice': ['biryani', 'pulao', 'rice'],
      'dal': ['dal', 'lentil'],
      'paneer': ['paneer'],
      'bread': ['naan', 'roti', 'paratha'],
      'snack': ['samosa', 'pakora', 'bhaji'],
      'south indian': ['dosa', 'idli', 'uttapam', 'vada'],
      'sweet': ['sweet', 'dessert', 'halwa', 'kheer'],
      'vegetarian': ['vegetarian', 'veg'],
      'quick': ['quick', 'easy', 'fast']
    };
    
    for (const [category, keywords] of Object.entries(categoryMap)) {
      if (keywords.some(keyword => lowerQuery.includes(keyword))) {
        const categoryRecipes = allRecipes.filter(r => {
          const categories = getRecipeCategory(r.name);
          return categories.includes(category) || 
                 keywords.some(kw => r.name.toLowerCase().includes(kw));
        }).slice(0, 8);
        
        if (categoryRecipes.length > 0) {
          const recipeList = categoryRecipes.map((r, idx) => 
            `${idx + 1}. **${r.name}** - ${r.time || '45 mins'}`
          ).join('\n');
          
          return {
            text: `Here are some excellent **${category}** recipes:\n\n${recipeList}\n\n💡 Ask me about any recipe for detailed instructions!\n\nOr try:\n• "Show me alternatives to [recipe]"\n• "What can I make in 30 minutes?"`,
            recipe: null
          };
        }
      }
    }
    
    return null;
  };

  const generateMockResponse = async (query: string, people: string) => {
    const lowerQuery = query.toLowerCase();
    
    // Greetings handling - more conversational
    if (lowerQuery.match(/^(hi|hello|hey|namaste|hola|greetings)/)) {
      const casualGreetings = [
        "Hey! 👋 Great to see you! What would you like to cook today?",
        "Hello! 😊 I'm here and ready to help! What's on your mind?",
        "Hi there! 🙏 Ready to create something delicious together?",
        "Namaste! 👨‍🍳 Let's cook something amazing! What are you craving?"
      ];
      return {
        text: casualGreetings[Math.floor(Math.random() * casualGreetings.length)],
        recipe: null
      };
    }
    
    // Common non-recipe words to filter out
    const stopWords = new Set([
      'hi', 'hello', 'hey', 'hola', 'namaste', 'how', 'what', 'when', 'where', 'why',
      'can', 'could', 'would', 'should', 'the', 'and', 'or', 'but', 'in', 'on', 'at',
      'to', 'for', 'of', 'with', 'from', 'by', 'a', 'an', 'is', 'are', 'was', 'were',
      'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would',
      'make', 'show', 'tell', 'give', 'get', 'me', 'you', 'i', 'we', 'they', 'my', 'your',
      'this', 'that', 'these', 'those', 'it', 'its'
    ]);
    
    // Extract meaningful words from query (4+ chars, not stop words)
    const extractQueryWords = (text: string): string[] => {
      return text.toLowerCase()
        .split(/\s+/)
        .filter(word => word.length >= 4 && !stopWords.has(word));
    };
    
    // Check if a word exists as a complete word in text (word boundary matching)
    const hasWholeWord = (text: string, word: string): boolean => {
      const regex = new RegExp(`\\b${word}\\b`, 'i');
      return regex.test(text);
    };
    
    // Enhanced professional responses
    const getRecipeResponse = async (recipeName: string) => {
      const allRecipes = getAllRecipes();
      
      // Try exact match first
      let foundRecipe = allRecipes.find(r => 
        r.name.toLowerCase() === recipeName.toLowerCase()
      );
      
      // Try whole-word match in recipe name
      if (!foundRecipe) {
        const queryWords = extractQueryWords(recipeName);
        
        if (queryWords.length > 0) {
          foundRecipe = allRecipes.find(r => {
            const recipeNameLower = r.name.toLowerCase();
            // Check if all significant query words are present as whole words in recipe name
            return queryWords.every(word => hasWholeWord(recipeNameLower, word));
          });
        }
      }
      
      // Try matching at least 50% of significant query words
      if (!foundRecipe) {
        const queryWords = extractQueryWords(recipeName);
        
        if (queryWords.length > 0) {
          foundRecipe = allRecipes.find(r => {
            const recipeNameLower = r.name.toLowerCase();
            const matchingWords = queryWords.filter(word => hasWholeWord(recipeNameLower, word));
            // Match if at least 50% of query words are in recipe name
            return matchingWords.length >= Math.ceil(queryWords.length * 0.5);
          });
        }
      }

      if (foundRecipe) {
        return await getDetailedRecipe(foundRecipe.name, people, foundRecipe);
      }
      
      return null;
    };

    // Check for ingredient list request
    if (lowerQuery.includes('list ingredients') || 
        lowerQuery.includes('show ingredients') ||
        lowerQuery.includes('what ingredients') ||
        (lowerQuery.includes('ingredient') && (lowerQuery.includes('categories') || lowerQuery.includes('list') || lowerQuery.includes('available')))) {
      const availableCategories = getIngredientCategories();
      return {
        text: `I have comprehensive alternatives for ingredients in these categories:\n\n${availableCategories.map(cat => `🔸 **${cat}**`).join('\n')}\n\n💡 **Try asking:**\n• "Alternative for cornflour"\n• "Substitute for heavy cream"\n• "Replace turmeric"\n• "What to use instead of paneer"\n• "Ghee alternatives"\n• "Egg substitutes"\n\n🌟 I have **100+ ingredients** with detailed alternatives, ratios, and descriptions!`,
        recipe: null
      };
    }
    
    // PRIORITY 1: Check for explicit recipe requests FIRST (like "I am making X" or "How to make X")
    // This ensures recipe instructions are shown by default, not alternatives
    if (lowerQuery.includes('making ') || 
        lowerQuery.includes('make ') || 
        lowerQuery.includes('cook ') ||
        lowerQuery.includes('cooking ') ||
        lowerQuery.includes('prepare ') ||
        lowerQuery.includes('preparing ') ||
        lowerQuery.includes('recipe for') ||
        lowerQuery.includes('how to')) {
      const recipeResponse = await getRecipeResponse(query);
      if (recipeResponse) {
        setLastTopic('recipe');
        return recipeResponse;
      }
    }
    
    // PRIORITY 2: Handle ingredient alternative requests (only if explicitly asking for alternatives)
    if (isIngredientAlternativeRequest(query)) {
      const ingredientName = extractIngredientFromQuery(query);
      
      if (ingredientName) {
        const ingredient = findIngredient(ingredientName);
        
        if (ingredient) {
          setLastTopic('ingredient-alternatives');
          return {
            text: getIngredientAlternativesResponse(ingredient),
            recipe: null
          };
        } else {
          // Ingredient not found in database
          const availableCategories = getIngredientCategories();
          return {
            text: `I couldn't find specific alternatives for "${ingredientName}" in my database yet. However, I have comprehensive alternatives for:\n\n${availableCategories.map(cat => `• ${cat}`).join('\n')}\n\n💡 **Tip:** Try asking about specific ingredients like:\n• "Alternative for cornflour"\n• "Substitute for heavy cream"\n• "Replace turmeric with what"\n• "What to use instead of paneer"\n\nOr ask me about any recipe and I'll help you with ingredient substitutions!`,
            recipe: null
          };
        }
      }
    }
    
    // PRIORITY 3: Handle contextual alternative requests (uses conversation context)
    const contextualAltResponse = handleContextualAlternatives(query);
    if (contextualAltResponse) {
      setLastTopic('alternatives');
      return contextualAltResponse;
    }
    
    // PRIORITY 4: Handle "what else" type queries
    const whatElseResponse = handleWhatElseQuery(query);
    if (whatElseResponse) {
      setLastTopic('category-search');
      return whatElseResponse;
    }
    
    // PRIORITY 5: Try to detect if user is just typing a recipe name (even without "how to make")
    const allRecipes = getAllRecipes();
    const queryWords = extractQueryWords(query);
    
    // Check if the query matches a recipe name directly
    if (queryWords.length > 0 && queryWords.length <= 5) {
      const matchedRecipe = allRecipes.find(r => {
        const recipeNameLower = r.name.toLowerCase();
        const queryLower = query.toLowerCase().trim();
        
        // Exact match
        if (recipeNameLower === queryLower) return true;
        
        // All words from query appear in recipe name
        const allWordsMatch = queryWords.every(word => hasWholeWord(recipeNameLower, word));
        if (allWordsMatch) return true;
        
        // Recipe name is contained in query or vice versa
        if (recipeNameLower.includes(queryLower) || queryLower.includes(recipeNameLower)) return true;
        
        return false;
      });
      
      if (matchedRecipe) {
        const response = await getDetailedRecipe(matchedRecipe.name, people, matchedRecipe);
        setLastTopic('recipe');
        return response;
      }
    }
    
    // PRIORITY 6: Try general recipe search as fallback
    const recipeResponse = await getRecipeResponse(query);
    if (recipeResponse) {
      // Update conversation context
      setLastTopic('recipe');
      return recipeResponse;
    }
    
    // Handle questions about specific recipes
    const handleRecipeQuestions = async () => {
      const allRecipes = getAllRecipes();
      const langCode = languageCodes[language]?.recognition || 'en-IN';
      
      // Check if asking about ingredients
      if (lowerQuery.includes('ingredient') || lowerQuery.includes('what do i need') || lowerQuery.includes('what needs')) {
        const queryWords = extractQueryWords(query);
        for (const recipe of allRecipes) {
          // Check if recipe name words match query words using whole-word matching
          const recipeWords = extractQueryWords(recipe.name);
          const hasMatch = recipeWords.some(rWord => 
            queryWords.some(qWord => qWord === rWord || hasWholeWord(recipe.name.toLowerCase(), qWord))
          );
          
          if (hasMatch) {
            const ingredientsList = recipe.ingredients.map((ing: any) => 
              `• ${ing.name || ing}`
            ).join('\n');
            return {
              text: `Here are the ingredients needed for **${recipe.name}**:\n\n${ingredientsList}\n\nWould you like the complete recipe with steps?`,
              recipe: null
            };
          }
        }
      }
      
      // Check if asking about steps
      if (lowerQuery.includes('how to make') || lowerQuery.includes('steps') || lowerQuery.includes('how do i cook')) {
        const queryWords = extractQueryWords(query);
        for (const recipe of allRecipes) {
          // Check if recipe name words match query words using whole-word matching
          const recipeWords = extractQueryWords(recipe.name);
          const hasMatch = recipeWords.some(rWord => 
            queryWords.some(qWord => qWord === rWord || hasWholeWord(recipe.name.toLowerCase(), qWord))
          );
          
          if (hasMatch) {
            return await getDetailedRecipe(recipe.name, people, recipe);
          }
        }
      }
      
      // Check if asking about alternatives/substitutes
      if (lowerQuery.includes('alternative') || lowerQuery.includes('substitute') || lowerQuery.includes('replace')) {
        const queryWords = extractQueryWords(query);
        for (const recipe of allRecipes) {
          // Check if recipe name words match query words using whole-word matching
          const recipeWords = extractQueryWords(recipe.name);
          const hasMatch = recipeWords.some(rWord => 
            queryWords.some(qWord => qWord === rWord || hasWholeWord(recipe.name.toLowerCase(), qWord))
          );
          
          if (hasMatch) {
            const alternatives: string[] = [];
            
            if (recipe.ingredients) {
              recipe.ingredients.forEach((ing: any) => {
                if (ing.alternatives && ing.alternatives.length > 0) {
                  alternatives.push(`**${ing.name}**: ${ing.alternatives.join(', ')}`);
                }
              });
            }
            
            if (alternatives.length > 0) {
              setLastDiscussedRecipe(recipe);
              setLastTopic('ingredient-alternatives');
              return {
                text: `Here are the ingredient alternatives for **${recipe.name}**:\n\n${alternatives.join('\n\n')}\n\n💡 **Tip:** These alternatives work well and won't compromise the taste!\n\n💬 You can also ask:\n• "Show me similar recipes to ${recipe.name}"\n• "What else can I make?"\n• "Alternatives to cream" (for general substitutes)`,
                recipe: null
              };
            } else {
              setLastDiscussedRecipe(recipe);
              setLastTopic('alternatives');
              return {
                text: `For **${recipe.name}**, I can suggest general alternatives:\n\n• For dairy: Use plant-based alternatives\n• For protein: Swap with similar proteins\n• For spices: Adjust to your taste\n\n**Or try:** Ask me "Show me similar recipes" to find alternatives to this dish!\n\nWhich specific ingredient would you like to substitute?`,
                recipe: null
              };
            }
          }
        }
      }
      
      return null;
    };
    
    const questionResponse = await handleRecipeQuestions();
    if (questionResponse) return questionResponse;

    // Handle common questions
    if (lowerQuery.includes('substitute') || lowerQuery.includes('alternative') || lowerQuery.includes('instead')) {
      return handleSubstitutionQuery(lowerQuery);
    }

    if (lowerQuery.includes('vegan') || lowerQuery.includes('dairy-free')) {
      return handleVeganQuery();
    }

    if (lowerQuery.includes('store') || lowerQuery.includes('storage') || lowerQuery.includes('leftover')) {
      return handleStorageQuery();
    }

    if (lowerQuery.includes('tip') || lowerQuery.includes('secret') || lowerQuery.includes('better')) {
      return handleTipsQuery();
    }

    if (lowerQuery.includes('spicy') || lowerQuery.includes('spice level')) {
      return handleSpiceQuery();
    }

    if (lowerQuery.includes('time') || lowerQuery.includes('quick') || lowerQuery.includes('fast')) {
      return handleTimeQuery();
    }
    
    // Handle recipe listing requests
    if (lowerQuery.includes('list') || lowerQuery.includes('show me') || lowerQuery.includes('what recipes') || lowerQuery.includes('available recipes')) {
      return handleRecipeListQuery();
    }
    
    // Default helpful response
    const currentLang = translations[language] || translations.english;
    
    // Make default response more contextual
    let defaultText = currentLang.default;
    
    // Add context-aware suggestions if we have a last discussed recipe
    if (lastDiscussedRecipe) {
      defaultText += `\n\n💡 **Contextual Suggestions:**\nSince we were just discussing **${lastDiscussedRecipe.name}**, you can ask:\n• "Show me alternatives to this"\n• "What else can I make like this?"\n• "How to modify this recipe?"`;
    }
    
    return {
      text: defaultText,
      recipe: null
    };
  };

  const handleSubstitutionQuery = (query: string) => {
    // Check if asking about a specific recipe's alternatives
    const allRecipes = getAllRecipes();
    const queryWords = extractQueryWords(query);
    
    for (const recipe of allRecipes) {
      // Check if recipe name words match query words using whole-word matching
      const recipeWords = extractQueryWords(recipe.name);
      const hasMatch = recipeWords.some(rWord => 
        queryWords.some(qWord => qWord === rWord || hasWholeWord(recipe.name.toLowerCase(), qWord))
      );
      
      if (hasMatch) {
        const alternatives: string[] = [];
        
        if (recipe.ingredients) {
          recipe.ingredients.forEach((ing: any) => {
            if (ing.alternatives && ing.alternatives.length > 0) {
              alternatives.push(`**${ing.name || ing}**: ${ing.alternatives.join(', ')}`);
            }
          });
        }
        
        if (alternatives.length > 0) {
          setLastDiscussedRecipe(recipe);
          setLastTopic('substitutions');
          return {
            text: `Here are the ingredient alternatives for **${recipe.name}**:\n\n${alternatives.join('\n\n')}\n\n💡 **Tip:** These alternatives work well and won't compromise the taste!\n\n💬 **Also ask:** "Show me similar recipes" to find alternatives to this dish!`,
            recipe: null
          };
        }
      }
    }
    
    const substitutions: Record<string, string> = {
      'cream': '✓ Cashew paste (soak 10-12 cashews, blend with water)\n✓ Coconut cream\n✓ Greek yogurt + milk\n✓ Silken tofu blended',
      'butter': '✓ Ghee (traditional, adds flavor)\n✓ Cooking oil (neutral)\n✓ Coconut oil (mild flavor)\n✓ Vegan butter',
      'paneer': '✓ Tofu (firm, pressed)\n✓ Halloumi cheese\n✓ Cottage cheese\n✓ Chickpeas (for vegan)',
      'yogurt': '✓ Sour cream\n✓ Coconut yogurt (vegan)\n✓ Buttermilk\n✓ Cashew cream',
      'ghee': '✓ Butter\n✓ Coconut oil\n✓ Vegetable oil\n✓ Olive oil',
      'onion': '✓ Shallots (sweeter flavor)\n✓ Leeks (milder)\n✓ Onion powder (1 tbsp = 1 medium onion)\n✓ Garlic (for flavor)',
      'tomato': '✓ Canned tomatoes\n✓ Tomato puree\n✓ Tomato paste + water\n✓ Red bell peppers (for color)',
      'ginger': '✓ Ginger powder (1 tsp = 1 tbsp fresh)\n✓ Galangal\n✓ Ground ginger\n✓ Omit if unavailable',
      'garlic': '✓ Garlic powder (1 tsp = 3 cloves)\n✓ Asafoetida (hing)\n✓ Garlic paste\n✓ Shallots',
    };

    for (const [ingredient, subs] of Object.entries(substitutions)) {
      if (query.includes(ingredient)) {
        return {
          text: `Great question! Here are the best substitutes for **${ingredient}**:\n\n${subs}\n\n💡 Tip: Always adjust quantities to taste when using substitutes!`,
          recipe: null
        };
      }
    }

    return {
      text: "I can help you find substitutes! Could you tell me which specific ingredient you'd like to replace? Common ones I can help with:\n\n• Heavy cream\n• Butter/Ghee\n• Paneer\n• Yogurt\n• Onions/Garlic\n• Tomatoes\n• Specific spices\n\nOr ask me about alternatives for a specific recipe!",
      recipe: null
    };
  };

  const handleVeganQuery = () => {
    return {
      text: "I can definitely help you make this vegan! Here are the key substitutions:\n\n🌱 **Dairy Replacements:**\n• Butter → Coconut oil or vegan butter\n• Cream → Cashew cream or coconut cream\n• Paneer → Firm tofu (pressed) or chickpeas\n• Yogurt → Coconut yogurt\n\n**Pro Tips:**\n• Press tofu for 30 mins before cooking\n• Marinate tofu in the sauce for better flavor\n• Cashew cream: Blend 1 cup soaked cashews with ½ cup water\n• Use nutritional yeast for extra flavor\n\nWould you like the full vegan recipe for a specific dish?",
      recipe: null
    };
  };

  const handleStorageQuery = () => {
    return {
      text: "Here's how to properly store your Indian dishes:\n\n**Refrigerator Storage:**\n• Curries: 3-4 days in airtight container\n�� Rice/Biryani: 3-4 days, store separately from curry\n• Bread (naan/roti): 2-3 days in sealed bag\n• Dal: 4-5 days\n\n**Freezer Storage:**\n• Curries: Up to 3 months\n• Biryani: Up to 2 months\n• Uncooked rotis: 3 months\n\n**Reheating Tips:**\n• Add 2-3 tbsp water when reheating curries\n• Microwave: Cover and stir halfway\n• Stovetop: Low heat, stir frequently\n• Rice: Sprinkle water, cover, heat\n\n**Best Practice:** Let food cool completely before storing. Don't leave at room temp for >2 hours.",
      recipe: null
    };
  };

  const handleTipsQuery = () => {
    return {
      text: "Here are my top professional cooking tips for Indian cuisine:\n\n**🔥 Flavor Boosters:**\n• Always bloom whole spices in hot oil first\n• Add kasuri methi (dried fenugreek) at the end\n• Use tomato paste for deeper color\n• Add sugar pinch to balance acidity\n\n**👨‍🍳 Technique Tips:**\n• Cook onions until golden brown (15-20 min)\n• Let oil separate from masala before adding main ingredient\n• Finish with cream/butter for restaurant-style richness\n• Rest biryani for 5 mins before serving\n\n**⚡ Time Savers:**\n• Make ginger-garlic paste in bulk, freeze in ice cube trays\n• Pre-chop onions, store in fridge\n• Use pressure cooker for faster dal cooking\n\n**Secret Ingredient:** A tiny pinch of garam masala at the very end (not while cooking) preserves its aroma!",
      recipe: null
    };
  };

  const handleSpiceQuery = () => {
    return {
      text: "Let's adjust the spice level to your preference!\n\n**To Reduce Spice:**\n• Use Kashmiri chili powder (red color, mild heat)\n• Add more cream/yogurt to balance\n• Include sugar (1/2 tsp) to cut heat\n• Serve with cooling raita\n\n**To Increase Spice:**\n• Add green chilies with seeds\n• Use regular red chili powder\n• Add black pepper\n• Include ginger for warming heat\n\n**Heat Scale Guide:**\n• Mild: 1/2 tsp chili powder\n• Medium: 1 tsp chili powder\n• Hot: 1.5 tsp + green chilies\n• Extra Hot: 2 tsp + fresh chilies\n\nRemember: You can always add more spice, but can't remove it!",
      recipe: null
    };
  };

  const handleTimeQuery = () => {
    return {
      text: "Here are my quick cooking suggestions:\n\n**⚡ 15-Minute Meals:**\n• Egg Bhurji\n• Poha\n• Upma\n• Quick Dal Tadka (with canned lentils)\n\n**30-Minute Meals:**\n• Aloo Gobi\n• Chana Masala (canned chickpeas)\n• Vegetable Pulao\n• Paneer Tikka\n\n**Time-Saving Tips:**\n• Use pressure cooker (reduces time by 60%)\n• Pre-cut vegetables night before\n• Use store-bought ginger-garlic paste\n• Cook rice in electric rice cooker\n• Make base gravy in bulk, freeze\n\n**Instant Pot Magic:**\n• Biryani: 20 mins (vs 90 mins)\n• Dal: 8 mins (vs 30 mins)\n• Curry: 15 mins (vs 45 mins)\n\nWhich quick recipe would you like?",
      recipe: null
    };
  };
  
  const handleRecipeListQuery = () => {
    const allRecipes = getAllRecipes();
    const sampleRecipes = allRecipes.slice(0, 20).map(r => `• ${r.name}`).join('\n');
    const totalCount = allRecipes.length;
    
    return {
      text: `I have access to **${totalCount}+ Indian recipes** from all regions! Here are some popular ones:\n\n${sampleRecipes}\n\n...and ${totalCount - 20}+ more!\n\n**You can ask me:**\n• "How to make [recipe name]"\n• "Ingredients for [recipe name]"\n• "Alternatives in [recipe name]"\n• "Show me recipes from [state/region]"\n\nWhich recipe would you like to explore? 👨‍🍳`,
      recipe: null
    };
  };

  const getDetailedRecipe = async (recipeName: string, people: string, providedRecipe?: any) => {
    let recipe = providedRecipe;
    
    if (!recipe) {
      // Try mockRecipes first
      recipe = mockRecipes.find(r => r.name.toLowerCase().includes(recipeName.toLowerCase()));
      
      // If not found, try enhanced database
      if (!recipe) {
        const enhancedRecipe = recipeDatabase[recipeName];
        if (enhancedRecipe) {
          recipe = {
            name: enhancedRecipe.name,
            ingredients: enhancedRecipe.ingredients.map((ing, idx) => ({
              name: ing,
              amount: 1,
              unit: 'as needed',
              alternatives: enhancedRecipe.alternatives?.[idx]?.substitutes || []
            })),
            steps: enhancedRecipe.steps,
            time: enhancedRecipe.time || '45 mins',
            difficulty: enhancedRecipe.difficulty || 'Medium',
            baseServings: 4,
            tips: enhancedRecipe.tips || []
          };
        }
      }
    }
    
    if (!recipe) {
      return {
        text: `I don't have the exact recipe for ${recipeName} in my database yet, but I can help you with general cooking instructions or suggest similar dishes!`,
        recipe: null
      };
    }

    const servings = parseInt(people);
    const scaleFactor = servings / (recipe.baseServings || 4);

    const scaleAmount = (amount: number) => {
      const scaled = amount * scaleFactor;
      if (scaled < 1) return scaled.toFixed(2);
      if (scaled < 10) return scaled.toFixed(1);
      return Math.round(scaled).toString();
    };

    // Get language code for translation
    const langCode = languageCodes[language]?.recognition || 'en-IN';
    
    // Handle different ingredient formats and translate if needed
    const ingredientsPromises = recipe.ingredients.map(async (ing: any) => {
      if (typeof ing === 'string') {
        const translatedIng = language !== 'english' ? await translateText(ing, langCode) : ing;
        return `• ${translatedIng}`;
      } else if (ing.name) {
        const translatedName = language !== 'english' ? await translateText(ing.name, langCode) : ing.name;
        const translatedUnit = language !== 'english' ? await translateText(ing.unit, langCode) : ing.unit;
        
        let alternativesText = '';
        if (ing.alternatives && ing.alternatives.length > 0) {
          const translatedAlts = language !== 'english' 
            ? await Promise.all(ing.alternatives.map((alt: string) => translateText(alt, langCode)))
            : ing.alternatives;
          const altLabel = language !== 'english' ? await translateText('Alt', langCode) : 'Alt';
          alternativesText = ` (${altLabel}: ${translatedAlts.join(', ')})`;
        }
        
        return `• ${translatedName}: ${scaleAmount(ing.amount)} ${translatedUnit}${alternativesText}`;
      }
      return `• ${JSON.stringify(ing)}`;
    });

    const ingredientsList = (await Promise.all(ingredientsPromises)).join('\n');

    // Translate steps
    const stepsPromises = recipe.steps.map(async (step: string, index: number) => {
      const translatedStep = language !== 'english' ? await translateText(step, langCode) : step;
      return `${index + 1}. ${translatedStep}`;
    });
    
    const stepsList = (await Promise.all(stepsPromises)).join('\n\n');
    
    // Translate tips if available
    let tipsSection = '';
    if (recipe.tips && recipe.tips.length > 0) {
      const tipsPromises = recipe.tips.map(async (tip: string) => {
        const translatedTip = language !== 'english' ? await translateText(tip, langCode) : tip;
        return `• ${translatedTip}`;
      });
      const translatedTips = (await Promise.all(tipsPromises)).join('\n');
      const proTipsLabel = language !== 'english' ? await translateText('Pro Tips', langCode) : 'Pro Tips';
      tipsSection = `\n\n**💡 ${proTipsLabel}:**\n${translatedTips}`;
    }

    const currentLang = translations[language] || translations.english;

    const responseText = `${currentLang.recipeIntro} ${recipe.name} ${currentLang.forPeople} ${servings} ${servings === 1 ? currentLang.person : currentLang.people}!\n\n**⏱️ ${currentLang.time}:** ${recipe.time}\n**👥 ${currentLang.servings}:** ${servings}\n**📊 ${currentLang.difficulty}:** ${recipe.difficulty}\n\n**🥘 ${currentLang.ingredients}:**\n${ingredientsList}\n\n**👨‍🍳 ${currentLang.steps}:**\n${stepsList}${tipsSection}\n\n**💡 ${currentLang.tip}:** ${currentLang.tipText}\n\n💬 **Ask me:** "Show me alternatives" or "What else can I make?" for similar recipes!`;

    const recipeObj = {
      name: recipe.name,
      servings: servings,
      time: recipe.time,
      difficulty: recipe.difficulty,
      ingredients: recipe.ingredients.map((ing: any) => {
        if (typeof ing === 'string') {
          return { name: ing, amount: 1, unit: 'as needed', scaledAmount: '1' };
        }
        return {
          ...ing,
          scaledAmount: scaleAmount(ing.amount || 1)
        };
      }),
      steps: recipe.steps,
      tips: recipe.tips
    };

    // Update conversation context
    setLastDiscussedRecipe(recipe);
    setLastTopic('recipe');

    return {
      text: responseText,
      recipe: recipeObj
    };
  };

  const translations: Record<string, any> = {
    english: {
      recipeIntro: "Perfect! Let me help you make",
      forPeople: "for",
      people: "people",
      person: "person",
      time: "Total Time",
      servings: "Servings",
      difficulty: "Difficulty",
      ingredients: "Ingredients",
      steps: "Cooking Steps",
      tip: "Pro Tip",
      tipText: "Taste and adjust seasonings before serving. Indian cooking is all about balancing flavors!",
      default: `I'm here to help you with your cooking!\n\n**🍳 I can:**\n• Provide complete recipes with step-by-step instructions\n• Adjust ingredients for any number of people\n• Suggest ingredient substitutes and alternatives\n• Recommend similar recipes based on what you like\n• Share cooking tips and techniques\n\n**Try asking:**\n• "How to make Butter Chicken?"\n• "Show me alternatives" (after getting a recipe)\n• "What else can I make with paneer?"\n• "Quick vegetarian recipes"\n\nWhat would you like to cook today? 👨‍🍳`
    },
    hindi: {
      recipeIntro: "बढ़िया! यहाँ बताया गया है कि कैसे बनाएं",
      forPeople: "के लिए",
      people: "लोग",
      person: "व्यक्ति",
      time: "कुल समय",
      servings: "सर्विंग्स",
      difficulty: "कठिनाई",
      ingredients: "सामग्री",
      steps: "पकाने के चरण",
      tip: "प्रो टिप",
      tipText: "परोसने से पहले स्वाद लें और मसाले समायोजित करें। भारतीय खाना पकाना स्वादों को संतुलित करने के बारे में है!",
      default: `मैं आपकी खाना पकाने में मदद के लिए यहाँ हूँ!\n\n**🍳 मैं कर सकता हूँ:**\n• पूरी रेसिपी प्रदान करें\n• किसी भी संख्या के लोगों के लिए सामग्री समायोजित करें\n• सामग्री विकल्प सुझाएं\n• समान रेसिपी की सिफारिश करें\n• खाना पकाने की युक्तियाँ साझा करें\n\nआज क्या पकाना चाहेंगे? 👨‍🍳`
    },
    tamil: {
      recipeIntro: "சரியாக! இதை எப்படி செய்வது என்று இங்கே",
      forPeople: "க்கு",
      people: "பேர்",
      person: "நபர்",
      time: "மொத்த நேரம்",
      servings: "பரிமாறல்கள்",
      difficulty: "சிரமம்",
      ingredients: "தேவையான பொருட்கள்",
      steps: "சமையல் படிகள்",
      tip: "முக்கிய குறிப்பு",
      tipText: "பரிமாறும் முன் சுவை பார்த்து மசாலாக்களை சரிசெய்யவும். இந்திய சமையல் சுவைகளை சமநிலைப்படுத்துவதைப் பற்றியது!",
      default: `உங்கள் சமையலில் உதவ நான் இங்கே இருக்கிறேன்!\n\n**🍳 நான் செய்ய முடியும்:**\n• முழுமையான செய்முறைகளை வழங்கவும்\n• எந்த எண்ணிக்கையிலான நபர்களுக்கும் பொருட்களை சரிசெய்யவும்\n• பொருள் மாற்றுகளை பரிந்துரைக்கவும்\n• ஒத்த செய்முறைகளை பரிந்துரைக்கவும்\n• சமையல் குறிப்புகளை பகிரவும்\n\nஇன்று என்ன சமைக்க விரும்புகிறீர்கள்? 👨‍🍳`
    },
    bengali: {
      recipeIntro: "নিখুঁত! এখানে কীভাবে তৈরি করবেন",
      forPeople: "জন্য",
      people: "জন",
      person: "ব্যক্তি",
      time: "মোট সময়",
      servings: "পরিবেশন",
      difficulty: "অসুবিধা",
      ingredients: "উপকরণ",
      steps: "রান্নার ধাপ",
      tip: "প্রো টিপ",
      tipText: "পরিবেশনের আগে স্বাদ নিন এবং মশলা সামঞ্জস্য করুন। ভারতীয় রান্না স্বাদের ভারসাম্য সম্পর্কে!",
      default: `আমি আপনার রান্নায় সাহায্য করতে এখানে আছি!\n\n**🍳 আমি পারি:**\n• সম্পূর্ণ রেসিপি প্রদান করুন\n• যেকোনো সংখ্যক মানুষের জন্য উপাদান সামঞ্জস্য করুন\n• উপাদান বিকল্প পরামর্শ দিন\n• অনুরূপ রেসিপি সুপারিশ করুন\n• রান্নার টিপস শেয়ার করুন\n\nআজ কি রান্না করতে চান? 👨‍🍳`
    },
    marathi: {
      recipeIntro: "परिपूर्ण! येथे कसे बनवायचे ते आहे",
      forPeople: "साठी",
      people: "लोक",
      person: "व्यक्ती",
      time: "एकूण वेळ",
      servings: "सर्व्हिंग",
      difficulty: "अडचण",
      ingredients: "साहित्य",
      steps: "स्वयंपाक पायऱ्या",
      tip: "प्रो टीप",
      tipText: "सर्व्ह करण्यापूर्वी चव पहा आणि मसाले समायोजित करा. भारतीय स्वयंपाक हे चवींचे संतुलन आहे!",
      default: `मी तुमच्या स्वयंपाकात मदत करण्यासाठी येथे आहे!\n\n**🍳 मी करू शकतो:**\n• संपूर्ण पाककृती प्रदान करणे\n• कोणत्याही संख्येच्या लोकांसाठी घटक समायोजित करणे\n• घटक पर्याय सुचवणे\n• समान पाककृती शिफारस करणे\n• स्वयंपाक टिपा सामायिक करणे\n\nआज काय शिजवायचे आहे? 👨‍🍳`
    }
  };

  return (
    <div className="relative min-h-screen py-12 overflow-hidden">
      <KitchenBackground />
      <div className="relative container mx-auto max-w-7xl px-4 z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <Badge className="mb-4" style={{ background: 'var(--tech-blue)', color: 'white' }}>
            <Sparkles className="mr-1 h-3 w-3" />
            AI-Powered Assistant
          </Badge>
          <div className="flex items-center justify-center gap-3 mb-2">
            <h1 className="text-3xl md:text-5xl">Talk to Your AI Chef</h1>
            <Button
              size="sm"
              variant="ghost"
              className="rounded-full"
              onClick={() => {
                toast.info('📚 Check AI_INTEGRATION_GUIDE.md for detailed setup instructions!', { duration: 5000 });
              }}
            >
              <HelpCircle className="h-5 w-5" />
            </Button>
          </div>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Get professional cooking guidance with voice commands and multilingual support
          </p>
          
          {selectedRecipe && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-[var(--saffron)]/20 to-[var(--tech-blue)]/20 border"
            >
              <span className="text-sm">Showing recipe for: <strong>{selectedRecipe.name}</strong></span>
              <button
                onClick={() => {
                  onClearRecipe();
                  setCurrentRecipe(null);
                }}
                className="hover:opacity-70"
              >
                <X className="h-4 w-4" />
              </button>
            </motion.div>
          )}
        </motion.div>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Conversation List Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <Card className="p-4 h-[700px] flex flex-col">
              <Button
                onClick={createNewConversation}
                className="w-full mb-4"
                style={{ background: 'var(--saffron)' }}
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                New Chat
              </Button>

              <ScrollArea className="flex-1">
                <div className="space-y-2">
                  {conversations.map((conv) => (
                    <div
                      key={conv.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-all hover:border-[var(--tech-blue)] ${
                        activeConversationId === conv.id ? 'border-[var(--tech-blue)] bg-[var(--tech-blue)]/5' : ''
                      }`}
                      onClick={() => setActiveConversationId(conv.id)}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm truncate">{conv.title}</p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(conv.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteConversation(conv.id);
                          }}
                          className="hover:text-red-500"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </Card>
          </motion.div>

          {/* Chat Interface */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2"
          >
            <Card className="h-[700px] flex flex-col">
              {/* Settings Bar */}
              <div className="border-b p-4">
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="flex items-center gap-2 flex-1">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <Select value={numPeople} onValueChange={setNumPeople}>
                      <SelectTrigger className="flex-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20].map(num => (
                          <SelectItem key={num} value={String(num)}>
                            {num} {num === 1 ? 'Person' : 'People'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center gap-2 flex-1">
                    <Globe className="h-4 w-4 text-muted-foreground" />
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="flex-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="english">English</SelectItem>
                        <SelectItem value="hindi">हिन्दी (Hindi)</SelectItem>
                        <SelectItem value="tamil">தமிழ் (Tamil)</SelectItem>
                        <SelectItem value="bengali">বাংলা (Bengali)</SelectItem>
                        <SelectItem value="marathi">मराठी (Marathi)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={autoSpeak ? "default" : "outline"}
                      onClick={() => setAutoSpeak(!autoSpeak)}
                      style={autoSpeak ? { background: 'var(--green)' } : {}}
                      title="Auto-speak AI responses"
                    >
                      <Volume2 className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={downloadConversation}
                      title="Download conversation"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-hidden">
                <ScrollArea className="h-full">
                  <div className="p-4 space-y-4" ref={chatContainerRef}>
                    {getCurrentMessages().map((message, index) => (
                      <motion.div
                        key={`${activeConversationId}-${index}`}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                            message.role === 'user'
                              ? 'bg-gradient-to-r from-[var(--tech-blue)] to-[var(--tech-blue-light)] text-white rounded-br-none'
                              : 'bg-muted rounded-bl-none'
                          }`}
                        >
                          {message.role === 'assistant' && (
                            <div className="flex items-center gap-2 mb-2">
                              <ChefHat className="h-4 w-4" style={{ color: 'var(--saffron)' }} />
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 px-2"
                                onClick={() => speakText(message.content)}
                                disabled={isSpeaking}
                              >
                                {isSpeaking ? (
                                  <StopCircle className="h-3 w-3" onClick={stopSpeaking} />
                                ) : (
                                  <Volume2 className="h-3 w-3" />
                                )}
                              </Button>
                            </div>
                          )}
                          <span className="whitespace-pre-line text-sm">{message.content}</span>
                        </div>
                      </motion.div>
                    ))}
                    {isLoading && (
                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="flex justify-start"
                      >
                        <div className="bg-muted rounded-2xl px-4 py-3 rounded-bl-none">
                          <div className="flex items-center gap-2">
                            <Loader2 className="h-4 w-4 animate-spin" style={{ color: 'var(--saffron)' }} />
                            <span className="text-sm">Cooking up a response...</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </div>

              {/* Input */}
              <div className="border-t p-4">
                <div className="flex gap-2">
                  <Button
                    size="icon"
                    variant={isListening ? "default" : "outline"}
                    className="rounded-full shrink-0"
                    style={isListening ? { background: 'var(--saffron)' } : { borderColor: 'var(--saffron)' }}
                    onClick={isListening ? stopListening : startListening}
                    title={isListening ? "Stop listening" : "Start voice input"}
                  >
                    {isListening ? (
                      <MicOff className="h-4 w-4 animate-pulse" />
                    ) : (
                      <Mic className="h-4 w-4" style={{ color: 'var(--saffron)' }} />
                    )}
                  </Button>
                  <Input
                    placeholder="Ask me anything... e.g., 'How to make Paneer Butter Masala?' or use voice 🎤"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSend()}
                    className="flex-1"
                    disabled={isLoading}
                  />
                  <Button
                    size="icon"
                    onClick={handleSend}
                    className="rounded-full shrink-0"
                    style={{ background: 'var(--tech-blue)' }}
                    disabled={!input.trim() || isLoading}
                  >
                    {isLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                {isListening && (
                  <p className="text-xs text-center mt-2 text-muted-foreground animate-pulse">
                    🎤 Listening in {language}... Speak now!
                  </p>
                )}
              </div>
            </Card>
          </motion.div>

          {/* Recipe Display */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <Card className="sticky top-24 p-6 max-h-[700px] overflow-y-auto">
              {currentRecipe ? (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl mb-2">{currentRecipe.name}</h3>
                    <div className="flex flex-wrap gap-2 text-sm">
                      <Badge variant="outline">{currentRecipe.servings} servings</Badge>
                      <Badge variant="outline">⏱️ {currentRecipe.time}</Badge>
                      {currentRecipe.difficulty && (
                        <Badge variant="outline">{currentRecipe.difficulty}</Badge>
                      )}
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-3 flex items-center gap-2">
                      <ChefHat className="h-4 w-4" style={{ color: 'var(--saffron)' }} />
                      Ingredients
                    </h4>
                    <div className="space-y-2">
                      {currentRecipe.ingredients?.map((ing: any, idx: number) => (
                        <div key={idx} className="text-sm flex items-start gap-2">
                          <span className="text-[var(--green)]">•</span>
                          <span>
                            <strong>{ing.name}:</strong> {ing.scaledAmount} {ing.unit}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="mb-3">Steps</h4>
                    <div className="space-y-3">
                      {currentRecipe.steps?.map((step: string, idx: number) => (
                        <div key={idx} className="flex gap-3">
                          <div
                            className="shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs text-white"
                            style={{ background: 'var(--tech-blue)' }}
                          >
                            {idx + 1}
                          </div>
                          <p className="text-sm pt-0.5">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={() => setCurrentRecipe(null)}
                    variant="outline"
                    className="w-full"
                  >
                    Clear Recipe
                  </Button>
                </div>
              ) : (
                <div className="text-center py-12">
                  <ChefHat className="h-12 w-12 mx-auto mb-4 opacity-20" />
                  <p className="text-sm text-muted-foreground">
                    Ask about a recipe to see detailed instructions here
                  </p>
                </div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>


  // Log user interactions (e.g., recipe viewed/asked) to Firestore users/activity for developer analytics
  async function logActivity(type, payload) {
    try {
      // if user is logged in, attach uid. This is a simple append to a global 'activity_log' collection
      await setDoc(doc(db, 'activity', String(Date.now())), { type, payload, createdAt: serverTimestamp() }, { merge: true });
    } catch (e) {
      console.error('Failed to log activity', e);
    }
  }

      {/* Footer */}
      <Footer onNavigate={onNavigate} />
    </div>
  );
}
