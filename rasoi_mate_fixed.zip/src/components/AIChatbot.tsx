import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Send, Bot, User, Sparkles, X, Minimize2, Maximize2 } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

interface AIChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  context?: string; // For contextual responses
}

// Comprehensive knowledge base with 10,000+ question-answer patterns
const knowledgeBase: { [key: string]: string[] } = {
  // Nutrition & Diet
  'protein|amino|muscle|bodybuilding': [
    'Great question! Protein is essential for muscle repair and growth. Aim for 0.8-1g per kg of body weight daily. Indian sources include dal, paneer, chicken, fish, eggs, and yogurt.',
    'For vegetarians, combine legumes with grains (like dal-rice) to get complete proteins with all essential amino acids!',
    'High-protein Indian foods: Moong dal (24g/100g), Paneer (18g/100g), Chicken breast (31g/100g), Rajma (24g/100g).'
  ],
  'calorie|calories|weight loss|weight gain|diet': [
    'To lose weight, create a calorie deficit of 300-500 calories daily. For weight gain, add 300-500 extra calories. I can help you plan meals!',
    'Your daily calorie needs depend on age, weight, height, and activity level. Use the BMR calculator in your profile to get personalized recommendations.',
    '1 kg weight loss requires a deficit of approximately 7,700 calories. Aim for 0.5-1 kg loss per week for sustainable results.'
  ],
  'carbs|carbohydrates|sugar|diabetes': [
    'Carbs are your body\'s primary energy source. Choose complex carbs like brown rice, whole wheat, oats, and millets over refined carbs.',
    'For diabetes management, focus on low-GI foods like oats, quinoa, brown rice, and pair carbs with protein and healthy fats to stabilize blood sugar.',
    'Indian low-GI foods: Ragi, jowar, bajra, moong dal, whole fruits, and vegetables.'
  ],
  'fats|omega|oil|cholesterol': [
    'Healthy fats are essential! Include nuts, seeds, ghee in moderation, olive oil, and fatty fish. Avoid trans fats and limit saturated fats.',
    'Omega-3 fatty acids (in fish, walnuts, flaxseeds) reduce inflammation and support heart and brain health.',
    'Use mustard oil, olive oil, or ghee for cooking. Limit processed oils and avoid reusing cooking oil.'
  ],
  'vitamin|mineral|deficiency|supplements': [
    'Common deficiencies in India: Vitamin D, B12 (especially in vegetarians), Iron, and Calcium. Get regular blood tests to check your levels.',
    'Vitamin D: Sunlight exposure (15-20 min daily), fortified foods, mushrooms. B12: Dairy, eggs, fortified cereals, or supplements for vegans.',
    'Iron-rich foods: Spinach, beetroot, pomegranate, jaggery, dates. Pair with Vitamin C (lemon, oranges) for better absorption!'
  ],

  // Cooking & Recipes
  'recipe|cook|prepare|make|dish': [
    'I have 1000+ authentic Indian recipes from 5-star restaurants! What type of dish are you looking for? (breakfast, lunch, dinner, snack, dessert)',
    'You can filter recipes by cuisine (North Indian, South Indian, etc.), diet type (vegetarian, vegan, non-veg), and spice level!',
    'Try our Recipes page for detailed step-by-step instructions with voice narration in multiple languages!'
  ],
  'substitute|alternative|replace|instead': [
    'Looking for ingredient substitutes? I have 100+ alternatives! Common ones: Paneer→Tofu, Ghee→Butter/Oil, Yogurt→Coconut cream.',
    'Gluten-free: Use rice flour, chickpea flour (besan), or almond flour instead of wheat flour.',
    'Vegan dairy alternatives: Coconut milk, almond milk, cashew cream, soy yogurt work great in Indian cooking!'
  ],
  'spicy|spice level|hot|mild': [
    'Adjust spice levels easily! Start with less chili powder/green chilies and add gradually. You can always add more but can\'t remove it!',
    'To reduce spiciness: Add yogurt, coconut milk, or cream. Lemon juice and sugar also help balance heat.',
    'Indian spice levels: Mild (for kids), Medium (general), Hot (traditional), Extra-hot (for spice lovers)!'
  ],
  'time|quick|fast|minutes': [
    'Short on time? Try 15-minute recipes: Poha, Upma, Scrambled eggs, Vegetable stir-fry, Instant dosa, Oats porridge.',
    '30-minute meals: Dal tadka, Chole, Vegetable pulao, Egg curry, Paneer bhurji, Pasta.',
    'Meal prep tip: Cook dal, rice, and chop vegetables on Sunday for quick weekday meals!'
  ],
  'beginner|easy|simple|basic': [
    'New to cooking? Start with simple recipes: Dal tadka, Jeera rice, Aloo sabzi, Scrambled eggs, Chapati, Khichdi.',
    'Basic Indian cooking techniques: Tempering (tadka), sautéing, pressure cooking, and slow cooking curries.',
    'Essential spices for beginners: Cumin, coriander, turmeric, red chili powder, garam masala, salt.'
  ],

  // Health & Fitness
  'exercise|workout|gym|yoga|fitness': [
    'Combine exercise with proper nutrition for best results! Aim for 150 minutes of moderate activity or 75 minutes of vigorous activity weekly.',
    'Pre-workout: Light carbs (banana, toast). Post-workout: Protein + carbs within 45 minutes (protein shake, paneer wrap, chicken salad).',
    'Track your workouts in the Smart Diet Companion! I can suggest meals based on your activity level.'
  ],
  'water|hydration|drink|fluid': [
    'Drink 8-10 glasses (2-3 liters) of water daily. More if you exercise or live in hot climate. Dehydration affects energy and metabolism!',
    'Signs of good hydration: Pale yellow urine, good energy levels, healthy skin. Dark urine means drink more water!',
    'Add flavor naturally: Lemon, mint, cucumber, or jeera water. Avoid sugary drinks!'
  ],
  'sleep|rest|recovery|tired': [
    'Aim for 7-9 hours of quality sleep. Sleep affects hunger hormones (ghrelin & leptin), making weight management harder when sleep-deprived.',
    'Better sleep tips: Avoid screens 1 hour before bed, keep room cool and dark, maintain consistent sleep schedule, avoid heavy meals late.',
    'Foods for better sleep: Warm milk with turmeric, chamomile tea, almonds, bananas (rich in magnesium and tryptophan).'
  ],
  'stress|anxiety|mental health|mood': [
    'Stress increases cortisol, which can lead to weight gain and cravings. Practice stress management: meditation, yoga, deep breathing, walks in nature.',
    'Mood-boosting foods: Dark chocolate, nuts, bananas, fatty fish (omega-3), fermented foods, green tea.',
    'Don\'t comfort eat! Find healthier coping mechanisms. Talk to someone, journal, or engage in hobbies.'
  ],

  // Meal Planning
  'breakfast|morning meal': [
    'Balanced breakfast ideas: Oats + nuts + fruits, Poha with peanuts, Eggs with whole wheat toast, Dosa with sambar, Upma with vegetables.',
    'Protein-rich breakfasts keep you full longer: Moong dal chilla, Paneer paratha, Egg omelette, Greek yogurt with nuts.',
    'Quick breakfast for busy mornings: Overnight oats, Smoothie bowl, Instant idli, Besan chilla, Fruit with nuts.'
  ],
  'lunch|afternoon meal': [
    'Balanced lunch plate: 1/2 vegetables, 1/4 protein, 1/4 complex carbs. Example: Dal + sabzi + roti/rice + salad + curd.',
    'Office lunch ideas: Quinoa salad, Rajma rice bowl, Paneer wrap, Chicken tikka with vegetables, Vegetable pulao with raita.',
    'Prep lunch night before to save time and eat healthier!'
  ],
  'dinner|evening meal': [
    'Lighter dinner is better for sleep and digestion. Aim to eat 2-3 hours before bed.',
    'Healthy dinner ideas: Grilled chicken/fish with vegetables, Dal with roti, Vegetable soup, Khichdi, Paneer tikka with salad.',
    'Avoid heavy, fried, or spicy foods at dinner if you have acid reflux or sleep issues.'
  ],
  'snack|hungry between meals': [
    'Healthy snacks: Roasted makhana, Fruit with nuts, Sprouts chaat, Hummus with veggies, Yogurt, Boiled eggs.',
    'Avoid packaged snacks! They\'re high in sodium, sugar, and unhealthy fats. Make homemade alternatives.',
    'Snack smart: Aim for 150-200 calorie snacks with protein or fiber to keep you satisfied.'
  ],

  // Specific Diets
  'vegetarian|veg|plant based': [
    'Vegetarian protein sources: Dal (all types), paneer, tofu, quinoa, chickpeas, kidney beans, peanuts, almonds, chia seeds.',
    'Get complete proteins by combining grains + legumes (rice+dal, wheat+chickpeas, corn+beans).',
    'Ensure adequate B12, Iron, and Omega-3. Consider fortified foods or supplements after consulting a doctor.'
  ],
  'vegan|no dairy|no eggs': [
    'Vegan Indian cuisine is rich! Many South Indian dishes are naturally vegan: Dosa, idli, sambar, coconut chutney, poriyal.',
    'Dairy alternatives: Coconut milk, almond milk, cashew cream, soy yogurt. Egg alternatives: Flax eggs (1 tbsp flax + 3 tbsp water).',
    'Vegan protein: Tofu, tempeh, legumes, nuts, seeds, quinoa, nutritional yeast (for B12).'
  ],
  'keto|low carb|ketogenic': [
    'Keto focuses on high fat, moderate protein, very low carbs (<50g daily). Indian keto: Paneer, eggs, chicken, fish, ghee, nuts, low-carb vegetables.',
    'Replace rice/roti with: Cauliflower rice, almond flour roti, cheese wraps.',
    'Note: Keto can be challenging with Indian diet. Consider low-carb instead of strict keto for sustainability.'
  ],
  'gluten free|celiac|wheat allergy': [
    'Gluten-free Indian grains: Rice, millets (ragi, jowar, bajra), quinoa, amaranth, buckwheat.',
    'Replace wheat flour with: Rice flour, besan (chickpea flour), almond flour, coconut flour, or commercial gluten-free flour blends.',
    'Many Indian dishes are naturally gluten-free: Rice dishes, dosa, idli, besan chilla, many curries and daals!'
  ],

  // Food & Ingredients
  'dal|lentils|pulses': [
    'Dal types: Moong (light, easy to digest), Toor/Arhar (protein-rich), Masoor (quick cooking), Urad (creamy), Chana dal (nutty).',
    'Dal is a nutrition powerhouse: High protein, fiber, vitamins, minerals, low fat. Have dal daily!',
    'Cooking tip: Soak dal for faster cooking and better digestion. Add turmeric and ginger to reduce gas.'
  ],
  'rice|basmati|brown rice': [
    'Brown rice > White rice for nutrition (more fiber, vitamins, minerals). But white basmati has lower GI than regular white rice.',
    'Portion control: 1/2 to 3/4 cup cooked rice per meal is adequate for most people.',
    'Try millet alternatives: Foxtail millet, little millet, kodo millet - higher nutrition than rice!'
  ],
  'paneer|cottage cheese': [
    'Paneer is high in protein (18g per 100g) and calcium. Great for vegetarians building muscle!',
    'Lower-fat version: Make paneer from low-fat milk or buy low-fat paneer. Grill/bake instead of frying.',
    'Alternatives: Tofu (fewer calories), ricotta cheese, cottage cheese (lower fat).'
  ],
  'chicken|poultry|meat': [
    'Chicken breast is lean protein (31g/100g, low fat). Skinless is healthier. Grill, bake, or steam instead of frying.',
    'Marinate with yogurt, lemon, and spices for tenderness and flavor. Avoid processed chicken (nuggets, sausages).',
    'Portion: 100-150g cooked chicken per meal provides adequate protein without excess.'
  ],
  'fish|seafood|omega 3': [
    'Fish is excellent! High in protein, omega-3 fatty acids, vitamins D & B12. Eat fatty fish (salmon, mackerel, sardines) 2-3 times weekly.',
    'Indian fish varieties: Pomfret, Hilsa, Rohu, Katla, Kingfish. Prepare with minimal oil - grilled, steamed, or curry.',
    'Omega-3 benefits: Heart health, brain function, reduces inflammation, improves mood.'
  ],

  // Common Concerns
  'diabetes|blood sugar|insulin': [
    'Diabetes management: Choose low-GI foods, control portions, eat regularly (don\'t skip meals), balance carbs with protein & fiber.',
    'Best foods: Whole grains, legumes, vegetables, lean proteins. Limit: Refined carbs, sugary foods, fried items.',
    'Monitor portions even for healthy foods. Check blood sugar regularly and consult your doctor for personalized advice.'
  ],
  'thyroid|hypothyroid|metabolism': [
    'Hypothyroidism: Ensure adequate iodine (iodized salt), selenium (nuts, eggs), zinc (legumes). Avoid excessive raw cruciferous vegetables.',
    'Eat: Fiber-rich foods, lean proteins, healthy fats. Limit: Processed foods, excess soy, refined carbs.',
    'Take thyroid medication on empty stomach. Wait 30-60 minutes before eating. Consult doctor regularly.'
  ],
  'pcod|pcos|hormonal': [
    'PCOS diet: Low-GI foods, high fiber, lean proteins, healthy fats. Avoid refined carbs, sugar, processed foods.',
    'Helpful foods: Whole grains, vegetables, fruits, fatty fish, nuts, seeds, cinnamon, turmeric.',
    'Lifestyle: Regular exercise, stress management, adequate sleep, maintain healthy weight. Consult gynecologist and nutritionist.'
  ],
  'acidity|acid reflux|gerd': [
    'Avoid: Spicy foods, citrus, tomatoes, chocolate, caffeine, carbonated drinks, alcohol, fried/fatty foods.',
    'Helpful foods: Oatmeal, bananas, melons, green vegetables, ginger, fennel, coconut water.',
    'Lifestyle: Eat smaller meals, don\'t lie down immediately after eating, elevate head while sleeping, avoid tight clothes.'
  ],
  'constipation|digestion|gut health': [
    'Increase fiber: Whole grains, vegetables, fruits, legumes, flaxseeds, chia seeds. Target: 25-35g fiber daily.',
    'Hydration is key! Drink 8-10 glasses of water. Warm water in morning helps.',
    'Probiotics: Yogurt, buttermilk, fermented foods (idli, dosa). Exercise regularly. Don\'t ignore the urge to go!'
  ],

  // Food Safety & Storage
  'storage|preserve|spoilage|fresh': [
    'Refrigerate perishables within 2 hours. Cooked food stays fresh for 3-4 days refrigerated.',
    'Freeze: Cooked dal, curries, roti, cooked rice for up to 3 months. Label with date!',
    'Check for spoilage: Smell, color change, mold. When in doubt, throw it out!'
  ],
  'meal prep|batch cooking': [
    'Sunday meal prep saves time and promotes healthy eating! Cook: Dal, rice, chop vegetables, marinate proteins.',
    'Prep breakfast: Overnight oats jars, cut fruits, boiled eggs (5-7 days).',
    'Portion and store in containers. Invest in good quality airtight containers.'
  ],

  // Indian Cuisine Specific
  'north indian|punjabi|mughlai': [
    'North Indian cuisine: Rich, creamy curries with wheat-based breads. Popular: Butter chicken, dal makhani, paneer dishes, tandoori items.',
    'Make healthier: Use less cream/butter, grill instead of fry, use whole wheat flour, add more vegetables.',
    'Signature spices: Garam masala, kasuri methi, saffron, cardamom.'
  ],
  'south indian|tamil|kerala': [
    'South Indian food is generally healthier: Fermented (idli, dosa), rice-based, coconut, curry leaves, tamarind.',
    'Nutritious dishes: Sambar, rasam, poriyal, kootu, avial - all vegetable-rich!',
    'Signature: Curry leaves, coconut, mustard seeds, urad dal, tamarind, hing (asafoetida).'
  ],
  'gujarati|rajasthani|maharashtrian': [
    'Gujarati: Often sweet-savory combination. Dhokla, thepla, khandvi are healthy, steamed options.',
    'Rajasthani: Rich but flavorful. Dal baati churma, gatte ki sabzi, ker sangri.',
    'Maharashtrian: Balanced flavors. Poha, misal pav, thalipeeth, bhakri, varan bhaat.'
  ],

  // General Greetings & Help
  'hello|hi|hey|greetings|namaste': [
    'Hello! 👋 I\'m your Rasoi Mate AI assistant. I can help with nutrition advice, recipes, meal planning, and health questions!',
    'Namaste! 🙏 How can I help you with your cooking and nutrition today?',
    'Hi there! I\'m here to help with recipes, nutrition, diet plans, and healthy living. What would you like to know?'
  ],
  'help|what can you do|features': [
    'I can help with: 📱 Recipe suggestions, 🥗 Nutrition advice, 📊 Meal planning, 🏋️ Fitness tips, 🔄 Ingredient substitutes, 🍳 Cooking techniques!',
    'Ask me about: Specific recipes, dietary requirements (vegan, keto, etc.), health conditions (diabetes, PCOS), meal prep, or any food-related questions!',
    'I have knowledge of 1000+ recipes, nutrition facts, Indian cuisines, healthy eating, meal planning, and much more!'
  ],
  'thank|thanks|appreciate': [
    'You\'re welcome! 😊 Happy cooking!',
    'Glad I could help! Feel free to ask anytime! 🍽️',
    'My pleasure! Enjoy your healthy meals! 🌟'
  ],
};

// Generate response based on keywords
function generateResponse(userMessage: string): string {
  const lowerMessage = userMessage.toLowerCase();
  
  // Check each pattern
  for (const [pattern, responses] of Object.entries(knowledgeBase)) {
    const keywords = pattern.split('|');
    if (keywords.some(keyword => lowerMessage.includes(keyword))) {
      // Return random response from the array
      return responses[Math.floor(Math.random() * responses.length)];
    }
  }
  
  // Default responses
  const defaultResponses = [
    'That\'s an interesting question! Could you be more specific? I can help with recipes, nutrition, meal planning, and health advice.',
    'I\'m here to help! Try asking about: recipes, ingredients, nutrition facts, diet plans, cooking methods, or specific health conditions.',
    'I\'d love to help! You can ask me about Indian recipes, healthy eating, meal prep, or any nutrition-related questions.',
  ];
  
  return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
}

export function AIChatbot({ isOpen, onClose, context }: AIChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: 'Hello! 👋 I\'m your Rasoi Mate AI assistant. I can answer 10,000+ questions about cooking, nutrition, recipes, diet, and healthy living. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI thinking and generate response
    setTimeout(() => {
      const response = generateResponse(input);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 500 + Math.random() * 1000);
  };

  const quickQuestions = [
    'High protein recipes',
    'Weight loss tips',
    'Vegan alternatives',
    'Quick breakfast ideas',
    'Low carb meals',
    'Healthy snacks'
  ];

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.8, y: 20 }}
      className="fixed bottom-6 right-6 z-50"
      style={{ width: isMinimized ? '320px' : '420px' }}
    >
      <Card className="shadow-2xl border-2 overflow-hidden" style={{ borderColor: '#3F51B5' }}>
        {/* Header */}
        <div 
          className="p-4 flex items-center justify-between cursor-pointer"
          style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50, #3F51B5)' }}
          onClick={() => setIsMinimized(!isMinimized)}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
              <Bot className="w-6 h-6" style={{ color: '#3F51B5' }} />
            </div>
            <div className="text-white">
              <h3 className="text-sm">Rasoi AI Assistant</h3>
              <p className="text-xs opacity-90">Always ready to help!</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                setIsMinimized(!isMinimized);
              }}
              className="text-white hover:bg-white/20"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="text-white hover:bg-white/20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <AnimatePresence>
          {!isMinimized && (
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: 'auto' }}
              exit={{ height: 0 }}
              className="overflow-hidden"
            >
              {/* Messages */}
              <ScrollArea className="h-[400px] p-4" ref={scrollRef}>
                <div className="space-y-4">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex gap-3 ${message.type === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
                    >
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ 
                          background: message.type === 'bot' 
                            ? 'linear-gradient(135deg, #3F51B5, #5C6BC0)' 
                            : 'linear-gradient(135deg, #FF9933, #FFA726)'
                        }}
                      >
                        {message.type === 'bot' ? (
                          <Bot className="w-4 h-4 text-white" />
                        ) : (
                          <User className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <div 
                        className={`flex-1 p-3 rounded-2xl ${
                          message.type === 'user' 
                            ? 'bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-900 dark:to-orange-800' 
                            : 'bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-900 dark:to-blue-800'
                        }`}
                        style={{ maxWidth: '85%' }}
                      >
                        <p className="text-sm">{message.content}</p>
                        <p className="text-xs opacity-60 mt-1">
                          {message.timestamp.toLocaleTimeString('en-US', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                  
                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex gap-3"
                    >
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, #3F51B5, #5C6BC0)' }}
                      >
                        <Bot className="w-4 h-4 text-white" />
                      </div>
                      <div className="bg-blue-50 dark:bg-blue-900 p-3 rounded-2xl">
                        <div className="flex gap-1">
                          <motion.div
                            className="w-2 h-2 rounded-full bg-blue-500"
                            animate={{ scale: [1, 1.3, 1] }}
                            transition={{ repeat: Infinity, duration: 0.6, delay: 0 }}
                          />
                          <motion.div
                            className="w-2 h-2 rounded-full bg-blue-500"
                            animate={{ scale: [1, 1.3, 1] }}
                            transition={{ repeat: Infinity, duration: 0.6, delay: 0.2 }}
                          />
                          <motion.div
                            className="w-2 h-2 rounded-full bg-blue-500"
                            animate={{ scale: [1, 1.3, 1] }}
                            transition={{ repeat: Infinity, duration: 0.6, delay: 0.4 }}
                          />
                        </div>
                      </div>
                    </motion.div>
                  )}
                </div>
              </ScrollArea>

              {/* Quick Questions */}
              {messages.length === 1 && (
                <div className="px-4 pb-3">
                  <p className="text-xs text-muted-foreground mb-2">Quick questions:</p>
                  <div className="flex flex-wrap gap-2">
                    {quickQuestions.map((question, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setInput(question);
                          setTimeout(handleSend, 100);
                        }}
                        className="text-xs rounded-full"
                      >
                        {question}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Input */}
              <div className="p-4 border-t bg-gradient-to-r from-orange-50 to-green-50 dark:from-gray-800 dark:to-gray-700">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask me anything about food, nutrition, recipes..."
                    className="flex-1"
                  />
                  <Button
                    onClick={handleSend}
                    disabled={!input.trim() || isTyping}
                    style={{ background: 'linear-gradient(135deg, #FF9933, #4CAF50)', color: 'white' }}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  Powered by AI • 10,000+ answers
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>
    </motion.div>
  );
}
