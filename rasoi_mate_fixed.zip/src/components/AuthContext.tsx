import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { auth, db } from '../firebase';
import { onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { toast } from 'sonner@2.0.3';

// User interface
export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  joinedDate: string;
  lastLogin: string;
  recipesCooked: number;
  favoriteRecipes: string[];
  recentActivity: ActivityLog[];
  preferences: UserPreferences;
  isDeveloper: boolean;
  stats: UserStats;
  healthProfile?: HealthProfile;
}

export interface ActivityLog {
  id: string;
  type: 'recipe_viewed' | 'recipe_cooked' | 'recipe_saved' | 'feedback_sent' | 'login' | 'signup';
  description: string;
  timestamp: string;
  metadata?: any;
}

export interface UserPreferences {
  language: string;
  dietaryRestrictions: string[];
  favoriteRegions: string[];
  skillLevel: 'beginner' | 'intermediate' | 'advanced';
  emailNotifications: boolean;
}

export interface UserStats {
  totalRecipesCooked: number;
  totalRecipesViewed: number;
  totalRecipesSaved: number;
  streakDays: number;
  favoriteCategory: string;
  cookingTime: number; // in minutes
}

export interface HealthProfile {
  gender: 'male' | 'female' | 'other' | '';
  age: number;
  weight: number; // in kg
  height: number; // in cm
  goal: 'weight-loss' | 'weight-gain' | 'maintain' | '';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active' | '';
  dietaryPreference: 'vegetarian' | 'vegan' | 'non-vegetarian' | 'eggetarian' | '';
}

interface AuthContextType {
  user: User | null;
  isLoggedIn: boolean;
  isDeveloper: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  updateHealthProfile: (profile: Partial<HealthProfile>) => void;
  addActivity: (activity: Omit<ActivityLog, 'id' | 'timestamp'>) => void;
  getAllUsers: () => User[];
  getTotalUsers: () => number;
  getActiveUsers: () => number;
  getRecentSignups: () => User[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Authorized developer emails
const AUTHORIZED_DEVELOPERS = [
  'sohamsingale775@gmail.com',
  'jerry415721@gmail.com'
];

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Check for existing session on mount
  useEffect(() => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      try {
        const userData = JSON.parse(currentUser);
        setUser(userData);
        setIsLoggedIn(true);
      } catch (error) {
        console.error('Error loading user session:', error);
        localStorage.removeItem('currentUser');
      }
    }
  }, []);

  // Save user to localStorage whenever it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('currentUser', JSON.stringify(user));
      
      // Update user in allUsers array
      const allUsers = getAllUsersFromStorage();
      const userIndex = allUsers.findIndex(u => u.id === user.id);
      if (userIndex !== -1) {
        allUsers[userIndex] = user;
        localStorage.setItem('allUsers', JSON.stringify(allUsers));
      }
    }
  }, [user]);

  const getAllUsersFromStorage = (): User[] => {
    try {
      const users = localStorage.getItem('allUsers');
      return users ? JSON.parse(users) : [];
    } catch {
      return [];
    }
  };

  const checkDeveloperAccess = (email: string): boolean => {
    return AUTHORIZED_DEVELOPERS.includes(email.toLowerCase());
  };

  const generateUserId = (): string => {
    return `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const allUsers = getAllUsersFromStorage();
      const foundUser = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

      if (!foundUser) {
        toast.error('No account found with this email. Please sign up first.');
        return false;
      }

      // Validate password
      const passwords = JSON.parse(localStorage.getItem('userPasswords') || '{}');
      const storedPassword = passwords[email.toLowerCase()];

      if (storedPassword && storedPassword !== password) {
        toast.error('Incorrect password. Please try again.');
        return false;
      }

      // Update last login and add activity
      const now = new Date().toISOString();
      const loginActivity: ActivityLog = {
        id: `activity_${Date.now()}`,
        type: 'login',
        description: 'Logged into account',
        timestamp: now
      };

      const updatedUser: User = {
        ...foundUser,
        lastLogin: now,
        recentActivity: [loginActivity, ...(foundUser.recentActivity || [])].slice(0, 50)
      };

      setUser(updatedUser);
      setIsLoggedIn(true);

      // Update in allUsers
      const userIndex = allUsers.findIndex(u => u.id === foundUser.id);
      allUsers[userIndex] = updatedUser;
      localStorage.setItem('allUsers', JSON.stringify(allUsers));

      toast.success(`Welcome back, ${foundUser.name}! 🎉`);
      return true;
    } catch (error) {
      console.error('Login error:', error);
      toast.error('An error occurred during login. Please try again.');
      return false;
    }
  };

  const signup = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      const allUsers = getAllUsersFromStorage();
      
      // Check if user already exists
      const userExists = allUsers.some(u => u.email.toLowerCase() === email.toLowerCase());
      if (userExists) {
        toast.error('An account with this email already exists. Please login instead.');
        return false;
      }

      const now = new Date().toISOString();
      const userId = generateUserId();
      const isDev = checkDeveloperAccess(email);

      const signupActivity: ActivityLog = {
        id: `activity_${Date.now()}`,
        type: 'signup',
        description: 'Created account',
        timestamp: now
      };

      const newUser: User = {
        id: userId,
        name,
        email: email.toLowerCase(),
        joinedDate: now,
        lastLogin: now,
        recipesCooked: 0,
        favoriteRecipes: [],
        recentActivity: [signupActivity],
        preferences: {
          language: 'english',
          dietaryRestrictions: [],
          favoriteRegions: [],
          skillLevel: 'beginner',
          emailNotifications: true
        },
        isDeveloper: isDev,
        stats: {
          totalRecipesCooked: 0,
          totalRecipesViewed: 0,
          totalRecipesSaved: 0,
          streakDays: 0,
          favoriteCategory: '',
          cookingTime: 0
        },
        healthProfile: {
          gender: '',
          age: 0,
          weight: 0,
          height: 0,
          goal: '',
          activityLevel: '',
          dietaryPreference: ''
        }
      };

      // Save user
      allUsers.push(newUser);
      localStorage.setItem('allUsers', JSON.stringify(allUsers));

      // Save password (encrypted in production!)
      const passwords = JSON.parse(localStorage.getItem('userPasswords') || '{}');
      passwords[email.toLowerCase()] = password;
      localStorage.setItem('userPasswords', JSON.stringify(passwords));

      setUser(newUser);
      setIsLoggedIn(true);

      toast.success(`Welcome to Rasoi Mate, ${name}! 🎉`);
      return true;
    } catch (error) {
      console.error('Signup error:', error);
      toast.error('An error occurred during signup. Please try again.');
      return false;
    }
  };

  const signInWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const u = result.user;
      // ensure user profile exists
      const docRef = doc(db,'users', u.uid);
      const snap = await getDoc(docRef);
      if(!snap.exists()){
        const profile = { id: u.uid, name: u.displayName || '', email: u.email, joinedDate: new Date().toISOString(), recipesCooked:0, favoriteRecipes:[], recentActivity:[], preferences: {}, isDeveloper: AUTHORIZED_DEVELOPERS.includes((u.email||'').toLowerCase()) };
        await setDoc(docRef, profile, { merge: true });
      }
      return true;
    } catch(e){ console.error('Google sign-in failed', e); toast.error('Google sign-in failed'); return false; }
  };

  const logout = async () => { try { await signOut(auth); setUser(null); setIsLoggedIn(false); localStorage.removeItem('currentUser'); toast.success('Logged out successfully. See you soon! 👋'); } catch(e){ console.error(e); toast.error('Logout failed'); } };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
    }
  };

  const updateHealthProfile = (profile: Partial<HealthProfile>) => {
    if (user) {
      const updatedHealthProfile = {
        ...user.healthProfile,
        ...profile
      } as HealthProfile;
      
      const updatedUser = {
        ...user,
        healthProfile: updatedHealthProfile
      };
      
      setUser(updatedUser);
      toast.success('Health profile updated successfully! 🎯');
    }
  };

  const addActivity = (activity: Omit<ActivityLog, 'id' | 'timestamp'>) => {
    if (user) {
      const newActivity: ActivityLog = {
        ...activity,
        id: `activity_${Date.now()}`,
        timestamp: new Date().toISOString()
      };

      const updatedUser = {
        ...user,
        recentActivity: [newActivity, ...(user.recentActivity || [])].slice(0, 50)
      };

      setUser(updatedUser);
    }
  };

  const getAllUsers = (): User[] => {
    return getAllUsersFromStorage();
  };

  const getTotalUsers = (): number => {
    return getAllUsersFromStorage().length;
  };

  const getActiveUsers = (): number => {
    const allUsers = getAllUsersFromStorage();
    const now = Date.now();
    const oneHourAgo = now - (60 * 60 * 1000);
    
    return allUsers.filter(u => {
      const lastLogin = new Date(u.lastLogin).getTime();
      return lastLogin > oneHourAgo;
    }).length;
  };

  const getRecentSignups = (): User[] => {
    const allUsers = getAllUsersFromStorage();
    return allUsers
      .sort((a, b) => new Date(b.joinedDate).getTime() - new Date(a.joinedDate).getTime())
      .slice(0, 5);
  };

  const value: AuthContextType = {
    user,
    isLoggedIn,
    isDeveloper: user?.isDeveloper || false,
    login,
    signup,
    logout,
    updateUser,
    updateHealthProfile,
    addActivity,
    getAllUsers,
    getTotalUsers,
    getActiveUsers,
    getRecentSignups
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
