import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Mail, MessageSquare, Users, BookOpen, Send, Bug, Lightbulb, AlertCircle, Youtube, Instagram, ArrowLeft } from 'lucide-react';
import { useState, useRef } from 'react';
import { toast } from 'sonner@2.0.3';
import { KitchenBackground } from './KitchenBackground';
import { Footer } from './Footer';

interface ContactPageProps {
  onNavigate?: (page: string) => void;
}

export function ContactPage({ onNavigate }: ContactPageProps = {}) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    category: 'general',
    subject: '',
    message: '',
  });
  const [sending, setSending] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  // EmailJS Configuration
  // To set this up:
  // 1. Create a free account at https://www.emailjs.com/
  // 2. Create an Email Service (Gmail, Outlook, etc.)
  // 3. Create an Email Template with these variables: from_name, from_email, to_email, category, subject, message
  // 4. Get your Public Key from Account > API Keys
  // 5. Replace these values with your actual EmailJS credentials
  const EMAILJS_SERVICE_ID = 'service_7k8g0j8'; // Replace with your service ID
  const EMAILJS_TEMPLATE_ID = 'template_t7837mo'; // Replace with your template ID
  const EMAILJS_PUBLIC_KEY = 'VZfx0BUmxWNp2WAzM'; // Replace with your public key

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    
    // Send to BOTH developers for all feedback
    const recipients = ['sohamsingale775@gmail.com', 'jerry415721@gmail.com'];
    const recipientString = recipients.join(', ');
    
    // Save feedback to localStorage for developers
    const feedback = {
      ...formData,
      timestamp: new Date().toISOString(),
      id: Date.now(),
      recipients: recipientString,
    };
    
    const existingFeedback = JSON.parse(localStorage.getItem('userFeedback') || '[]');
    localStorage.setItem('userFeedback', JSON.stringify([feedback, ...existingFeedback]));

    // Check if EmailJS is configured
    if (EMAILJS_PUBLIC_KEY === 'YOUR_PUBLIC_KEY_HERE') {
      // Fallback to mailto if EmailJS is not configured - send to BOTH developers
      const emailSubject = encodeURIComponent(`[Rasoi Mate - ${formData.category.toUpperCase()}] ${formData.subject}`);
      const emailBody = encodeURIComponent(
        `Name: ${formData.name}\nEmail: ${formData.email}\nCategory: ${formData.category}\n\nMessage:\n${formData.message}\n\n---\nSent from Rasoi Mate Contact Form`
      );

      window.location.href = `mailto:${recipientString}?subject=${emailSubject}&body=${emailBody}`;
      
      toast.success('📧 Opening your email client... Message will be sent to both developers: ' + recipientString);
      setSending(false);
      setFormData({ name: '', email: '', category: 'general', subject: '', message: '' });
      return;
    }

    // Send email using EmailJS to BOTH developers
    try {
      // Send email to each developer
      for (const recipient of recipients) {
        const templateParams = {
          from_name: formData.name,
          from_email: formData.email,
          to_email: recipient,
          category: formData.category,
          subject: formData.subject,
          message: formData.message,
          category_label: formData.category.charAt(0).toUpperCase() + formData.category.slice(1),
        };

        // Dynamically import EmailJS only when needed to avoid fetch errors in Figma environment
        const emailjs = await import('@emailjs/browser').then(m => m.default);
        await emailjs.send(
          EMAILJS_SERVICE_ID,
          EMAILJS_TEMPLATE_ID,
          templateParams,
          EMAILJS_PUBLIC_KEY
        );
      }

      toast.success(`✅ Message sent successfully to both developers!`);
      setFormData({ name: '', email: '', category: 'general', subject: '', message: '' });
    } catch (error) {
      console.error('EmailJS Error:', error);
      
      // Fallback to mailto if EmailJS fails - send to BOTH
      const emailSubject = encodeURIComponent(`[Rasoi Mate - ${formData.category.toUpperCase()}] ${formData.subject}`);
      const emailBody = encodeURIComponent(
        `Name: ${formData.name}\nEmail: ${formData.email}\nCategory: ${formData.category}\n\nMessage:\n${formData.message}\n\n---\nSent from Rasoi Mate Contact Form`
      );

      window.location.href = `mailto:${recipientString}?subject=${emailSubject}&body=${emailBody}`;
      
      toast.error('Failed to send email. Opening your email client as fallback...');
    } finally {
      setSending(false);
    }
  };

  const handleQuickAction = (category: string, subject: string, message: string) => {
    setFormData({
      ...formData,
      category,
      subject,
      message
    });
    
    // Scroll to form
    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    
    // Show toast
    toast.info(`Form ready! Please fill in your details and ${category === 'bug' ? 'describe the bug' : category === 'feature' ? 'describe your idea' : 'share your recipe'}.`);
  };

  const contactOptions = [
    {
      icon: Bug,
      title: 'Report a Bug',
      description: 'Found something not working? Let us know so we can fix it',
      action: 'Report Issue',
      color: 'var(--destructive)',
      category: 'bug',
      defaultSubject: 'Bug Report: ',
      defaultMessage: 'Please describe the bug you encountered:\n\n1. What were you trying to do?\n2. What happened instead?\n3. Steps to reproduce:\n\nBrowser/Device: '
    },
    {
      icon: Lightbulb,
      title: 'Feature Request',
      description: 'Have an idea to make Rasoi Mate better? We\'d love to hear it',
      action: 'Suggest Feature',
      color: 'var(--saffron)',
      category: 'feature',
      defaultSubject: 'Feature Request: ',
      defaultMessage: 'Please describe your feature idea:\n\n1. What feature would you like to see?\n2. How would it help you?\n3. Any specific details or examples:\n\n'
    },
    {
      icon: BookOpen,
      title: 'Submit Recipe',
      description: 'Share your unique recipe or regional dish with our community',
      action: 'Share Recipe',
      color: 'var(--green)',
      category: 'recipe',
      defaultSubject: 'Recipe Submission: ',
      defaultMessage: 'Recipe Name: \n\nRegion/Cuisine: \n\nPrep Time: \n\nIngredients:\n- \n\nSteps:\n1. \n\nSpecial Tips: '
    },
  ];

  return (
    <div className="min-h-screen py-12 relative overflow-hidden">
      <KitchenBackground />
      <div className="container mx-auto max-w-7xl px-4 relative z-10">
        {/* Back Button */}
        {onNavigate && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="mb-6"
          >
            <Button
              variant="ghost"
              onClick={() => onNavigate('home')}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </motion.div>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <Badge className="mb-4" style={{ background: 'var(--green)', color: 'white' }}>
            <Mail className="mr-1 h-3 w-3" />
            Get in Touch
          </Badge>
          <h1 className="text-3xl md:text-5xl mb-4">Contact & Feedback</h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            We value your feedback! Report bugs, request features, or just say hello
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Contact Options */}
          {contactOptions.map((option, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -8 }}
            >
              <Card 
                className="p-6 h-full hover:shadow-xl transition-all cursor-pointer"
                onClick={() => handleQuickAction(option.category, option.defaultSubject, option.defaultMessage)}
              >
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center mb-4"
                  style={{ background: `${option.color}20` }}
                >
                  <option.icon className="h-6 w-6" style={{ color: option.color }} />
                </div>
                <h3 className="mb-2">{option.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{option.description}</p>
                <Button variant="outline" className="w-full" style={{ borderColor: option.color, color: option.color }}>
                  {option.action}
                </Button>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Contact Form */}
        <motion.div
          ref={formRef}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="max-w-3xl mx-auto scroll-mt-8"
        >
          <Card className="p-8 md:p-12">
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl mb-2">Send us Feedback</h2>
              <p className="text-muted-foreground">
                Your message will be sent directly to our developer team via email
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Your Name *</Label>
                  <Input
                    id="name"
                    placeholder="Enter your name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select value={formData.category} onValueChange={(val) => setFormData({ ...formData, category: val })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4" />
                        General Inquiry
                      </div>
                    </SelectItem>
                    <SelectItem value="bug">
                      <div className="flex items-center gap-2">
                        <Bug className="h-4 w-4" />
                        Bug Report
                      </div>
                    </SelectItem>
                    <SelectItem value="feature">
                      <div className="flex items-center gap-2">
                        <Lightbulb className="h-4 w-4" />
                        Feature Request
                      </div>
                    </SelectItem>
                    <SelectItem value="recipe">
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4" />
                        Recipe Submission
                      </div>
                    </SelectItem>
                    <SelectItem value="partnership">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Partnership Opportunity
                      </div>
                    </SelectItem>
                    <SelectItem value="feedback">
                      <div className="flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" />
                        General Feedback
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject *</Label>
                <Input
                  id="subject"
                  placeholder="Brief description of your message"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Your Message *</Label>
                <Textarea
                  id="message"
                  placeholder="Tell us more about your feedback, bug report, or suggestion..."
                  rows={8}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                />
              </div>

              <div className="bg-muted/50 p-4 rounded-lg border">
                <p className="text-sm text-muted-foreground">
                  <strong>Note:</strong> Your message will be sent directly to BOTH developers via email (Soham & Jerry). 
                  {formData.category === 'recipe' && ' Recipe submissions help us expand our collection!'}
                  {formData.category === 'bug' && ' Bug reports help us improve the platform.'}
                  {formData.category === 'feature' && ' Feature requests help us prioritize what to build next!'}
                  {!['recipe', 'bug', 'feature'].includes(formData.category) && ' All feedback is valuable and reviewed by our team.'}
                </p>
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full"
                disabled={sending}
                style={{ background: 'linear-gradient(135deg, var(--tech-blue), var(--tech-blue-light))' }}
              >
                {sending ? (
                  <>
                    <motion.div
                      className="mr-2"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    >
                      <Send className="h-4 w-4" />
                    </motion.div>
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Send Feedback
                  </>
                )}
              </Button>
            </form>
          </Card>
        </motion.div>

        {/* Additional Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-12"
        >
          <Card className="p-8 text-center bg-gradient-to-r from-[var(--saffron)]/10 via-[var(--tech-blue)]/10 to-[var(--green)]/10 border-0">
            <h3 className="text-xl mb-4">Direct Email Contact</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
              <div>
                <p className="text-sm text-muted-foreground mb-1">General Inquiries</p>
                <a href="mailto:sohamsingale775@gmail.com" className="hover:underline" style={{ color: 'var(--tech-blue)' }}>
                  sohamsingale775@gmail.com
                </a>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Partnership Opportunities</p>
                <a href="mailto:sohamsingale775@gmail.com" className="hover:underline" style={{ color: 'var(--tech-blue)' }}>
                  sohamsingale775@gmail.com
                </a>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Recipe Submissions</p>
                <a href="mailto:jerry415721@gmail.com" className="hover:underline" style={{ color: 'var(--tech-blue)' }}>
                  jerry415721@gmail.com
                </a>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Developer Team</p>
                <a href="mailto:sohamsingale775@gmail.com" className="text-xs hover:underline block" style={{ color: 'var(--tech-blue)' }}>
                  Soham Singale
                </a>
                <a href="mailto:jerry415721@gmail.com" className="text-xs hover:underline block" style={{ color: 'var(--tech-blue)' }}>
                  Jerry
                </a>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Social Media Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          className="mt-8"
        >
          <Card className="p-8 text-center">
            <h3 className="text-xl mb-4">Follow Us on Social Media</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Stay updated with new recipes, cooking tips, and AI features!
            </p>
            <div className="flex justify-center gap-6">
              <a 
                href="https://www.youtube.com/@RasoiMate" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-2 p-4 rounded-lg hover:bg-muted/50 transition-all"
              >
                <div className="w-12 h-12 rounded-full flex items-center justify-center bg-red-50 group-hover:scale-110 transition-transform">
                  <Youtube className="h-6 w-6 text-red-600" />
                </div>
                <div className="text-center">
                  <p className="text-sm">YouTube</p>
                  <p className="text-xs text-muted-foreground">@RasoiMate</p>
                </div>
              </a>
              <a 
                href="https://www.instagram.com/rasoi_mate" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-2 p-4 rounded-lg hover:bg-muted/50 transition-all"
              >
                <div className="w-12 h-12 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform"
                  style={{ background: 'linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%)' }}
                >
                  <Instagram className="h-6 w-6 text-white" />
                </div>
                <div className="text-center">
                  <p className="text-sm">Instagram</p>
                  <p className="text-xs text-muted-foreground">@rasoi_mate</p>
                </div>
              </a>
            </div>
          </Card>
        </motion.div>

        {/* Response Time Notice */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center"
        >
          <p className="text-sm text-muted-foreground">
            ⚡ We typically respond within 24-48 hours. For urgent issues, please email directly.
          </p>
        </motion.div>
      </div>

      {/* Footer */}
      <Footer onNavigate={onNavigate} />
    </div>
  );
}
