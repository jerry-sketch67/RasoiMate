import { motion } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { ScrollArea } from './ui/scroll-area';
import { Star, Heart, Clock, TrendingUp, Award, BookOpen, Mail, Bell, ChefHat, Activity, Calendar, Sparkles } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState, useEffect } from 'react';
import { toast } from 'sonner@2.0.3';
import { useAuth } from './AuthContext';
import { Footer } from './Footer';
import { useLiveRecipes, useFeatureFlags } from '../hooks/useFirebaseHooks';

const mockRecentRecipes = [
  {
    id: 1,
    name: 'Paneer Butter Masala',
    image: 'https://images.unsplash.com/photo-1701579231378-3726490a407b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYW5lZXIlMjBidXR0ZXIlMjBtYXNhbGF8ZW58MXx8fHwxNzYwMzIwNTI0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    cookedDate: '2 days ago',
  },
  {
    id: 2,
    name: 'Masala Dosa',
    image: 'https://images.unsplash.com/photo-1743517894265-c86ab035adef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb3NhJTIwc291dGglMjBpbmRpYW58ZW58MXx8fHwxNzYwMjkzNjI5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    cookedDate: '5 days ago',
  },
];

const mockSavedRecipes = [
  {
    id: 4,
    name: 'Chole Bhature',
    image: 'https://images.unsplash.com/photo-1680359873864-43e89bf248ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9sZSUyMGJoYXR1cmUlMjBmb29kfGVufDF8fHx8MTc2MDMyMDYzNXww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 5,
    name: 'Samosa',
    image: 'https://images.unsplash.com/photo-1697155836252-d7f969108b5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW1vc2ElMjBpbmRpYW4lMjBzbmFja3N8ZW58MXx8fHwxNzYwMzIwNjM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
];

export function DashboardPage() {
  const liveRecipes = useLiveRecipes(200);
  const flags = useFeatureFlags();

  const { user, updateUser, addActivity } = useAuth();
  const [recipes, setRecipes] = useState(mockRecentRecipes);
  const [activeTab, setActiveTab] = useState('overview');

  if (!user) return null;

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getDaysSinceJoined = () => {
    const joined = new Date(user.joinedDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - joined.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="min-h-screen py-12 bg-gradient-to-br from-background via-accent/10 to-background">
      <div className="container mx-auto max-w-7xl px-4">
        {/* Header with personalized greeting */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-3xl font-bold shadow-lg">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl mb-1">
                Welcome back, {user.name}! 👋
              </h1>
              <p className="text-muted-foreground">
                Here's your cooking journey at a glance
              </p>
            </div>
          </div>
          
          {user.isDeveloper && (
            <Badge className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
              🔐 Developer Account
            </Badge>
          )}
        </motion.div>

        {/* Dynamic Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <Card className="p-6 hover:shadow-lg transition-shadow border-2 hover:border-blue-500/50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500/20 to-blue-500/10 flex items-center justify-center">
                <ChefHat className="h-6 w-6" style={{ color: 'var(--tech-blue)' }} />
              </div>
              <div>
                <p className="text-2xl font-bold">{user.stats?.totalRecipesCooked || 0}</p>
                <p className="text-sm text-muted-foreground">Recipes Cooked</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow border-2 hover:border-red-500/50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-red-500/20 to-red-500/10 flex items-center justify-center">
                <Heart className="h-6 w-6 text-red-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{user.favoriteRecipes?.length || 0}</p>
                <p className="text-sm text-muted-foreground">Saved Recipes</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow border-2 hover:border-yellow-500/50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-yellow-500/20 to-yellow-500/10 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{user.stats?.streakDays || 0}</p>
                <p className="text-sm text-muted-foreground">Day Streak</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 hover:shadow-lg transition-shadow border-2 hover:border-green-500/50">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-500/20 to-green-500/10 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{user.stats?.totalRecipesViewed || 0}</p>
                <p className="text-sm text-muted-foreground">Recipes Viewed</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Account Information */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Account Information
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Email</p>
                <p className="font-medium">{user.email}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Member Since</p>
                <p className="font-medium">{formatDate(user.joinedDate)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Last Active</p>
                <p className="font-medium">{formatDate(user.lastLogin)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Days as Member</p>
                <p className="font-medium">{getDaysSinceJoined()} days</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Skill Level</p>
                <Badge className="capitalize">{user.preferences?.skillLevel || 'Beginner'}</Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Preferred Language</p>
                <p className="font-medium capitalize">{user.preferences?.language || 'English'}</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Tabs Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="activity">Activity Log</TabsTrigger>
              <TabsTrigger value="preferences">Preferences</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Recent Recipes */}
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Recent Activity
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {recipes.map((recipe) => (
                    <Card key={recipe.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="aspect-video relative overflow-hidden">
                        <ImageWithFallback
                          src={recipe.image}
                          alt={recipe.name}
                          className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold mb-2">{recipe.name}</h3>
                        <p className="text-sm text-muted-foreground">{recipe.cookedDate}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              </Card>

              {/* Saved Recipes */}
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Saved for Later
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {mockSavedRecipes.map((recipe) => (
                    <Card key={recipe.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                      <div className="aspect-square relative overflow-hidden">
                        <ImageWithFallback
                          src={recipe.image}
                          alt={recipe.name}
                          className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-3">
                        <p className="font-medium text-sm">{recipe.name}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Activity Log Tab */}
            <TabsContent value="activity">
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Recent Activity
                </h2>
                <ScrollArea className="h-[500px] pr-4">
                  {user.recentActivity && user.recentActivity.length > 0 ? (
                    <div className="space-y-4">
                      {user.recentActivity.map((activity) => (
                        <motion.div
                          key={activity.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-start gap-4 p-4 rounded-lg bg-accent/50 border"
                        >
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                            <Activity className="h-5 w-5 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium capitalize">{activity.type.replace('_', ' ')}</p>
                            <p className="text-sm text-muted-foreground">{activity.description}</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(activity.timestamp).toLocaleString()}
                            </p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No activity yet. Start cooking to see your activity log!</p>
                    </div>
                  )}
                </ScrollArea>
              </Card>
            </TabsContent>

            {/* Preferences Tab */}
            <TabsContent value="preferences">
              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-4">Your Preferences</h2>
                <div className="space-y-6">
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Dietary Restrictions</Label>
                    <div className="flex flex-wrap gap-2">
                      {user.preferences?.dietaryRestrictions && user.preferences.dietaryRestrictions.length > 0 ? (
                        user.preferences.dietaryRestrictions.map((restriction: string) => (
                          <Badge key={restriction} variant="outline">{restriction}</Badge>
                        ))
                      ) : (
                        <p className="text-sm text-muted-foreground">No dietary restrictions set</p>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium mb-2 block">Favorite Regions</Label>
                    <div className="flex flex-wrap gap-2">
                      {user.preferences?.favoriteRegions && user.preferences.favoriteRegions.length > 0 ? (
                        user.preferences.favoriteRegions.map((region: string) => (
                          <Badge key={region} variant="outline">{region}</Badge>
                        ))
                      ) : (
                        <p className="text-sm text-muted-foreground">No favorite regions set</p>
                      )}
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium mb-2 block">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      {user.preferences?.emailNotifications ? 'Enabled ✓' : 'Disabled'}
                    </p>
                  </div>
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    <Footer />
    </div>
  );
{
