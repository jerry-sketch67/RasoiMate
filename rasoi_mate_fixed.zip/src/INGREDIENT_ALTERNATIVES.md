# Comprehensive Ingredient Alternatives Guide

## Overview

Rasoi Mate now includes **100+ ingredient alternatives** covering all common cooking ingredients, spices, dairy products, flours, oils, and more! The AI assistant can provide detailed substitution information with ratios and usage notes.

## How to Use

Simply ask the AI assistant about any ingredient:
- "Alternative for cornflour"
- "What can I use instead of cream?"
- "Substitute for red chili powder"
- "Replace paneer with what?"
- "What's a good alternative to turmeric?"

## Ingredient Categories Covered

### 1. **Thickening Agents**
- Cornflour/Cornstarch
- Arrowroot powder
- Potato starch
- Rice flour
- Tapioca starch
- All-purpose flour

### 2. **Spices - Hot**
- Red chili powder
- Kashmiri chili
- Green chili
- Cayenne pepper
- Paprika

### 3. **Spices - Aromatic**
- Cumin
- Coriander powder
- Cardamom
- Fennel seeds
- Fenugreek seeds

### 4. **Spices - Warm**
- Cinnamon
- Cloves
- Nutmeg
- Allspice

### 5. **Spices - Color & Health**
- Turmeric
- Saffron

### 6. **Spice Blends**
- Garam masala
- Curry powder
- Chaat masala

### 7. **Dairy - Rich**
- Cream
- Heavy cream
- Ghee
- Butter

### 8. **Dairy - Liquid**
- Milk (with vegan alternatives)
- Yogurt
- Buttermilk

### 9. **Dairy - Cheese**
- Paneer
- Cottage cheese
- Ricotta

### 10. **Dairy - Concentrated**
- Khoya/Mawa
- Condensed milk

### 11. **Sweeteners**
- Sugar
- Jaggery
- Honey
- Maple syrup
- Coconut sugar

### 12. **Acids - Souring Agents**
- Lemon juice
- Lime juice
- Tamarind
- Vinegar
- Amchur (dried mango powder)

### 13. **Aromatics**
- Onion
- Garlic
- Ginger
- Shallots

### 14. **Herbs**
- Cilantro/Coriander leaves
- Curry leaves
- Mint
- Parsley
- Basil

### 15. **Flours**
- All-purpose flour
- Whole wheat flour
- Besan (chickpea flour)
- Rice flour

### 16. **Oils**
- Vegetable oil
- Coconut oil
- Olive oil
- Ghee

### 17. **Binding Agents**
- Eggs (with vegan alternatives)
- Flax eggs
- Chia eggs

### 18. **Vegetables**
- Tomato
- Red bell peppers

### 19. **Nuts**
- Cashews
- Almonds

### 20. **Special Ingredients**
- Coconut milk
- Rose water
- Kewra water

## Sample Queries

### For Thickening Agents
```
User: "Alternative for cornflour"
AI: Provides 8 alternatives including arrowroot powder (1:1 ratio), 
    potato starch (1:1), rice flour (2:1), etc. with detailed notes
```

### For Dairy Products
```
User: "What can I use instead of cream?"
AI: Provides vegan and non-vegan options:
    - Coconut cream (1:1, vegan)
    - Cashew cream (1:1, vegan)
    - Full-fat milk + butter
    - Greek yogurt
    - Silken tofu blended
```

### For Spices
```
User: "Substitute for turmeric"
AI: Provides alternatives for color and flavor:
    - Saffron (for color, expensive)
    - Annatto powder (for color)
    - Curry powder (contains turmeric)
    - Ginger + paprika mix
```

## Features

### 1. **Ratio Information**
Every alternative includes recommended substitution ratios:
- 1:1 (equal amounts)
- 2:1 (use double)
- 0.5:1 (use half)
- Custom ratios with measurements

### 2. **Detailed Notes**
Each alternative includes:
- Flavor profile differences
- Best use cases
- Special preparation instructions
- Vegan/dietary considerations

### 3. **Category Organization**
Alternatives are organized by ingredient type for easy reference

### 4. **Interactive Guide**
Click the "Ingredient Guide" button in the AI Assistant sidebar to see all available categories

## Vegan & Dietary Alternatives

The system includes extensive vegan alternatives for:
- All dairy products (milk, cream, yogurt, cheese, ghee)
- Eggs (flax eggs, chia eggs, aquafaba)
- Binding agents
- Sweeteners (honey alternatives)

## Tips for Using Alternatives

1. **Start with Recommended Ratios**: Always begin with the suggested ratio and adjust to taste
2. **Consider Flavor Profiles**: Some alternatives may change the flavor slightly
3. **Test Small Batches**: When trying a new substitute, test it in a small batch first
4. **Texture Matters**: Some alternatives work better for specific cooking methods
5. **Read the Notes**: Pay attention to special instructions for best results

## Adding Custom Alternatives

Want to suggest a new ingredient alternative? Use the Contact or Feedback page to share your culinary knowledge!

## Technical Implementation

The ingredient alternatives system is powered by:
- **Database**: `/components/utils/recipeSearchHelpers.ts`
- **100+ Ingredients**: Comprehensive coverage of Indian and global cooking
- **Smart Matching**: Partial matching for ingredient names
- **Context-Aware**: Integrates with recipe context and conversation history

## Examples by Use Case

### Making a Recipe Vegan
- Butter → Coconut oil or vegan butter
- Cream → Cashew cream or coconut cream
- Paneer → Pressed tofu or chickpeas
- Yogurt → Coconut yogurt
- Ghee → Coconut oil
- Milk → Any plant-based milk

### Gluten-Free Cooking
- All-purpose flour → Rice flour or almond flour
- Wheat flour → Gluten-free flour blend
- Besan → Already gluten-free!

### Reducing Heat
- Red chili powder → Paprika
- Green chilies → Bell peppers
- Cayenne → Sweet paprika

### Healthy Substitutions
- Sugar → Jaggery or coconut sugar
- Cream → Greek yogurt
- Ghee → Olive oil or avocado oil
- White rice → Brown rice or quinoa

## Quick Reference Chart

| Original | Best Alternative | Ratio | Notes |
|----------|-----------------|-------|-------|
| Cornflour | Arrowroot powder | 1:1 | Best for clear sauces |
| Cream | Coconut cream | 1:1 | Vegan, slight coconut flavor |
| Paneer | Pressed tofu | 1:1 | Pan-fry for best texture |
| Turmeric | Curry powder | 1:1 | Contains turmeric + spices |
| Ghee | Coconut oil | 1:1 | High smoke point, vegan |
| Sugar | Jaggery | 1:1 | Richer flavor, traditional |
| Yogurt | Coconut yogurt | 1:1 | Vegan alternative |
| Eggs | Flax eggs | 1:1 | 1 tbsp flax + 3 tbsp water |

## Conclusion

With 100+ ingredient alternatives at your fingertips, Rasoi Mate makes it easy to:
- Cook with what you have on hand
- Accommodate dietary restrictions
- Make recipes vegan, gluten-free, or allergen-friendly
- Experiment with new flavors
- Learn about traditional substitutions

Just ask the AI assistant about any ingredient, and get instant, detailed substitution guidance!
