# 🤖 Rasoi Mate AI Integration Guide

## Overview

Rasoi Mate supports **Real AI Integration** with multiple providers. You can use your own API keys to get authentic AI-powered cooking assistance, or use the built-in demo mode for testing.

---

## 🚀 Supported AI Providers

### 1. **OpenAI (GPT-3.5 / GPT-4)**
- **Best For**: Professional cooking guidance, detailed recipes
- **Cost**: ~$0.002 per request (GPT-3.5)
- **Response Quality**: ⭐⭐⭐⭐⭐
- **Get API Key**: https://platform.openai.com/api-keys

### 2. **Google Gemini 1.5 Flash**
- **Best For**: Free usage, multilingual support, fast responses
- **Cost**: FREE (with quota limits)
- **Response Quality**: ⭐⭐⭐⭐⭐
- **Model**: gemini-1.5-flash
- **Get API Key**: https://makersuite.google.com/app/apikey

### 3. **Anthropic Claude**
- **Best For**: Detailed step-by-step instructions
- **Cost**: ~$0.003 per request (Claude Haiku)
- **Response Quality**: ⭐⭐⭐⭐⭐
- **Get API Key**: https://console.anthropic.com/settings/keys

---

## 📝 How to Set Up AI Integration

### Step 1: Enable Real AI Mode
1. Go to **AI Assistant** page
2. Check the **"Enable Real AI"** checkbox
3. Select your preferred AI provider from the dropdown

### Step 2: Add Your API Key
1. Click **"Get Key"** button to open the provider's website
2. Sign up / Log in to get your API key
3. Copy the API key
4. Paste it in the API Key field in Rasoi Mate

### Step 3: Start Chatting!
- Your API key is saved locally (secure)
- All conversations use your selected AI provider
- Voice commands work with real AI too!

---

## 🔑 Getting API Keys

### OpenAI API Key
```
1. Go to: https://platform.openai.com/api-keys
2. Sign up or log in
3. Click "Create new secret key"
4. Copy the key (starts with sk-...)
5. Paste in Rasoi Mate
```

**Cost**: Pay-as-you-go, typically $0.002 per 1K tokens (very cheap!)

### Google Gemini API Key
```
1. Go to: https://makersuite.google.com/app/apikey
2. Sign in with Google account
3. Click "Create API Key"
4. Copy the key (starts with AIza...)
5. Paste in Rasoi Mate
```

**Cost**: FREE! (60 requests per minute)

### Anthropic Claude API Key
```
1. Go to: https://console.anthropic.com/settings/keys
2. Sign up or log in
3. Click "Create Key"
4. Copy the key (starts with sk-ant-...)
5. Paste in Rasoi Mate
```

**Cost**: Pay-as-you-go, ~$0.003 per 1K tokens

---

## 💡 Which AI Provider Should I Choose?

### For **Free Usage**: 
→ **Google Gemini** (Best choice!)
- Completely free
- Excellent quality
- Good multilingual support

### For **Best Quality**: 
→ **OpenAI GPT-3.5** or **GPT-4**
- Industry-leading responses
- Very accurate cooking instructions
- Great at understanding context

### For **Detailed Instructions**: 
→ **Anthropic Claude**
- Excels at step-by-step guidance
- Very safe and helpful
- Great for beginners

---

## 🎯 Features with Real AI

When you enable real AI, you get:

✅ **Authentic Cooking Advice** - Real professional-quality responses  
✅ **Context Awareness** - AI remembers your conversation  
✅ **Custom Recipes** - Create new recipes on the fly  
✅ **Smart Substitutions** - Get instant ingredient alternatives  
✅ **Dietary Modifications** - Vegan, gluten-free, etc. conversions  
✅ **Troubleshooting** - Fix cooking mistakes in real-time  
✅ **Multilingual Support** - Works in Hindi, Tamil, Bengali, Marathi  

---

## 🔒 Security & Privacy

- ✅ API keys are stored **locally** in your browser
- ✅ Keys are **never sent to Rasoi Mate servers**
- ✅ Direct communication with AI providers only
- ✅ You control your API usage and costs
- ✅ No data is shared with third parties

---

## 🎭 Demo Mode (No API Key Needed)

Don't have an API key? No problem!

**Demo Mode** provides:
- Pre-programmed cooking responses
- Access to 20+ Indian recipes
- Ingredient scaling for servings
- Basic cooking tips
- Multilingual translations

Just uncheck "Enable Real AI" to use demo mode.

---

## 📊 API Usage & Costs

### Typical Costs (per conversation):
- **OpenAI GPT-3.5**: $0.001 - $0.01 per chat
- **Google Gemini**: FREE
- **Claude**: $0.001 - $0.015 per chat

### Tips to Save Money:
1. Use **Google Gemini** for free usage
2. Use **GPT-3.5** instead of GPT-4 (much cheaper)
3. Keep conversations focused
4. Use demo mode for simple queries

---

## ❓ Troubleshooting

### "API Key Invalid"
- Double-check you copied the entire key
- Make sure the key is active
- Verify you selected the correct provider

### "API Request Failed"
- Check your internet connection
- Verify you have API credits (OpenAI/Claude)
- Try demo mode as fallback

### "Quota Exceeded"
- Google Gemini: Wait a minute (60 req/min limit)
- OpenAI/Claude: Add credits to your account

### "No Response"
- Switch to demo mode temporarily
- Check browser console for errors
- Try a different AI provider

---

## 🌟 Pro Tips

1. **Save Your Key**: Rasoi Mate remembers your API key for next time
2. **Try Gemini First**: It's free and high quality!
3. **Use Voice Commands**: Works with real AI too
4. **Multi-language**: Ask in Hindi/Tamil, get responses in that language
5. **Context Matters**: Mention dietary restrictions upfront
6. **Be Specific**: "Paneer tikka for 6 people" vs "recipe"

---

## 🔄 Switching Providers

You can switch AI providers anytime:

1. Change the dropdown selection
2. Update the API key if needed
3. Continue your conversation

Each provider has slightly different response styles!

---

## 📞 Support

Having issues with AI integration?

- 📧 Email: sohamsingale775@gmail.com
- 💬 Use the Contact page in Rasoi Mate
- 🐛 Report bugs through the feedback form

---

## 🚀 Getting Started Checklist

- [ ] Go to AI Assistant page
- [ ] Enable Real AI mode
- [ ] Choose AI provider (Gemini recommended for free)
- [ ] Get API key from provider's website
- [ ] Paste API key in Rasoi Mate
- [ ] Start cooking with AI! 🍳

---

**Happy Cooking with AI! 👨‍🍳🤖**

*Last Updated: October 13, 2025*
