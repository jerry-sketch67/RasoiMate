// Auto-generated firebase initialization (Rasoi Mate)
// Replace values if you want to use environment variables for production.
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getAnalytics, isSupported as analyticsSupported } from 'firebase/analytics';
import { getMessaging, isSupported as messagingSupported } from 'firebase/messaging';

const firebaseConfig = {
  apiKey: "AIzaSyC30lF7elGNEQ5vQ29i8g5eBVVyJCO8thc",
  authDomain: "rasoi-mate.firebaseapp.com",
  projectId: "rasoi-mate",
  storageBucket: "rasoi-mate.appspot.com",
  messagingSenderId: "751007972735",
  appId: "1:751007972735:web:REPLACE_WITH_ACTUAL", // replace if you have it
  measurementId: "G-REPLACE_ME" // optional
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);

let analytics = null;
export async function getAnalyticsSafe() {
  if (analytics) return analytics;
  if (await analyticsSupported()) {
    analytics = getAnalytics(app);
    return analytics;
  }
  return null;
}

// Optional: messaging (FCM) if you enable later
export async function getMessagingSafe() {
  if (await messagingSupported()) {
    return getMessaging();
  }
  return null;
}

export default app;