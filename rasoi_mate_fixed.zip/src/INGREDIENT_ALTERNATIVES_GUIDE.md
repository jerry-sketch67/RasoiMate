# Ingredient Alternatives Feature Guide

## Overview
The Rasoi Mate AI Assistant now includes a comprehensive ingredient alternatives database with **100+ ingredients** across multiple categories. Users can ask for alternatives/substitutes for any culinary ingredient and receive detailed recommendations with ratios and descriptions.

## Features

### 🌟 Comprehensive Coverage
- **100+ ingredients** with detailed alternatives
- **10+ categories**: Flours & Starches, Dairy, Spices, Oils & Fats, Sweeteners, Acids, Proteins, Vegetables, Nuts & Seeds, Thickening Agents, Raising Agents, and Miscellaneous
- Each alternative includes:
  - Name of substitute
  - Conversion ratio (e.g., "1:1" or "¾ cup for 1 cup")
  - Description/notes about the substitute
  - Category classification

### 📋 Available Categories
1. **Flours & Starches**: Cornflour, All-Purpose Flour, Whole Wheat Flour, Rice Flour, Besan, Cornmeal
2. **Dairy**: Heavy Cream, Milk, Yogurt, Butter, Paneer, Ghee
3. **Spices**: Cumin, Coriander, Turmeric, Garam Masala, Red Chili Powder, Cardamom, Cinnamon, Mustard Seeds, Asafoetida, Fenugreek, Cloves, Bay Leaves, Curry Leaves, Black Pepper, Saffron, Paprika
4. **Oils & Fats**: Vegetable Oil, Olive Oil, Coconut Oil, Sesame Oil
5. **Sweeteners**: Sugar, Honey, Jaggery
6. **Acids**: Lemon Juice, Vinegar, Tamarind, Amchur
7. **Proteins**: Chicken, Eggs, Lentils
8. **Vegetables**: Onion, Garlic, Ginger, Tomato, Green Chili, Cilantro
9. **Nuts & Seeds**: Cashews, Almonds, Peanuts, Sesame Seeds
10. **Thickening Agents**: Agar Agar, Xanthan Gum
11. **Raising Agents**: Baking Powder, Baking Soda, Yeast
12. **Miscellaneous**: Coconut Milk, Chocolate, Cocoa Powder, Soy Sauce

## How to Use

### Query Patterns
Users can ask in multiple ways:
- "Alternative for cornflour"
- "Substitute for heavy cream"
- "Replace turmeric with what"
- "What to use instead of paneer"
- "Don't have butter, what else?"
- "Out of eggs, what can I use"
- "Replacement for ghee"

### Example Queries & Responses

#### Example 1: Cornflour
**User:** "Alternative for cornflour"

**AI Response:**
```
Great question! Here are the best alternatives for Cornflour (Flours & Starches):

1. **Arrowroot Powder** - Ratio: 1:1
   Best for clear sauces and glazes

2. **Potato Starch** - Ratio: 1:1
   Great thickening agent, gluten-free

3. **Tapioca Starch** - Ratio: 2 tsp for 1 tbsp
   Works well in baked goods

4. **Rice Flour** - Ratio: 2:1
   Use double the amount, gluten-free

5. **All-Purpose Flour** - Ratio: 2:1
   Use double the amount

6. **Wheat Flour** - Ratio: 2:1
   Common substitute but not gluten-free

💡 **Pro Tip:** Choose based on your dietary needs, availability, and the specific dish you're making!

Need alternatives for another ingredient? Just ask!
```

#### Example 2: Heavy Cream
**User:** "What can I use instead of heavy cream"

**AI Response:**
```
Great question! Here are the best alternatives for Heavy Cream (Dairy):

1. **Coconut Cream** - Ratio: 1:1
   Dairy-free, rich alternative

2. **Cashew Cream** - Ratio: 1:1
   Blend soaked cashews with water

3. **Greek Yogurt** - Ratio: 1:1
   Lower fat, tangy flavor

4. **Evaporated Milk** - Ratio: 1:1
   Thinner consistency

5. **Butter + Milk** - Ratio: ⅓ cup butter + ¾ cup milk
   For 1 cup cream

6. **Silken Tofu** - Ratio: Blend until smooth
   Vegan option

💡 **Pro Tip:** Choose based on your dietary needs, availability, and the specific dish you're making!

Need alternatives for another ingredient? Just ask!
```

## Implementation Details

### Files Modified
1. `/components/utils/recipeSearchHelpers.ts`
   - Added `IngredientAlternative` interface
   - Added `ingredientAlternativesDatabase` array with 100+ entries
   - Added helper functions:
     - `isIngredientAlternativeRequest()`: Detects ingredient alternative queries
     - `findIngredient()`: Fuzzy matching to find ingredient in database
     - `extractIngredientFromQuery()`: Extracts ingredient name from user query
     - `getIngredientAlternativesResponse()`: Formats response with alternatives
     - `getIngredientCategories()`: Returns list of available categories
     - `getIngredientsByCategory()`: Filters ingredients by category

2. `/components/AIAssistantPage.tsx`
   - Updated imports to include new helper functions
   - Added ingredient alternative handling logic (highest priority in query processing)
   - Added ingredient category listing feature
   - Updated welcome message to highlight ingredient alternatives

### Query Processing Priority
The AI Assistant processes queries in this order:
1. **Ingredient list request** (show available categories)
2. **Ingredient alternative request** ← NEW (highest priority)
3. Contextual alternative requests (recipe-based)
4. "What else" queries (category search)
5. Specific recipe requests
6. Recipe-specific questions
7. Default helpful response

### Search Algorithm
The ingredient search uses multi-level fuzzy matching:
1. **Exact match**: Ingredient name exactly matches query
2. **Search terms match**: Alternative names/spellings match (e.g., "maida" → "All-Purpose Flour")
3. **Partial ingredient match**: Ingredient name contains query or vice versa
4. **Partial search terms match**: Search terms partially match query

This ensures maximum flexibility in how users ask questions.

## Benefits

### For Users
- ✅ Instant access to ingredient alternatives
- ✅ Detailed ratios for accurate substitutions
- ✅ Descriptions to understand how substitutes work
- ✅ Multiple options for different dietary needs (vegan, gluten-free, etc.)
- ✅ Works for Indian and international ingredients

### For the Platform
- ✅ Enhanced AI assistant capabilities
- ✅ Reduces friction when users lack specific ingredients
- ✅ Supports dietary modifications and preferences
- ✅ Comprehensive database that can grow over time
- ✅ Natural language understanding for flexible queries

## Future Enhancements

### Potential Additions
1. **More ingredients**: Expand to 200+ ingredients
2. **Regional variations**: Include regional Indian names (e.g., "poha" → "flattened rice")
3. **Allergen filters**: Highlight nut-free, dairy-free options
4. **Taste profiles**: Add flavor impact notes
5. **Cost indicators**: Budget-friendly vs. premium alternatives
6. **Availability**: Common vs. specialty store items
7. **User contributions**: Allow users to suggest alternatives
8. **Recipe-specific recommendations**: Context-aware based on dish type

## Testing Suggestions

### Test Queries
Try these to verify the feature:
- "Alternative for cornflour"
- "What can I substitute for paneer"
- "Replace butter with what"
- "Don't have turmeric"
- "Egg substitutes"
- "Vegan alternative to ghee"
- "Gluten-free flour options"
- "List ingredient categories"
- "What ingredients do you have alternatives for"

### Edge Cases
- Misspellings: "cornflower" instead of "cornflour"
- Regional names: "maida", "atta", "besan"
- Plural forms: "eggs" vs "egg"
- Alternative phrasings: "instead of", "replacement for", "substitute"

## Technical Notes

### Data Structure
```typescript
interface IngredientAlternative {
  ingredient: string;           // Primary name
  alternatives: Array<{
    name: string;               // Alternative name
    ratio?: string;             // Conversion ratio
    description?: string;       // Usage notes
    category?: string;          // Sub-category (optional)
  }>;
  category: string;             // Main category
  searchTerms?: string[];       // Alternative names/spellings
}
```

### Performance
- Database is loaded in memory (minimal overhead)
- Search is O(n) but with early termination
- Response generation is instant
- No external API calls required

## Conclusion
This feature significantly enhances Rasoi Mate's value proposition by making it a comprehensive cooking assistant that helps users work around ingredient limitations. The natural language processing ensures users can ask questions in their own words, while the detailed responses provide professional-level guidance.
