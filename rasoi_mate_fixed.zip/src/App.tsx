import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './components/HomePage';
import { AIAssistantPage } from './components/AIAssistantPage';
import { RecipesPage } from './components/RecipesPage';
import { DrinksPage } from './components/DrinksPage';
import { VocalToLocalPage } from './components/VocalToLocalPage';
import { AboutPage } from './components/AboutPage';
import { ContactPage } from './components/ContactPage';
import { LoginPage } from './components/LoginPage';
import { SignupPage } from './components/SignupPage';
import { DashboardPage } from './components/DashboardPage';
import { DeveloperDashboardPage } from './components/DeveloperDashboardPage';
import { AdminPanelPage } from './components/AdminPanelPage';
import { PrivacyPolicyPage } from './components/PrivacyPolicyPage';
import { TermsOfServicePage } from './components/TermsOfServicePage';
import { HelpCenterPage } from './components/HelpCenterPage';
import { SettingsPage } from './components/SettingsPage';
import { Toaster } from './components/ui/sonner';
import { LanguageProvider } from './components/LanguageContext';
import { AuthProvider, useAuth } from './components/AuthContext';

// Main App Component wrapped in AuthProvider
function AppContent() {
  const { user, isLoggedIn, isDeveloper, logout } = useAuth();
  const [currentPage, setCurrentPage] = useState('home');
  const [darkMode, setDarkMode] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<any>(null);

  // Initialize Google Analytics
  useEffect(() => {
    // Add Google Analytics script
    const gtagScript = document.createElement('script');
    gtagScript.async = true;
    gtagScript.src = 'https://www.googletagmanager.com/gtag/js?id=G-EYR5YLXSLH';
    document.head.appendChild(gtagScript);

    // Add gtag configuration
    const gtagConfig = document.createElement('script');
    gtagConfig.innerHTML = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'G-EYR5YLXSLH');
    `;
    document.head.appendChild(gtagConfig);
  }, []);

  useEffect(() => {
    // Check for dark mode preference
    const isDark = localStorage.getItem('darkMode') === 'true';
    setDarkMode(isDark);
    if (isDark) {
      document.documentElement.classList.add('dark');
    }
  }, []);

  // Track page views
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'page_view', {
        page_title: currentPage,
        page_path: `/${currentPage}`,
      });
    }
  }, [currentPage]);

  const handleToggleDarkMode = () => {
    const newDarkMode = !darkMode;
    setDarkMode(newDarkMode);
    localStorage.setItem('darkMode', String(newDarkMode));
    
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleRecipeSelect = (recipe: any) => {
    setSelectedRecipe(recipe);
    setCurrentPage('ai-assistant');
  };

  const handleLogout = () => {
    logout();
    setCurrentPage('home');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={setCurrentPage} />;
      case 'ai-assistant':
        return <AIAssistantPage selectedRecipe={selectedRecipe} onClearRecipe={() => setSelectedRecipe(null)} />;
      case 'recipes':
        return <RecipesPage onRecipeSelect={handleRecipeSelect} />;
      case 'drinks':
        return <DrinksPage onNavigate={setCurrentPage} />;
      case 'vocal-to-local':
        return <VocalToLocalPage onNavigate={setCurrentPage} />;
      case 'about':
        return <AboutPage onNavigate={setCurrentPage} />;
      case 'contact':
        return <ContactPage onNavigate={setCurrentPage} />;
      case 'login':
        return <LoginPage onNavigate={setCurrentPage} />;
      case 'signup':
        return <SignupPage onNavigate={setCurrentPage} />;
      case 'dashboard':
        if (!isLoggedIn) return <LoginPage onNavigate={setCurrentPage} />;
        return <DashboardPage />;
      case 'admin-panel':
        if (!isLoggedIn || !isDeveloper) return <LoginPage onNavigate={setCurrentPage} />;
        return <AdminPanelPage />;
      case 'developer-dashboard':
        if (!isLoggedIn || !isDeveloper) return <LoginPage onNavigate={setCurrentPage} />;
        return <DeveloperDashboardPage />;
      case 'privacy':
        return <PrivacyPolicyPage onNavigate={setCurrentPage} />;
      case 'terms':
        return <TermsOfServicePage onNavigate={setCurrentPage} />;
      case 'help':
        return <HelpCenterPage onNavigate={setCurrentPage} />;
      case 'settings':
        return <SettingsPage onNavigate={setCurrentPage} darkMode={darkMode} onToggleDarkMode={handleToggleDarkMode} />;
      case 'privacy-policy':
        return <PrivacyPolicyPage onNavigate={setCurrentPage} />;
      case 'terms-of-service':
        return <TermsOfServicePage onNavigate={setCurrentPage} />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        darkMode={darkMode}
        onToggleDarkMode={handleToggleDarkMode}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
        isDeveloper={isDeveloper}
        user={user}
      />
      
      <main className="flex-1">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ 
            duration: 0.3,
            ease: 'easeInOut'
          }}
        >
          {renderPage()}
        </motion.div>
      </main>
      
      <Footer onNavigate={setCurrentPage} />
      <Toaster position="top-center" />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <AppContent />
      </LanguageProvider>
    </AuthProvider>
  );
}
