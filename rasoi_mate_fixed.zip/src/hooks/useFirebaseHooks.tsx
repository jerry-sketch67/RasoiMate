// Example React hooks to consume the Firestore listeners
import { useEffect, useState } from 'react';
import { listenSiteSettings, listenFeatureFlags, listenRecipes } from '../utils/firebaseHelpers';

export function useSiteSettings() {
  const [settings, setSettings] = useState(null);
  useEffect(() => {
    const unsub = listenSiteSettings(setSettings);
    return () => unsub();
  }, []);
  return settings;
}

export function useFeatureFlags() {
  const [flags, setFlags] = useState({});
  useEffect(() => {
    const unsub = listenFeatureFlags(setFlags);
    return () => unsub();
  }, []);
  return flags;
}

export function useLiveRecipes(limitCount=100) {
  const [recipes, setRecipes] = useState([]);
  useEffect(() => {
    const unsub = listenRecipes(setRecipes, limitCount);
    return () => unsub();
  }, [limitCount]);
  return recipes;
}