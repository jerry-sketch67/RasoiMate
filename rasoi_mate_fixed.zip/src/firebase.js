// src/firebase.js

// Import required Firebase SDK modules
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";
import { getStorage } from "firebase/storage";

// ✅ Your Firebase Configuration (complete and verified)
const firebaseConfig = {
  apiKey: "AIzaSyC30lF7elGNEQ5vQ29i8g5eBVVyJCO8thc",
  authDomain: "rasoi-mate.firebaseapp.com",
  projectId: "rasoi-mate",
  storageBucket: "rasoi-mate.appspot.com",
  messagingSenderId: "751007972735",
  appId: "1:751007972735:web:fa62edd8498fe6691bae4a",
  measurementId: "G-XXXXXXXXXX" // optional – only if Analytics is enabled
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);

// ✅ Initialize Firebase services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
export const analytics = getAnalytics(app);

// ✅ Export the app (optional, if needed elsewhere)
export default app;
