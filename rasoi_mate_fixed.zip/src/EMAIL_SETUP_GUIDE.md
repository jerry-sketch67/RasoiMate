# Email Setup Guide for Rasoi Mate

This guide will help you set up EmailJS to enable direct email sending from the contact form to sohamsingale775@gmail.com.

## What is EmailJS?

EmailJS is a free service that allows you to send emails directly from client-side JavaScript without needing a backend server. It's perfect for contact forms!

## Setup Instructions

### Step 1: Create an EmailJS Account

1. Go to [https://www.emailjs.com/](https://www.emailjs.com/)
2. Click "Sign Up" and create a free account
3. Verify your email address

### Step 2: Add an Email Service

1. Go to the **Email Services** page in your EmailJS dashboard
2. Click **"Add New Service"**
3. Choose **Gmail** (recommended)
4. Connect your Gmail account (sohamsingale775@gmail.com)
5. Give the service a name (e.g., "Rasoi Mate Gmail")
6. Copy the **Service ID** (something like `service_xxxxxxx`)

### Step 3: Create an Email Template

1. Go to the **Email Templates** page
2. Click **"Create New Template"**
3. Set up the template with these details:

**Template Name:** Rasoi Mate Contact Form

**Subject:**
```
[Rasoi Mate - {{category_label}}] {{subject}}
```

**Content (HTML):**
```html
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
  <div style="background: linear-gradient(135deg, #FF9933, #4CAF50); padding: 20px; text-align: center;">
    <h1 style="color: white; margin: 0;">Rasoi Mate Feedback</h1>
  </div>
  
  <div style="padding: 20px; background: #f5f5f5;">
    <h2 style="color: #3F51B5;">New {{category_label}} Submission</h2>
    
    <div style="background: white; padding: 15px; border-radius: 8px; margin: 10px 0;">
      <p><strong>From:</strong> {{from_name}}</p>
      <p><strong>Email:</strong> {{from_email}}</p>
      <p><strong>Category:</strong> {{category}}</p>
      <p><strong>Subject:</strong> {{subject}}</p>
    </div>
    
    <div style="background: white; padding: 15px; border-radius: 8px; margin: 10px 0;">
      <h3 style="color: #3F51B5; margin-top: 0;">Message:</h3>
      <p style="white-space: pre-wrap;">{{message}}</p>
    </div>
    
    <div style="margin-top: 20px; padding: 10px; background: #e8f5e9; border-radius: 8px; text-align: center;">
      <p style="margin: 0; color: #4CAF50;">Sent from Rasoi Mate Contact Form</p>
    </div>
  </div>
</div>
```

4. In the **Settings** tab:
   - Set **To Email** to `{{to_email}}` (this makes it dynamic based on category)
   - Or set it to a fixed email like `sohamsingale775@gmail.com`

5. **Save** the template
6. Copy the **Template ID** (something like `template_xxxxxxx`)

### Step 4: Get Your Public Key

1. Go to **Account** → **General**
2. Find your **Public Key** (something like `xxxxx-xxxxxxxxxx`)
3. Copy this key

### Step 5: Update the Code

Open `/components/ContactPage.tsx` and update these lines (around line 27-29):

```typescript
const EMAILJS_SERVICE_ID = 'service_xxxxxxx'; // Replace with your Service ID
const EMAILJS_TEMPLATE_ID = 'template_xxxxxxx'; // Replace with your Template ID
const EMAILJS_PUBLIC_KEY = 'xxxxx-xxxxxxxxxx'; // Replace with your Public Key
```

### Step 6: Configure Template Variables

Make sure your EmailJS template uses these variables:
- `{{from_name}}` - Sender's name
- `{{from_email}}` - Sender's email address
- `{{to_email}}` - Recipient email (dynamic based on category)
- `{{category}}` - Feedback category (general, bug, feature, etc.)
- `{{category_label}}` - Formatted category label
- `{{subject}}` - Email subject
- `{{message}}` - Message content

## Email Routing by Category

The system automatically routes emails to the appropriate person:

| Category | Recipient |
|----------|-----------|
| General Inquiry | sohamsingale775@gmail.com |
| Bug Report | sohamsingale775@gmail.com |
| Feature Request | sohamsingale775@gmail.com |
| Recipe Submission | jerry415721@gmail.com |
| Partnership | sohamsingale775@gmail.com |
| General Feedback | sohamsingale775@gmail.com |

## Free Tier Limits

EmailJS free tier includes:
- **200 emails per month**
- **2 email templates**
- **1 email service**

This should be sufficient for most contact form usage. If you need more, consider upgrading.

## Testing

1. After updating the credentials, refresh your Rasoi Mate website
2. Go to the Contact page
3. Fill out the form with test data
4. Submit the form
5. Check the email inbox (sohamsingale775@gmail.com or jerry415721@gmail.com depending on category)

## Troubleshooting

### Emails Not Sending
- Check that all three IDs (Service, Template, Public Key) are correct
- Verify your Gmail account is connected in EmailJS
- Check browser console for error messages
- Make sure you haven't exceeded the free tier limit (200/month)

### Wrong Recipient
- Verify the template is using `{{to_email}}` variable
- Check the category mapping in the code

### Template Not Found
- Make sure the Template ID matches exactly
- Template must be published (not in draft mode)

## Fallback Behavior

If EmailJS is not configured or fails:
- The system will automatically fall back to `mailto:` links
- This opens the user's default email client
- All feedback is still saved to localStorage for developer dashboard

## Security Notes

- Your EmailJS Public Key is safe to expose in client-side code
- Never expose your Secret Key (not used in this implementation)
- EmailJS has rate limiting to prevent abuse
- Consider adding reCAPTCHA if you experience spam

## Alternative: Using Mailto (Current Fallback)

If you prefer not to set up EmailJS, the current `mailto:` fallback works fine. Users will need to:
1. Have an email client configured on their device
2. Manually send the pre-filled email

However, EmailJS provides a much smoother user experience!

---

**Need Help?** Contact Soham at sohamsingale775@gmail.com
