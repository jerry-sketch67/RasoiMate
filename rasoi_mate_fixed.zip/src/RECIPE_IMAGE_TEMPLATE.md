# Recipe Image Template - Quick Reference

## How to Use This File

1. Copy the `individualRecipeImages` object below
2. Paste it into `/components/data/enhancedRecipeData.ts` at **line 41** (replacing the empty object)
3. Fill in your image URLs for each recipe
4. Save the file and changes will reflect immediately

---

## Template Code

Copy and paste this into `/components/data/enhancedRecipeData.ts` at line 41:

```typescript
// Individual Recipe Images - Add your custom recipe images here
const individualRecipeImages: Record<string, string> = {
  // ANDHRA PRADESH RECIPES
  'Royyala Iguru': '',  // Prawn curry
  'Pesarattu': '',  // Green gram dosa
  'Gongura Pachadi': '',  // Sorrel leaves chutney
  'Guntur Chicken': '',  // Spicy chicken
  'Hyderabadi Biryani': '',  // Famous biryani
  'Gongura Mutton': '',  // Mutton with sorrel leaves
  'Gutti Vankaya': '',  // Stuffed eggplant curry
  'Pulihora': '',  // Tamarind rice
  'Bommidala Pulusu': '',  // Fish curry
  'Pappu Charu': '',  // Dal soup
  
  // TAMIL NADU RECIPES
  'Chettinad Chicken': '',  // Spicy chicken curry
  'Madurai Kari Dosa': '',  // Mutton dosa
  'Pongal': '',  // Rice and lentil dish
  'Idli Sambar': '',  // Steamed cakes with lentil curry
  'Filter Coffee': '',  // South Indian coffee
  'Kozhukattai': '',  // Steamed dumplings
  'Rasam': '',  // Tangy soup
  'Murukku': '',  // Crunchy snack
  'Paniyaram': '',  // Savory balls
  'Vada': '',  // Fried lentil donuts
  
  // KERALA RECIPES
  'Malabar Parotta': '',  // Layered flatbread
  'Fish Moilee': '',  // Fish in coconut curry
  'Appam': '',  // Rice pancakes
  'Kerala Sadya': '',  // Feast platter
  'Puttu': '',  // Steamed rice cake
  'Karimeen Pollichathu': '',  // Pearl spot fish
  'Avial': '',  // Mixed vegetable curry
  'Olan': '',  // Ash gourd curry
  'Thoran': '',  // Stir-fried vegetables
  'Parippu Curry': '',  // Lentil curry
  
  // KARNATAKA RECIPES
  'Bisi Bele Bath': '',  // Spicy rice dish
  'Mysore Masala Dosa': '',  // Spicy dosa
  'Rava Idli': '',  // Semolina cakes
  'Dharwad Peda': '',  // Sweet delicacy
  'Jolada Rotti': '',  // Sorghum flatbread
  'Ragi Mudde': '',  // Finger millet balls
  'Neer Dosa': '',  // Thin rice crepes
  'Akki Rotti': '',  // Rice flatbread
  'Holige': '',  // Sweet flatbread
  'Mangalore Buns': '',  // Sweet fried bread
  
  // MAHARASHTRA RECIPES
  'Vada Pav': '',  // Potato fritter sandwich
  'Pav Bhaji': '',  // Mashed vegetables with bread
  'Misal Pav': '',  // Spicy sprouts curry
  'Puran Poli': '',  // Sweet flatbread
  'Modak': '',  // Sweet dumplings
  'Bhakri': '',  // Millet flatbread
  'Sabudana Khichdi': '',  // Tapioca dish
  'Zunka Bhakar': '',  // Chickpea flour curry
  'Kolhapuri Chicken': '',  // Spicy chicken
  'Bharli Vangi': '',  // Stuffed eggplant
  
  // GUJARAT RECIPES
  'Dhokla': '',  // Steamed savory cake
  'Khandvi': '',  // Rolled chickpea snack
  'Thepla': '',  // Spiced flatbread
  'Undhiyu': '',  // Mixed vegetable curry
  'Fafda': '',  // Crispy snack
  'Handvo': '',  // Savory rice cake
  'Khakhra': '',  // Crispy thin bread
  'Doodhpak': '',  // Rice pudding
  'Sev Tameta': '',  // Tomato curry
  'Mohanthal': '',  // Chickpea flour fudge
  
  // RAJASTHAN RECIPES
  'Dal Baati Churma': '',  // Lentils with baked bread balls
  'Laal Maas': '',  // Spicy red meat curry
  'Gatte ki Sabzi': '',  // Chickpea flour dumplings curry
  'Ker Sangri': '',  // Desert beans and berries
  'Pyaaz Kachori': '',  // Onion stuffed pastry
  'Mawa Kachori': '',  // Sweet stuffed pastry
  'Bajre ki Roti': '',  // Pearl millet bread
  'Kalakand': '',  // Milk sweet
  'Ghewar': '',  // Honeycomb sweet
  'Mirchi Vada': '',  // Chili fritters
  
  // PUNJAB RECIPES
  'Butter Chicken': '',  // Creamy tomato chicken curry
  'Sarson ka Saag': '',  // Mustard greens curry
  'Makki ki Roti': '',  // Corn flatbread
  'Chole Bhature': '',  // Chickpea curry with fried bread
  'Amritsari Kulcha': '',  // Stuffed bread
  'Lassi': '',  // Yogurt drink
  'Rajma Chawal': '',  // Kidney beans with rice
  'Paneer Tikka': '',  // Grilled cottage cheese
  'Aloo Paratha': '',  // Potato stuffed flatbread
  'Pindi Chole': '',  // Spicy chickpeas
  
  // WEST BENGAL RECIPES
  'Machher Jhol': '',  // Fish curry
  'Rasgulla': '',  // Sweet cheese balls
  'Mishti Doi': '',  // Sweet yogurt
  'Shukto': '',  // Mixed vegetable curry
  'Kosha Mangsho': '',  // Slow-cooked mutton
  'Chingri Malai Curry': '',  // Prawn coconut curry
  'Luchi': '',  // Fried flatbread
  'Alur Dom': '',  // Potato curry
  'Sandesh': '',  // Cheese sweet
  'Rosogolla': '',  // Spongy sweet balls
  
  // ODISHA RECIPES
  'Dalma': '',  // Lentils with vegetables
  'Pakhala Bhata': '',  // Fermented rice
  'Chhena Poda': '',  // Baked cheese cake
  'Chingudi Jhola': '',  // Prawn curry
  'Dahi Bara Aloo Dum': '',  // Lentil dumplings with potato
  'Santula': '',  // Mixed vegetable stew
  'Rasabali': '',  // Fried cheese patties in syrup
  'Kheer': '',  // Rice pudding
  'Enduri Pitha': '',  // Turmeric leaf wrapped cake
  'Bara Ghuguni': '',  // Lentil fritters with peas
  
  // ASSAM RECIPES
  'Masor Tenga': '',  // Sour fish curry
  'Khaar': '',  // Alkaline vegetable dish
  'Pitha': '',  // Rice cakes
  'Duck Curry': '',  // Traditional duck curry
  'Aloo Pitika': '',  // Mashed potato
  'Paror Mangxo': '',  // Pigeon curry
  'Ou Tenga': '',  // Elephant apple curry
  'Narikol Laru': '',  // Coconut balls
  'Til Pitha': '',  // Sesame rice cakes
  'Xaak Bhaji': '',  // Leafy greens stir-fry
  
  // BIHAR RECIPES
  'Litti Chokha': '',  // Roasted wheat balls with mashed vegetables
  'Sattu Paratha': '',  // Roasted gram flour flatbread
  'Champaran Meat': '',  // Mutton curry
  'Thekua': '',  // Sweet fried snack
  'Khaja': '',  // Layered sweet
  'Chandrakala': '',  // Sweet pastry
  'Pua': '',  // Sweet pancakes
  'Dal Pitha': '',  // Lentil dumplings
  'Ghugni': '',  // Dried pea curry
  'Tilkut': '',  // Sesame sweet
  
  // GOA RECIPES
  'Fish Curry': '',  // Goan fish curry
  'Vindaloo': '',  // Spicy pork curry
  'Xacuti': '',  // Complex spice curry
  'Cafreal': '',  // Green herb chicken
  'Bebinca': '',  // Layered dessert
  'Sorpotel': '',  // Pork curry
  'Sanna': '',  // Rice cakes
  'Recheado Masala': '',  // Spice-stuffed fish
  'Balchao': '',  // Spicy prawn pickle
  'Feijoada': '',  // Bean stew
  
  // HIMACHAL PRADESH RECIPES
  'Dham': '',  // Festive platter
  'Sidu': '',  // Steamed bread
  'Chha Gosht': '',  // Lamb curry
  'Madra': '',  // Chickpea curry
  'Tudkiya Bhath': '',  // Pulao
  'Aktori': '',  // Buckwheat cake
  'Babru': '',  // Stuffed bread
  'Patande': '',  // Pancakes
  'Channa Madra': '',  // Chickpea curry
  'Khatta': '',  // Sour curry
  
  // JAMMU & KASHMIR RECIPES
  'Rogan Josh': '',  // Aromatic mutton curry
  'Yakhni': '',  // Yogurt-based curry
  'Dum Aloo': '',  // Potato curry
  'Gushtaba': '',  // Meatball curry
  'Modur Pulao': '',  // Sweet rice
  'Kahwa': '',  // Traditional tea
  'Tabak Maaz': '',  // Fried ribs
  'Nadru Yakhni': '',  // Lotus stem curry
  'Haakh': '',  // Collard greens
  'Sheermal': '',  // Sweet saffron bread
  
  // UTTARAKHAND RECIPES
  'Kafuli': '',  // Spinach curry
  'Bhatt ki Churkani': '',  // Black soybean curry
  'Aloo ke Gutke': '',  // Spiced potatoes
  'Jhangora Kheer': '',  // Barnyard millet pudding
  'Chainsoo': '',  // Black gram dal
  'Dubuk': '',  // Lentil fritters in curry
  'Gahat Dal': '',  // Horse gram lentils
  'Baadi': '',  // Spiced ball curry
  'Kandalee Ka Saag': '',  // Himalayan nettle greens
  'Singal': '',  // Layered bread
  
  // UTTAR PRADESH RECIPES
  'Lucknowi Biryani': '',  // Awadhi biryani
  'Tunday Kabab': '',  // Minced meat kabab
  'Kakori Kabab': '',  // Soft seekh kabab
  'Galawati Kabab': '',  // Melt-in-mouth kabab
  'Nihari': '',  // Slow-cooked stew
  'Sheermal': '',  // Saffron flatbread
  'Petha': '',  // Ash gourd sweet
  'Kulfi Falooda': '',  // Ice cream with noodles
  'Bedmi Puri': '',  // Lentil stuffed bread
  'Malaiyo': '',  // Milk foam dessert
  
  // MADHYA PRADESH RECIPES
  'Bhutte ka Kees': '',  // Grated corn dish
  'Poha Jalebi': '',  // Flattened rice with sweet
  'Dal Bafla': '',  // Wheat balls with lentils
  'Mawa Bati': '',  // Milk sweet
  'Sabudana Khichdi': '',  // Tapioca pearls
  'Biryani': '',  // Spiced rice
  'Chakki ki Shaak': '',  // Colocasia leaves curry
  'Bhopali Gosht Korma': '',  // Mutton korma
  'Kusli': '',  // Wheat flour rolls
  'Lavang Lata': '',  // Sweet pastry
  
  // CHHATTISGARH RECIPES
  'Chila': '',  // Rice flour pancake
  'Farra': '',  // Steamed rice rolls
  'Dubki Kadhi': '',  // Fried lentil curry
  'Aamat': '',  // Mixed vegetable curry
  'Muthiya': '',  // Steamed dumplings
  'Angakar Roti': '',  // Coal-roasted bread
  'Petha': '',  // Pumpkin sweet
  'Til Barfi': '',  // Sesame sweet
  'Bafauri': '',  // Steamed lentil cakes
  'Dehrori': '',  // Lentil fritters
  
  // JHARKHAND RECIPES
  'Dhuska': '',  // Rice pancake
  'Chilka Roti': '',  // Rice flatbread
  'Rugra': '',  // Mushroom curry
  'Pitha': '',  // Rice cakes
  'Bamboo Shoot Curry': '',  // Tribal delicacy
  'Thekua': '',  // Sweet snack
  'Arsa': '',  // Rice sweet
  'Litti': '',  // Wheat balls
  'Paneer Jalebi': '',  // Cheese sweet
  'Handia': '',  // Rice beer
  
  // TELANGANA RECIPES
  'Hyderabadi Haleem': '',  // Meat and wheat stew
  'Mirchi ka Salan': '',  // Chili curry
  'Double ka Meetha': '',  // Bread pudding
  'Irani Chai': '',  // Special tea
  'Osmania Biscuit': '',  // Savory biscuits
  'Qubani ka Meetha': '',  // Apricot dessert
  'Sheer Khurma': '',  // Vermicelli pudding
  'Pathar ka Gosht': '',  // Stone-cooked meat
  'Bagara Baingan': '',  // Eggplant curry
  'Khatti Dal': '',  // Sour lentils
  
  // MEGHALAYA RECIPES
  'Jadoh': '',  // Rice and meat
  'Tungrymbai': '',  // Fermented soybean
  'Dohneiiong': '',  // Pork with black sesame
  'Pumaloi': '',  // Sticky rice
  'Nakham Bitchi': '',  // Dried fish chutney
  'Minil Songa': '',  // Rice cake
  'Ki Kpu': '',  // Rice flour pancake
  'Pukhlein': '',  // Deep-fried rice cake
  'Jhur Sideh': '',  // Salad
  'Kyat': '',  // Rice beer
  
  // MANIPUR RECIPES
  'Eromba': '',  // Mashed vegetable curry
  'Singju': '',  // Vegetable salad
  'Kangshoi': '',  // Vegetable stew
  'Chamthong': '',  // Vegetable soup
  'Nga Thongba': '',  // Fish curry
  'Paaknam': '',  // Vegetable fritters
  'Chak-hao Kheer': '',  // Black rice pudding
  'Kanghou': '',  // Stir-fried vegetables
  'Alu Kangmet': '',  // Potato curry
  'Morok Metpa': '',  // Chili chutney
  
  // MIZORAM RECIPES
  'Bai': '',  // Vegetable stew
  'Vawksa Rep': '',  // Smoked pork
  'Sawhchiar': '',  // Rice with vegetables
  'Koat Pitha': '',  // Banana fritters
  'Misa Mach Poora': '',  // Grilled fish
  'Panch Phoran Tarkari': '',  // Five spice vegetable
  'Chhum Han': '',  // Steamed vegetables
  'Zu': '',  // Rice beer
  'Arsa Buhchiar': '',  // Rice sweet
  'Hmarcha Rawt': '',  // Chili chutney
  
  // NAGALAND RECIPES
  'Smoked Pork': '',  // Pork with bamboo shoot
  'Axone': '',  // Fermented soybean
  'Anishi': '',  // Colocasia curry
  'Fish with Bamboo': '',  // Fish curry
  'Samathu': '',  // Mixed vegetable curry
  'Galho': '',  // Rice and vegetable porridge
  'Akini Chokibo': '',  // Snail curry
  'Zutho': '',  // Rice beer
  'Hinkejvu': '',  // Colocasia leaf curry
  'Bean with Pork': '',  // Bean and pork stew
  
  // TRIPURA RECIPES
  'Mui Borok': '',  // Bamboo shoot curry
  'Gudok': '',  // Mixed vegetables
  'Chakhwi': '',  // Bamboo shoot stew
  'Wahan Mosdeng': '',  // Pork with vegetables
  'Bangui Rice': '',  // Special rice
  'Berma': '',  // Dried fish chutney
  'Panch Phoron Tarka': '',  // Five spice curry
  'Chakhao Kheer': '',  // Black rice pudding
  'Kosoi Bwtwi': '',  // Chicken curry
  'Muya Awandru': '',  // Fermented fish
  
  // SIKKIM RECIPES
  'Thukpa': '',  // Noodle soup
  'Momos': '',  // Dumplings
  'Gundruk': '',  // Fermented leafy greens
  'Sinki': '',  // Fermented radish
  'Phagshapa': '',  // Pork with radish
  'Sha Phaley': '',  // Fried meat bread
  'Sael Roti': '',  // Sweet fried bread
  'Chhurpi': '',  // Cheese
  'Kinema': '',  // Fermented soybean
  'Thenthuk': '',  // Hand-pulled noodle soup
  
  // ARUNACHAL PRADESH RECIPES
  'Thukpa': '',  // Noodle soup
  'Momos': '',  // Steamed dumplings
  'Apong': '',  // Rice beer
  'Pika Pila': '',  // Bamboo shoot pickle
  'Lukter': '',  // Meat cooked in blood
  'Pehak': '',  // Fermented fish
  'Marua': '',  // Millet
  'Ngatok': '',  // Smoked meat
  'Chura Sabji': '',  // Cheese curry
  'Zan': '',  // Millet porridge
  
  // ANDAMAN & NICOBAR RECIPES
  'Fish Curry': '',  // Coastal fish curry
  'Coconut Prawn': '',  // Prawn in coconut
  'Crab Curry': '',  // Spiced crab
  'Lobster Thermidor': '',  // Baked lobster
  'Grilled Barracuda': '',  // Grilled fish
  'Sea Bass': '',  // Fish preparation
  'Octopus Curry': '',  // Seafood curry
  'Squid Fry': '',  // Fried squid
  'Fish Amritsari': '',  // Fish fry
  'Coconut Rice': '',  // Rice with coconut
  
  // DADRA & NAGAR HAVELI / DAMAN & DIU RECIPES
  'Sol Kadhi': '',  // Kokum drink
  'Fish Curry': '',  // Coastal fish curry
  'Prawn Balchao': '',  // Spicy prawn pickle
  'Chicken Cafreal': '',  // Green masala chicken
  'Bebinca': '',  // Layered dessert
  'Fish Recheado': '',  // Stuffed fish
  'Sorpotel': '',  // Spicy pork curry
  'Pork Vindaloo': '',  // Goan pork curry
  'Xacuti': '',  // Spicy curry
  'Feni': '',  // Local spirit
  
  // LAKSHADWEEP RECIPES
  'Fish Curry': '',  // Island fish curry
  'Tuna Curry': '',  // Tuna preparation
  'Octopus Fry': '',  // Fried octopus
  'Coconut Fish': '',  // Fish in coconut
  'Mas Huni': '',  // Tuna salad
  'Reef Fish': '',  // Fresh reef fish
  'Lobster Curry': '',  // Spiced lobster
  'Coconut Pudding': '',  // Sweet dessert
  'Mas Riha': '',  // Fish curry
  'Bis Keemiya': '',  // Pastry
  
  // PUDUCHERRY RECIPES
  'Fish Curry': '',  // French-Indian fusion
  'Creole Curry': '',  // Mixed curry
  'Croissant Pudding': '',  // Bread pudding
  'Boudin': '',  // Sausage
  'Prawn Masala': '',  // Spiced prawns
  'French Toast': '',  // Egg bread
  'Crab Masala': '',  // Spiced crab
  'Meen Kuzhambu': '',  // Tamil fish curry
  'Poriyal': '',  // Vegetable stir-fry
  'Idiyappam': '',  // String hoppers
  
  // CHANDIGARH RECIPES (Similar to Punjab)
  'Butter Chicken': '',
  'Chole Bhature': '',
  'Rajma': '',
  'Paneer Tikka': '',
  'Amritsari Fish': '',
  'Kulcha': '',
  'Paratha': '',
  'Lassi': '',
  'Aloo Gobi': '',
  'Kadhi Pakora': '',
  
  // DELHI RECIPES
  'Chole Bhature': '',  // Chickpea curry with bread
  'Butter Chicken': '',  // Creamy tomato chicken
  'Paranthe Wali Gali': '',  // Various parathas
  'Street Chaat': '',  // Street food
  'Kebabs': '',  // Grilled meat
  'Biryani': '',  // Mughlai rice
  'Nihari': '',  // Slow-cooked stew
  'Kulfi': '',  // Ice cream
  'Jalebi': '',  // Sweet spiral
  'Dahi Bhalla': '',  // Lentil dumplings in yogurt
};
```

---

## Quick Fill Instructions

1. **Find images on Unsplash:**
   - Go to unsplash.com
   - Search for the dish name (e.g., "butter chicken", "biryani")
   - Copy the image URL

2. **Format the URL:**
   - Use this format: `https://images.unsplash.com/photo-XXXXX?w=1080&q=80`

3. **Paste into template:**
   ```typescript
   'Butter Chicken': 'https://images.unsplash.com/photo-XXXXX?w=1080&q=80',
   ```

4. **Save and test:**
   - Save the file
   - Go to Vocal to Local page
   - Check if images appear correctly

---

## Priority Recipes (Most Popular)

If you want to start with the most popular recipes, focus on these first:

1. Hyderabadi Biryani
2. Butter Chicken
3. Chole Bhature
4. Masala Dosa
5. Fish Curry (various states)
6. Rogan Josh
7. Dal Baati Churma
8. Vada Pav
9. Dhokla
10. Momos

---

## Need Help?

If you need help finding specific images or bulk uploading, let me know which state/region you want to focus on first!
