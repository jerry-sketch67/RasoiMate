# Recipe Image Guide - Vocal to Local

## How to Add Individual Images to Each Recipe

### Location
All recipe images are managed in: **`/components/data/enhancedRecipeData.ts`**

### Method 1: Add Individual Image to Specific Recipe

Find your recipe in the `recipeDatabase` object and add/edit the `image` property:

```typescript
'Recipe Name': {
  name: 'Recipe Name',
  type: 'Curry',
  description: 'Description here',
  image: 'YOUR_IMAGE_URL_HERE',  // ← Add your image URL here
  ingredients: [...],
  steps: [...],
  // ... other properties
}
```

### Method 2: Bulk Image Mapping (Recommended)

Create a mapping object at the top of the file for easier management:

```typescript
// Individual Recipe Images - Add your custom images here
const individualRecipeImages: Record<string, string> = {
  'Royyala Iguru': 'https://your-image-url.com/royyala-iguru.jpg',
  'Pesarattu': 'https://your-image-url.com/pesarattu.jpg',
  'Gongura Pachadi': 'https://your-image-url.com/gongura-pachadi.jpg',
  'Guntur Chicken': 'https://your-image-url.com/guntur-chicken.jpg',
  'Hyderabadi Biryani': 'https://your-image-url.com/biryani.jpg',
  // Add more recipes here...
};
```

Then reference it in your recipes:

```typescript
'Royyala Iguru': {
  name: 'Royyala Iguru',
  image: individualRecipeImages['Royyala Iguru'] || recipeImages.seafood,
  // ... other properties
}
```

### Image URL Sources

#### Option 1: Unsplash (Free, High Quality)
```
https://images.unsplash.com/photo-PHOTO_ID?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080
```

#### Option 2: Your Own Server/CDN
```
https://your-domain.com/images/recipes/recipe-name.jpg
```

#### Option 3: Public Image Hosting
- Imgur: `https://i.imgur.com/IMAGE_ID.jpg`
- Cloudinary: `https://res.cloudinary.com/YOUR_CLOUD/image/upload/v1234567/recipe.jpg`

### Example: Complete Recipe with Custom Image

```typescript
'Butter Chicken': {
  name: 'Butter Chicken',
  type: 'Curry',
  description: 'Creamy tomato-based chicken curry',
  time: '45 mins',
  servings: '4 people',
  difficulty: 'Medium',
  image: 'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398',
  ingredients: [
    '500g chicken',
    '200ml cream',
    // ... more ingredients
  ],
  steps: [
    'Marinate chicken...',
    // ... more steps
  ],
}
```

### Quick Recipe List Template

Here's a template to help you organize your images:

```typescript
// RECIPE IMAGE MAPPING - Copy this and fill in your URLs
const individualRecipeImages = {
  // Andhra Pradesh
  'Royyala Iguru': '',
  'Pesarattu': '',
  'Gongura Pachadi': '',
  'Guntur Chicken': '',
  
  // Tamil Nadu
  'Chettinad Chicken': '',
  'Madurai Kari Dosa': '',
  'Pongal': '',
  
  // Kerala
  'Malabar Parotta': '',
  'Fish Moilee': '',
  'Appam': '',
  
  // Karnataka
  'Bisi Bele Bath': '',
  'Mysore Masala Dosa': '',
  
  // Add more as needed...
};
```

### Tips

1. **Image Requirements:**
   - Minimum size: 800x600 pixels
   - Recommended: 1080x720 pixels
   - Format: JPG, PNG, or WebP
   - File size: Keep under 500KB for fast loading

2. **Image Quality:**
   - Use well-lit, appetizing food photography
   - Show the finished dish clearly
   - Prefer authentic presentations

3. **Fallback System:**
   - If no individual image is set, it will use category images
   - Category images are defined in `recipeImages` object (lines 27-38)

4. **Batch Processing:**
   - Process images in batches by state/region
   - Keep a spreadsheet with Recipe Name → Image URL mapping
   - Use find-and-replace to update multiple recipes at once

### Need Help Finding Images?

**Free Image Sources:**
- Unsplash.com - Search for Indian dishes
- Pexels.com - Food photography
- Pixabay.com - Free food images

**Search Tips:**
- Search by recipe name + "food"
- Try regional variations: "South Indian food", "Bengali cuisine"
- Be specific: "Hyderabadi biryani" vs just "biryani"

### Example: Full Implementation

```typescript
// At the top of enhancedRecipeData.ts (after recipeImages)

const individualRecipeImages: Record<string, string> = {
  'Royyala Iguru': 'https://images.unsplash.com/photo-1633945274605-664e21a6c0b9',
  'Pesarattu': 'https://images.unsplash.com/photo-1668236543090-82eba5ee5976',
  'Hyderabadi Biryani': 'https://images.unsplash.com/photo-1589302168068-964664d93dc0',
  // ... add all your recipes
};

// Helper function to get recipe image
const getRecipeImage = (recipeName: string, type: string): string => {
  // First try individual image
  if (individualRecipeImages[recipeName]) {
    return individualRecipeImages[recipeName];
  }
  
  // Fall back to category image
  const typeKey = type.toLowerCase();
  if (typeKey.includes('curry')) return recipeImages.curry;
  if (typeKey.includes('breakfast')) return recipeImages.breakfast;
  if (typeKey.includes('biryani')) return recipeImages.biryani;
  if (typeKey.includes('snack')) return recipeImages.snack;
  if (typeKey.includes('tandoori')) return recipeImages.tandoori;
  if (typeKey.includes('thali')) return recipeImages.thali;
  if (typeKey.includes('sweet')) return recipeImages.sweet;
  if (typeKey.includes('chutney')) return recipeImages.chutney;
  if (typeKey.includes('seafood') || typeKey.includes('fish')) return recipeImages.seafood;
  if (typeKey.includes('dal') || typeKey.includes('lentil')) return recipeImages.dal;
  
  // Default fallback
  return recipeImages.curry;
};

// Then in your recipes:
'Royyala Iguru': {
  name: 'Royyala Iguru',
  type: 'Curry',
  image: getRecipeImage('Royyala Iguru', 'Curry'),
  // ... rest of recipe
}
```

---

## Current Recipe Count

The Vocal to Local section contains **1000+ recipes** across all Indian states and union territories.

## Quick Start

1. Open `/components/data/enhancedRecipeData.ts`
2. Find the recipe you want to update (use Ctrl+F)
3. Add or edit the `image: 'YOUR_URL'` line
4. Save and the changes will reflect immediately

## Need Bulk Updates?

If you want to update many recipes at once, you can:
1. Create a CSV/spreadsheet with Recipe Name and Image URL columns
2. Use find-replace to batch update
3. Or provide me the list and I'll help update them programmatically
