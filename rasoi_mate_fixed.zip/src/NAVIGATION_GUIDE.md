# Rasoi Mate - Complete Navigation Guide

## 🎯 Navigation Overview

All pages in the Rasoi Mate application are fully connected with smooth transitions and intuitive navigation patterns.

---

## 📱 Main Navigation Structure

### **Header Navigation (Available on all pages)**
The header provides consistent navigation across the entire application:

#### Desktop Navigation:
- **Home** → Main landing page
- **AI Assistant** → Voice & text-based cooking assistant
- **Recipes** → Browse 500+ recipes
- **Smart Diet** → Personalized meal planning and restaurant recipes
- **Vocal to Local** → Regional recipes from all Indian states
- **About** → Learn about Rasoi Mate
- **Contact** → Feedback, bug reports, and feature requests

#### User Actions (Desktop):
- **Login** → Navigate to login page (when not logged in)
- **Signup** → Navigate to signup page (when not logged in)
- **Dashboard** → User dashboard (when logged in)
- **Admin Panel** → Developer/Admin panel (when logged in as developer)
- **Logout** → Sign out and return to home

#### Mobile Navigation:
- **Hamburger Menu** → Opens with slide animation
- All desktop navigation items
- Language selector
- Same user action buttons
- Smooth close animation

---

## 🔐 Authentication Flow

### **Login Page** (`/login`)
- **Purpose**: User authentication
- **Navigation After Success**: → Dashboard
- **Alternative Actions**:
  - "Don't have an account?" → Signup Page
  - "Forgot Password?" → Password recovery
  - Click logo → Home

### **Signup Page** (`/signup`)
- **Purpose**: New user registration
- **Navigation After Success**: → Dashboard
- **Alternative Actions**:
  - "Already have an account?" → Login Page
  - Click logo → Home

### **Dashboard** (`/dashboard`)
- **Access**: Requires login
- **Protected Route**: Redirects to Login if not authenticated
- **Features**:
  - User profile
  - Saved recipes
  - Cooking history
  - Settings
- **Navigation**: Header links to all main pages

---

## 🏠 Page-Specific Navigation

### **Home Page** (`/home`)
- **Main Entry Point**: Default landing page
- **Quick Actions**:
  - "Explore Recipes" → Recipes Page
  - "Start Cooking" → AI Assistant Page
  - "Learn More" → About Page
  - Feature cards → Respective pages

### **AI Assistant Page** (`/ai-assistant`)
- **Features**:
  - Voice commands
  - Text chat
  - Recipe recommendations
- **Back Navigation**: Header or logo → Home

### **Recipes Page** (`/recipes`)
- **Features**:
  - Search and filter recipes
  - Click recipe → Recipe detail dialog
  - "Cook with AI" → AI Assistant with selected recipe
- **Newly Added Section**: Shows 5 latest recipes with unique images
- **Back Navigation**: Header or logo → Home

### **Smart Diet Companion** (`/smart-diet`)
- **Access**: Requires login for full features
- **Features**:
  - Restaurant recipes (1000+ recipes)
  - Meal planning
  - Nutritional information
- **Back Navigation**: Header or logo → Home

### **Vocal to Local** (`/vocal-to-local`)
- **Features**:
  - 37 Indian states/territories
  - 1000+ regional recipes
  - District-wise filtering
  - Voice narration
- **Back Navigation**: Header or logo → Home

### **About Page** (`/about`)
- **Back Button**: "← Back to Home" (top left)
- **Content**: Company story, values, timeline
- **Navigation**: Header links available

### **Contact Page** (`/contact`)
- **Back Button**: "← Back to Home" (top left)
- **Features**:
  - General inquiries
  - Bug reports
  - Feature requests
  - Recipe submissions
- **Navigation**: Header links available

### **Privacy Policy** (`/privacy`)
- **Back Button**: "← Back to Home" (top left)
- **Access**: Via Footer or direct link
- **Navigation**: Header links available

### **Terms of Service** (`/terms`)
- **Back Button**: "← Back to Home" (top left)
- **Access**: Via Footer or direct link
- **Navigation**: Header links available

### **Help Center** (`/help`)
- **Back Button**: Integrated in page
- **Features**:
  - FAQ sections
  - Video tutorials
  - Search functionality
- **Navigation**: Header links available

---

## 🎨 Animation & Transitions

### **Page Transitions**
All page changes feature smooth animations:
```javascript
- Fade in/out: opacity 0 → 1
- Slide: x: 20 → 0 (entering) | 0 → -20 (exiting)
- Duration: 0.3s
- Easing: ease-in-out
```

### **Mobile Menu Animation**
```javascript
- Opening: opacity 0, height 0 → opacity 1, height auto
- Closing: Reverse animation
- Auto-closes on navigation selection
```

### **Hover Effects**
- Navigation buttons: Smooth color transition
- Cards: Lift effect with shadow
- Buttons: Scale and color change

---

## 🔄 Navigation Patterns

### **Primary Navigation**
1. **Header**: Always visible (sticky)
2. **Logo Click**: Returns to Home from any page
3. **Active State**: Current page highlighted in header

### **Secondary Navigation**
1. **Back Buttons**: Available on secondary pages
2. **Footer Links**: Quick access to legal pages
3. **Breadcrumbs**: On complex flows (Dashboard, Admin Panel)

### **Protected Routes**
Pages requiring authentication automatically redirect:
- Dashboard → Login (if not authenticated)
- Admin Panel → Login (if not developer)
- Smart Diet (full features) → Login

---

## 📱 Responsive Navigation

### **Desktop (>768px)**
- Full header with all navigation items
- Language selector visible
- User menu with profile
- No hamburger menu

### **Mobile (<768px)**
- Hamburger menu icon
- Collapsible navigation drawer
- Touch-optimized buttons
- Slide-in animation
- Mobile-optimized language selector

---

## ⚡ Quick Access Features

### **Global Features (Available Everywhere)**
1. **Dark Mode Toggle**: Top right corner
2. **Language Selector**: 8 Indian languages
3. **Search**: On Recipes and Vocal to Local pages
4. **Voice Input**: AI Assistant and Recipes pages

### **Keyboard Shortcuts** (Future Enhancement)
- `Ctrl/Cmd + K`: Quick search
- `Ctrl/Cmd + H`: Home
- `Ctrl/Cmd + /`: Help Center
- `Esc`: Close dialogs/modals

---

## 🛡️ Developer Navigation

### **Admin Panel** (`/admin-panel`)
- **Access**: Developer accounts only
- **Sections**:
  - Dashboard → System overview
  - Recipe Manager → CRUD operations
  - Newly Added Recipes → Featured recipes management
  - User Management → User administration
  - Feature Toggles → Enable/disable features
  - Settings → Site configuration
  - System Logs → Activity monitoring
  - Analytics → Usage statistics

### **Developer Dashboard** (`/developer-dashboard`)
- **Access**: Developer accounts only
- **Features**: Advanced system controls

---

## 🎯 User Journey Examples

### **New User Journey**
1. Land on **Home** page
2. Click "Sign Up" → **Signup** page
3. Create account → **Dashboard**
4. Explore features via header navigation

### **Recipe Discovery Journey**
1. **Home** → Click "Explore Recipes"
2. **Recipes** page → Browse/Search
3. Click recipe → Recipe Detail Dialog
4. "Cook with AI" → **AI Assistant** with recipe loaded

### **Regional Cooking Journey**
1. **Home** → Click "Vocal to Local"
2. **Vocal to Local** → Select state
3. Select district → View regional recipes
4. Click recipe → Recipe details with voice narration

### **Feedback Journey**
1. Any page → Click "Contact" in header
2. **Contact** page → Select feedback type
3. Fill form → Submit
4. Confirmation → Back to Home or previous page

---

## ✨ Animation Features

### **Smart Animate Effects**
- **Page transitions**: Fade + slide
- **Card appearances**: Staggered animation
- **Button interactions**: Scale + color
- **Mobile menu**: Slide from right
- **Modals**: Fade in with scale

### **Loading States**
- Skeleton loaders for content
- Spinner for form submissions
- Progress indicators for multi-step flows

---

## 🔧 Technical Implementation

### **Routing System**
```typescript
// Centralized navigation state
const [currentPage, setCurrentPage] = useState('home');

// Navigation handler
const onNavigate = (page: string) => {
  setCurrentPage(page);
  // Smooth scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
};
```

### **Protected Routes**
```typescript
// Auto-redirect if not authenticated
if (!isLoggedIn) {
  return <LoginPage onNavigate={setCurrentPage} />;
}
```

### **Animation Implementation**
```typescript
// Page transition wrapper
<motion.div
  key={currentPage}
  initial={{ opacity: 0, x: 20 }}
  animate={{ opacity: 1, x: 0 }}
  exit={{ opacity: 0, x: -20 }}
  transition={{ duration: 0.3, ease: 'easeInOut' }}
>
  {renderPage()}
</motion.div>
```

---

## 📊 Navigation Analytics

All page navigation is tracked via Google Analytics:
- Page views
- Navigation paths
- Time on page
- User flow analysis

---

## 🚀 Future Enhancements

1. **Keyboard Navigation**: Full keyboard accessibility
2. **Swipe Gestures**: Mobile swipe between pages
3. **History Management**: Browser back/forward support
4. **Deep Linking**: Direct links to specific content
5. **Breadcrumb Navigation**: Visual path indicator
6. **Quick Actions Menu**: Cmd+K style quick access

---

## 📝 Navigation Best Practices

1. **Always provide a way back**: Every page has home navigation
2. **Clear active states**: Users know where they are
3. **Consistent positioning**: Header always at top
4. **Mobile-first**: Touch-optimized interactions
5. **Fast transitions**: 0.3s maximum duration
6. **Loading feedback**: Never leave users wondering

---

## 🎉 Summary

The Rasoi Mate navigation system provides:
- ✅ Complete page interconnection
- ✅ Smooth Smart Animate transitions
- ✅ Mobile-responsive navigation
- ✅ Protected route handling
- ✅ Back buttons on secondary pages
- ✅ Consistent header navigation
- ✅ User-friendly flow patterns
- ✅ Accessibility considerations

All navigation is implemented, tested, and ready for production use!
