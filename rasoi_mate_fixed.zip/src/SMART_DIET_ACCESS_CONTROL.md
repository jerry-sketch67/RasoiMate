# Smart Diet Companion - Access Control & Editable Features

## Overview
The Smart Diet Companion now features comprehensive access control and editable user health profile management, ensuring personalized and secure diet planning experiences.

## 🔒 Access Control System

### Locked State (Not Logged In)
When users are not authenticated, they see:

#### UI Elements:
- **Lock Icon**: Large gradient lock icon (FF9933 → 4CAF50 → 3F51B5)
- **Title**: "Smart Diet Companion" with gradient text
- **Message**: "Sign in to unlock your personalized Rasoi diet plan"
- **Features Preview**: 3 cards showing what's available after login
  - Personalized Goals (Target icon, saffron)
  - Track Workouts (Activity icon, green)
  - Smart Meal Plans (Utensils icon, tech blue)

#### Call-to-Action Buttons:
1. **Login to Continue** - Gradient button (saffron → green)
   - LogIn icon
   - Navigates to login page
2. **Create Account** - Outlined button (tech blue)
   - UserPlus icon
   - Navigates to signup page

#### Design Features:
- Decorative background circles with brand colors
- Smooth fade-in animations (Motion)
- Centered card layout with shadow
- No fake data or placeholder content visible

### Unlocked State (Logged In)
Once authenticated, users gain full access to:
- Complete health profile management
- Personalized meal plans
- Workout tracking
- AI suggestions
- Analytics dashboard

## 👤 Health Profile Management

### Profile Data Structure
```typescript
interface HealthProfile {
  gender: 'male' | 'female' | 'other' | '';
  age: number;                    // years
  weight: number;                 // kg
  height: number;                 // cm
  goal: 'weight-loss' | 'weight-gain' | 'maintain' | '';
  activityLevel: 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active' | '';
  dietaryPreference: 'vegetarian' | 'vegan' | 'non-vegetarian' | 'eggetarian' | '';
}
```

### Profile States

#### 1. Incomplete Profile
**Visual Indicators:**
- Orange warning banner at top of page
- Message: "Complete Your Health Profile"
- Prominent "Complete Profile" button
- Profile card shows "Complete your profile to get started"

**Content Restrictions:**
- No meal plans shown
- No workout tracking
- No analytics
- Shows centered call-to-action card instead

#### 2. Complete Profile
**Requirements:**
- Age > 0
- Weight > 0
- Goal selected
- (Gender, height, activity level, dietary preference are optional but recommended)

**Full Access To:**
- All meal plans with macros
- Workout tracking
- AI suggestions
- Health analytics
- Daily timeline

### Edit Profile Dialog

#### Access Points:
1. Edit icon (✏️) on profile card
2. "Complete Profile" button (when incomplete)
3. Warning banner button

#### Dialog Features:
- **Modal Design**: Clean, scrollable dialog with max-height
- **Two-Column Layout**: Responsive grid (1 col mobile, 2 cols desktop)
- **Form Fields**:
  - Gender (Select dropdown)
  - Age (Number input, 1-120 years)
  - Weight (Number input, kg, decimal allowed)
  - Height (Number input, cm)
  - Goal (Select dropdown)
  - Activity Level (Select dropdown with descriptions)
  - Dietary Preference (Select dropdown, full width)

#### Validation:
- Weight must be > 0
- Age must be > 0
- Shows error toast if validation fails
- All fields are optional but recommended for accuracy

#### Save Behavior:
1. Updates user.healthProfile in AuthContext
2. Persists to localStorage
3. Shows success toast: "Health profile updated successfully! 🎯"
4. Auto-regenerates diet plan after 500ms
5. Shows second toast: "Diet plan updated based on your new profile! 🎯"
6. Recalculates calorie goals

## 🧠 Dynamic Data Behavior

### Calorie Goal Calculation
Automatically calculated based on profile:

```javascript
baseCalories = gender === 'male' ? 2000 : 1800

activityMultipliers = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  active: 1.725,
  very-active: 1.9
}

calculatedGoal = baseCalories * multiplier

if goal === 'weight-loss':
  calorieGoal = calculatedGoal - 500
else if goal === 'weight-gain':
  calorieGoal = calculatedGoal + 500
else:
  calorieGoal = calculatedGoal
```

### AI Suggestions Personalization
Suggestions adapt based on:
- User's selected goal (e.g., "weight-loss" → "lighter dinner")
- Activity level
- Completed workouts
- Profile completion status

### Meal Plan Customization
Each meal card shows:
- Customization tags based on user goal
- Message: "Customized for your [goal] goal and [activity status]"
- Macros adjusted for user's needs

## 🎨 Design Consistency

### Color Scheme
Maintains Rasoi Mate brand colors:
- **Saffron (#FF9933)**: Primary actions, energy indicators
- **Green (#4CAF50)**: Success states, health metrics
- **Tech Blue (#3F51B5)**: Information, analytics

### Animations
- **Lock State Entry**: Scale animation (0.9 → 1)
- **Feature Cards**: Staggered fade-in (delay increments)
- **Profile Update**: Smooth transitions
- **State Changes**: 300ms opacity transitions
- **Button Interactions**: whileHover and whileTap

### Typography
- Gradient text for titles
- Consistent spacing and hierarchy
- Rounded corners (rounded-3xl, rounded-2xl, rounded-xl)
- Soft shadows (shadow-lg, shadow-xl, shadow-2xl)

## 🔄 Interaction Flow

### First-Time User
1. Navigate to Smart Diet Companion
2. See locked state with preview
3. Click "Login" or "Create Account"
4. Complete authentication
5. Return to Smart Diet Companion (automatically)
6. See profile incomplete warning
7. Click "Complete Profile"
8. Fill in health details
9. Save profile
10. View personalized meal plans

### Returning User (Profile Complete)
1. Navigate to Smart Diet Companion
2. Instantly see personalized dashboard
3. View current meal plans
4. Track workouts
5. Check analytics
6. Edit profile anytime via ✏️ icon

### Updating Profile
1. Click edit icon
2. Modify any field
3. Click "Save Changes"
4. See success confirmation
5. Watch diet plan auto-regenerate
6. View updated recommendations

## 🛡️ Security & Privacy

### Data Storage
- Health profile stored in AuthContext
- Synced to localStorage
- Persists across sessions
- Updated in real-time

### Access Control
- Profile data only accessible when logged in
- No data shown before authentication
- Automatic logout clears sensitive data

### Data Validation
- Client-side validation before save
- Type-safe interfaces
- Error handling with user feedback

## 📱 Responsive Behavior

### Mobile (< 768px)
- Single column layout
- Full-width cards
- Stacked buttons
- Scrollable dialog

### Tablet (768px - 1024px)
- Two-column grid where appropriate
- Compact spacing
- Readable form fields

### Desktop (> 1024px)
- Three-column layout (2-col main + 1-col sidebar)
- Side-by-side form fields in dialog
- Optimal spacing

## 🚀 Performance Optimizations

### Conditional Rendering
- Meal plans only rendered when profile complete
- Heavy components lazy-loaded
- Images use ImageWithFallback

### State Management
- Efficient useEffect dependencies
- Minimal re-renders
- Local state for UI interactions

### Animations
- GPU-accelerated transforms
- Optimized Motion components
- Smooth 60fps transitions

## 🎯 Future Enhancements

### Planned Features
1. **Photo Upload**: Profile picture upload
2. **BMI Calculator**: Automatic BMI calculation and display
3. **Progress Tracking**: Weight history chart
4. **Goal Timeline**: Visual progress toward health goals
5. **Meal Logging**: Mark meals as completed
6. **Barcode Scanner**: Scan food items
7. **Fitness App Sync**: Google Fit, Apple Health integration
8. **Nutritionist Chat**: AI-powered dietary advice

### Technical Improvements
1. Backend integration for data persistence
2. Real-time sync across devices
3. Advanced analytics dashboard
4. Machine learning for meal recommendations
5. Social sharing features

## 📊 Metrics & Analytics

### Tracked Data
- Profile completion rate
- Edit frequency
- Login → profile complete time
- Feature usage patterns

### Success Indicators
- % users who complete profile
- Time to first meal plan view
- Return user engagement
- Profile update frequency

## 🐛 Known Limitations

### Current Constraints
- No image upload yet
- Manual workout entry only
- Basic calorie calculation
- No historical data tracking
- Limited dietary restriction support

### Workarounds
- Use avatar initials as placeholder
- Provide manual workout options
- Clear activity tracking
- Weekly stats instead of historical

## 💡 Usage Tips

### For Users
1. **Complete Your Profile**: More data = better recommendations
2. **Update Regularly**: Keep weight and activity level current
3. **Log Workouts**: Track all activities for accurate calorie burn
4. **Follow Meal Plans**: AI-generated plans are personalized
5. **Check Analytics**: Monitor your Rasoi Score daily

### For Developers
1. Profile data syncs automatically via AuthContext
2. Use updateHealthProfile() for updates
3. Check isProfileComplete before showing content
4. Handle empty/null values gracefully
5. Test both locked and unlocked states

## 🔧 Troubleshooting

### Common Issues

**Profile not saving:**
- Check localStorage permissions
- Verify AuthContext is mounted
- Check browser console for errors

**Meal plans not showing:**
- Confirm user is logged in
- Verify profile is complete (age > 0, weight > 0, goal set)
- Check isProfileComplete flag

**Calorie calculation incorrect:**
- Verify all profile fields are filled
- Check gender, weight, activity level
- Review calculation logic in useEffect

**Dialog not opening:**
- Check Dialog component imports
- Verify editProfileOpen state
- Check for z-index conflicts

## 📝 Code Examples

### Checking Authentication
```tsx
if (!isLoggedIn) {
  // Show locked state
  return <LockedState />;
}
```

### Checking Profile Completion
```tsx
const isProfileComplete = user?.healthProfile && 
  user.healthProfile.age > 0 && 
  user.healthProfile.weight > 0 && 
  user.healthProfile.goal !== '';
```

### Updating Profile
```tsx
const handleSaveProfile = () => {
  updateHealthProfile(editForm);
  setEditProfileOpen(false);
};
```

### Navigating to Auth
```tsx
<Button onClick={() => onNavigate?.('login')}>
  Login to Continue
</Button>
```

## 📚 Related Documentation
- [Smart Diet Companion Features](./SMART_DIET_COMPANION.md)
- [Auth Context Guide](./AUTH_CONTEXT_GUIDE.md)
- [User Profile Management](./USER_PROFILE_GUIDE.md)
- [Component API Reference](./COMPONENT_API.md)

---

**Last Updated**: November 2, 2025
**Version**: 2.0
**Status**: Production Ready ✅
