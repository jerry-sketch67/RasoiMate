# 🍳 Rasoi Mate - AI-Powered Smart Kitchen Assistant

**Your Personal AI Chef for Indian Cooking** 🇮🇳

Rasoi Mate is a comprehensive web application that brings AI-powered cooking assistance to Indian kitchens. Cook, learn, and explore 20+ authentic Indian recipes with voice commands and multilingual support.

![Rasoi Mate](https://images.unsplash.com/photo-1556910103-1c02745aae4d?w=1200)

---

## ✨ Key Features

### 🤖 **AI Assistant**
- **Real AI Integration** with OpenAI, Google Gemini, and Anthropic Claude
- **Mock AI Mode** for demo and testing (no API key needed)
- **🌶️ NEW: Comprehensive Ingredient Alternatives** - 100+ ingredients with detailed substitutes, ratios & descriptions
- **Voice Commands** with speech recognition and synthesis
- **Multilingual Support**: English, Hindi, Tamil, Bengali, Marathi
- **Context-Aware Conversations** - AI remembers your chat history
- **Professional Cooking Guidance** - Recipes, substitutions, tips, troubleshooting

### 📚 **Recipe Library**
- **1000+ Authentic 5-Star Restaurant Recipes** from top Indian restaurants
- **20+ Featured Recipes** with detailed instructions
- **Auto-Translation** to any Indian language
- **Voice Narration** in selected language
- **Dynamic Serving Adjustment** - Scale recipes for any number of people
- **Filter by**: Region, Diet, Difficulty, Cuisine, Calories
- **Ingredient Alternatives** for every recipe
- **Step-by-Step Instructions** with pro tips
- **Nutritional Information** - Calories, protein, carbs, fats, fiber

### 🍽️ **Smart Diet Companion** (NEW!)
- **Personalized Meal Plans** based on your health profile
- **1000+ 5-Star Restaurant Recipes** including dishes from:
  - Bukhara (ITC Maurya), Moti Mahal, Karim's
  - Saravana Bhavan, MTR, Paradise Biryani
  - Thalassery, Mainland China, and 50+ more
- **BMR & Calorie Calculation** using scientific formulas
- **Dietary Preference Support** - Veg, Non-Veg, Vegan, Eggetarian
- **Goal-Based Planning** - Weight Loss, Weight Gain, Maintenance
- **Activity Level Tracking** - Sedentary to Very Active
- **Nutritional Breakdown** - Complete macro tracking
- **Smart Recipe Selection** - Matches calories and preferences
- **8 Indian Cuisines** - North, South, East, West, Mughlai, Coastal, Indo-Chinese, Fusion
- **Access Control** - Sign in required for personalized plans

### 👨‍💻 **Developer Dashboard**
- **Recipe Management** - Add, edit, delete custom recipes
- **User Analytics** - View all registered users and their activity
- **Feedback Management** - See all user feedback submissions
- **Real-Time Statistics** - Track app usage and engagement
- **Special Access** for authorized Gmail IDs

### 🎯 **Other Features**
- **Local to Vocal** - Promote rural Indian recipes and cooking traditions
- **Email Feedback System** - Direct email to developers
- **Separate Login/Signup** with authentication
- **Dark/Light Mode** support
- **Responsive Design** - Works on mobile, tablet, desktop
- **Beautiful UI** with Indian culinary colors (Saffron, Green, Tech Blue)

---

## 🚀 Quick Start

### 1. **Browse Recipes**
- Explore 20+ Indian recipes
- Filter by region, diet, or difficulty
- View detailed ingredients and instructions

### 2. **Use AI Assistant**
- **Demo Mode**: Just start chatting (no setup needed)
- **Real AI Mode**: 
  1. Enable "Real AI" checkbox
  2. Select provider (Gemini is FREE!)
  3. Add your API key
  4. Start cooking with AI!

### 3. **Voice Cooking**
- Select your language
- Click microphone to speak
- AI responds in your language
- Use "Speak Recipe" to hear instructions

---

## 🔑 AI Integration

Rasoi Mate supports **3 AI providers**:

### 🆓 **Google Gemini** (Recommended)
- **Cost**: FREE!
- **Quality**: ⭐⭐⭐⭐⭐
- **Get Key**: https://makersuite.google.com/app/apikey
- **Why**: Best for beginners, no cost

### 🤖 **OpenAI GPT-3.5/GPT-4**
- **Cost**: ~$0.002 per request (very cheap)
- **Quality**: ⭐⭐⭐⭐⭐
- **Get Key**: https://platform.openai.com/api-keys
- **Why**: Industry-leading AI, excellent responses

### 🧠 **Anthropic Claude**
- **Cost**: ~$0.003 per request
- **Quality**: ⭐⭐⭐⭐⭐
- **Get Key**: https://console.anthropic.com/settings/keys
- **Why**: Best for detailed instructions

📖 **Full Guide**: See [AI_INTEGRATION_GUIDE.md](./AI_INTEGRATION_GUIDE.md)

---

## 🎨 Design System

### Color Palette
- **Saffron**: `#FF9933` - Indian heritage
- **Green**: `#4CAF50` - Fresh ingredients
- **Tech Blue**: `#3F51B5` - Modern technology

### Typography
- **Font**: Poppins (Google Fonts)
- **Responsive**: Adapts to screen size

### Components
- **Rounded Cards** with smooth shadows
- **Gradient Backgrounds** for key sections
- **Smooth Animations** with Motion/Framer Motion
- **Shadcn/UI** component library

---

## 📱 Pages & Navigation

### Public Pages
1. **Home** - Interactive video demo, feature showcase
2. **AI Assistant** - Chat with AI chef, voice commands
3. **Recipes** - Browse and filter 20+ recipes
4. **Local to Vocal** - Rural recipe promotion
5. **About** - Team information and mission
6. **Contact** - Feedback form with email integration

### Authenticated Pages
7. **Login** - User authentication
8. **Signup** - New user registration
9. **Dashboard** - User profile and saved recipes
10. **Developer Dashboard** - Admin panel (authorized emails only)

---

## 👨‍💻 Developer Access

**Special access for**:
- sohamsingale775@gmail.com
- jerry415721@gmail.com

**Admin Features**:
- Add/Edit/Delete recipes
- View all registered users
- See user feedback submissions
- Export user data
- Real-time analytics

---

## 🌍 Multilingual Support

**Supported Languages**:
- 🇬🇧 English (India)
- 🇮🇳 हिन्दी (Hindi)
- 🇮🇳 தமிழ் (Tamil)
- 🇮🇳 বাংলা (Bengali)
- 🇮🇳 मराठी (Marathi)
- 🇮🇳 తెలుగు (Telugu)
- 🇮🇳 ગુજરાતી (Gujarati)

**Features**:
- UI translation with Google Translate widget
- Recipe content translation
- Voice synthesis in selected language
- Speech recognition in Indian languages

---

## 🌶️ Ingredient Alternatives Database

**NEW Feature: Comprehensive Substitutes for 100+ Ingredients**

The AI Assistant now includes an extensive database of ingredient alternatives to help you cook even when you're missing specific items.

### Coverage
- **100+ Ingredients** across 12 categories
- **Detailed Ratios** for accurate substitutions (e.g., "1:1", "2:1", "¾ cup for 1 cup")
- **Usage Descriptions** explaining when and how to use each substitute
- **Dietary Options** including vegan, gluten-free, dairy-free alternatives

### Categories Covered
1. **Flours & Starches**: Cornflour, All-Purpose Flour, Whole Wheat, Rice Flour, Besan
2. **Dairy**: Heavy Cream, Milk, Yogurt, Butter, Paneer, Ghee
3. **Spices**: Cumin, Coriander, Turmeric, Garam Masala, Cardamom, Saffron, etc.
4. **Oils & Fats**: Vegetable Oil, Olive Oil, Coconut Oil, Sesame Oil
5. **Sweeteners**: Sugar, Honey, Jaggery
6. **Acids**: Lemon Juice, Vinegar, Tamarind, Amchur
7. **Proteins**: Chicken, Eggs, Lentils
8. **Vegetables**: Onion, Garlic, Ginger, Tomato, Green Chili, Cilantro
9. **Nuts & Seeds**: Cashews, Almonds, Peanuts, Sesame Seeds
10. **Thickening Agents**: Agar Agar, Xanthan Gum
11. **Raising Agents**: Baking Powder, Baking Soda, Yeast
12. **Miscellaneous**: Coconut Milk, Chocolate, Soy Sauce, etc.

### How to Use
Simply ask the AI Assistant:
- "Alternative for cornflour"
- "Substitute for heavy cream"
- "Replace turmeric with what"
- "What to use instead of paneer"
- "Don't have butter, what else?"
- "List ingredient categories"

The AI will instantly provide detailed alternatives with conversion ratios and descriptions!

📚 **See Full Documentation**: [INGREDIENT_ALTERNATIVES_GUIDE.md](INGREDIENT_ALTERNATIVES_GUIDE.md)

---

## 🔒 Privacy & Security

- ✅ **Local Storage Only** - No server-side data storage
- ✅ **Secure API Keys** - Stored locally in browser
- ✅ **No Third-Party Tracking** - Your data stays private
- ✅ **Direct API Calls** - Communication only with AI providers
- ✅ **Email Privacy** - Contact forms use default email client

---

## 📦 Technology Stack

### Frontend
- **React** 18+ with TypeScript
- **Tailwind CSS** v4.0 for styling
- **Motion/Framer Motion** for animations
- **Shadcn/UI** component library
- **Lucide React** for icons

### AI Integration
- **OpenAI API** (GPT-3.5/GPT-4)
- **Google Gemini API** (Gemini Pro)
- **Anthropic API** (Claude 3 Haiku)

### Storage
- **LocalStorage** for user data
- **Session Storage** for temporary state

### APIs
- **Web Speech API** for voice input/output
- **Google Translate API** for translations
- **Unsplash API** for recipe images

---

## 🎯 Use Cases

### For Home Cooks
- Get instant recipe instructions
- Scale recipes for family gatherings
- Learn traditional cooking techniques
- Find ingredient substitutions

### For Beginners
- Step-by-step guidance
- Voice-guided cooking
- Troubleshoot cooking mistakes
- Learn Indian cuisine basics

### For Meal Planning
- Browse recipes by region/diet
- Save favorite recipes
- Adjust servings easily
- Get cooking time estimates

### For Dietary Needs
- Vegan recipe modifications
- Gluten-free alternatives
- Low-calorie options
- Allergen substitutions

---

## 🔧 Setup Instructions

### No Installation Needed!
This is a **web-based application** - just open and use!

### For Development
```bash
# Clone the repository (if applicable)
git clone [repository-url]

# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

---

## 🤝 Contributing

We welcome contributions! Here's how:

1. **Report Bugs** - Use the Contact/Feedback form
2. **Suggest Features** - Submit via feedback form
3. **Submit Recipes** - Email to jerry415721@gmail.com
4. **Improve Code** - Submit pull requests (if open source)

---

## 📧 Contact & Support

### Email
- **General**: sohamsingale775@gmail.com
- **Recipes**: jerry415721@gmail.com

### Feedback Categories
- 🐛 Bug Reports
- 💡 Feature Requests
- 📚 Recipe Submissions
- 🤝 Partnership Opportunities
- 💬 General Feedback

---

## 🎉 Credits

### Developers
- **Soham Singale** - Lead Developer
- **Jerry** - Recipe Curator & Developer

### Special Thanks
- Unsplash for recipe images
- OpenAI, Google, Anthropic for AI APIs
- Shadcn for UI components
- Lucide for beautiful icons

---

## 📝 License

This project is for educational and personal use.

**Note**: API keys and services may have their own terms of service. Please review:
- [OpenAI Terms](https://openai.com/policies/terms-of-use)
- [Google API Terms](https://developers.google.com/terms)
- [Anthropic Terms](https://www.anthropic.com/legal/commercial-terms)

---

## 🌟 Features Roadmap

### Coming Soon
- [ ] Video cooking tutorials
- [ ] Social recipe sharing
- [ ] Meal planning calendar
- [ ] Nutrition information
- [ ] Shopping list generator
- [ ] Cooking timer integration
- [ ] Photo upload for recipe help
- [ ] Community recipe ratings

---

## 📊 Statistics

- **20+ Recipes** spanning all Indian regions
- **7+ Languages** supported
- **3 AI Providers** integrated
- **10+ Recipe Categories** (Veg, Non-Veg, Vegan, etc.)
- **100%** Free to use (except AI API costs)

---

## 🏆 Why Rasoi Mate?

### 🎯 **Accessibility**
Making AI cooking assistance accessible to all Indians, in their native language

### 🇮🇳 **Cultural**
Preserving and promoting Indian culinary traditions with modern technology

### 💡 **Innovation**
Combining AI, voice tech, and multilingual support for the kitchen

### 🆓 **Free**
Core features completely free, optional paid AI for enhanced experience

---

## 🚀 Get Started Now!

1. Open Rasoi Mate
2. Browse recipes or chat with AI
3. Select your language
4. Start cooking delicious Indian food! 🍛

---

**Made with ❤️ and 🌶️ in India**

*Bringing AI to Indian Kitchens, One Recipe at a Time*

---

**Version**: 2.0  
**Last Updated**: October 13, 2025  
**Status**: ✅ Fully Functional
